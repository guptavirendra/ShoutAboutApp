# M.AppSecAgentSkills

## Repository Role (Canonical)

M.AppSecAgentSkills is the canonical working source for Molina-focused secure development instructions in this workspace.

- Primary source for active updates to SSDF, 218A, and Molina skill packages under `.agents/skills/`.
- Downstream consumers should reference this repository first for day-to-day usage.
- Upstream expansions from broader framework repositories should be reviewed and pulled in intentionally.
- Legacy flat-structure variants should remain read-only to prevent duplicate edits and drift.

This template provides a structured starting point for software projects that need to align with:
- NIST SSDF (SP 800-218) Secure Software Development Framework
- NIST 218A Secure Software Development Practices for Generative AI and Dual-Use Foundation Models
- Molina AppSec Program Checklist
- OWASP Gen AI Security: Top 10 for LLM Applications 2025, Top 10 for Agentic Applications 2026 (ASI), and the Practical Guide for Secure MCP Server Development v1.0 (Feb 2026)

## Prerequisites

Before copying any skill packages from `.agents/skills/` into a downstream project, verify that you are logged into Azure CLI using your developer account:

```sh
az login
```

Confirm the correct account is active with `az account show` before proceeding. All skills in this repository are gated on this requirement regardless of which frameworks they target.

## VS Code Customization Workflow for Molina AppSec Gates

The Molina AppSec program operationalizes three sequential security gates (PRE, P2D, P2B) through VS Code customization features. Each gate is powered by a combination of always-on governance rules, specialized agents, executable skills, and external tool integrations:

| Gate Phase | Workflow Stage | Customization Type | Purpose |
|---|---|---|---|
| **PRE** | Intake & Stakeholder Validation | Always-on instructions | Enforce mandatory prerequisites |
| | Artifact Collection | Prompt files | Trigger PRE review checklist |
| **P2D** | Architecture Review | Agent skills + custom agents | Execute design validation |
| | Evidence Gathering | MCP tool integrations | Query design repositories |
| **P2B** | Test Execution Validation | Agent skills + hooks | Verify security test completion |
| | Findings Triage & Closure | Custom agents + MCP | Track remediation status |
| | Gate Decision & Approval | Planner agent + approval forms | Render PASS/CONDITIONAL/FAIL |

## Direct Skill Import

This section guides both human users and coding agents on importing skills directly from this repository into a downstream project's `.agents/skills/` directory.

### Prerequisites and Mandatory Checks

1. **Azure CLI login (non-negotiable gate):** Run `az login` with your developer account and confirm the correct account is active:
   ```sh
   az account show
   ```
   Do not proceed without this confirmation.

2. **Trust boundary check:** If importing project-level skills from an untrusted or recently cloned repository, review the skill source first. Project-level skills travel with code and can inject instructions into the development context — only import from sources you trust.

3. **Workspace readiness:** Confirm that the target project's `.agents/skills/` directory exists or can be safely created.

### Import Paths and Modes

**Source:** This repository's `.agents/skills/` directory contains the canonical skill packages.

**Target:** Downstream project's `.agents/skills/` directory (cross-client interoperability standard per [Agent Skills specification](https://agentskills.io/client-implementation/adding-skills-support)).

**Import modes:**

- **Full import:** Copy all skill folders from `.agents/skills/` to the downstream project's `.agents/skills/`.
  - Use when adopting the complete Molina AppSec governance stack.
  - Preserves all skill folder structure and supporting assets (references/, assets/).

- **Selective import:** Copy only specific skill folders (e.g., `molina-application-security/`, `nist-ssdf/`) to the downstream project's `.agents/skills/`.
  - Use when adopting specific frameworks or phases.
  - Always include dependencies: if importing `anti-mythos-agentic-security`, also import `molina-application-security`, `molina-nist-218a`, and `nist-ssdf`.

### For Human Users

**Import steps:**

1. Verify Azure CLI login in your terminal:
   ```sh
   az account show
   ```

2. Navigate to the downstream project directory.

3. Ensure the `.agents/skills/` directory exists; create it if needed:
   ```sh
   mkdir -p .agents/skills
   ```

4. Copy the desired skill folders from this repository to your downstream project's `.agents/skills/`. Examples:
   ```sh
   # Full import: copy all skills
   cp -r <source-repo>/.agents/skills/* ./.agents/skills/
   
   # Selective import: copy only specific skills and their dependencies
   cp -r <source-repo>/.agents/skills/nist-ssdf ./.agents/skills/
   cp -r <source-repo>/.agents/skills/molina-application-security ./.agents/skills/
   ```

5. Post-import validation:
   - Verify each imported skill folder contains a `SKILL.md` file.
   - Verify YAML frontmatter in each `SKILL.md` is valid (contains `name:`, `description:`, `license:` fields).
   - Confirm all referenced relative paths in skill documentation (e.g., `references/`, `assets/`) exist in the imported folders.
   - (Optional) Document the source repository and import timestamp for audit traceability.

### For Coding Agents

**Mandatory preconditions before any automated import:**

Stop and notify the operator of the following before proceeding:

- [ ] **Stop and announce:** Inform the operator of the exact scope (which skills, from which source repository, to which downstream project). Do not assume approval.
- [ ] **Confirm Azure login:** Check that `az login` and `az account show` have been successfully executed in the current operator session. If not confirmed, stop and require the operator to complete these commands directly in the terminal.
- [ ] **Validate source repository:** Confirm the source repository path exists and contains `.agents/skills/` with expected skill directories (each containing `SKILL.md`).
- [ ] **Validate target workspace:** Confirm the downstream project's `.agents/skills/` directory exists or can be safely created without errors.
- [ ] **Deterministic collision handling:** If a skill with the same `name` already exists in the target `.agents/skills/`:
  - Project-level skills (in the downstream project) override imported skills (principle: project imports override canonical source).
  - Log a warning that the skill is being shadowed.
  - Do not overwrite without explicit operator approval.
- [ ] **Post-import validation:** After import, verify that each skill folder contains `SKILL.md` and that YAML frontmatter parses correctly. If any validation fails, report all errors and stop (fail-closed behavior).

**Example coding-agent workflow:**

```
1. Agent: "I will import [skill names] from [source repo path] into .agents/skills/. Please confirm the scope and source."
2. [Wait for operator confirmation — do not proceed on silence.]
3. Agent: "Checking: Is az account show active and valid?"
   If invalid: Stop and ask operator to run az login and az account show in terminal.
4. Agent: "Validating source repo and target directory."
5. For each skill to import:
   a. Check if skill name already exists in target .agents/skills/.
   b. If collision: Log warning, skip, and wait for operator guidance.
   c. If no collision: Copy skill folder.
6. Agent: "Validating all imported SKILL.md files for YAML syntax and required fields."
   If errors: Report and stop (fail-closed).
7. Agent: "Import complete: [count] skills imported, [count] skipped/shadowed, [count] validation errors."
8. Agent: "Recommend: Run your development environment's native skill-discovery scan to confirm skills are visible."
```

## Offer to Copy Skills to User Profile

Agents may offer to copy skills from this repository into the user profile path `c:\Users\<user>\.agents\skills\` for cross-workspace reuse.

### When to offer

1. At intake/planning start when a workflow needs Molina or framework skills.
2. When a user asks for framework-specific guidance and the skill is not available in profile.
3. When a session references skills that are present in this repo but missing from profile.

### Required offer flow

1. Announce offered skills and copy scope (full, minimal, or selective).
2. Show source and destination paths.
3. Require explicit response: `yes, all`, `yes, minimal`, `yes, selective: <skill names>`, or `no`.
4. Validate source and destination before copy.
5. Create timestamped backups for collided destination skills before overwrite at `c:\Users\<user>\.agents\skill-backups\skills-copy-<yyyyMMdd-HHmmss>\`.
6. Handle collisions per skill with explicit overwrite approval.
7. Validate copied `SKILL.md` files and YAML frontmatter.
8. Report outcome summary: copied, skipped, overwritten, failed, and backup path.
9. If overwrite copy or post-copy validation fails, provide rollback instructions using the recorded backup path.

### Speckit-autopilot scoped exception

When this offer flow is triggered from `speckit-autopilot` orchestration:

1. Do not pause phase execution waiting for offer responses.
2. Do not execute copy or overwrite without explicit approval.
3. Continue autonomous execution and record the approval-needed action as deferred in HOTL (`Approval-Required Actions`).

This exception applies only to `speckit-autopilot` autonomous runs. Standard explicit-approval and fail-closed behavior remains mandatory for direct/manual copy workflows.

### Profile copy versus downstream project import

| Aspect | User profile copy | Downstream project import |
|---|---|---|
| Target | `c:\Users\<user>\.agents\skills\` | `<project>/.agents/skills/` |
| Backup policy | Timestamped backup before overwrite (`.agents/skill-backups/`) | Optional, project-defined |
| Azure CLI prerequisite | Not required | Required (`az login`, `az account show`) |
| Collision policy | User-approved per-skill overwrite | Project-level skills override imported skills |
| Primary use | Personal cross-workspace reuse | Team/project governance onboarding |

For guardrails and fail-closed behavior, follow [AGENTS.md](AGENTS.md).

### External Implementation Reference

For teams integrating Agent Skills support into a coding agent or development tool, the [Agent Skills client-implementation guide](https://agentskills.io/client-implementation/adding-skills-support) provides detailed technical patterns for discovery, parsing, activation, and context management. The five-step lifecycle aligns with how this repository's skills are designed:

1. **Discover:** Scan `.agents/skills/` directories for skill folders containing `SKILL.md`.
2. **Parse:** Extract YAML frontmatter (`name`, `description`) and markdown body from each `SKILL.md`.
3. **Disclose:** Present available skills (catalog) to the model without loading full content.
4. **Activate:** Load full `SKILL.md` instructions when the model or user selects a skill.
5. **Manage:** Protect skill instructions from context pruning; deduplicate repeated activations; optionally resolve relative paths to bundled resources.

This repository's documentation focuses on governance, compliance, and organizational policy; the external guide covers technical implementation patterns. Both are complementary.

## Structure

All framework documentation lives under `.agents/skills/`:

| Skill | Path | Contents |
|---|---|---|
| molina-appsec-code-review | [.agents/skills/molina-appsec-code-review/](.agents/skills/molina-appsec-code-review/SKILL.md) | Router/composer only; defaults to CWE-699 + AppSec best practices in one master `CODE_REVIEW.md`; single profiles or all three require explicit selection |
| cwe-699-code-review (bundled child) | [.agents/skills/molina-appsec-code-review/code-reviews/cwe-699-code-review/](.agents/skills/molina-appsec-code-review/code-reviews/cwe-699-code-review/SKILL.md) | 33 CWE routing categories, specific weakness mappings, finding index, category coverage/results, severity/blocker counts and remediation priorities within the parent's master report |
| appsec-best-practices (bundled child) | [.agents/skills/molina-appsec-code-review/code-reviews/appsec-best-practices/](.agents/skills/molina-appsec-code-review/code-reviews/appsec-best-practices/SKILL.md) | Legacy cross-framework review: SSDF, secure-by-design, Molina gate alignment and conditional OAuth/AI/agentic/MCP/218A checks; part of the default pair, or explicitly selectable alone |
| react-nextjs-best-practices (bundled child) | [.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/](.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/SKILL.md) | React/Vite/SSR and conditional Next.js App/Pages Router checks, ASVS mappings, DOM/messaging/navigation/rich-content source-to-sink guidance, checklist, 16 scenarios, and validator; inherits the parent's report and AppSec banner |
| nist-ssdf | `.agents/skills/nist-ssdf/` | SSDF checklist, README, PDFs, references/ |
| molina-nist-218a | `.agents/skills/molina-nist-218a/` | AI-focused: 218A checklist, README, PDFs, references/ with Molina tool integration |
| molina-application-security | `.agents/skills/molina-application-security/` | AppSec program checklist, architecture requirements, CSV, remediation tracker template, approval form template |
| anti-mythos-agentic-security | `.agents/skills/anti-mythos-agentic-security/` | Agentic AppSec blueprint for GitHub + Azure DevOps: harness DAG, evaluation spec, tool contract patterns, observability contract, platform adapters, OWASP ASI crosswalk, threat modeling extension, evidence pack templates, findings schema, platform adoption matrix, implementation roadmap, governance runbook |
| owasp-genai-security | `.agents/skills/owasp-genai-security/` | OWASP LLM Top 10 (2025) reference, Agentic Top 10 (ASI01–ASI10) checklist, MCP Server Security checklist + Minimum Bar, skill manifest with routing tables |

### Focused secure code review

Use [molina-appsec-code-review](.agents/skills/molina-appsec-code-review/SKILL.md)
for a standalone review of files, features, working changes, or commit ranges.
It preserves the AppSec banner and report format from the
`M.AppSecSpeckit` `m-appsec-codereview` skill without requiring its submodule
layout. Source files remain read-only; the sole write exception is the
project-root `CODE_REVIEW.md`, with explicit approval before replacing an
existing report.

Example: "Use molina-appsec-code-review to review the current working changes
and write CODE_REVIEW.md. Do not apply fixes."

The parent contains routing/composition only. Common scope, safety, evidence,
severity, Status and report-write rules live in the
[shared review contract](.agents/skills/molina-appsec-code-review/references/review-contract.md),
loaded by every selected child. Technical checklists live only in the children.

**Review selection uses a default pair, not technology-triggered expansion:**

| Request | Review types executed |
|---|---|
| "Secure code review of this codebase" or "review this React app" | CWE-699 + AppSec best practices (default pair), one merged report |
| "Run CWE-699 only" | CWE-699 alone |
| "Run the React/Next.js code review" | React/Next.js only; no CWE-699 pass |
| "Run appsec-best-practices" | AppSec best practices only, with its applicable supporting guidance |
| "Run CWE-699 and React/Next.js reviews" | Both explicitly named profiles |
| "Run all code review types together" | All three: CWE-699, React/Next.js, and AppSec best practices |

"All files" or "thorough review" changes scope/depth, not the selected types.
Specialist guidance is routed inside the selected AppSec child, not executed
directly by the parent. "All" does not load every installed governance skill.
Ambiguous/conflicting selections are clarified,
not silently expanded. Mandatory project policy can block and escalate a review,
but does not authorize unrequested review passes.
"Both code reviews" needs a named pair because there are three profiles.
"Both default reviews" selects the default pair; "a single review" needs a
named type. A selected child invoked directly runs alone, without its siblings.

The
[AppSec best practices profile](.agents/skills/molina-appsec-code-review/code-reviews/appsec-best-practices/SKILL.md)
restores the original `m-appsec-codereview` cross-framework checks. Selecting
it (by default or explicit request) authorizes SSDF, Molina alignment, and secure-by-design baseline guidance,
plus OAuth, AI/LLM/agentic/MCP or 218A guidance when applicable. These are
supporting checks inside the selected profile, not extra CWE/React passes.
The default is CWE-699 plus AppSec best practices, with shared weaknesses
deduplicated and each child's unique evidence preserved. Supporting skill folders must be available
in the installed catalog; missing required guidance is disclosed and blocks
the affected assessment rather than being silently skipped.

Gate alignment and a formal gate decision are distinct: the latter needs an
explicit request and required evidence. Missing mandatory evidence means FAIL;
no report grants human approval or authorizes promotion. All evidence remains
in the parent's single report, with no copied template or additional artifacts.

The bundled
[React/Next.js child](.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/SKILL.md)
is loaded directly by the parent only when that profile is selected;
independent discovery of nested skills is not required. Keep the entire parent
folder together when distributing it. The child explicitly reads the
[parent report template](.agents/skills/molina-appsec-code-review/assets/code-review-template.md):
React-only, Next.js, mixed-scope, and unconfirmed-framework reviews all use the
same AppSec banner, report sections, finding format, and single `CODE_REVIEW.md`.
Framework metadata, owner layers, validation evidence, and residual risk enrich
that report rather than creating a separate framework report.
Per-finding lifecycle status is retained as `OPEN` / `REMEDIATE` / `CLOSED`,
separate from check results; closure requires verified remediation evidence.
The [migration history](.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/references/migration-history.md)
preserves original milestones, the source commit chain, intentional changes,
and recovery using the `archive/react-nextjs-best-practices` tag.

Other specialized sibling skills are loaded only when explicitly requested
or as applicable supporting guidance inside selected AppSec best practices,
and only when available.
Standalone review does not require RITM or external AppSec services; mandatory
project gate rules still apply and missing required evidence remains fail-closed.
As part of the default pair or an explicitly requested CWE review, the parent directly loads its
[CWE-699 child](.agents/skills/molina-appsec-code-review/code-reviews/cwe-699-code-review/SKILL.md).
It uses the same master template and `CODE_REVIEW.md`, with CWE-specific
source/version, category coverage, finding index, explicit category results,
severity/blocker counts, and remediation priorities retained within the
parent sections. Findings shared with React/Next.js or multiple categories
are counted once. There is no separate CWE report or top-level CWE skill
folder; distribute the whole parent package.

Use
[molina-application-security](.agents/skills/molina-application-security/SKILL.md)
for the full PRE/P2D/P2B workflow. Downstream imports remain subject to the
prerequisites above.

Authoring validation and initial tabletop results are recorded in the skill's
[evaluation summary](.agents/skills/molina-appsec-code-review/evals/benchmark.json).
Structural conformance, tabletop responses, and actual editor activation are
separate checks; the summary explicitly lists unverified integration behavior
and excluded baseline runs. Those initial results apply to parent version 1.0,
not the later framework port. It is not an external certification.

### owasp-genai-security skill files

The `owasp-genai-security` skill consolidates three authoritative OWASP Gen AI Security Project artifacts into a single defense-in-depth stack: **LLM Top 10 (model)** → **ASI Top 10 (agent autonomy & orchestration)** → **MCP Guide (tool / server runtime)**.

| File | Purpose |
|------|---------|
| [.agents/skills/owasp-genai-security/SKILL.md](.agents/skills/owasp-genai-security/SKILL.md) | Skill manifest, routing tables, output template, cross-framework integration |
| [.agents/skills/owasp-genai-security/Agentic-Top10-Checklist.md](.agents/skills/owasp-genai-security/Agentic-Top10-Checklist.md) | ASI01–ASI10 entries with required mitigations and T-code / AIVSS mappings |
| [.agents/skills/owasp-genai-security/MCP-Server-Security-Checklist.md](.agents/skills/owasp-genai-security/MCP-Server-Security-Checklist.md) | 8 MCP control areas + the MCP Security Minimum Bar review checklist |
| [.agents/skills/owasp-genai-security/LLM-Top10-Reference.md](.agents/skills/owasp-genai-security/LLM-Top10-Reference.md) | LLM01:2025 – LLM10:2025 reference index with cross-pointers to ASI / MCP |
| [.agents/skills/owasp-genai-security/README.md](.agents/skills/owasp-genai-security/README.md) | Skill overview, when-to-use guidance, and integration with other skills |

Activate this skill for LLM applications (prompts, RAG, output handling), AI agents (single, planner+executor, or multi-agent), MCP servers/clients/hosts, A2A protocols, tool governance, AI supply chain (AIBOM), prompt injection, tool poisoning, agent goal hijack, rogue agents, and AI identity / NHI controls.

## Anti-Mythos Blueprint Status

| Phase | Status | Branch | Description |
|---|---|---|---|
| Phase 1 — Harness Specifications | COMPLETE | `feature/agents-skills-migration` | DAG, evaluation harness, tool contracts, observability contract, platform adapters |
| Phase 2 — Control Mappings and Evidence Templates | COMPLETE | `feature/anti-mythos-phase2` | OWASP ASI crosswalk, threat modeling extension, evidence pack templates, findings schema, tool schema patterns, evidence collection checklists |
| Phase 3 — Adoption Enablement and Governance | IN PROGRESS | `feature/anti-mythos-phase3` | Platform adoption matrix, implementation roadmap, change management, governance runbook |
| Phase 4 — Live Pilot | NOT STARTED | — | Real project reviews on each platform |
| Phase 5 — Steady-State Operations | NOT STARTED | — | Cadence-driven governance |

## Usage
1. **Verify Azure CLI login** — run `az login` with your developer account and confirm the correct account is active with `az account show` before copying any skill packages into a downstream project.
2. Review each skill folder under `.agents/skills/` for framework-specific guidance.
3. Use the SDLC Gap Register in `.agents/skills/nist-ssdf/assets/SDLC-Gap-Register-Template.md` to track cross-framework compliance.
4. Add your project's documentation and evidence in the relevant skill folder.
5. Reference the Molina AppSec Program checklist in `.agents/skills/molina-application-security/Molina-AppSec-Program-Checklist.md`.
6. For agentic workflows spanning GitHub and Azure DevOps, use `.agents/skills/anti-mythos-agentic-security/` as the harness-first blueprint.

## Maintainer Note
- `TODO.md` is an internal backlog for template maintainers.
- Consumer projects should use skill package guidance under `.agents/skills/` rather than treating `TODO.md` as an implementation checklist.

## References
- [NIST SSDF](https://csrc.nist.gov/publications/detail/sp/800-218/final)
- [NIST SP 800-218A](https://csrc.nist.gov/publications/detail/sp/800-218A/final)
- Molina AppSec Program Checklist (see `.agents/skills/molina-application-security/Molina-AppSec-Program-Checklist.md`)
- [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)
- [OWASP Gen AI Security Project (Agentic Top 10, MCP Guide)](https://genai.owasp.org/)
- [OWASP Top 10 for Agentic Applications 2026 (ASI01–ASI10)](.agents/skills/owasp-genai-security/Agentic-Top10-Checklist.md)
- [OWASP Practical Guide for Secure MCP Server Development v1.0](.agents/skills/owasp-genai-security/MCP-Server-Security-Checklist.md)

## Copilot Instructions


When using an AI copilot or automated assistant (such as GitHub Copilot) for this project:

- **Reference the Checklists:** Always use the checklists in [.agents/skills/molina-nist-218a/218A-Checklist.md](.agents/skills/molina-nist-218a/218A-Checklist.md), [.agents/skills/nist-ssdf/SSDF-Checklist.md](.agents/skills/nist-ssdf/SSDF-Checklist.md), [.agents/skills/molina-application-security/Molina-AppSec-Program-Checklist.md](.agents/skills/molina-application-security/Molina-AppSec-Program-Checklist.md), and the OWASP Gen AI checklists in [.agents/skills/owasp-genai-security/Agentic-Top10-Checklist.md](.agents/skills/owasp-genai-security/Agentic-Top10-Checklist.md), [.agents/skills/owasp-genai-security/MCP-Server-Security-Checklist.md](.agents/skills/owasp-genai-security/MCP-Server-Security-Checklist.md), and [.agents/skills/owasp-genai-security/LLM-Top10-Reference.md](.agents/skills/owasp-genai-security/LLM-Top10-Reference.md) as authoritative guides for secure software, AI model, agentic, and MCP server development.

### Example: Adding Framework to Agent Instructions (GitHub Copilot)

**Prompt Example:**
> "Follow the NIST 218A Checklist for Secure Software Development Practices for Generative AI and Dual-Use Foundation Models. Ensure all relevant checklist items are addressed for each development phase."

**Agent Instruction Example:**
> "As an AI agent, you must:
> - Reference and apply the NIST SSDF, NIST 218A, and Molina AppSec Program checklists for every code change and review.
> - Document how each checklist item is satisfied in your output or comments.
> - Embed checklist items in your tasks and prompts to automate secure development validation.
> - Track and report compliance for audits using the provided checklists."

**GitHub Copilot Task Example:**
> "For every pull request, validate that all relevant items from `.agents/skills/molina-nist-218a/218A-Checklist.md`, `.agents/skills/nist-ssdf/SSDF-Checklist.md`, and `.agents/skills/molina-application-security/Molina-AppSec-Program-Checklist.md` are addressed. Add comments referencing the checklist items and document evidence in the relevant skill folder."

- **Embed in Copilot Tasks:** Copy specific checklist items into your copilot prompts or tasks to automate, validate, or monitor secure development practices.
- **Document Compliance:** Use the checklists to track progress and document evidence of compliance for audits and reviews.
- **Update Regularly:** Keep the checklists and copilot instructions up to date as standards and project requirements evolve.
- **Extend with skills:** All framework guidance is packaged as Agent Skills under `.agents/skills/`. Add new skill folders there for any additional frameworks.

> These instructions help ensure that AI copilots and development teams consistently apply secure development best practices throughout the project.
