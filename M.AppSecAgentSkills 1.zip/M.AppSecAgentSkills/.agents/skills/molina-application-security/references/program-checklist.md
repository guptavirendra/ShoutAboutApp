# Molina AppSec Program Checklist for Application Security Request List Tracker

This checklist is based on the items from Molina-AppSec-Program.csv and is intended to help track and remediate application security requirements and gaps.

## Checklist

- [ ] **1. Lack of Application Team SharePoint URL**  
	- Phase: Prereq  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents accurate management of artifacts to conduct the application security review

- [ ] **2. Lack of AppSec review request ticket in iServe**  
	- Phase: Prereq  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Centralize request, communication, timeline monitoring, and visibility for involved teams

- [ ] **3.1 Lack of Design Authority Review (Enterprise Architecture)**  
	- Phase: Prereq  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Application team to work with AppSec to gain approval prior to Permit to Build. Prevents duplication of capabilities

- [ ] **3.2 Lack of previous AppSec remediation plan for application**  
	- Phase: Prereq  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents closure of remediation items from previous AppSec review for the application

- [ ] **4. Lack of stakeholder information**  
	- Phase: Prereq  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents point of contacts from being known in case of breach / incident

- [ ] **5. Lack of two (2) application software development security trainings per year**  
	- Phase: Prereq  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents developers from creating secure code. Provide one certificate per training per developer.  
	- [Training Link](https://molinahealthcare.csod.com/ui/lms-learning-details/app/curriculum/fa7fd57f-c8d0-4eb9-a191-83310f5cd01f)

- [ ] **6. Lack of project changes description**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from understanding the overall impact of the project or the changes being made, including baseline profile applicability.

- [ ] **7. Lack of environment description**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from understanding the project landscape from a security perspective

- [ ] **8. Lack of security functionality description for each component**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from understanding overall security functionalities available for application design and traceability to requirement categories.

- [ ] **9. Lack of architecture diagram**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from understanding of application components impacted by changes and architecture requirement coverage.

- [ ] **10. Lack of activity diagram**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from understanding of application components impacted by changes

- [ ] **11. Lack of data flow diagram**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Data Flow diagram to show data types and access control between components with category traceability (Data Security and Auditing).

- [ ] **12. Lack of sequence diagram**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from understanding of application components impacted by changes

- [ ] **13. Lack of end-to-end OAuth including last mile to backend services**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents end-to-end access control throughout the Molina SDLC and validation of Authorization requirement coverage.

- [ ] **13.1 Lack of open source software management**  
	- Phase: Design: P2D  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Application teams to start planning to use Molina's EWSPR capability

- [ ] **14. Lack of remediated threats based on updated threat modeling diagram**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Threat modeling is required for Tier 0/1 or Internet-facing applications

- [ ] **15. Lack of changes inventory sheet (UI/Front-end URLs, backend API URLs, etc.)**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security team from properly auditing the security review. Missing DevOps repository and CI/CD pipeline evidence is a blocker under Application Security requirement 2.

- [ ] **16. Lack of SAST**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Dev changes need to go through SonarQube. Provide DevOps repository and CI/CD-integrated SAST results; missing evidence is a blocker under Application Security requirement 2.

- [ ] **17. Lack of Software Supply Chain report**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Provide link to Wiz Software Supply Chain results. Start remediation for all security issues found

- [ ] **18. Lack of DAST - web services and API**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: API endpoint URLs and payloads must be provided as OpenAPI specifications

- [ ] **19. Lack of DAST - UI**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: Prevents security vulnerabilities from being introduced

- [ ] **20. Lack of application level penetration testing**  
	- Phase: Testing: P2B  
	- Severity: CRITICAL  
	- Status: OPEN  
	- Description: This is a twice a year requirement for externally facing applications

> For details, see [assets/program-tracker.csv](../assets/program-tracker.csv).
