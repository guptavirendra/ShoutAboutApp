# Application Security Architecture Requirements and References

Last updated: 7/14/2026  
Last updated by: John Weldon

## Table of Contents

- [Application Security Architecture Requirements and References](#application-security-architecture-requirements-and-references)
- [Architecture](#architecture)
- [Authentication](#authentication)
- [Authorization](#authorization)
- [Data Security](#data-security)
- [Auditing](#auditing)
- [Application Security](#application-security)
- [References](#references)

APPLICATION SECURITY BASELINES ARE IN BOLD
Gaps against bolded requirements are blockers unless a documented exception exists.

## Architecture

1. Utilize an authentication, authorization, and access control framework to manage access control to applications and components, such as Microsoft Authentication Library (MSAL).
2. APIs shall be defined using OpenAPI 3.0 or better or WSDL specifications for WCF/SOAP web services.
3. **DDOS, WAF protection for externally facing IP addresses and hostnames (i.e., Akamai)**
4. **Enable API security protection for hostnames and endpoints within API management**
5. **Captcha shall be used to prevent automated attempts for data enumeration**
6. Stakeholder and project teams will work with IT Security Architecture to review and provide further requirements during design and all other phases of the project
7. **Error messages shall be generic and not provide information on the state of the application**
8. **Security Architecture shall be engaged at all phases for further review and requirements on the next product change**
9. **Rate limiting shall be enabled for both the network and application levels**
10. System shall only allow the member to register when there is exactly one unique member found
11. API security features shall be used (rate limiting, DOS protection, tokens, etc.)
12. Solution will utilize an on-premises deployment model with no outside connectivity
13. Solution will deploy using multi-tier architecture to separate business logic from presentation logic.
14. Vendor leverages Salesforce for system-to-system single-sign on in a hybrid cloud deployment model with connectivity between the vendor and Salesforce, interfacing with potential, anonymous leads from the Internet
15. Data shall be treated as sensitive as DOB and other identifying information of the potential lead (not currently a member) is being passed to Salesforce API
16. Security configuration and features of Salesforce for Molina users shall be enabled, enforced and appropriate
17. Security logic shall be separated from business logic within the solution
18. Solution will deploy architecture to separate business and security components from presentation components

## Authentication

1. Cloud applications shall use accepted client credential options such as Secret keys, Certificates, Managed Identities for Azure resources, and / or Federated Credentials [References 16]
2. Active directory (AD) level authentication shall be used to access the service
3. Authentication shall exist, be effective and appropriate for system-to-system authentication
4. User, service, and systems accounts shall utilize AD authentication
5. Solution will utilize Molina's Privileged Account Management (PAM) tool for managing service account and application credentials
6. Member shall be temporarily locked out for 24 hours after two failed attempts of registering (rate limiting for lower boundary)
7. 2 days failed retries, requires member to contact the customer support
8. Multi-layer, variant, obfuscated Captcha shall be used to prevent automated attempts for data enumeration
9. System shall only allow the member to register when there is exactly one unique member found
10. Application-level authentication shall be used to access the service
11. User level authentication shall be used on all requests following the registration process
12. User shall be temporarily locked out for 24 hours after 5 failed attempts of registering
13. User Authentication will utilize Kerberos
14. Service Accounts will utilize Kerberos authentication
15. Solution will utilize Molina's Privileged Account Management (PAM) tool for managing service account / virtual user / application credentials, provide run-time passwords, and password rotation.
16. All accounts will be unique
17. Robot accounts will have set expiration
18. Two-Factor Authentication for users will be enabled for high-risk, and administrative accounts along with accounts that have many-to-one relationships to other accounts
19. No anonymous access or guest accounts allowed.
20. Security configuration of Salesforce authentication for the solution shall be appropriate for system-to-system authentication

## Authorization

1. API access SHALL use OAUTH v2 or better
2. User authorization shall be enforced for the action (coarse-grain) and the access to data (fine-grain) that is being requested within the API
3. There is a documented process to review, approve, and manage access to the system. The IT Security Administration group will manage all access to and within the solution.
4. Role based access will be utilized. Users will be assigned roles with the least privilege necessary to perform their functions.
5. User accounts, Service Accounts, and Application accounts will utilize Active Directory for authorization
6. User accounts, Service Accounts, and Application accounts shall be appropriately separated between non-production and production environments to provide dual control and separation of duties (i.e., account shall only have access to the systems and data within a specific environment - Dev, QA/Test, Staging/UAT or Production)
7. Service Accounts and Robots will be governed using profiles that have access to specific functionality
8. Service Accounts and Robots will be deployed within Molina's enterprise behind organizational firewalls.
9. Quarterly entitlement reviews will be performed to ensure users have the appropriate level of access.
10. System-to-system authorization will be assigned least privilege necessary to perform the appropriate process
11. User authorization will be assigned least privilege necessary to perform the appropriate process within Salesforce
12. Authorization logic shall be separated from business logic within the solution

## Data Security

1. Applications and APIs shall perform input/output validation before processing data.
2. Application configuration password shall be protected using a secrets/password management system (i.e., Azure Key Vault, Amazon Key Manager)
3. All HTTP-based communications MUST use HTTPS with TLS v1.2 or greater.
4. Capability for mutual / two-way TLS
5. Private Key used must be at least 2048 bits
6. Avoid using hardcoded keys, use key management system
7. Molina restricted data will not reside on any solution components, at any point.
8. Data at rest is encrypted with AES-256 for secret key ciphers, and 2048-bit RSA for public key algorithms.
9. System-to-system TLS connections shall be validated and if invalid shall be revoked
10. Requests to the API that contain sensitive data shall be submitted via HTTP POST
11. Vendor shall not store sensitive data belonging to Molina

## Auditing

12. When multiple matches are found when conducting look up for member account, the activity shall be logged and Compliance notified within a timely manner
13. Ensure that effective security auditing and logging is enforced on application components
14. Effectively log all access security activities by the users
15. Effectively log all access security activities by the system-to-system interactions
16. Effectively log all access security activities that are performed by the user via the web API
17. Error messages shall be generic and not provide information on the state of the application
18. Security logs shall be centralized and appropriately reviewed by a security operations / CIRT capability
19. Sensitive data shall not be logged

## Application Security

1. All developers shall complete two (2) security-related software application courses and/or training at least annually
2. **All security reviews must have devops repository(ies) to host changes and use CI/CD pipeline for security testing. [18]**
3. Security evaluation, assessment, dynamic security testing and penetration testing shall be conducted on a risk-based approach and in a timely manner
4. Security evaluations are conducted when a significant change occurs
5. System, application, and source code vulnerabilities rated Medium or higher shall be mitigated before, deployment to QA and Production
6. Static application security testing (e.g., Fortify, Coverity, etc.) shall be conducted at every development sprint of development and results remediated before source code is promoted within the SDLC
7. Dynamic application security testing (e.g., Whitehat, Qualys, etc.) shall be conducted at every development sprint of development and results remediated before source code is promoted within the SDLC
8. The application and its components shall be developed to be protected against, but not limited to, the OWASP Top 10
9. Mobile, .NET, REST and Web Services application components shall follow information security guidelines as referenced below
10. .NET, REST, PHP, and Web Services application components shall follow OWASP guidelines as referenced below
11. Security Architecture shall be integrated within the development team's agile process by reviewing security-specific Epics, Backlogs, user stories and having a security agile review every sprint
12. Security requirements and/or references below shall be added to security-specific Epics, backlogs, and user stories to be satisfied in a timely manner prioritized on a risk-based approach
13. Threat model diagram shall be produced and updated every development sprint thereafter
14. Threat Model shall be created and then reviewed by Security Architecture
15. Data flow diagram shall be created and then reviewed by Security Architecture
16. An application security framework, such as BSIMM and/or NIST SSDF, shall be adhered to

## References

Product and stakeholder teams shall follow OWASP guidelines and vendor security best practices based on technology used, along with other requirements:

1. [CWE Architectural Concepts](https://cwe.mitre.org/data/definitions/1008.html)
2. [.NET](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)
3. [REST](https://cheatsheetseries.owasp.org/cheatsheets/REST_Security_Cheat_Sheet.html)
4. [Web Services](https://cheatsheetseries.owasp.org/cheatsheets/Web_Service_Security_Cheat_Sheet.html)
5. [PHP](https://cheatsheetseries.owasp.org/cheatsheets/PHP_Configuration_Cheat_Sheet.html)
6. [Mobile Application Security Requirements and Verification](https://github.com/OWASP/owasp-masvs/releases/download/1.1.4/OWASP_Mobile_AppSec_Verification_Standard_1.1.4_Document.pdf)
7. [OWASP Top 10](https://owasp.org/Top10/)
8. [OWASP Mobile Application Security (MAS)](https://mas.owasp.org/)
9. [CIS Controls](https://www.cisecurity.org/controls/)
10. [Weaknesses in Mobile Applications](https://cwe.mitre.org/data/definitions/919.html)
11. [Build Security in Maturity Model (BSIMM) Software Security Framework](https://www.bsimm.com/framework.html)
12. [OWASP Application Security Verification Standard (ASVS)](https://owasp.org/www-project-application-security-verification-standard/)
13. [Microsoft's Threat Modeling mitigations](https://learn.microsoft.com/azure/security/develop/threat-modeling-tool)
14. [Gatekeeper pattern (concept)](https://learn.microsoft.com/azure/architecture/patterns/gatekeeper)
15. [NIST SSDF](https://nvlpubs.nist.gov/nistpubs/CSWP/NIST.CSWP.04232020.pdf)
16. [Providing application identity credentials when there's no user](https://learn.microsoft.com/entra/identity-platform/how-to-web-app-service-to-service-call)
17. [Applying GitOps principles to your operations](https://github.blog/enterprise-software/devops/applying-gitops-principles-to-your-operations/)
18. [GitOps and Shift Left Security: The DevSecOps Landscape](https://cloudsecurityalliance.org/artifacts/gitops-and-shift-left-security-the-devsecops-landscape/)

