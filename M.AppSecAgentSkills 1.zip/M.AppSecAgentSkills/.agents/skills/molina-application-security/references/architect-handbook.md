# Application Security Review: Architect Handbook

*May 28th, 2024*

---

## AppSec Review Phase 1 - Guidelines for Required Artifacts (1/4)

**APPLICATION SECURITY - ARCHITECT HANDBOOK**

### Design Authority Review (Enterprise Architecture)

**Requested items**
- Deck from Permit to Design
- Minutes from Permit to Design

**Closure Criteria**
- Check that shared diagrams are in alignment with documentation presented and reviewed during Design Authority

**Expected Outcomes from AppSec Analysis**
- Confirmation that the project went through DA process when applicable

**To be validated before:** Permit to Build

---

### Application Team SharePoint URL

**Requested items**
- Access to App team SharePoint

**Closure Criteria**
- Ensure access is provided to full AppSec team

**Expected Outcomes from AppSec Analysis**
- SharePoint with requested artifacts and updated review tracker

---

### iServe ticket for AppSec review request

**Requested items**
- Ticket created in iServe to request AppSec review

**Closure Criteria**
- Ensure iServe ticket is existing, assigned to involved architect, and that key communications are logged in iServe

**Expected Outcomes from AppSec Analysis**
- Updated iServe ticket

---

### Stakeholder information

**Requested items**
- List of stakeholder's full names of directors or higher for application towers involved in the design

**Closure Criteria**
- Ensure that all requested contacts have been provided including application tower and related director (refer to dedicated template)

**Expected Outcomes from AppSec Analysis**
- Key stakeholders to contact in case of a security breach or for escalations throughout the AppSec review process

---

### Project, product, or service changes description

**Requested items**
- Description of change and its use within Molina from a business perspective

**Closure Criteria**
- Ensure alignment on scope (change, related components involved, data, etc.) and identify impact of the changes, for instance, online of business, users, data involved, components, integration within Molina environment

**Expected Outcomes from AppSec Analysis**
- Confirmation of Application Security review scope and business impact

---

## AppSec Review Phase 1 - Guidelines for Required Artifacts (2/4)

**APPLICATION SECURITY - ARCHITECT HANDBOOK**

### Security functionality description (Access Control i.e. OAuth v2+, mTLS, API key)

**Requested items**
- Acceptable description of applications security functionalities (such as authentication authorization, logging & monitoring, encryption, confidentiality, integrity, IAM)

**Closure Criteria**
- Ensure alignment of security functionalities mentioned with the rest of the review (i.e. functionalities are depicted in applicable diagrams)
- Ensure security functionalities address any risks identified throughout the review, for new component
- Analyze the risk level from a security perspective and define the appropriate security controls to implement
- Confirm selected baseline profile (`On-Prem` or `Hybrid-Salesforce`) and map controls to requirement categories.

**Expected Outcomes from AppSec Analysis**
- Confirmation of the security measures that App team has in place (via evidences)
- Definition of related security controls to implement, criticality and implementation status

**To be validated before:** Permit to Build

---

### Data flow diagram

**Requested items**
- Molina specific data flow diagram provided

**Closure Criteria**
- Ensure alignment of data flow diagram with the rest of the review (i.e. is there unaccounted data flows in the diagram that have not been addressed previously)
- Verify that transferred data is represented on the diagram
- Assess the risk level leveraging the data classification standard and direct to privacy review contact if needed
- If needed, advise update to artefacts and list additional findings

**Expected Outcomes from AppSec Analysis**
- Confirmation of the risk level of the data involved in the project

---

### Sequence diagram

**Requested items**
- Sequence diagram presenting how the application interacts with Molina's environment

**Closure Criteria**
- Ensure alignment of sequence diagram with the rest of the review (i.e. is there unaccounted components in the diagram that have not been addressed previously)
- Verify the accuracy of the diagram and ensure all involved components and their interactions are represented
- For each transferred data, ensure description of how the transfer is being conducted and that this is secure
- Confirm that requirement categories are covered for the selected baseline profile, and if needed, advise update to artefacts and list additional findings

**Expected Outcomes from AppSec Analysis**
- Understanding components impacted by changes and their nature of interactions within Molina's environment, and list of additional security findings if needed

---

## AppSec Review Phase 1 - Guidelines for Required Artifacts (3/4)

**APPLICATION SECURITY - ARCHITECT HANDBOOK**

### Remediated threats based on updated threat modeling diagram

**Requested items**
- Threat Modeling diagram
- List of all identified threats
- Evidence of starting remediation of identified threats
- Target dates to complete remediation of identified threats

**Closure Criteria**
- Only required for Tier 1 or Tier 0 internet facing applications and all vendor applications (completed by the vendor)
- If required, review threat model and define acceptable timeline to remediate threats from a security perspective

**Expected Outcomes from AppSec Analysis**
- Confirmation that threats identified to be remediated before go live are being tackled
- List of threats to be handled after go live with expected timeline for resolution

**To be validated before:** Permit to Build

---

### Two (2) application software development security trainings per year

**Requested items**
- 2 training certificates completed within 1 year of the current date

**Closure Criteria**
- Verify that certificates were issued within a year timeframe using Molina Learning Lab security training for developers

**Expected Outcomes from AppSec Analysis**
- Confirmation that developers working on the project have up to date required security training

**To be validated before:** Permit to Design / Build

---

### Environment description

**Requested items**
- Environment description for solution and components impacted by the change, highlighting components location (i.e. external/internal, in relation with other components)

**Closure Criteria**
- Verify details are Molina specific. If not available, collect vendor details
- Ensure alignment with rest of the review (i.e. are the environment details consistent with diagrams, inventory, and threat modeling provided)

**Expected Outcomes from AppSec Analysis**
- Confirmation of environment details impacted by the changes, which will determine the scope of security testing

**To be validated before:** Permit to Build

---

### Initial Architecture diagram

**Requested items**
- First version of diagram with placement of placeholder components within the networks

**Closure Criteria**
- Verify architecture diagram represents all the components for the solution within the network
- Ensure alignment with the rest of the review (i.e. are the components included in descriptions accounted for in the diagram)
- Confirm that requirement categories are covered for the selected baseline profile, and if needed, advise update to artefacts and list additional findings

**Expected Outcomes from AppSec Analysis**
- Understanding of application components impacted by changes, and list of additional security controls if needed

---

## AppSec Review Phase 1 - Guidelines for Required Artifacts (4/4)

**APPLICATION SECURITY - ARCHITECT HANDBOOK**

### Activity diagram

**Requested items**
- Diagram highlighting activities that occurs when Molina users interact with the application

**Closure Criteria**
- Verify activity diagram is Molina specific and not generic to their application (Molina user should be specified in the diagram)
- Ensure alignment with the descriptions provided and future security testing
- Confirm that requirement categories are covered for the selected baseline profile, and if needed, advise update to artefacts and list additional findings

**Expected Outcomes from AppSec Analysis**
- Understanding of application activities logic, and list of additional security controls if needed and scoping of security testing

**To be validated before:** Permit to Build

---

### End-to-end OAuth including last mile to backend services

**Requested items**
- Evidence of OAuth between systems and confirmation of which authorization code flows used (i.e. payload)

**Closure Criteria**
- Ensure alignment with the rest of the review (i.e. is OAuth included throughout the solution)
- Check that authentication process between systems is following standards and provide guidance/additional security controls to App team if needed
- Confirm OAuth v2+ or better is used for API access, with last-mile token and authorization enforcement documented.

**Expected Outcomes from AppSec Analysis**
- Verification and validation of end-to-end access control using payloads is following standards and list of additional security controls if needed

---

### Previous AppSec review plan for the project

**Requested items**
- Previous AppSec review tracker for application when applicable

**Closure Criteria**
- Review tracker and identify if any artifacts are still pending

**Expected Outcomes from AppSec Analysis**
- Confirmation that remediation plan is completed

---

## AppSec Review Phase 2 - Guidelines for Required Artifacts (1/2)

**APPLICATION SECURITY - ARCHITECT HANDBOOK**

### Networking inventory sheet (server hostnames and IPs, access URLs, API endpoint URLs, and payloads)

**Requested items**
- Inventory of IP addresses, network segmentation inventory, URLs, and payloads. Including mapping from inventory to diagrams

**Closure Criteria**
- Ensure alignment with the shared diagrams (URL, endpoints, internet facing or not)
- Confirm level of security for endpoints provided
- Confirm that runtime requirements are covered for the selected baseline profile (WAF, API security controls, rate limiting, and logging), and if needed, advise update to artefacts and list additional findings

**Expected Outcomes from AppSec Analysis**
- Confirmation the network inventory applicable for the change under shows an acceptable security level

**To be validated before:** Permit to Operate

---

### Final Architecture diagram

**Requested items**
- Updated diagram including mapping of items in Network Inventory Sheet

**Closure Criteria**
- Verify architecture diagram represents all the components for the solution within the network
- Ensure alignment with the rest of the review (i.e. are the components included in descriptions accounted for in the diagram)
- Confirm that requirement categories are covered for the selected baseline profile, and if needed, advise update to artefacts and list additional findings

**Expected Outcomes from AppSec Analysis**
- Understanding of application components impacted by changes, and list of additional security controls if needed

---

### SAST

**Requested items**
- Evidence of starting SAST testing with AppSecOps team if needed

**Closure Criteria**
- Assess if SAST is needed for this project and direct the App team to the AppSecOps process to launch the scan

**Expected Outcomes from AppSec Analysis**
- Understanding that necessary Security testing will be carried out to the AppSecOps team

---

### DAST

**Requested items**
- Evidence of starting DAST testing with AppSecOps team if needed

**Closure Criteria**
- Assess if DAST is needed for this project and direct the App team to the AppSecOps process to launch the scan

**Expected Outcomes from AppSec Analysis**
- Understanding that necessary Security testing will be carried out to the AppSecOps team

---

## AppSec Review Phase 2 - Guidelines for Required Artifacts (2/2)

**APPLICATION SECURITY - ARCHITECT HANDBOOK**

### Software Supply Chain report

**Requested items**
- Evidence of starting the process of obtaining software supply chain report with AppSecOps team if needed

**Closure Criteria**
- Assess if software supply chain is needed for this project and direct the App team to the AppSecOps process

**Expected Outcomes from AppSec Analysis**
- Understanding that necessary Security testing will be carried out to the AppSecOps team

**To be validated before:** Permit to Operate

---

### Application-level penetration testing

**Requested items**
- Evidence of starting testing with penetration testing team if needed

**Closure Criteria**
- Assess if penetration testing is needed for this project and direct the App team to the penetration testing process

**Expected Outcomes from AppSec Analysis**
- Understanding that necessary Security testing will be carried out by the penetration testing team

**To be validated before:** Permit to Operate

---

## Appendix: Items To Be Removed From AppSec Request List (Target Process)

### Previous Security Architecture Review (Permit to Build)

**Requested items**
- SecArc documentation
- SecArc review approval

**Closure Criteria**
- If needed, provide SecArc contact information to the team and advise them to start as soon as possible

**Handover:** N/A - Assurance team syncing with SecArc directly

---

### Privacy review / approval (Permit to Build)

**Requested items**
- Evidence of Privacy review completed if required

**Closure Criteria**
- Only required if analysis of documentation shows PHI/PII is handled by the application, if not mark as "N/A"
- If required, share the Privacy review contact with the App team to launch the process

**Handover:** Document to share for reference

---

### Design Authority Review - Permit to Operate (Target Process)

**Requested items**
- Deck from Permit to Build
- Minutes from Permit to Build

**Closure Criteria**
- Check that shared diagrams are in alignment with documentation presented and reviewed during Design Authority

**Handover:** N/A - Will be under Assurance team moving forward
