# Application Security Review Process

> **Source**: Converted from *1. Application Security Review Process Intro and Qualifications_v1.pptx* into structured Markdown so GitHub Copilot and other AI tooling can reliably parse, summarize, and reference it.

---

## 1. Purpose

The Application Security Review (AppSec Review) ensures the protection of Molina Healthcare assets and data (e.g., PHI) and validates that application changes meet security requirements **before Permit to Operate / Go Live**.

An AppSec Review is required for:

- New applications
- Major application upgrades or releases
- Major integrations
- In-house developed applications or custom APIs
- Internet-facing or client-facing applications
- Applications handling sensitive or regulated data
- Ad-hoc security approvals

Reviews typically start **after Permit to Design** and must complete **before Permit to Operate**.

---

## 2. How to Initiate an AppSec Review

1. Submit an **Application Security (AppSec) Review** request via iServe.
2. After submission, the AppSec team schedules a kickoff meeting.
3. The project team provides required artifacts via a dedicated SharePoint folder.

> **Policy**: AppSec approval is mandatory prior to production go-live for eligible projects.

---

## 3. AppSec in the Design Authority (DA) Process

AppSec activities align to DA milestones:

- Permit to Design
- Permit to Build
- Permit to Operate

AppSec contributions include:

- Secure design review
- Threat modeling (when required)
- Security testing validation
- Remediation plan tracking
- Formal approval and documentation

---

## 4. Triggers for an Application Security Review

An AppSec Review is triggered when **any** of the following occur.

### 4.1 Change Types

- Major application upgrade
- New application development
- Major application integration
- Significant architectural or code changes
- Introduction of custom APIs (including Apigee)
- New Azure services (App Services, Functions, Databricks, notebooks)
- SSO integration (member or provider portals)

### 4.2 Risk Indicators

- Internet-facing exposure
- Client-facing functionality
- Sensitive or regulated data handling
- Integration with Tier 0 or Tier 1 systems
- Change in authentication, authorization, or APIs

> **Note**: AppSec approvals are valid for **12 months**. Any qualifying change after 12 months requires a new review.

---

## 5. Review Types

### 5.1 Regular Review

A **regular review** is required when **any** of the following apply:

- Last AppSec review was more than 12 months ago
- Major architectural, data, or code changes
- Outstanding vulnerabilities not yet remediated
- Baseline profile changed (for example, On-Prem to Hybrid-Salesforce)

**Characteristics**

- Full secure design review
- Threat modeling (if applicable)
- Full security testing
- Standard SLA: ~51 days

---

### 5.2 Fast-Track Review

A **fast-track review** is allowed **only if all criteria are met**:

- Previous regular review completed within 12 months
- No major changes since last review
- Scope explicitly confirmed by AppSec
- Same baseline profile as prior approved review (`On-Prem` or `Hybrid-Salesforce`)

**Characteristics**

- Partial artifact reuse
- No threat modeling
- Minimum SLA: ~9 days (with complete artifacts)

---

## 6. Fast-Track Review Flow (High Level)

1. Qualification (1 day)
2. Artifact collection (2 days)
3. Secure design review (2 days)
4. Security testing validation (1 day)
5. Peer review and approval decision (2 days)
6. Remediation plan updates (2 days)

SLA pauses if artifacts are missing or incomplete.

---

## 7. Regular Review Flow (High Level)

1. Qualification (~3 days)
2. Artifact collection (~15 days)
3. Secure design review (~5 days)
4. Threat modeling (if required)
5. Security testing (SAST / DAST)
6. Peer review and approval (~11 days)

---

## 8. RACI Summary

| Activity | Application Team | AppSec Team | AppSecOps |
|--------|------------------|------------|-----------|
| Initiate review request | R/A | C | - |
| Assign AppSec architect | I | R/A | - |
| Confirm review requirement | C | R/A | - |
| Provide SharePoint access | R/A | I | - |
| Upload artifacts | R/A | I | - |
| Secure design review | C | R/A | - |
| Threat modeling / testing | C | I | R/A |
| Remediation plan updates | C | R/A | - |
| Approval decision | I | R/A | - |

---

## 9. Required Inputs (Initial)

### 9.1 Administrative

- iServe AppSec Review request
- Dedicated SharePoint folder
- Access granted to AppSec distribution list

### 9.2 Prior Evidence (If Applicable)

- Permit to Design documentation
- Previous AppSec remediation plans
- Prior baseline profile selection and applicability notes

### 9.3 Training

- Evidence of **at least two secure development trainings per year** for developers

### 9.4 Stakeholders

- Application, Business, and IT owners
- Project manager
- Project ID and deployment date
- Onshore and offshore points of contact
- Vendor contacts (if applicable)

---

## 10. Secure Design Review Artifacts

### 10.1 General Description

- Application or project overview
- Description of changes
- Environment details and integrations
- Baseline profile selection (`On-Prem` or `Hybrid-Salesforce`) and justification

### 10.2 Architecture and Flow Diagrams

- Architecture diagram
- Activity diagram
- Data flow diagram
- Sequence diagram

### 10.3 Security Evidence

- End-to-end OAuth flows
- Inventory of IPs, URLs, and payloads
- Requirement category coverage notes (Architecture, Authentication, Authorization, Data Security, Auditing, Application Security)

---

## 11. Threat Modeling Artifacts (If Required)

- Threat model diagrams
- Threat inventory and remediation tracking

Threat modeling is required for:

- Tier 0 or Tier 1 applications
- Internet-facing systems
- Certain vendor applications

---

## 12. Security Testing Artifacts

### 12.1 Required Testing

- Static Application Security Testing (SAST)
- Dynamic Application Security Testing (DAST), Web and/or API
- Penetration testing for internet-facing applications

### 12.2 Penetration Testing Criteria

- Internet-facing application changes under `molinahealthcare.com`
- Asset inventory included in scope
- Evidence of testing results and coverage

---

## 13. In-House Languages Triggering AppSec Review

AppSec review applies to in-house code written in supported languages, including but not limited to:

- .NET / .NET Core / C#
- Java / Kotlin
- JavaScript / TypeScript
- Python
- Go
- PHP
- Ruby
- C / C++
- Infrastructure as Code (Terraform, Bicep, Docker)
- SQL / PL-SQL / T-SQL
- XML / JSON / YAML

(Refer to Fortify-supported versions for exact compiler coverage.)

---

## 14. Key Rules (Copilot-Friendly)

```text
- AppSec approval is mandatory before production go-live
- Approval validity is 12 months
- Any major change resets the review requirement
- Fast-track reviews require explicit AppSec confirmation
- Missing or incomplete artifacts pause SLAs
```
