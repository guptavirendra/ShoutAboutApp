<#
.SYNOPSIS
    Validates the molina-application-security skill package against agentskills.io spec requirements.
.DESCRIPTION
    Checks frontmatter fields, required files, directory structure, body size limits,
    control ID consistency between priority-controls narrative and control-status tables,
    and eval coverage. Exits with code 0 on PASS, 1 on FAIL.
.PARAMETER SkillPath
    Path to the skill root directory. Defaults to the directory containing this script's parent.
.EXAMPLE
    powershell -File scripts/validate-skill.ps1 -SkillPath .
#>
[CmdletBinding()]
param(
    [Alias("skill-path")]
    [string]$SkillPath = (Split-Path $PSScriptRoot -Parent)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$script:errors   = @()
$script:warnings = @()

function Fail([string]$msg)    { $script:errors   += "  [FAIL] $msg" }
function Warn([string]$msg)    { $script:warnings += "  [WARN] $msg" }
function Pass([string]$msg)    { Write-Host "  [PASS] $msg" -ForegroundColor Green }

Write-Host "`nValidating skill: $SkillPath`n" -ForegroundColor Cyan

# ---------------------------------------------------------------------------
# 1. Required files
# ---------------------------------------------------------------------------
Write-Host "--- Required files ---"
$requiredFiles = @("SKILL.md", "README.md", "evals/evals.json")
foreach ($f in $requiredFiles) {
    $full = Join-Path $SkillPath $f
    if (Test-Path $full) { Pass $f } else { Fail "Missing required file: $f" }
}

# Check for references/ and assets/ directories
Write-Host "`n--- Directory structure ---"
$refDir = Join-Path $SkillPath "references"
if (Test-Path $refDir) {
    $refFiles = @(Get-ChildItem $refDir -File)
    Pass "references/ directory present ($($refFiles.Count) files)"
} else {
    Warn "references/ directory not present (recommended for skills with supporting docs)"
}

$assetsDir = Join-Path $SkillPath "assets"
if (Test-Path $assetsDir) {
    $assetFiles = @(Get-ChildItem $assetsDir -File)
    Pass "assets/ directory present ($($assetFiles.Count) files)"
} else {
    Warn "assets/ directory not present (recommended for reusable templates and data)"
}

# ---------------------------------------------------------------------------
# 2. Frontmatter
# ---------------------------------------------------------------------------
Write-Host "`n--- Frontmatter ---"
$skillMd = Join-Path $SkillPath "SKILL.md"
if (Test-Path $skillMd) {
    $content = Get-Content $skillMd -Raw

    # Extract YAML frontmatter block
    $fmMatch = [System.Text.RegularExpressions.Regex]::Match(
        $content, '^---[\r\n]+(.+?)[\r\n]+---',
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )
    if ($fmMatch.Success) {
        $fm = $fmMatch.Groups[1].Value

        # name field
        if ($fm -match 'name:\s*(.+)') {
            $name = $Matches[1].Trim()
            $dirName = Split-Path $SkillPath -Leaf
            if ($name -ceq $dirName) {
                Pass "name '$name' matches directory name"
            } else {
                Fail "name '$name' does not match directory name '$dirName'"
            }
            $nameValid = [System.Text.RegularExpressions.Regex]::IsMatch($name, '^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$')
            if ($nameValid -and $name -notmatch '--') {
                Pass "name format valid"
            } else {
                Fail "name '$name' format invalid"
            }
        } else {
            Fail "Frontmatter missing 'name' field"
        }

        # description field
        if ($fm -match 'description:\s*"(.+)"') {
            $desc = $Matches[1]
            if ($desc.Length -le 1024) {
                Pass "description present ($($desc.Length)/1024 chars)"
            } else {
                Fail "description exceeds 1024 characters ($($desc.Length))"
            }
            if ($desc -match 'WHEN:') {
                Pass "description contains WHEN-trigger keywords"
            } else {
                Warn "description has no WHEN: trigger block"
            }
        } else {
            Fail "Frontmatter missing 'description' field or not quoted correctly"
        }

        # recommended fields
        foreach ($field in @('license','compatibility','allowed-tools')) {
            if ($fm -match ($field + ':')) { Pass "frontmatter.$field present" }
            else { Warn "frontmatter.$field not set (recommended)" }
        }

        # metadata subfields
        foreach ($meta in @('version','author')) {
            if ($fm -match $meta) { Pass "metadata.$meta present" }
            else { Warn "metadata.$meta not set (recommended)" }
        }
    } else {
        Fail "SKILL.md has no valid YAML frontmatter block (expected --- delimiters)"
    }  # end fmMatch

    # ---------------------------------------------------------------------------
    # 3. Body size
    # ---------------------------------------------------------------------------
    Write-Host "`n--- Body size ---"
    $lines = ($content -split "`n").Count
    if ($lines -le 500) {
        Pass "Body size: $lines lines (limit: 500)"
    } else {
        Warn "Body size: $lines lines exceeds 500-line recommendation - move excess to references/"
    }

    # ---------------------------------------------------------------------------
    # 4. Control ID consistency
    # ---------------------------------------------------------------------------
    Write-Host "`n--- Control ID consistency ---"

    # PRE: verify all 6 controls mentioned
    $preIds = [regex]::Matches($content, 'PRE-(\d+)') | ForEach-Object { [int]$_.Groups[1].Value } | Sort-Object -Unique
    $expectedPre = 1..6
    $missingPre = @($expectedPre | Where-Object { $_ -notin $preIds })
    if ($missingPre.Count -eq 0) { Pass "All PRE-01 through PRE-06 referenced" }
    else { $ids = ($missingPre | ForEach-Object { 'PRE-0' + $_ }) -join ', '; Fail "Missing PRE controls: $ids" }

    # P2D: verify all 9 controls mentioned
    $p2dIds = [regex]::Matches($content, 'P2D-(\d+)') | ForEach-Object { [int]$_.Groups[1].Value } | Sort-Object -Unique
    $expectedP2d = 1..9
    $missingP2d = @($expectedP2d | Where-Object { $_ -notin $p2dIds })
    if ($missingP2d.Count -eq 0) { Pass "All P2D-01 through P2D-09 referenced" }
    else { $ids = ($missingP2d | ForEach-Object { 'P2D-0' + $_ }) -join ', '; Fail "Missing P2D controls: $ids" }

    # P2B: verify all 7 controls mentioned
    $p2bIds = [regex]::Matches($content, 'P2B-(\d+)') | ForEach-Object { [int]$_.Groups[1].Value } | Sort-Object -Unique
    $expectedP2b = 1..7
    $missingP2b = @($expectedP2b | Where-Object { $_ -notin $p2bIds })
    if ($missingP2b.Count -eq 0) { Pass "All P2B-01 through P2B-07 referenced" }
    else { $ids = ($missingP2b | ForEach-Object { 'P2B-0' + $_ }) -join ', '; Fail "Missing P2B controls: $ids" }

    # Detect erroneous WAF control (P2B-07 should not be labeled WAF)
    if ($content -match 'P2B-07.*WAF|WAF.*P2B-07') {
        Fail "P2B-07 incorrectly labeled as WAF - P2B-07 is 'application level penetration testing'"
    } else {
        Pass "P2B-07 is not mislabeled as WAF"
    }

    # Skills-used line
    if ($content -match 'Skills used:') {
        Pass "'Skills used:' output signal present"
    } else {
        Fail "Missing 'Skills used:' output signal in standard output template"
    }

    # Baseline profile selection guidance
    if ($content -match 'Baseline Profile: <On-Prem\|Hybrid-Salesforce\|Not Applicable>') {
        Pass "Standard output template includes baseline profile field"
    } else {
        Fail "Missing baseline profile field in standard output template"
    }

    # Requirement category traceability guidance
    $requiredCategories = @('Architecture','Authentication','Authorization','Data Security','Auditing','Application Security')
    $missingCategories = @($requiredCategories | Where-Object { $content -notmatch ("Requirement Category Coverage:[\s\S]*" + [regex]::Escape($_) + ':') })
    if ($missingCategories.Count -eq 0) {
        Pass "Requirement category coverage section includes all six categories"
    } else {
        Fail "Requirement category coverage section missing: $($missingCategories -join ', ')"
    }
}

# ---------------------------------------------------------------------------
# 5. Evals
# ---------------------------------------------------------------------------
Write-Host "`n--- Evals ---"
$evalsPath = Join-Path $SkillPath "evals/evals.json"
if (Test-Path $evalsPath) {
    try {
        $evalsJson = Get-Content $evalsPath -Raw | ConvertFrom-Json
        $count = ($evalsJson.evals | Measure-Object).Count
        if ($count -ge 3) {
            Pass "evals.json has $count test cases (minimum: 3)"
        } elseif ($count -ge 2) {
            Warn "evals.json has $count test cases (recommend at least 3)"
        } else {
            Fail "evals.json has $count test cases - minimum 2 required"
        }

        foreach ($eval in $evalsJson.evals) {
            if (-not $eval.assertions -or $eval.assertions.Count -eq 0) {
                Fail "Eval id=$($eval.id) has no assertions"
            } else {
                Pass "Eval id=$($eval.id) has $($eval.assertions.Count) assertions"
            }
        }
    } catch {
        Fail "evals.json parse error: $_"
    }
}

# ---------------------------------------------------------------------------
# 6. Summary
# ---------------------------------------------------------------------------
Write-Host "`n--- Summary ---"
$warnCount  = $script:warnings.Count
$errorCount = $script:errors.Count

if ($warnCount -gt 0) {
    Write-Host "`nWarnings ($warnCount):" -ForegroundColor Yellow
    $script:warnings | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
}

if ($errorCount -eq 0) {
    Write-Host "`nValidation result: PASS ($warnCount warnings)" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`nErrors ($errorCount):" -ForegroundColor Red
    $script:errors | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    Write-Host "`nValidation result: FAIL ($errorCount errors, $warnCount warnings)" -ForegroundColor Red
    exit 1
}
