# AppSec Request for Approval Form Template

Use this form when residual risk must be accepted, remediation is deferred, or conditional gate progression is requested.

## Request Metadata
| Field | Value |
|---|---|
| Request ID | APPSEC-APR-<yyyy>-<nnn> |
| Project Name |  |
| RITM ID | RITM-<id> |
| Gate Phase | PRE / P2D / P2B |
| Submission Date |  |
| Requested Decision Date |  |
| Requestor Name / Role |  |

## Requested Disposition
Select one:
- approve
- approve with conditions
- reject

## Findings and Risk Summary
| Finding ID | Molina Line Item / Control ID | Severity | Current Status (OPEN/REMEDIATE/CLOSED) | Business Impact | Security Impact |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Remediation and Compensating Controls
- Planned remediation completion date:
- Remediation owner:
- Compensating controls currently in place:
- Monitoring and escalation commitments:

## Justification
Provide rationale for why full closure cannot be completed before gate decision and why requested disposition is appropriate.

## Evidence Attachments
| Evidence Type | Reference Link / Artifact | Notes |
|---|---|---|
| Scan report(s) |  |  |
| Remediation plan |  |  |
| Tracker extract |  |  |
| Risk acceptance documentation |  |  |
| Retest evidence (if partial) |  |  |

## Approvals
| Approver Role | Name | Decision (Approve / Approve with Conditions / Reject) | Decision Date | Conditions / Notes |
|---|---|---|---|---|
| IT Security |  |  |  |  |
| Business Owner |  |  |  |  |
| Compliance (if required) |  |  |  |  |

## Final Decision Summary
- Final decision:
- Effective period / expiry (if applicable):
- Follow-up actions and due dates:
