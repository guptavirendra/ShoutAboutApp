# Architecture Traceability Report Template

Use this template to document requirement coverage evidence for P2D and P2B gates.

## Header

| Field | Value |
|---|---|
| Project Name |  |
| RITM ID |  |
| Gate Phase | P2D / P2B |
| Baseline Profile | On-Prem / Hybrid-Salesforce |
| Reviewer |  |
| Review Date |  |

## Requirement Coverage Register

| Requirement Category | Requirement ID | Requirement Summary | Control ID | Evidence Artifact | Status (Addressed/Gap/Exception) | Notes |
|---|---|---|---|---|---|---|
| Architecture | Arch-01 |  | P2D-04 |  |  |  |
| Authentication | Auth-01 |  | P2D-03 |  |  |  |
| Authorization | AuthZ-01 |  | P2D-08 |  |  |  |
| Data Security | DataSec-01 |  | P2D-06 |  |  |  |
| Auditing | Audit-13 |  | P2D-03 |  |  |  |
| Application Security | AppSec-05 |  | P2B-03 |  |  |  |

## Exception Register

| Exception ID | Requirement Reference | Justification | Risk Owner | Expiration Date | Approval Link |
|---|---|---|---|---|---|
| EX-001 |  |  |  |  |  |
