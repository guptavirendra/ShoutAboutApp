# AppSec Remediation Tracker Template

Use this template to track any AppSec review intake and remediation lifecycle for a project RITM.

## Project Metadata
| Field | Value |
|---|---|
| Project Name |  |
| RITM ID | RITM-<id> |
| Initiative / Release |  |
| Gate Phase | PRE / P2D / P2B |
| Business Owner |  |
| IT Security Owner |  |
| Last Updated |  |

## Status Vocabulary
| Tracker Status | Meaning | Normalized Lifecycle Status | Gate Implication |
|---|---|---|---|
| OPEN | Finding/control gap is identified and not remediated | Open or Blocked | FAIL when critical controls are affected |
| REMEDIATE | Remediation work is active or pending verification | In Progress or Ready for Review | CONDITIONAL when approved due dates exist |
| CLOSED | Remediation and verification are complete | Closed | PASS when required evidence is validated |

## Findings and Remediation Register
| Finding ID | Molina Line Item | Control ID | Requirement Category | Requirement Reference | Source Tool / Report | Finding Summary | Severity | Tracker Status (OPEN/REMEDIATE/CLOSED) | Owner | Target Remediation Date | Actual Remediation Date | Remediation Action Summary | Compensating Controls | Evidence Link | Verification Status | Verified By | Verification Date | Closure Outcome |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F-001 | 16 | P2B-03 | Application Security | AppSec-05 | SonarQube <report-id> |  | Critical | OPEN |  |  |  |  |  |  | Not Verified |  |  |  |
| F-002 | 17 | P2B-04 | Application Security | AppSec-02 | Wiz <report-id> |  | High | REMEDIATE |  |  |  |  |  |  | Ready for Review |  |  |  |
| F-003 | 19 | P2B-06 | Data Security | DataSec-01 | DAST <report-id> |  | Medium | CLOSED |  |  |  |  |  |  | Verified |  |  | Closed |

## Weekly Review Checklist
| Check | Complete (Y/N) | Notes |
|---|---|---|
| Every OPEN item has owner and due date |  |  |
| Every REMEDIATE item has evidence-in-progress update |  |  |
| Every CLOSED item has verifier, date, and closure evidence |  |  |
| Critical findings without closure are escalated |  |  |
| Approval request filed for deferred or accepted risk |  |  |

## Approval Linkage
If a finding cannot be closed before gate decision, link an approval request record from [request-for-approval-template.md](request-for-approval-template.md) and reference it in the finding row.
