# Architecture Baseline Profiles

Use this file to resolve mutually exclusive architecture requirements before P2D control scoring.

## Profile Selection Rule

Select exactly one baseline profile for each review scope:
- `On-Prem`: applies when solution has no outside connectivity.
- `Hybrid-Salesforce`: applies when Salesforce or vendor internet connectivity is in scope.

If profile selection is not explicit, P2D decision cannot exceed FAIL.

## On-Prem Profile

Primary applicability:
- Architecture requirements 1-13, 17-18
- Authentication requirements 1-20
- Authorization requirements 1-12
- Data Security requirements 1-11
- Auditing requirements 12-19
- Application Security requirements 1-16

Interpretation notes:
- Require internal network segmentation and access boundary controls.
- Treat outside connectivity assumptions as out-of-scope unless a change request modifies baseline.

## Hybrid-Salesforce Profile

Primary applicability:
- Architecture requirements 1-11, 14-18
- Authentication requirements 1-20
- Authorization requirements 1-12
- Data Security requirements 1-11
- Auditing requirements 12-19
- Application Security requirements 1-16

Interpretation notes:
- Require explicit external trust boundaries and endpoint security controls.
- Validate Salesforce authentication and authorization configuration as mandatory scope.

## Required Evidence for Profile Selection

- Project scope summary with deployment model statement
- Environment description identifying internal and external components
- Architecture diagram with trust boundaries
- AppSec reviewer confirmation of selected profile
