---
name: molina-application-security
license: MIT
description: "Automates Molina AppSec Program gate validation and stakeholder workflows for PRE, P2D, and P2B phases using RITM-based remediation tracking and iServe, SonarQube, Wiz, and PAM tool integration. WHEN: \"Molina AppSec\", \"PRE gate\", \"P2D gate\", \"P2B gate\", \"RITM\", \"iServe\", \"SonarQube\", \"AppSec review\", \"security gate\"."
allowed-tools: Read
compatibility: "Designed for Claude Code in Molina Azure DevOps environments. Requires iServe, SonarQube, Wiz, and PAM tool access."
metadata:
  argument-hint: "--project-id ID --gate PRE|P2D|P2B"
  user-invocable: "true"
  author: M.AppSecAgentSkills
  version: "1.1"
---

# Molina Application Security

This skill operationalizes Molina-specific application security governance across 20 gates in three phases:
- `PRE` (prerequisites before development)
- `P2D` (design and architecture security)
- `P2B` (security testing and remediation before release)

## Gotchas

- **SLA clock starts from RITM creation, not from review request.** If a project submits a request on day 1 but the RITM is created on day 3, the SLA started on day 3. Confirm RITM timestamp before calculating deadlines.
- **P2D gate requires architecture evidence BEFORE P2B.** Design review artifacts cannot be backfilled after build. A P2B gate without a passed P2D gate is a hard blocker regardless of test results.
- **Security exception ≠ skip gate.** An exception requires documented risk acceptance with a named risk owner and expiration date. It does not remove the gate or its evidence requirements.
- **OPEN / REMEDIATE / CLOSED are Molina-specific status terms.** Do not translate these to OWASP, CVSS, or SSDF terminology without explicit mapping. CLOSED requires verifiable evidence of remediation, not just a status change.

## How to use this skill

Skill check:
- Before making a decision or asking a question, read this skill and the referenced checklist files.
- Start with [references/appsec-review-process.md](references/appsec-review-process.md) to confirm review triggers, review type, and SLA expectations.
- Use [references/architect-handbook.md](references/architect-handbook.md) to confirm required artifacts, closure criteria, and phase-specific review expectations.
- In your output, include `Skills used: molina-application-security` and the sections you applied.
- Ask follow-up questions only if gate evidence is missing after applying this playbook.

Execution flow:
1. Determine current phase and target gate (`PRE`, `P2D`, or `P2B`).
2. Confirm review trigger, review type, and expected SLA using [references/appsec-review-process.md](references/appsec-review-process.md).
3. Select the architecture baseline profile (`On-Prem` or `Hybrid-Salesforce`) before scoring P2D controls.
4. Validate all required controls for that phase against the checklist and [references/architect-handbook.md](references/architect-handbook.md).
5. Collect evidence artifacts and record status deltas.
6. Flag blockers, assign owners, and propose remediation actions.
7. Correlate findings to SSDF and 218A where applicable.

## Core capabilities

### 1. Security gate validation
- Validate all phase-appropriate Molina gates before promotion.
- Enforce evidence completeness for each gate status.
- Produce a pass/fail decision with explicit blocking criteria.

### 2. Stakeholder workflow orchestration
- Validate that required stakeholders exist and are active.
- Track approvals, pending actions, and escalation timelines.
- Generate role-specific status updates for Business Owner, IT Security, Development, and Compliance.

Stakeholder categories:

| Role | Scope |
|---|---|
| Business Owner | Application business requirements and approval authority |
| IT Security | Architecture review, compliance validation, iServe access |
| Development Team | Implementation responsibility and technical delivery |
| Compliance | Audit readiness and regulatory requirement validation |

### 3. Remediation planning and tracking
- Convert failed gates into remediation tasks with severity and due date.
- Track retest evidence and closure criteria.
- Keep an auditable change trail from detection to closure.

Remediation management workflow:
1. Identify security gaps and violations from tool outputs and gate assessments.
2. Generate prioritized remediation plans with timelines and resource requirements.
3. Track remediation progress with automated status updates and notifications.
4. Validate fix completion through re-testing and verification workflows.
5. Generate compliance reports showing remediation effectiveness and residual risk.

### 4. Tool integration posture checks
- Verify configuration and availability of iServe, SonarQube, Wiz, and PAM.
- Confirm expected outputs (reports, scan IDs, approval logs) are available.
- Mark control as conditional when external systems are unavailable.

### 5. AppSec review tracker operations (RITM-based)
- Use a generic RITM identifier for every review record (example format: `RITM6611559`).
- Track intake, findings, and remediation in [assets/program-tracker.csv](assets/program-tracker.csv) and [assets/remediation-tracker-template.md](assets/remediation-tracker-template.md).
- Keep tracker entries project-neutral in this repository (do not include production-only sensitive details).
- Record control coverage by linking findings to Molina line items and phase-gate control IDs.

### 6. Findings severity and remediation evidence
- For each finding, record source tool/report reference, severity, owner, due date, and status.
- Evidence must include remediation action summary, verifier, verification date, and artifact link.
- If remediation cannot close before gate decision, route through an approval request using [assets/request-for-approval-template.md](assets/request-for-approval-template.md).
- Keep evidence auditable from initial detection through retest and closure.

## Phase gate playbook

### PRE gates (before development)

Required controls:
- `PRE-01`: Application team SharePoint URL provided and IT Security has iServe/SharePoint access.
- `PRE-02`: AppSec review request ticket created in iServe.
- `PRE-03`: Design Authority Review (Enterprise Architecture) complete or scheduled.
- `PRE-04`: Previous AppSec remediation plan for the application reviewed and current.
- `PRE-05`: Stakeholder matrix complete with roles and contact data.
- `PRE-06`: Two (2) application software development security trainings per year completed and current.

Control status reference (required pass/fail table output for PRE line items):

| Control ID | Molina Program Line Item | Status (PASS/CONDITIONAL/FAIL) |
|---|---|---|
| PRE-01 | 1. Lack of Application Team SharePoint URL | <PASS/CONDITIONAL/FAIL> |
| PRE-02 | 2. Lack of AppSec review request ticket in iServe | <PASS/CONDITIONAL/FAIL> |
| PRE-03 | 3.1 Lack of Design Authority Review (Enterprise Architecture) | <PASS/CONDITIONAL/FAIL> |
| PRE-04 | 3.2 Lack of previous AppSec remediation plan for application | <PASS/CONDITIONAL/FAIL> |
| PRE-05 | 4. Lack of stakeholder information | <PASS/CONDITIONAL/FAIL> |
| PRE-06 | 5. Lack of two (2) application software development security trainings per year | <PASS/CONDITIONAL/FAIL> |

Reference checks:
- Confirm the review still qualifies as regular or fast-track using [references/appsec-review-process.md](references/appsec-review-process.md).
- Confirm the Phase 1 artifact set and closure criteria using [references/architect-handbook.md](references/architect-handbook.md).

Validation actions:
1. Confirm all required roles are assigned and active.
2. Verify access provisioning and collaboration workspace readiness.
3. Verify training completion and identify expirations.
4. Record unresolved prerequisites as gate blockers.

Evidence artifacts:
- Stakeholder matrix export
- Access verification records
- Training completion report

### P2D gates (design and architecture)

Priority controls:
- `P2D-04`: Architecture diagram includes security components and trust boundaries.
- `P2D-06`: Data flow diagram defines data classification, encryption, and handling model.
- `P2D-08`: End-to-end OAuth v2+ including last mile to backend services designed and documented.
- `P2D-01` through `P2D-09`: Alignment with all requirement categories in [references/architecture-requirements.md](references/architecture-requirements.md) for the selected baseline profile.

Control status reference (required pass/fail table output for P2D line items):

| Control ID | Molina Program Line Item | Status (PASS/CONDITIONAL/FAIL) |
|---|---|---|
| P2D-01 | 6. Lack of project changes description | <PASS/CONDITIONAL/FAIL> |
| P2D-02 | 7. Lack of environment description | <PASS/CONDITIONAL/FAIL> |
| P2D-03 | 8. Lack of security functionality description for each component | <PASS/CONDITIONAL/FAIL> |
| P2D-04 | 9. Lack of architecture diagram | <PASS/CONDITIONAL/FAIL> |
| P2D-05 | 10. Lack of activity diagram | <PASS/CONDITIONAL/FAIL> |
| P2D-06 | 11. Lack of data flow diagram | <PASS/CONDITIONAL/FAIL> |
| P2D-07 | 12. Lack of sequence diagram | <PASS/CONDITIONAL/FAIL> |
| P2D-08 | 13. Lack of end-to-end OAuth including last mile to backend services | <PASS/CONDITIONAL/FAIL> |
| P2D-09 | 13.1 Lack of open source software management | <PASS/CONDITIONAL/FAIL> |

Validation actions:
1. Confirm baseline profile selection (`On-Prem` or `Hybrid-Salesforce`) and check architecture documentation completeness and security controls.
2. Verify data protection model aligns with Molina data handling expectations.
3. Confirm authentication/authorization patterns and least-privilege posture.
4. Cross-check design against [references/architecture-requirements.md](references/architecture-requirements.md) by category (Architecture, Authentication, Authorization, Data Security, Auditing, Application Security).

Evidence artifacts:
- Approved architecture diagrams
- Data classification and protection design docs
- AuthN/AuthZ design records
- Architecture requirements traceability checklist

### P2B gates (security testing and release readiness)

Priority controls:
- `P2B-01`: Threat modeling diagram updated with remediated threats documented.
- `P2B-03`: SAST completion with critical/high findings remediated.
- `P2B-04`: Software supply chain report completed with findings addressed.
- `P2B-05`: DAST completion for web services and APIs with validated remediation (OWASP ZAP, Burp Suite, or approved commercial tool).
- `P2B-06`: DAST completion for UI with validated remediation.
- `P2B-07`: Application-level penetration testing completed and remediation validated.

Control status reference (required pass/fail table output for P2B line items):

| Control ID | Molina Program Line Item | Status (PASS/CONDITIONAL/FAIL) |
|---|---|---|
| P2B-01 | 14. Lack of remediated threats based on updated threat modeling diagram | <PASS/CONDITIONAL/FAIL> |
| P2B-02 | 15. Lack of changes inventory sheet (UI/Front-end URLs, backend API URLs, and OpenAPI definitions; DevOps repository and CI/CD pipeline evidence) | <PASS/CONDITIONAL/FAIL> |
| P2B-03 | 16. Lack of SAST with CI/CD security testing integration evidence | <PASS/CONDITIONAL/FAIL> |
| P2B-04 | 17. Lack of Software Supply Chain report | <PASS/CONDITIONAL/FAIL> |
| P2B-05 | 18. Lack of DAST - web services and API | <PASS/CONDITIONAL/FAIL> |
| P2B-06 | 19. Lack of DAST - UI | <PASS/CONDITIONAL/FAIL> |
| P2B-07 | 20. Lack of application level penetration testing | <PASS/CONDITIONAL/FAIL> |

Validation actions:
1. Verify scan/test execution and collection of final reports.
2. Ensure unresolved critical/high findings are explicitly accepted or remediated.
3. Verify re-test evidence for remediated issues.
4. Confirm runtime protections (WAF, API security controls, network and application rate limiting, and centralized monitoring) are in place for the deployed profile.
5. Validate DevOps repository and CI/CD security testing path for code changes; fail gate if absent.

Evidence artifacts:
- SonarQube result exports and quality gate status
- DAST and penetration test reports
- Wiz security findings and closure evidence
- WAF/API security configuration proof
- DevOps repository link and CI/CD pipeline security run logs

## Tool-specific integration checks

### iServe
- Stakeholder assignment completeness
- Approval workflow status and pending approvers
- Decision log export for audit
- Review request submitted and tracked according to [references/appsec-review-process.md](references/appsec-review-process.md)
- Ticket assignment, communication logging, and artifact tracking aligned with [references/architect-handbook.md](references/architect-handbook.md)

### SonarQube
- Latest scan status is successful
- Quality gate status meets policy
- No unresolved critical/high security findings

### Wiz
- Latest workload/image scan completed
- High-severity findings triaged and remediated or risk-accepted
- Policy compliance status recorded

### PAM
- Service accounts tracked in PAM
- Credential rotation policy active
- Privileged access governance evidence available

## Gate decision model

Decision outputs:
- `PASS`: all required controls validated and evidenced
- `CONDITIONAL`: minor evidence gaps with approved remediation due dates
- `FAIL`: one or more critical blockers prevent safe progression

Per-control scoring rule:
- Every assessment output must include a phase-appropriate control status table covering all Molina Program line items for that gate.
- A gate-level `PASS` requires no `FAIL` entries in the required table.
- A gate-level `CONDITIONAL` is allowed only when `FAIL` is absent and remediation due dates are documented.
- A gate-level `FAIL` is required when one or more critical controls are marked `FAIL`.

Blocking conditions:
- Missing required stakeholder roles or approvals
- Unresolved critical/high vulnerabilities with no accepted exception
- Missing architecture/security documentation for in-scope gates
- Missing evidence for mandatory controls
- P2D profile not selected when Architecture requirement 12 (On-Prem) and requirement 14 (Hybrid-Salesforce) applicability is ambiguous
- Unmet bold baseline requirements in [references/architecture-requirements.md](references/architecture-requirements.md) without an approved documented exception
- Missing DevOps repository or CI/CD security testing evidence for code changes (Application Security requirement 2; maps to P2B-02 and P2B-03)

## Status normalization model

Use this mapping to keep tracker statuses, lifecycle statuses, and gate decisions consistent:

| Tracker Status | Lifecycle Status | Gate Implication |
|---|---|---|
| `OPEN` | `Open` or `Blocked` | `FAIL` when critical controls remain unresolved |
| `REMEDIATE` | `In Progress` or `Ready for Review` | `CONDITIONAL` when blockers are absent and due dates are approved |
| `CLOSED` | `Closed` | `PASS` when required evidence is validated |

Normalization rules:
1. `OPEN` means remediation work is not complete and cannot be treated as a passing condition.
2. `REMEDIATE` means remediation is active or pending verification; include owner and due date.
3. `CLOSED` requires verifier confirmation and closure evidence link.
4. If any critical control maps to `OPEN`, gate decision cannot exceed `FAIL`.

## AppSec Request for Approval workflow

Use [assets/request-for-approval-template.md](assets/request-for-approval-template.md) when any of the following apply:
- Residual risk must be accepted for a release.
- Remediation is deferred beyond the required gate timeline.
- Conditional progression is requested with outstanding non-closed findings.

Required approval data:
- RITM identifier and project scope
- Findings summary with severity and business impact
- Compensating controls and remediation timeline
- Requested disposition (`approve`, `approve with conditions`, `reject`)
- Approver roles, decision date, and evidence links

## Standard output template

Use this structure in responses and reports:

```markdown
Skills used: molina-application-security (Phase Gate Playbook, Gate Decision Model)

Project: <project-id>
RITM: <ritm-id>
Gate: <PRE|P2D|P2B>
Decision: <PASS|CONDITIONAL|FAIL>
Baseline Profile: <On-Prem|Hybrid-Salesforce|Not Applicable>

Tracker Status Summary:
- OPEN: <count>
- REMEDIATE: <count>
- CLOSED: <count>

Required Control Status Table:

| Control ID | Control Name | Status (PASS/CONDITIONAL/FAIL) |
|---|---|---|
| <control-id> | <molina program line item> | <PASS/CONDITIONAL/FAIL> |

Findings Summary:
| Finding ID | Severity | Tracker Status (OPEN/REMEDIATE/CLOSED) | Owner | Due Date |
|---|---|---|---|---|
| <finding-id> | <critical/high/medium/low> | <OPEN/REMEDIATE/CLOSED> | <owner> | <yyyy-mm-dd> |

Evidence Notes:
- <control-id>: <evidence>

Requirement Category Coverage:
- Architecture: <covered/gap>
- Authentication: <covered/gap>
- Authorization: <covered/gap>
- Data Security: <covered/gap>
- Auditing: <covered/gap>
- Application Security: <covered/gap>

Blockers:
- <control-id>: <reason>

Remediation Actions:
- Owner: <name/role>, Action: <task>, Due: <date>

Cross-Framework Mapping:
- SSDF: <practice IDs>
- 218A: <practice IDs if AI scope>
```

## Cross-framework correlation

Use these mappings to produce unified compliance reporting:
- `PRE-06` -> SSDF `PO.1` (training and awareness)
- `P2D-04` -> SSDF `PS.2` (secure design)
- `P2B-03` -> SSDF `PW.4` (SAST security testing)
- `P2B-05` -> SSDF `PW.4` (DAST security testing)
- `P2B-07` -> SSDF `PW.4` (penetration testing)
- `P2D-08` -> Architecture Requirements `Authorization-01` (OAuth v2 or better)
- `P2B-05`, `P2B-06` -> Architecture Requirements `Application Security-08` (OWASP Top 10 protection expectation)
- `P2D-06` -> 218A `PO.5.1` (data security) for AI projects
- `P2D-08` -> 218A `PS.1.3` (protection controls) for AI projects
- `P2B-03`, `P2B-05`, `P2B-06`, `P2B-07` -> 218A `PW.8` (AI security testing) for AI projects

## Available resources

Primary sources (load only when explicitly needed for the active gate):
- [references/program-checklist.md](references/program-checklist.md) — complete gate control checklist with all 20 line items; read when producing a control status table
- [references/architecture-requirements.md](references/architecture-requirements.md) — architecture baseline categories and requirement references; read when validating any P2D design control or runtime control coverage
- [assets/program-tracker.csv](assets/program-tracker.csv) — RITM-keyed tracker data; read when reporting status or computing gate decisions
- [assets/remediation-tracker-template.md](assets/remediation-tracker-template.md) — remediation tracking template; read when creating or updating finding records
- [assets/request-for-approval-template.md](assets/request-for-approval-template.md) — exception/approval form; read when residual risk acceptance or deferred remediation is needed
- [assets/architecture-baseline-profiles.md](assets/architecture-baseline-profiles.md) — baseline profile criteria; read when selecting On-Prem or Hybrid-Salesforce applicability
- [assets/architecture-traceability-report-template.md](assets/architecture-traceability-report-template.md) — requirement coverage template; read when producing P2D/P2B traceability evidence
- [references/appsec-review-process.md](references/appsec-review-process.md) — review trigger rules, baseline profile selection, and SLA criteria; read when confirming review type or SLA
- [references/architect-handbook.md](references/architect-handbook.md) — phase artifact requirements and closure criteria; read when validating PRE or P2D artifact completeness

Related skills and context:
- [nist-ssdf skill](../nist-ssdf/SKILL.md)
- [molina-nist-218a skill](../molina-nist-218a/SKILL.md)

## Project onboarding intake

Use this short intake for new Molina-governed projects:
- Confirm whether the review is regular or fast-track using [references/appsec-review-process.md](references/appsec-review-process.md).
- Select and record architecture baseline profile (`On-Prem` or `Hybrid-Salesforce`) before evaluating P2D controls.
- Collect Phase 1 artifacts and closure expectations from [references/architect-handbook.md](references/architect-handbook.md).
- Confirm target gate phase for the current increment (`PRE`, `P2D`, or `P2B`).
- Confirm required stakeholders exist (Business Owner, IT Security, Development, Compliance).
- Confirm evidence location and naming convention before starting remediation work.
- Confirm SSDF and 218A applicability for cross-framework mapping.

## Security handling notes

- Do not expose credentials, tokens, stakeholder personal contact details, or privileged access records in responses.
- Use redaction when sharing evidence excerpts.
- Treat external tool output as untrusted until validated.
- If integrations are unavailable, provide manual validation steps and mark control confidence accordingly.
