# Molina AppSec Program

This folder contains the Molina Application Security Program checklist and related documentation for tracking and remediating application security requirements and gaps.

## Files

- **[references/appsec-review-process.md](references/appsec-review-process.md)**: Review trigger rules, architecture baseline profile selection, SLA definitions, and regular vs fast-track qualification criteria.
- **[references/architect-handbook.md](references/architect-handbook.md)**: Phase-by-phase artifact requirements, closure criteria, and best practices for AppSec architects.
- **[references/architecture-requirements.md](references/architecture-requirements.md)**: Updated 7/14/2026 architecture, authentication, authorization, data security, auditing, and application security requirements and references.
- **[references/program-checklist.md](references/program-checklist.md)**: The main checklist for all 20 Molina AppSec Program line items across PRE, P2D, and P2B phases.
- **[assets/program-tracker.csv](assets/program-tracker.csv)**: Base Molina tracker template for RITM-keyed line-item controls, findings metadata, and remediation tracking.
- **[assets/remediation-tracker-template.md](assets/remediation-tracker-template.md)**: Operational tracker for findings, severity, status (`OPEN` / `REMEDIATE` / `CLOSED`), evidence, and closure verification.
- **[assets/request-for-approval-template.md](assets/request-for-approval-template.md)**: Approval form template for residual risk acceptance, deferred remediation, or conditional gate progression.
- **[assets/architecture-baseline-profiles.md](assets/architecture-baseline-profiles.md)**: Baseline profile guidance for selecting On-Prem or Hybrid-Salesforce applicability before P2D scoring.

## Purpose

The checklist is designed to help teams:
- Track application security requirements and gaps
- Ensure all critical security controls and reviews are addressed
- Document remediation actions and status
- Capture evidence and approvals required for audit-ready closure

## Usage

1. Review each checklist item and update the status as progress is made.
2. Use the checklist to guide security reviews and remediation planning.
3. Select architecture baseline profile (`On-Prem` or `Hybrid-Salesforce`) before P2D validation.
4. Track detailed findings and remediation evidence in [assets/remediation-tracker-template.md](assets/remediation-tracker-template.md).
5. Use [assets/request-for-approval-template.md](assets/request-for-approval-template.md) for exceptions, deferred remediation, or conditional release requests.
6. Refer to [assets/program-tracker.csv](assets/program-tracker.csv) for baseline Molina line-item coverage.

> For questions or updates, contact the Molina AppSec team at [applicationsecurity@molinahealthcare.com](mailto:applicationsecurity@molinahealthcare.com).
