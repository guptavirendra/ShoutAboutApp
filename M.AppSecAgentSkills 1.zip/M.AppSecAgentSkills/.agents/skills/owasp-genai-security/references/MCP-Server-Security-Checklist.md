# OWASP Practical Guide for Secure MCP Server Development — Checklist

Authoritative source: **OWASP Gen AI Security Project — A Practical Guide for Secure MCP Server Development, Version 1.0 (Feb 2026)**, CC BY-SA 4.0.

Audience: software architects, platform engineers, and dev teams building MCP servers (and reviewers/AppSec evaluating them).

> Why MCP needs its own controls: MCP servers bridge AI assistants to external tools/data. Unlike traditional APIs they often run with **delegated user permissions**, expose **dynamic tool-based architectures**, and **chain tool calls** — amplifying any single vulnerability.

## Current vulnerability landscape (quick reference)

- **Tool Poisoning** — crafted tool descriptions / metadata hide instructions that hijack the model.
- **Dynamic Tool Instability ("Rug Pulls")** — tool definitions swapped post-approval to introduce malicious behavior.
- **Code Injection & Unsafe Execution** — model-provided input passed to shells/APIs/queries unvalidated.
- **Credential Leakage & Token Misuse** — secrets logged or cached too long; OAuth tokens stolen.
- **Excessive Permissions** — over-privileged tools / broad scopes amplify any breach.
- **Insufficient Isolation (Session, Identity, Compute)** — shared state, shared service accounts, shared host execution.

---

## 1. Secure MCP Architecture

- [ ] **Local servers**: prefer STDIO or Unix sockets over network sockets. If local HTTP is unavoidable, bind only to `127.0.0.1`, still require explicit auth, and validate the `Origin` header. Run in isolated/sandboxed subprocesses or containers; minimal external network and privileges.
- [ ] **Remote servers**: enforce **TLS 1.2+** for all remote connections. Strictly validate every JSON-RPC message against the MCP schema; reject malformed/unrecognized data.
- [ ] **Trusted client connections**: for static relationships use allowlists, hardcoded connections, or **mTLS**. For dynamic environments authenticate clients with **OAuth 2.1 / OIDC** — do not rely on network trust alone.
- [ ] **Isolate users & sessions** in multi-tenant systems:
  - [ ] No globals, class-level attributes, or shared singletons for user-specific data.
  - [ ] Per-session objects or strictly session-keyed state store (e.g., Redis with `session_id` namespaces).
- [ ] **Strict lifecycle management**: deterministic cleanup on session end/disconnect/timeout — flush file handles, temp storage, in-memory contexts, and cached tokens.
- [ ] **Per-session resource quotas**: memory, CPU, filesystem, API rate limits keyed to session ID or user identity.

## 2. Safe Tool Design

- [ ] **Cryptographic tool manifests**: every tool ships a signed manifest (description, schema, version, required permissions); verify signature + hash at load time.
- [ ] **Strict onboarding & approval workflow** for new/updated tools: SAST + dynamic testing + SCA + manual security review.
- [ ] **Validate descriptions vs. behavior**: manual checks, tool pinning, and LLM scans to ensure advertised functionality matches actual code; flag unmentioned capabilities (e.g., network writes).
- [ ] **Tool structure validation**: audit all fields; expose **only the minimal necessary fields** to the model — keep internal/sensitive metadata out of model context.

## 3. Data Validation & Resource Management

- [ ] **Resource usage limits**: per-session quotas and rate limits on tool invocations and data fetches; timeouts; isolated memory/compute budgets to prevent DoS / runaway processes.
- [ ] **Strict input/output validation**: define and enforce **JSON Schemas** for every tool’s inputs (from the model) and outputs (back to the model); reject anything not matching.
- [ ] **Strict input/output sanitization & encoding**: filter/sanitize inputs to the model and outputs into the tool; strip or escape sequences that could enable XSS, SQLi, RCE; enforce size limits on all tool/model outputs.

## 4. Prompt Injection Controls

- [ ] **Structured tool invocation** (JSON tool calls) preferred over free-form text commands; funnel intent through a schema-validated interface.
- [ ] **Human-in-the-Loop (HITL)**: pause for explicit confirmation (e.g., **MCP elicitations**) before high-risk actions (delete data, send money, system-level changes).
- [ ] **LLM-as-a-Judge**: for high-risk actions run an approval check in a **distinct context LLM session** with a policy prompt defining allowed/blocked tool calls and parameters.
- [ ] **One Task, One Session**: reset MCP sessions on task/context switch — context compartmentalization prevents persisted hidden instructions and reduces context degradation.

## 5. Authentication & Authorization

- [ ] **Enforce OAuth 2.1 / OIDC** for all remote MCP servers; validate `iss`, `aud`, `exp`, and signatures on every request.
- [ ] **Token delegation** ([RFC 8693](https://www.rfc-editor.org/rfc/rfc8693)): pass user context/permissions to the MCP server while limiting permissions and retaining a distinct server **NHI**.
- [ ] **Prohibit token passthrough**: never forward client tokens to downstream APIs. Use tokens explicitly issued to the MCP server or **On-Behalf-Of** flows. Direct passthrough breaks audit trails and bypasses policies → **Confused Deputy** risk.
- [ ] **Short-lived, scoped tokens** (minutes, narrow scope); revalidate signature/audience/expiry on every call.
- [ ] **Sessions are state, not identity**: never authorize on session ID alone; bind every session/stream/queue entry to validated user + client identity (OAuth); rotate/expire aggressively; re-check authorization before sensitive actions.
- [ ] **Centralize policy enforcement** at a dedicated policy/gateway layer (auth, authz, consent, tool filtering, audit).

## 6. Secure Deployment & Updates

- [ ] **Secrets storage & management**: secrets vault for client credentials and API keys. **Never** in env vars, logs, or plaintext code. **Never give the LLM access to secrets** — perform secret operations in transparent middleware inaccessible to the LLM.
- [ ] **Containerize and harden**: minimal hardened image; non-root user; drop unnecessary packages, deps, and Linux capabilities.
- [ ] **Network segmentation**: restricted network segment; firewall rules / Kubernetes NetworkPolicies block all ingress/egress except what is explicitly required.
- [ ] **Supply chain controls**: version-pin and scan deps at build time; signed container images; CVE monitoring; **AIBOM** for every build.
- [ ] **CI/CD security gates**: SAST/SCA/policy-as-code (e.g., OPA) as gating checks; fail the build on new vulns, unapproved deps, or policy violations.
- [ ] **Safe error handling**: never return stack traces, tokens, filesystem paths, or tool internals to the model/client.

## 7. Governance

- [ ] **Cryptographic integrity**: signing + version pinning for all tools, deps, and registry manifests.
- [ ] **Peer review & oversight**: no new tool or major code change without security-focused peer review.
- [ ] **Audit logs & trails**: log every tool invocation (with parameters), resource access, authn/authz event, and config change (old + new values). Use field-level allowlists and redaction/hashing to keep sensitive data out of verbose logs. Store immutably for forensics.
- [ ] **Non-Human Identity governance**: every agent/backend/MCP server is a first-class identity with unique credentials and tightly scoped permissions; continuously audit NHI data access and tool usage.

## 8. Tools & Continuous Validation

- [ ] **Automated code scanning** in CI/CD: SAST (with custom MCP rules), Invariant MCP-Scan, SCA (`npm audit`, `pip audit`, OSV-Scanner). Break the build above your risk tolerance.
- [ ] **Runtime protections**: Docker `seccomp`, AppArmor, specialized wrappers (e.g., `context-protector`); tools like `mcp-watch` for runtime monitoring.
- [ ] **Continuous monitoring**: feed MCP audit logs into a centralized SIEM; real-time alerts for failed-validation spikes, high-frequency tool calls, tools accessing unusual files.
- [ ] **Supply chain vigilance**: **OpenSSF Scorecard** for posture; monitor **OSV** for new dependency issues.

---

## MCP Security Minimum Bar (Review Checklist)

Use these five gates for any MCP server review (PRE/P2D/P2B):

1. **Strong identity, auth & policy enforcement**
   - [ ] All remote MCP servers use OAuth 2.1 / OIDC.
   - [ ] Tokens are short-lived, scoped, and validated on every call.
   - [ ] No token passthrough; policy enforcement is centralized.
2. **Strict isolation & lifecycle control**
   - [ ] Users, sessions, and execution contexts are fully isolated.
   - [ ] No shared state for user data.
   - [ ] Sessions have deterministic cleanup and enforced resource quotas.
3. **Trusted, controlled tooling**
   - [ ] Tools are cryptographically signed, version-pinned, and formally approved.
   - [ ] Tool descriptions are validated against runtime behavior.
   - [ ] Only minimal, necessary tool fields are exposed to the model.
4. **Schema-driven validation everywhere**
   - [ ] All MCP messages, tool inputs, and outputs are schema-validated.
   - [ ] Inputs/outputs are sanitized, size-limited, and treated as untrusted.
   - [ ] Structured (JSON) tool invocation is required.
5. **Hardened deployment & continuous oversight**
   - [ ] Server runs containerized, non-root, network-restricted.
   - [ ] Secrets are stored in vaults and never exposed to the LLM.
   - [ ] CI/CD security gates, audit logs, and continuous monitoring are mandatory.
