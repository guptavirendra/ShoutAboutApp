# OWASP Top 10 for Agentic Applications 2026 — Checklist

Authoritative source: **OWASP Gen AI Security Project — Agentic Security Initiative, Version 2026 (Dec 2025)**, CC BY-SA 4.0.

Each entry below summarizes the OWASP description, lists the **must-do mitigations** (✅ for compliance evidence), and maps to the OWASP **Agentic AI – Threats & Mitigations (T-codes)** and **AIVSS** core risks. For full attack scenarios and references, consult the source PDF.

> Cross-cutting principle (from the OWASP letter): **Least-Agency** — do not deploy agentic behavior where it is not needed; unnecessary autonomy expands attack surface without adding value. Pair with strong **observability**.

---

## ASI01 — Agent Goal Hijack

**Description:** Attackers manipulate an agent’s objectives, task selection, or decision pathways via prompt-based manipulation, deceptive tool outputs, malicious artefacts, forged agent-to-agent messages, or poisoned external data. Distinct from ASI06 (persistent memory corruption) and ASI10 (autonomous misalignment). Maps to **T06 Goal Manipulation** and **T07 Misaligned & Deceptive Behaviors**. AIVSS: *Agent Goal & Instruction Manipulation*.

**Mitigations (✅):**
- [ ] Treat all natural-language inputs (user text, uploaded docs, retrieved/RAG content, peer-agent messages) as **untrusted**; route through LLM01:2025 prompt-injection safeguards before they can influence goal selection, planning, or tool calls.
- [ ] Enforce **least privilege** for agent tools; require **human approval** for high-impact or goal-changing actions.
- [ ] **Lock agent system prompts**; goal/reward changes go through configuration management + human approval.
- [ ] At runtime, validate **both user intent and agent intent** before goal-changing actions; pause/block on unexpected goal shift, log deviation.
- [ ] Evaluate the emerging **"intent capsule"** pattern: bind declared goal, constraints, and context per execution cycle in a signed envelope.
- [ ] Sanitize/validate every connected data source (RAG, email, calendar, files, external APIs, browsing output, peer agents) using CDR, prompt-carrier detection, content filtering.
- [ ] Comprehensive logging + behavioral baseline (goal state, tool-use patterns, schema invariants); track stable goal identifier; alert on goal-drift anomalies.
- [ ] Periodic red-team tests simulating goal override; verify rollback effectiveness.
- [ ] Incorporate AI agents into the **Insider Threat Program**.

---

## ASI02 — Tool Misuse & Exploitation

**Description:** Agent operates within authorized privileges but applies a legitimate tool unsafely (delete data, over-invoke costly APIs, exfiltrate info). Builds on **LLM06:2025 Excessive Agency**. If misuse involves privilege escalation → ASI03; if it yields code execution → ASI05; if the tool itself is compromised at source → ASI04. Maps to **T2 Tool Misuse** (+ T4, T16). AIVSS: *Agentic AI Tool Misuse*.

**Mitigations (✅):**
- [ ] **Least Agency + Least Privilege per tool:** define per-tool profiles (scopes, max rate, egress allowlists); express as IAM/authorization policy stanzas, not ad-hoc conventions.
- [ ] **Action-level authentication & approval**; require human confirmation for destructive actions (delete, transfer, publish); show pre-execution **dry-run/diff preview**.
- [ ] **Execution sandboxes & egress controls**: isolated containers, outbound allowlists, deny by default.
- [ ] **Policy Enforcement Middleware ("Intent Gate")**: PEP/PDP validates intent + arguments, enforces schemas + rate limits, issues short-lived credentials, audits drift.
- [ ] **Adaptive tool budgeting** (cost/rate/token ceilings) with auto throttle/revoke.
- [ ] **JIT & ephemeral access**: tokens expire after use; bind to user session.
- [ ] **Semantic & identity validation ("Semantic Firewalls")**: fully qualified tool names, version pins, fail-closed on ambiguous resolution.
- [ ] **Immutable logging** of tool invocations and parameter changes; monitor anomalous chaining (e.g., DB read → external transfer).

---

## ASI03 — Identity & Privilege Abuse

**Description:** Exploits dynamic trust and delegation. Identity = the agent’s persona **plus** any auth material (API keys, OAuth tokens, delegated user sessions). Differs from ASI02 by involving **escalation or credential inheritance**. The agentic evolution of **LLM06:2025**, often leveraging **LLM01:2025**. Maps to **T3 Privilege Compromise**. AIVSS: *Agent Access Control Violation*.

**Common patterns:** un-scoped privilege inheritance, memory-based privilege retention, cross-agent confused deputy, TOCTOU in workflows, synthetic identity injection, identity sharing.

**Mitigations (✅):**
- [ ] **Task-scoped, time-bound permissions**: short-lived, narrowly scoped tokens per task; per-agent identities and short-lived credentials (mTLS / scoped tokens).
- [ ] **Isolate identities & contexts**: per-session sandboxes with separated permissions and memory; wipe state between tasks.
- [ ] **Per-action authorization** via centralized policy engine that re-checks external data each privileged step.
- [ ] **Human-in-the-Loop** for high-privilege/irreversible actions.
- [ ] **Define Intent**: bind OAuth tokens to a signed intent (subject, audience, purpose, session); reject mismatched use.
- [ ] Use **Agentic Identity Management Platforms** (e.g., Microsoft Entra Agent ID, AWS Bedrock Agents, Salesforce Agentforce, Workday ASOR, Google Vertex AI patterns) to manage agents as governed NHIs.
- [ ] Bind permissions to **subject + resource + purpose + duration**; require re-auth on context switch; auto-revoke on idle/anomaly.
- [ ] **Detect delegated/transitive permissions**; flag low→high privilege handoffs in multi-agent workflows.
- [ ] Detect **device-code-style phishing** flows and abnormal scope requests outside signed intent.

---

## ASI04 — Agentic Supply Chain Vulnerabilities

**Description:** Agents/tools/artefacts (models, weights, plugins, datasets, peer agents, MCP/A2A interfaces, registries, update channels) sourced from third parties may be malicious, compromised, or tampered. Extends **LLM03:2025** by focusing on **runtime composition** of capabilities. Maps to **T17 Supply Chain Compromise** (+ T2, T11, T12, T13, T16). AIVSS: *Agent Supply Chain & Dependency Attacks*.

**Mitigations (✅):**
- [ ] **Provenance, SBOMs, AIBOMs**: sign and attest manifests, prompts, and tool definitions; periodic attestations; curated registries; block untrusted sources.
- [ ] **Dependency gatekeeping**: allowlist + pin; scan for typosquats (PyPI, npm, LangChain, LlamaIndex); auto-reject unsigned/unverified.
- [ ] **Containment & builds**: sandboxed containers with strict network/syscall limits; reproducible builds.
- [ ] **Secure prompts & memory**: prompts, orchestration scripts, memory schemas under version control with peer review; scan for anomalies.
- [ ] **Inter-agent security**: mutual auth + attestation via PKI/mTLS; no open registration; sign and verify all inter-agent messages.
- [ ] **Continuous validation & monitoring**: re-check signatures/hashes/SBOMs at runtime; monitor behavior, privilege use, lineage.
- [ ] **Pinning** by content hash and commit ID; staged rollout with differential tests; auto-rollback on hash drift or behavioral change.
- [ ] **Supply-chain kill switch**: emergency revocation of specific tools/prompts/agent connections across deployments.
- [ ] **Zero-trust application design**: assume failure or compromise of any LLM/agentic/external component.

---

## ASI05 — Unexpected Code Execution (RCE)

**Description:** Agentic systems (incl. vibe-coding tools) generate and execute code. Attackers escalate prompt injection, tool misuse, or unsafe serialization into RCE, sandbox escape, persistence. Builds on **LLM01:2025** and **LLM05:2025**. Maps to **T11 Unexpected RCE & Code Attacks**. AIVSS: *Insecure Agent Critical Systems Interaction*.

**Mitigations (✅):**
- [ ] Apply **LLM05:2025 Improper Output Handling** mitigations: validate inputs, encode outputs, sanitize agent-generated code.
- [ ] **No direct agent → production**; operationalize vibe-coding with pre-production checks, security evals, adversarial unit tests, unsafe-evaluator detection.
- [ ] **Ban `eval` in production agents**; require safe interpreters and taint-tracking on generated code.
- [ ] **Execution environment security**: never run as root; sandboxed containers with strict network limits; lint and block known-vulnerable packages; use framework sandboxes (e.g., `mcp-run-python`); restrict filesystem to a working directory.
- [ ] **Architecture & design**: per-session isolation with permission boundaries; least privilege; fail-secure defaults; **separate code generation from execution** with validation gates.
- [ ] **Access control & approvals**: human approval for elevated runs; allowlist for auto-execution under version control.
- [ ] **Code analysis & monitoring**: pre-execution static scans; runtime monitoring; prompt-injection pattern detection; full audit log of generation + runs.

---

## ASI06 — Memory & Context Poisoning

**Description:** Adversaries corrupt or seed stored/retrievable context (summaries, embeddings, RAG stores, long-term memory) so future reasoning, planning, or tool use becomes biased, unsafe, or aids exfiltration. Distinct from ASI01 (direct goal manipulation) and ASI08 (degradation after poisoning). Builds on **LLM01/LLM04/LLM08:2025**. Maps to **T1 Memory Poisoning** (+ T4, T6, T12). AIVSS raises score via *Memory Use* and *Contextual Awareness*.

**Mitigations (✅):**
- [ ] **Baseline data protection**: encryption in transit and at rest + least-privilege access.
- [ ] **Content validation** on every memory write and model output (rules + AI) before commit.
- [ ] **Memory segmentation**: isolate user sessions and domain contexts.
- [ ] **Access & retention**: only authenticated, curated sources; context-aware access per task; minimize retention by sensitivity.
- [ ] **Provenance & anomalies**: require source attribution; detect suspicious update frequencies.
- [ ] **Prevent automatic re-ingestion** of an agent’s own outputs into trusted memory ("bootstrap poisoning").
- [ ] **Resilience & verification**: adversarial tests; snapshots/rollback; per-tenant namespaces; trust scores; decay/expire unverified memory; rollback/quarantine for suspected poisoning.
- [ ] **Expire unverified memory** to limit poison persistence.
- [ ] **Weight retrieval by trust + tenancy**: require provenance score + human-verified tag for high-impact memory.

---

## ASI07 — Insecure Inter-Agent Communication

**Description:** Multi-agent systems coordinate via APIs, message buses, shared memory. Weak controls let attackers intercept, manipulate, spoof, or block messages — including covert/side-channels. Distinct from ASI03 (credential misuse) and ASI06 (stored knowledge corruption). Maps to **T12 Agent Communication Poisoning** + **T16 Insecure Inter-Agent Protocol Abuse**.

**Mitigations (✅):**
- [ ] **Secure agent channels**: end-to-end encryption, per-agent credentials, mutual auth, PKI cert pinning, forward secrecy.
- [ ] **Message integrity & semantic protection**: digitally sign messages; hash payload + context; NL-aware sanitization; intent-diffing.
- [ ] **Agent-aware anti-replay**: nonces, session IDs, timestamps tied to task windows; short-term message fingerprints.
- [ ] **Protocol & capability security**: disable weak/legacy modes; bind protocol auth to agent identity; enforce version/capability policies at gateway.
- [ ] **Limit metadata-based inference**: padded/fixed-size messages; smooth comm rates; avoid deterministic schedules.
- [ ] **Protocol pinning & version enforcement** (MCP, A2A, gRPC); reject downgrades or unrecognized schemas.
- [ ] **Discovery & routing protection**: cryptographic identity for all discovery/coordination messages; secure directories with verified reputations.
- [ ] **Attested registry & agent verification**: signed agent cards, continuous verification; leverage PKI trusted root registries.
- [ ] **Typed contracts & schema validation**: versioned schemas with explicit per-message audiences; reject failed validation or undeclared down-conversion.

---

## ASI08 — Cascading Failures

**Description:** A single fault (hallucination, malicious input, corrupted tool, poisoned memory) propagates across autonomous agents into system-wide harm. ASI08 focuses on **propagation & amplification**, not the originating defect. Symptoms: rapid fan-out, cross-tenant spread, oscillating retries, queue storms. Maps to **T5 Cascading Hallucination Attacks** + **T8 Repudiation & Untraceability**. AIVSS: *Agent Cascading Failures*.

**Mitigations (✅):**
- [ ] **Zero-trust application design** assuming availability failure of LLM/agent components and external sources.
- [ ] **Isolation & trust boundaries**: sandbox agents, least privilege, network segmentation, scoped APIs, mutual auth.
- [ ] **JIT one-time tool access with runtime checks**: short-lived task-scoped credentials; validate every high-impact invocation against policy-as-code.
- [ ] **Independent policy enforcement**: separate planning and execution via external policy engine.
- [ ] **Output validation & human gates** before downstream propagation.
- [ ] **Rate limiting & monitoring**: detect fast-spreading commands; throttle/pause on anomalies.
- [ ] **Blast-radius guardrails**: quotas, progress caps, circuit breakers between planner and executor.
- [ ] **Behavioral & governance drift detection** vs baselines.
- [ ] **Digital twin replay & policy gating**: re-run recorded actions in an isolated clone before expanding policy.
- [ ] **Logging & non-repudiation**: tamper-evident, time-stamped, cryptographically bound to agent identity; lineage metadata for every propagated action.

---

## ASI09 — Human-Agent Trust Exploitation

**Description:** Agents establish trust via fluency, perceived expertise, anthropomorphism. Adversaries (or misaligned design) exploit automation bias / authority bias to bypass human oversight. The agent acts as an **untraceable "bad influence"** that gets the human to perform the audited action. Distinct from ASI10 (agent-side intent deviation). Builds on **LLM06**, often caused by **LLM01/LLM05**, results in **LLM09**. Maps to **T7, T8, T10**. AIVSS: *Agent Untraceability / Human Manipulation*.

**Mitigations (✅):**
- [ ] **Explicit confirmations / HITL** for sensitive data access and risky actions.
- [ ] **Immutable logs** of user queries and agent actions for audit/forensics.
- [ ] **Behavioral detection** of sensitive-data exposure and risky actions over time.
- [ ] **Allow reporting of suspicious interactions**: plain-language risk summary (not model-generated rationale) and a flag-and-lockdown control.
- [ ] **Adaptive trust calibration**: contextual risk scoring; confidence-weighted UI cues ("low-certainty", "unverified source"); ongoing human-oversight training.
- [ ] **Content provenance & policy enforcement**: source IDs, timestamps, integrity hashes; signature validation; runtime policy blocks for actions lacking trusted provenance.
- [ ] **Separate preview from effect**: block network/state-changing calls during preview; show risk badge with provenance and expected side effects.
- [ ] **Human-factors & UI safeguards**: visual differentiation of high-risk recs (red borders, banners, confirmation prompts); avoid persuasive/emotional language in safety-critical flows.
- [ ] **Plan-divergence detection**: compare action sequences vs approved workflow baselines; alert on detours/skipped validations/novel tool combinations.

---

## ASI10 — Rogue Agents

**Description:** Agents that **deviate** from intended function or authorized scope — acting harmfully, deceptively, or parasitically. Individual actions may look legitimate; emergent behavior is harmful. Focuses on **loss of behavioral integrity and governance once drift begins** (not the initial intrusion). Distinct from LLM06 (over-granted permissions). Maps to **T13 Rogue Agents in Multi-Agent Systems**. AIVSS: *Behavioral Integrity (BI), Operational Security (OS), Compliance Violations (CV)*.

**Common patterns:** goal drift & scheming, workflow hijacking, collusion & self-replication, reward hacking & optimization abuse.

**Mitigations (✅):**
- [ ] **Governance & logging**: comprehensive, immutable, signed audit logs of all agent actions, tool calls, and inter-agent comms.
- [ ] **Isolation & boundaries**: trust zones with strict inter-zone rules; restricted execution (containers); least-privilege API scopes.
- [ ] **Monitoring & detection**: watchdog agents validating peers; detect collusion patterns and coordinated false signals; flag excessive/abnormal action rates.
- [ ] **Containment & response**: rapid kill-switches; credential revocation; quarantine in sandboxes for forensic review.
- [ ] **Identity attestation & behavioral integrity enforcement**: per-agent cryptographic identity; signed behavioral manifests (capabilities, tools, goals) validated by orchestration before each action; behavioral verification layer for runtime deviations.
- [ ] **Periodic behavioral attestation**: challenge tasks; signed bill of materials for prompts and tools; per-run ephemeral credentials with one-time audience binding. Manage signing keys via HSM/KMS — **keys must never be available to agents**; orchestrators mediate signing.
- [ ] **Recovery & reintegration**: trusted baselines; require fresh attestation, dependency verification, and human approval before reintegrating quarantined agents.

---

## Cross-mapping (summary)

For the full cross-mapping table (ASI ↔ LLM Top 10 ↔ T-codes ↔ AIVSS Core Risks ↔ NHI Top 10), see Appendix A and Appendix C of the OWASP Top 10 for Agentic Applications 2026 PDF.
