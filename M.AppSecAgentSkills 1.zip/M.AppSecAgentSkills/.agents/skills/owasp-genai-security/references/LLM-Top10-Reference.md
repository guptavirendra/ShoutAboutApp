# OWASP Top 10 for LLM Applications 2025 — Reference

Authoritative source: **OWASP Gen AI Security Project — Top 10 for LLM Applications, 2025**, CC BY-SA 4.0.
Canonical site: <https://genai.owasp.org/llm-top-10/>.

This file is a **reference index**, not a re-publication. It captures each entry’s short description and pre-mapped pointers into the [Agentic-Top10-Checklist.md](Agentic-Top10-Checklist.md) and [MCP-Server-Security-Checklist.md](MCP-Server-Security-Checklist.md) so reviewers can apply consistent mitigations across model, agent, and MCP layers.

> Use this when scoping a **plain LLM / RAG application** or when you need to anchor an Agentic/MCP finding back to its model-layer root cause.

| ID | Risk | Short description | Apply controls from |
|----|------|-------------------|---------------------|
| LLM01:2025 | Prompt Injection | Untrusted text manipulates a single model response. | [ASI01](Agentic-Top10-Checklist.md#asi01-agent-goal-hijack), [ASI06](Agentic-Top10-Checklist.md#asi06-memory--context-poisoning), MCP [§3](MCP-Server-Security-Checklist.md#3-data-validation--resource-management), [§4](MCP-Server-Security-Checklist.md#4-prompt-injection-controls) |
| LLM02:2025 | Sensitive Information Disclosure | Model reveals secrets, PII, or proprietary data via outputs or system-prompt leakage. | [ASI03](Agentic-Top10-Checklist.md#asi03-identity--privilege-abuse), [ASI10](Agentic-Top10-Checklist.md#asi10-rogue-agents), MCP [§3](MCP-Server-Security-Checklist.md#3-data-validation--resource-management), [§7](MCP-Server-Security-Checklist.md#7-governance) |
| LLM03:2025 | Supply Chain Vulnerabilities | Compromise via models, weights, datasets, plugins, or third-party deps. | [ASI04](Agentic-Top10-Checklist.md#asi04-agentic-supply-chain-vulnerabilities), MCP [§6](MCP-Server-Security-Checklist.md#6-secure-deployment--updates), [§8](MCP-Server-Security-Checklist.md#8-tools--continuous-validation) |
| LLM04:2025 | Data & Model Poisoning | Training/fine-tuning/RAG data tampered to bias outputs or plant backdoors. | [ASI06](Agentic-Top10-Checklist.md#asi06-memory--context-poisoning), [ASI08](Agentic-Top10-Checklist.md#asi08-cascading-failures), [218A skill](../nist-218a/SKILL.md) |
| LLM05:2025 | Improper Output Handling | Downstream systems trust model output (XSS, SQLi, RCE via templated output). | [ASI05](Agentic-Top10-Checklist.md#asi05-unexpected-code-execution-rce), MCP [§3](MCP-Server-Security-Checklist.md#3-data-validation--resource-management) |
| LLM06:2025 | Excessive Agency | Model granted too much autonomy or too many capabilities. | [ASI02](Agentic-Top10-Checklist.md#asi02-tool-misuse--exploitation), [ASI03](Agentic-Top10-Checklist.md#asi03-identity--privilege-abuse), [ASI10](Agentic-Top10-Checklist.md#asi10-rogue-agents), MCP [§2](MCP-Server-Security-Checklist.md#2-safe-tool-design), [§5](MCP-Server-Security-Checklist.md#5-authentication--authorization) |
| LLM07:2025 | System Prompt Leakage | System prompts disclosed, enabling jailbreaks/policy bypass. | [ASI01](Agentic-Top10-Checklist.md#asi01-agent-goal-hijack), [ASI03](Agentic-Top10-Checklist.md#asi03-identity--privilege-abuse) |
| LLM08:2025 | Vector & Embedding Weaknesses | Embedding-store poisoning, cross-tenant bleed, retrieval manipulation. | [ASI06](Agentic-Top10-Checklist.md#asi06-memory--context-poisoning) |
| LLM09:2025 | Misinformation | Hallucinations / unverifiable outputs treated as authoritative. | [ASI09](Agentic-Top10-Checklist.md#asi09-human-agent-trust-exploitation) |
| LLM10:2025 | Unbounded Consumption | Cost / token / resource exhaustion (DoW, runaway loops). | [ASI02](Agentic-Top10-Checklist.md#asi02-tool-misuse--exploitation), [ASI08](Agentic-Top10-Checklist.md#asi08-cascading-failures), MCP [§3](MCP-Server-Security-Checklist.md#3-data-validation--resource-management) |

## Reviewer guidance

When you find an LLM Top 10 issue in an agentic system, **always** check the corresponding ASI entry — agent autonomy typically amplifies the impact (e.g., a single LLM01 prompt injection becomes ASI01 multi-step goal hijack with tool execution). When the system exposes MCP tools, also check the MCP §-references above.

For full descriptions, attack scenarios, and references for each LLM entry, consult the canonical OWASP document at <https://genai.owasp.org/llm-top-10/>.
