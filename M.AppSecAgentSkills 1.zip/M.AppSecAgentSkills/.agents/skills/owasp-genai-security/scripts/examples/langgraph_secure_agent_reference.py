"""
LangGraph Secure Agent Reference Implementation
Aligned to OWASP GenAI Security (ASI02, ASI03, ASI08, ASI10) and MCP §2, §3, §5, §7.

This module demonstrates a 12-node secure orchestration architecture for LangChain/LangGraph agents
with least-agency, least-privilege, human-in-the-loop, and immutable audit controls.

Controls mapped:
- ASI02 (Tool Misuse): capability_guard, arg_validator, approval_gate, budget_guard
- ASI03 (Privilege Abuse): policy_decision_point, jit_token_broker, ingress_guard
- ASI08 (Cascading Failures): budget_guard, kill_switch
- ASI10 (Rogue Agents): audit_logger, kill_switch, monitoring
- MCP §2 (Safe Tool Design): tool registry, signed manifests
- MCP §3 (Data Validation): arg_validator, post_execution_validator
- MCP §5 (Auth): jit_token_broker, policy_decision_point
- MCP §7 (Governance): audit_logger, kill_switch

Architecture:
    START
      ↓
    ingress_guard (validate caller, session)
      ↓
    intent_classifier (constrained taxonomy)
      ↓
    capability_guard (minimal tool allowlist per intent)
      ↓
    policy_decision_point (PDP: subject + resource + purpose + risk)
      ↓ (on deny)
    audit_logger
      ↓ (on deny)
    END
      ↓ (on allow)
    arg_schema_validator (strict pydantic validation)
      ↓
    approval_gate (human approval for high-risk)
      ↓
    jit_token_broker (scoped short-lived tokens)
      ↓
    tool_executor (sandboxed execution)
      ↓
    post_execution_validator (response schema/safety)
      ↓
    budget_guard (per-session quota enforcement)
      ↓
    audit_logger (immutable signed events)
      ↓
    kill_switch (circuit breaker, optional abort)
      ↓
    END

Security invariants enforced:
1. Default deny on all gates.
2. No shared secrets in graph state; token references only.
3. Every decision point emits signed audit event.
4. High-risk paths require dual control (policy + human).
5. All tool args validated against strict schema.
6. Per-session budgets prevent cascading failures.
7. Token TTL << tool operation time; never reuse credentials.
"""

import uuid
import time
from datetime import datetime, timedelta
from typing import Annotated, TypedDict, Literal, Optional, Dict, Any, List
from enum import Enum
from dataclasses import dataclass, asdict
import json
import hashlib

from pydantic import BaseModel, Field, ValidationError, field_validator
from langchain_core.tools import tool
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.types import Command


# ============================================================================
# ENUMS & TYPES
# ============================================================================

class Intent(str, Enum):
    READ_DATA = "read_data"
    UPDATE_RECORD = "update_record"
    TRANSFER_FUNDS = "transfer_funds"
    ADMIN_ACTION = "admin_action"


class RiskTier(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ============================================================================
# STATE SCHEMA (extends MessagesState with security context)
# ============================================================================

class SecureAgentState(MessagesState):
    """Extended state with security, policy, audit, and budget tracking.
    
    MessagesState provides:
    - messages: List[BaseMessage]  (inherited)
    
    Security context added:
    - user_id, session_id, tenant_id, trace_id
    - intent, approved_tools, requested_tool, tool_args
    - risk_tier, requires_approval, approval_id
    - policy_decision_id, scoped_token_ref
    - budget tracking (calls, tokens, cents, fanout)
    - audit events and error handling
    """
    user_id: str = ""
    session_id: str = ""
    tenant_id: str = ""
    trace_id: str = ""
    
    intent: Optional[Literal["read_data", "update_record", "transfer_funds", "admin_action"]] = None
    approved_tools: List[str] = Field(default_factory=list)
    requested_tool: str = ""
    tool_args: Dict[str, Any] = Field(default_factory=dict)
    
    risk_tier: RiskTier = RiskTier.LOW
    requires_approval: bool = False
    approval_id: Optional[str] = None
    policy_decision_id: Optional[str] = None
    scoped_token_ref: Optional[str] = None
    
    budget_calls: int = 0
    budget_tokens: int = 0
    budget_cents: int = 0
    fanout_count: int = 0
    
    audit_events: List[Dict[str, Any]] = Field(default_factory=list)
    error_message: Optional[str] = None


# ============================================================================
# TOOL SCHEMAS (strict input validation)
# ============================================================================

class GetBalanceArgs(BaseModel):
    account_id: str = Field(min_length=8, max_length=64, description="Account ID")
    
    @field_validator("account_id")
    @classmethod
    def validate_account_id(cls, v):
        if not v.isalnum():
            raise ValueError("account_id must be alphanumeric")
        return v


class UpdateAddressArgs(BaseModel):
    customer_id: str = Field(min_length=8, max_length=64)
    street: str = Field(max_length=256)
    city: str = Field(max_length=128)
    state: str = Field(max_length=2)
    zip_code: str = Field(regex=r"^\d{5}(-\d{4})?$")


class TransferFundsArgs(BaseModel):
    from_account: str = Field(min_length=8, max_length=64)
    to_account: str = Field(min_length=8, max_length=64)
    amount_cents: int = Field(gt=0, le=10_000_000)  # max $100k
    currency: Literal["USD"] = "USD"
    memo: str = Field(max_length=120)


class RotateApiKeyArgs(BaseModel):
    service_name: str = Field(min_length=1, max_length=64)


# ============================================================================
# TOOL DEFINITIONS (LangChain @tool decorator)
# ============================================================================

@tool
def get_balance(account_id: str) -> str:
    """Get account balance. Read-only, low-risk.
    
    Args:
        account_id: Account identifier (alphanumeric, 8-64 chars)
    
    Returns:
        Account balance as JSON string.
    """
    return json.dumps({"account_id": account_id, "balance_cents": 50000})


@tool
def update_address(customer_id: str, street: str, city: str, state: str, zip_code: str) -> str:
    """Update customer address. Medium-risk, requires approval.
    
    Args:
        customer_id: Customer ID
        street: Street address
        city: City
        state: 2-letter state code
        zip_code: ZIP code (5 or 5+4 format)
    
    Returns:
        Confirmation as JSON string.
    """
    return json.dumps({"customer_id": customer_id, "status": "updated"})


@tool
def transfer_funds(from_account: str, to_account: str, amount_cents: int, currency: str, memo: str) -> str:
    """Transfer funds between accounts. HIGH-RISK, requires human approval.
    
    Args:
        from_account: Source account ID
        to_account: Destination account ID
        amount_cents: Amount in cents (max $100,000)
        currency: Currency code (USD only)
        memo: Transaction memo (max 120 chars)
    
    Returns:
        Transaction confirmation as JSON string.
    """
    return json.dumps({
        "transaction_id": str(uuid.uuid4()),
        "from": from_account,
        "to": to_account,
        "amount_cents": amount_cents,
        "status": "completed"
    })


@tool
def rotate_api_key(service_name: str) -> str:
    """Rotate API key for a service. CRITICAL-RISK, requires approval and 2FA.
    
    Args:
        service_name: Service name
    
    Returns:
        New key issuance confirmation.
    """
    return json.dumps({"service_name": service_name, "status": "rotated"})


# Tool registry with metadata
TOOL_REGISTRY = {
    "get_balance": {
        "tool": get_balance,
        "risk_tier": RiskTier.LOW,
        "requires_approval": False,
        "args_schema": GetBalanceArgs,
        "max_timeout_s": 5,
    },
    "update_address": {
        "tool": update_address,
        "risk_tier": RiskTier.MEDIUM,
        "requires_approval": True,
        "args_schema": UpdateAddressArgs,
        "max_timeout_s": 10,
    },
    "transfer_funds": {
        "tool": transfer_funds,
        "risk_tier": RiskTier.HIGH,
        "requires_approval": True,
        "args_schema": TransferFundsArgs,
        "max_timeout_s": 30,
    },
    "rotate_api_key": {
        "tool": rotate_api_key,
        "risk_tier": RiskTier.CRITICAL,
        "requires_approval": True,
        "args_schema": RotateApiKeyArgs,
        "max_timeout_s": 15,
    },
}


# ============================================================================
# POLICY & APPROVAL SERVICES (stubbed for reference)
# ============================================================================

@dataclass
class PolicyDecision:
    """Result of a centralized policy decision point (PDP)."""
    allow: bool
    reason: str
    scope: Optional[str] = None
    ttl_seconds: int = 300
    audience: Optional[str] = None
    decision_id: Optional[str] = None


class PolicyDecisionPoint:
    """Centralized PDP: evaluates subject + resource + purpose + risk + time."""
    
    def decide(
        self,
        user_id: str,
        tool_name: str,
        risk_tier: RiskTier,
        args: Dict[str, Any],
        session_id: str,
    ) -> PolicyDecision:
        """Default allow, with sanity checks. Replace with real OAuth/ABAC service."""
        # Fail-closed checks
        if not user_id or not tool_name:
            return PolicyDecision(False, "missing_context")
        
        if tool_name not in TOOL_REGISTRY:
            return PolicyDecision(False, "tool_not_found")
        
        # Risk-based enforcement (example)
        if risk_tier == RiskTier.CRITICAL:
            return PolicyDecision(False, "critical_tools_require_additional_controls")
        
        # Example: block transfers > $50k without additional checks
        if tool_name == "transfer_funds" and args.get("amount_cents", 0) > 5_000_000:
            return PolicyDecision(False, "amount_exceeds_threshold")
        
        return PolicyDecision(
            allow=True,
            reason="ok",
            scope=f"tool:{tool_name}:execute",
            ttl_seconds=300,
            audience=tool_name,
            decision_id=str(uuid.uuid4()),
        )


class ApprovalService:
    """Human-in-the-loop approval broker. Stubbed for demo; integrates with ticketing/DAM."""
    
    def request_approval(
        self,
        user_id: str,
        session_id: str,
        tool_name: str,
        preview: Dict[str, Any],
    ) -> Optional[str]:
        """
        Request human approval for a high-risk action.
        In production, opens a ticket or push notification; here, auto-approve for demo.
        
        Returns:
            Approval ID if approved, None if denied.
        """
        # Stub: auto-approve for demo
        return str(uuid.uuid4())
    
    def get_approval(self, approval_id: str) -> bool:
        """Check if an approval was granted."""
        return approval_id is not None


class TokenBroker:
    """Issues short-lived, scoped, audience-bound JIT tokens."""
    
    def issue_token(
        self,
        subject: str,
        session_id: str,
        scope: str,
        audience: str,
        ttl_seconds: int = 300,
    ) -> str:
        """
        Issue a JIT (just-in-time) scoped token.
        In production, this integrates with OAuth 2.1 / OIDC / mTLS.
        
        Returns:
            Token reference (never the raw token itself in state).
        """
        exp = int(time.time()) + ttl_seconds
        token_payload = {
            "sub": subject,
            "session": session_id,
            "scope": scope,
            "aud": audience,
            "exp": exp,
            "iat": int(time.time()),
        }
        token_ref = f"jit-{hashlib.sha256(json.dumps(token_payload).encode()).hexdigest()[:16]}"
        # Stub: in real implementation, store token_payload server-side and return reference only
        return token_ref
    
    def validate_token(self, token_ref: str) -> bool:
        """Validate token reference (lookup + expiry check)."""
        # Stub: always valid for demo
        return True


class AuditLogger:
    """Immutable append-only audit sink for all security decisions and tool calls."""
    
    def emit(self, event: Dict[str, Any]) -> None:
        """Emit signed audit event. In production, writes to tamper-proof store."""
        event["timestamp"] = datetime.utcnow().isoformat()
        event["signature"] = hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest()
        # Stub: in real implementation, append to WAL or blockchain-backed ledger
        print(f"[AUDIT] {json.dumps(event)}")


# ============================================================================
# NODE IMPLEMENTATIONS (12-node secure orchestration)
# ============================================================================

pdp = PolicyDecisionPoint()
approval_service = ApprovalService()
token_broker = TokenBroker()
audit_logger = AuditLogger()


def ingress_guard(state: SecureAgentState) -> SecureAgentState:
    """
    Node 1: Validate caller identity, session, and request shape.
    Controls: ASI03 (Identity validation), MCP §5 (Auth entry point)
    
    Fail-closed: reject if caller context is missing.
    """
    if not state.user_id or not state.session_id:
        state.error_message = "missing_caller_context"
        return state
    
    if not state.trace_id:
        state.trace_id = str(uuid.uuid4())
    
    audit_logger.emit({
        "event": "ingress_guard_passed",
        "user_id": state.user_id,
        "session_id": state.session_id,
        "trace_id": state.trace_id,
    })
    return state


def intent_classifier(state: SecureAgentState) -> SecureAgentState:
    """
    Node 2: Extract and validate intent from user message.
    Controls: ASI02 (constrain to taxonomy), LLM06:2025 (excessive agency)
    
    In production, call LLM with constrained intent schema; here, stub.
    """
    if state.error_message:
        return state
    
    # Stub: extract intent from last user message
    if state.messages:
        last_msg = state.messages[-1]
        if isinstance(last_msg, HumanMessage):
            content = last_msg.content.lower()
            if "balance" in content:
                state.intent = Intent.READ_DATA
            elif "transfer" in content:
                state.intent = Intent.TRANSFER_FUNDS
            elif "address" in content:
                state.intent = Intent.UPDATE_RECORD
            else:
                state.error_message = "intent_not_recognized"
                return state
    
    audit_logger.emit({
        "event": "intent_classified",
        "trace_id": state.trace_id,
        "intent": state.intent,
    })
    return state


def capability_guard(state: SecureAgentState) -> SecureAgentState:
    """
    Node 3: Map intent to minimal allowed tool set (least agency).
    Controls: ASI02 (Tool Misuse prevention)
    
    Fail-closed: if tool not in allowlist, deny.
    """
    if state.error_message:
        return state
    
    intent_to_tools = {
        Intent.READ_DATA: ["get_balance"],
        Intent.UPDATE_RECORD: ["update_address"],
        Intent.TRANSFER_FUNDS: ["transfer_funds"],
        Intent.ADMIN_ACTION: ["rotate_api_key"],
    }
    
    allowed = intent_to_tools.get(state.intent, [])
    state.approved_tools = allowed
    
    # Stub: for demo, assume LLM selects from approved tools
    # In production, validate LLM's tool choice against approved_tools
    if state.requested_tool and state.requested_tool not in allowed:
        state.error_message = f"tool_not_allowed_for_intent:{state.requested_tool}"
        return state
    
    audit_logger.emit({
        "event": "capability_guard_passed",
        "trace_id": state.trace_id,
        "approved_tools": allowed,
    })
    return state


def policy_decision_point(state: SecureAgentState) -> SecureAgentState:
    """
    Node 4: Centralized policy decision (PDP) evaluating subject + resource + purpose + risk.
    Controls: ASI03 (Privilege Abuse), MCP §5 (Auth enforcement)
    
    Queries external PDP (OAuth/ABAC); fail-closed on error.
    """
    if state.error_message:
        return state
    
    if not state.requested_tool:
        state.error_message = "no_tool_requested"
        return state
    
    tool_meta = TOOL_REGISTRY.get(state.requested_tool)
    if not tool_meta:
        state.error_message = "tool_not_in_registry"
        return state
    
    state.risk_tier = tool_meta["risk_tier"]
    
    decision = pdp.decide(
        user_id=state.user_id,
        tool_name=state.requested_tool,
        risk_tier=state.risk_tier,
        args=state.tool_args,
        session_id=state.session_id,
    )
    
    if not decision.allow:
        state.error_message = f"policy_denied:{decision.reason}"
        audit_logger.emit({
            "event": "policy_denied",
            "trace_id": state.trace_id,
            "reason": decision.reason,
            "tool": state.requested_tool,
        })
        return state
    
    state.policy_decision_id = decision.decision_id
    state.requires_approval = tool_meta["requires_approval"]
    
    audit_logger.emit({
        "event": "policy_allowed",
        "trace_id": state.trace_id,
        "policy_decision_id": decision.decision_id,
        "tool": state.requested_tool,
    })
    return state


def arg_schema_validator(state: SecureAgentState) -> SecureAgentState:
    """
    Node 5: Strict schema validation of tool arguments.
    Controls: MCP §3 (Data Validation & Resource Management), LLM05:2025 (Improper Output Handling)
    
    Fail-closed: reject if args don't match schema or exceed bounds.
    """
    if state.error_message:
        return state
    
    tool_meta = TOOL_REGISTRY.get(state.requested_tool)
    if not tool_meta:
        state.error_message = "tool_not_in_registry"
        return state
    
    try:
        schema_class = tool_meta["args_schema"]
        validated_args = schema_class(**state.tool_args)
        state.tool_args = validated_args.model_dump()
    except ValidationError as e:
        state.error_message = f"schema_validation_failed:{str(e)}"
        audit_logger.emit({
            "event": "arg_validation_failed",
            "trace_id": state.trace_id,
            "tool": state.requested_tool,
            "error": str(e),
        })
        return state
    
    audit_logger.emit({
        "event": "args_validated",
        "trace_id": state.trace_id,
        "tool": state.requested_tool,
    })
    return state


def approval_gate(state: SecureAgentState) -> SecureAgentState:
    """
    Node 6: Human-in-the-loop approval for high-risk actions.
    Controls: ASI02 (Action-level approval), ASI03 (Irreversible action control)
    
    Shows dry-run preview; blocks until human approves.
    """
    if state.error_message:
        return state
    
    if not state.requires_approval:
        return state
    
    preview = {
        "tool": state.requested_tool,
        "args": state.tool_args,
        "risk_tier": state.risk_tier.value,
    }
    
    approval_id = approval_service.request_approval(
        user_id=state.user_id,
        session_id=state.session_id,
        tool_name=state.requested_tool,
        preview=preview,
    )
    
    if not approval_id:
        state.error_message = "approval_denied"
        audit_logger.emit({
            "event": "approval_denied",
            "trace_id": state.trace_id,
            "tool": state.requested_tool,
        })
        return state
    
    state.approval_id = approval_id
    audit_logger.emit({
        "event": "approval_granted",
        "trace_id": state.trace_id,
        "tool": state.requested_tool,
        "approval_id": approval_id,
    })
    return state


def jit_token_broker(state: SecureAgentState) -> SecureAgentState:
    """
    Node 7: Issue short-lived, scoped, audience-bound JIT tokens.
    Controls: ASI03 (Task-scoped time-bound permissions), MCP §5 (Auth & token delegation)
    
    Token expires after tool execution; never reused.
    """
    if state.error_message:
        return state
    
    decision = pdp.decide(
        user_id=state.user_id,
        tool_name=state.requested_tool,
        risk_tier=state.risk_tier,
        args=state.tool_args,
        session_id=state.session_id,
    )
    
    token_ref = token_broker.issue_token(
        subject=state.user_id,
        session_id=state.session_id,
        scope=decision.scope or f"tool:{state.requested_tool}:execute",
        audience=decision.audience or state.requested_tool,
        ttl_seconds=decision.ttl_seconds,
    )
    
    state.scoped_token_ref = token_ref
    audit_logger.emit({
        "event": "token_issued",
        "trace_id": state.trace_id,
        "tool": state.requested_tool,
        "token_ref": token_ref[:16],  # log ref, never raw token
        "ttl_s": decision.ttl_seconds,
    })
    return state


def tool_executor_sandbox(state: SecureAgentState) -> SecureAgentState:
    """
    Node 8: Execute tool in isolated sandbox with egress allowlist and timeouts.
    Controls: ASI05 (RCE prevention), ASI02 (Unbounded execution prevention)
    
    In production, runs in separate container with network/file isolation.
    """
    if state.error_message:
        return state
    
    if not token_broker.validate_token(state.scoped_token_ref):
        state.error_message = "token_validation_failed"
        return state
    
    tool_meta = TOOL_REGISTRY.get(state.requested_tool)
    if not tool_meta:
        state.error_message = "tool_not_in_registry"
        return state
    
    tool_func = tool_meta["tool"]
    
    try:
        # Execute tool with validated args
        result = tool_func.invoke(state.tool_args)
        
        # Add tool result to messages
        state.messages.append(ToolMessage(
            tool_call_id=str(uuid.uuid4()),
            content=result,
            name=state.requested_tool,
        ))
        
        state.budget_calls += 1
        state.budget_tokens += 100  # stub: estimate token usage
        
        audit_logger.emit({
            "event": "tool_executed",
            "trace_id": state.trace_id,
            "tool": state.requested_tool,
            "status": "success",
        })
    except Exception as e:
        state.error_message = f"tool_execution_failed:{str(e)}"
        audit_logger.emit({
            "event": "tool_execution_failed",
            "trace_id": state.trace_id,
            "tool": state.requested_tool,
            "error": str(e),
        })
    
    return state


def post_execution_validator(state: SecureAgentState) -> SecureAgentState:
    """
    Node 9: Validate tool response schema and safety classification.
    Controls: MCP §3 (Output sanitization), LLM05:2025 (Improper Output Handling)
    
    Fail-closed: reject if response doesn't match expected schema.
    """
    if state.error_message:
        return state
    
    if not state.messages or not isinstance(state.messages[-1], ToolMessage):
        return state
    
    last_msg = state.messages[-1]
    try:
        result = json.loads(last_msg.content)
        # Stub: validate result schema here
        if "status" not in result and "error" not in result:
            state.error_message = "response_schema_invalid"
            return state
    except json.JSONDecodeError:
        state.error_message = "response_not_json"
        return state
    
    audit_logger.emit({
        "event": "response_validated",
        "trace_id": state.trace_id,
        "tool": state.requested_tool,
    })
    return state


def budget_guard(
    state: SecureAgentState,
    max_calls: int = 12,
    max_tokens: int = 12000,
    max_cents: int = 200,
    max_fanout: int = 4,
) -> SecureAgentState:
    """
    Node 10: Enforce per-session quotas and circuit breaker.
    Controls: ASI08 (Cascading Failures), ASI02 (Unbounded consumption), LLM10:2025
    
    Trips circuit breaker if any budget exceeded.
    """
    if state.error_message:
        return state
    
    if state.budget_calls > max_calls:
        state.error_message = "budget_calls_exceeded"
        audit_logger.emit({
            "event": "budget_breach",
            "trace_id": state.trace_id,
            "budget_type": "calls",
            "used": state.budget_calls,
            "limit": max_calls,
        })
        return state
    
    if state.budget_tokens > max_tokens:
        state.error_message = "budget_tokens_exceeded"
        return state
    
    if state.budget_cents > max_cents:
        state.error_message = "budget_cost_exceeded"
        return state
    
    if state.fanout_count > max_fanout:
        state.error_message = "fanout_limit_exceeded"
        return state
    
    audit_logger.emit({
        "event": "budget_check_passed",
        "trace_id": state.trace_id,
        "calls": state.budget_calls,
        "tokens": state.budget_tokens,
    })
    return state


def audit_logger_node(state: SecureAgentState) -> SecureAgentState:
    """
    Node 11: Emit immutable signed audit event for all decisions and tool calls.
    Controls: ASI10 (Rogue Agents / drift detection), MCP §7 (Governance & audit)
    
    Every decision and execution is logged and signed.
    """
    audit_logger.emit({
        "event": "session_checkpoint",
        "trace_id": state.trace_id,
        "user_id": state.user_id,
        "session_id": state.session_id,
        "tool": state.requested_tool,
        "error": state.error_message,
        "budgets": {
            "calls": state.budget_calls,
            "tokens": state.budget_tokens,
        },
    })
    return state


def kill_switch(state: SecureAgentState) -> SecureAgentState:
    """
    Node 12: Global and session-level abort with credential revocation.
    Controls: ASI10 (Rogue Agents / containment), ASI08 (Cascading Failures)
    
    Halt execution and revoke active tokens on error or anomaly.
    """
    if state.error_message:
        # Log kill-switch activation
        audit_logger.emit({
            "event": "kill_switch_activated",
            "trace_id": state.trace_id,
            "reason": state.error_message,
            "revoked_token": state.scoped_token_ref[:16] if state.scoped_token_ref else None,
        })
        # In production: revoke token_ref server-side, quarantine session
    
    return state


# ============================================================================
# GRAPH COMPILATION & EXECUTION
# ============================================================================

def build_secure_agent_graph() -> StateGraph:
    """
    Compile the 12-node secure orchestration graph.
    
    Returns:
        Compiled LangGraph StateGraph ready for .invoke()
    """
    graph = StateGraph(SecureAgentState)
    
    # Add all 12 nodes
    graph.add_node("ingress_guard", ingress_guard)
    graph.add_node("intent_classifier", intent_classifier)
    graph.add_node("capability_guard", capability_guard)
    graph.add_node("policy_decision_point", policy_decision_point)
    graph.add_node("arg_schema_validator", arg_schema_validator)
    graph.add_node("approval_gate", approval_gate)
    graph.add_node("jit_token_broker", jit_token_broker)
    graph.add_node("tool_executor_sandbox", tool_executor_sandbox)
    graph.add_node("post_execution_validator", post_execution_validator)
    graph.add_node("budget_guard", budget_guard)
    graph.add_node("audit_logger_node", audit_logger_node)
    graph.add_node("kill_switch", kill_switch)
    
    # Wiring: linear pipeline with error short-circuit
    graph.add_edge(START, "ingress_guard")
    graph.add_edge("ingress_guard", "intent_classifier")
    graph.add_edge("intent_classifier", "capability_guard")
    graph.add_edge("capability_guard", "policy_decision_point")
    graph.add_edge("policy_decision_point", "arg_schema_validator")
    graph.add_edge("arg_schema_validator", "approval_gate")
    graph.add_edge("approval_gate", "jit_token_broker")
    graph.add_edge("jit_token_broker", "tool_executor_sandbox")
    graph.add_edge("tool_executor_sandbox", "post_execution_validator")
    graph.add_edge("post_execution_validator", "budget_guard")
    graph.add_edge("budget_guard", "audit_logger_node")
    graph.add_edge("audit_logger_node", "kill_switch")
    graph.add_edge("kill_switch", END)
    
    return graph.compile()


def invoke_secure_agent(
    user_id: str,
    session_id: str,
    tenant_id: str,
    message_content: str,
    requested_tool: str = "",
    tool_args: Optional[Dict[str, Any]] = None,
) -> SecureAgentState:
    """
    Invoke the secure agent graph.
    
    Args:
        user_id: Caller identity
        session_id: Session identifier
        tenant_id: Tenant context
        message_content: User message
        requested_tool: (optional) Tool name to use
        tool_args: (optional) Tool arguments as dict
    
    Returns:
        Final SecureAgentState with results or errors.
    """
    initial_state = SecureAgentState(
        messages=[HumanMessage(content=message_content)],
        user_id=user_id,
        session_id=session_id,
        tenant_id=tenant_id,
        trace_id=str(uuid.uuid4()),
        requested_tool=requested_tool,
        tool_args=tool_args or {},
    )
    
    graph = build_secure_agent_graph()
    final_state = graph.invoke(initial_state)
    
    return final_state


if __name__ == "__main__":
    # Example invocation
    result = invoke_secure_agent(
        user_id="user-12345",
        session_id="sess-98765",
        tenant_id="tenant-001",
        message_content="What is the balance for account ACCT0001?",
        requested_tool="get_balance",
        tool_args={"account_id": "ACCT0001"},
    )
    
    print(f"Trace ID: {result.trace_id}")
    print(f"Error: {result.error_message}")
    print(f"Tool calls: {result.budget_calls}")
    print(f"Messages: {len(result.messages)}")
