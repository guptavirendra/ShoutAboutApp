"""
Pytest test suite for secure LangGraph agent reference implementation.

Tests validate all 12 nodes and their security controls:
- ASI02 (Tool Misuse)
- ASI03 (Privilege Abuse)
- ASI08 (Cascading Failures)
- ASI10 (Rogue Agents)
- MCP §2, §3, §5, §7

Run with:
    pytest test_secure_agent.py -v
    pytest test_secure_agent.py -v --cov=langgraph_secure_agent_reference
"""

import pytest
import json
from unittest.mock import Mock, patch, MagicMock
from langgraph_secure_agent_reference import (
    SecureAgentState,
    Intent,
    RiskTier,
    invoke_secure_agent,
    build_secure_agent_graph,
    ingress_guard,
    intent_classifier,
    capability_guard,
    policy_decision_point,
    arg_schema_validator,
    approval_gate,
    jit_token_broker,
    tool_executor_sandbox,
    post_execution_validator,
    budget_guard,
    audit_logger_node,
    kill_switch,
    PolicyDecisionPoint,
    ApprovalService,
    TokenBroker,
    AuditLogger,
    GetBalanceArgs,
    TransferFundsArgs,
    TOOL_REGISTRY,
)
from langchain_core.messages import HumanMessage, ToolMessage


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def base_state():
    """Base SecureAgentState for testing."""
    return SecureAgentState(
        messages=[HumanMessage(content="Get my balance")],
        user_id="test-user-001",
        session_id="sess-001",
        tenant_id="tenant-001",
        trace_id="trace-001",
    )


@pytest.fixture
def policy_service():
    """PolicyDecisionPoint instance."""
    return PolicyDecisionPoint()


@pytest.fixture
def approval_service():
    """ApprovalService instance."""
    return ApprovalService()


@pytest.fixture
def token_service():
    """TokenBroker instance."""
    return TokenBroker()


@pytest.fixture
def audit_service():
    """AuditLogger instance."""
    return AuditLogger()


# ============================================================================
# UNIT TESTS: Individual Nodes
# ============================================================================

class TestIngressGuard:
    """Test Node 1: Ingress Guard (caller identity validation)."""
    
    def test_valid_caller_context(self, base_state):
        """Valid user_id and session_id should pass."""
        result = ingress_guard(base_state)
        assert result.error_message is None
        assert result.trace_id is not None
    
    def test_missing_user_id(self, base_state):
        """Missing user_id should fail closed."""
        base_state.user_id = ""
        result = ingress_guard(base_state)
        assert result.error_message == "missing_caller_context"
    
    def test_missing_session_id(self, base_state):
        """Missing session_id should fail closed."""
        base_state.session_id = ""
        result = ingress_guard(base_state)
        assert result.error_message == "missing_caller_context"
    
    def test_trace_id_generated(self, base_state):
        """Trace ID should be generated if missing."""
        base_state.trace_id = ""
        result = ingress_guard(base_state)
        assert result.trace_id != ""


class TestIntentClassifier:
    """Test Node 2: Intent Classifier (constrain to taxonomy)."""
    
    def test_read_intent_recognized(self, base_state):
        """Message containing 'balance' should map to READ_DATA intent."""
        result = intent_classifier(base_state)
        assert result.intent == Intent.READ_DATA
    
    def test_transfer_intent_recognized(self, base_state):
        """Message containing 'transfer' should map to TRANSFER_FUNDS intent."""
        base_state.messages[0].content = "transfer funds"
        result = intent_classifier(base_state)
        assert result.intent == Intent.TRANSFER_FUNDS
    
    def test_update_intent_recognized(self, base_state):
        """Message containing 'address' should map to UPDATE_RECORD intent."""
        base_state.messages[0].content = "update address"
        result = intent_classifier(base_state)
        assert result.intent == Intent.UPDATE_RECORD
    
    def test_unrecognized_intent_fails_closed(self, base_state):
        """Unrecognized intent should fail closed."""
        base_state.messages[0].content = "do something weird"
        result = intent_classifier(base_state)
        assert result.error_message == "intent_not_recognized"
    
    def test_error_passthrough(self, base_state):
        """If error_message is set, node should pass through unchanged."""
        base_state.error_message = "upstream_error"
        result = intent_classifier(base_state)
        assert result.error_message == "upstream_error"


class TestCapabilityGuard:
    """Test Node 3: Capability Guard (least agency)."""
    
    def test_allowed_tool_for_intent(self, base_state):
        """Tool in approved list for intent should pass."""
        base_state.intent = Intent.READ_DATA
        base_state.requested_tool = "get_balance"
        result = capability_guard(base_state)
        assert result.error_message is None
        assert "get_balance" in result.approved_tools
    
    def test_disallowed_tool_for_intent(self, base_state):
        """Tool NOT in approved list should fail closed."""
        base_state.intent = Intent.READ_DATA
        base_state.requested_tool = "transfer_funds"
        result = capability_guard(base_state)
        assert "tool_not_allowed_for_intent" in result.error_message
    
    def test_all_tools_for_read_intent(self, base_state):
        """READ_DATA intent should only allow get_balance."""
        base_state.intent = Intent.READ_DATA
        result = capability_guard(base_state)
        assert result.approved_tools == ["get_balance"]
    
    def test_all_tools_for_transfer_intent(self, base_state):
        """TRANSFER_FUNDS intent should only allow transfer_funds."""
        base_state.intent = Intent.TRANSFER_FUNDS
        result = capability_guard(base_state)
        assert result.approved_tools == ["transfer_funds"]


class TestPolicyDecisionPoint:
    """Test Node 4: Policy Decision Point (centralized authz)."""
    
    def test_policy_allow_low_risk_tool(self, base_state, policy_service):
        """Low-risk tool with valid user should be allowed."""
        base_state.requested_tool = "get_balance"
        base_state.tool_args = {"account_id": "ACC12345678"}
        # Stub the PDP call
        result = policy_decision_point(base_state)
        assert result.error_message is None
        assert result.policy_decision_id is not None
    
    def test_policy_deny_missing_tool(self, base_state):
        """Missing tool should fail closed."""
        base_state.requested_tool = ""
        result = policy_decision_point(base_state)
        assert "no_tool_requested" in result.error_message
    
    def test_policy_deny_unknown_tool(self, base_state):
        """Unknown tool should fail closed."""
        base_state.requested_tool = "unknown_tool_xyz"
        result = policy_decision_point(base_state)
        assert result.error_message == "tool_not_in_registry"
    
    def test_risk_tier_assigned(self, base_state):
        """Risk tier should be assigned from tool registry."""
        base_state.requested_tool = "transfer_funds"
        result = policy_decision_point(base_state)
        assert result.risk_tier == RiskTier.HIGH


class TestArgSchemaValidator:
    """Test Node 5: Argument Schema Validator (strict validation)."""
    
    def test_valid_balance_args(self, base_state):
        """Valid account_id should pass validation."""
        base_state.requested_tool = "get_balance"
        base_state.tool_args = {"account_id": "ACC12345678"}
        result = arg_schema_validator(base_state)
        assert result.error_message is None
    
    def test_invalid_balance_args_too_short(self, base_state):
        """Account ID too short should fail."""
        base_state.requested_tool = "get_balance"
        base_state.tool_args = {"account_id": "ACC123"}
        result = arg_schema_validator(base_state)
        assert "schema_validation_failed" in result.error_message
    
    def test_invalid_balance_args_non_alphanumeric(self, base_state):
        """Non-alphanumeric account ID should fail."""
        base_state.requested_tool = "get_balance"
        base_state.tool_args = {"account_id": "ACC@#$%^&*()"}
        result = arg_schema_validator(base_state)
        assert "schema_validation_failed" in result.error_message
    
    def test_valid_transfer_args(self, base_state):
        """Valid transfer args should pass."""
        base_state.requested_tool = "transfer_funds"
        base_state.tool_args = {
            "from_account": "ACC12345678",
            "to_account": "ACC87654321",
            "amount_cents": 50000,
            "currency": "USD",
            "memo": "payment",
        }
        result = arg_schema_validator(base_state)
        assert result.error_message is None
    
    def test_transfer_args_amount_exceeds_limit(self, base_state):
        """Amount > $100k should fail."""
        base_state.requested_tool = "transfer_funds"
        base_state.tool_args = {
            "from_account": "ACC12345678",
            "to_account": "ACC87654321",
            "amount_cents": 20_000_000,  # $200k
            "currency": "USD",
            "memo": "payment",
        }
        result = arg_schema_validator(base_state)
        assert "schema_validation_failed" in result.error_message
    
    def test_transfer_args_currency_invalid(self, base_state):
        """Non-USD currency should fail."""
        base_state.requested_tool = "transfer_funds"
        base_state.tool_args = {
            "from_account": "ACC12345678",
            "to_account": "ACC87654321",
            "amount_cents": 50000,
            "currency": "EUR",  # invalid
            "memo": "payment",
        }
        result = arg_schema_validator(base_state)
        assert "schema_validation_failed" in result.error_message


class TestApprovalGate:
    """Test Node 6: Approval Gate (human-in-the-loop)."""
    
    def test_low_risk_tool_no_approval_required(self, base_state):
        """Low-risk tools should skip approval."""
        base_state.requested_tool = "get_balance"
        base_state.risk_tier = RiskTier.LOW
        base_state.requires_approval = False
        result = approval_gate(base_state)
        assert result.error_message is None
        assert result.approval_id is None
    
    def test_high_risk_tool_requires_approval(self, base_state):
        """High-risk tools should require approval."""
        base_state.requested_tool = "transfer_funds"
        base_state.risk_tier = RiskTier.HIGH
        base_state.requires_approval = True
        result = approval_gate(base_state)
        # Stub auto-approves for demo
        assert result.approval_id is not None
    
    def test_approval_denied(self, base_state):
        """When approval is denied, execution should halt."""
        base_state.requested_tool = "transfer_funds"
        base_state.risk_tier = RiskTier.HIGH
        base_state.requires_approval = True
        
        # Mock approval_service to deny
        with patch("langgraph_secure_agent_reference.approval_service.request_approval", return_value=None):
            result = approval_gate(base_state)
            assert result.error_message == "approval_denied"


class TestJITTokenBroker:
    """Test Node 7: JIT Token Broker (scoped credentials)."""
    
    def test_token_issued(self, base_state):
        """Valid request should issue scoped token reference."""
        base_state.requested_tool = "transfer_funds"
        base_state.risk_tier = RiskTier.HIGH
        result = jit_token_broker(base_state)
        assert result.scoped_token_ref is not None
        assert result.scoped_token_ref.startswith("jit-")
    
    def test_token_never_raw_in_state(self, base_state):
        """Token should always be a reference, never raw."""
        base_state.requested_tool = "get_balance"
        result = jit_token_broker(base_state)
        assert not result.scoped_token_ref.startswith("eyJ")  # not a JWT
        assert len(result.scoped_token_ref) < 256  # short reference, not full token


class TestToolExecutorSandbox:
    """Test Node 8: Tool Executor (sandboxed execution)."""
    
    def test_tool_execution_success(self, base_state):
        """Valid tool invocation should add ToolMessage to state."""
        base_state.requested_tool = "get_balance"
        base_state.tool_args = {"account_id": "ACC12345678"}
        base_state.scoped_token_ref = "jit-valid-token"
        result = tool_executor_sandbox(base_state)
        
        # Should have added a ToolMessage
        assert len(result.messages) == 2  # original HumanMessage + new ToolMessage
        assert isinstance(result.messages[-1], ToolMessage)
        assert result.budget_calls == 1
    
    def test_tool_execution_invalid_token(self, base_state):
        """Invalid token should prevent execution."""
        base_state.requested_tool = "get_balance"
        base_state.scoped_token_ref = None
        result = tool_executor_sandbox(base_state)
        assert "token_validation_failed" in result.error_message


class TestPostExecutionValidator:
    """Test Node 9: Post-Execution Validator (response safety)."""
    
    def test_valid_json_response(self, base_state):
        """Valid JSON response should pass validation."""
        base_state.messages.append(ToolMessage(
            tool_call_id="call-001",
            content='{"status": "ok", "balance_cents": 50000}',
            name="get_balance"
        ))
        base_state.requested_tool = "get_balance"
        result = post_execution_validator(base_state)
        assert result.error_message is None
    
    def test_invalid_json_response(self, base_state):
        """Invalid JSON should fail validation."""
        base_state.messages.append(ToolMessage(
            tool_call_id="call-001",
            content='not valid json',
            name="get_balance"
        ))
        base_state.requested_tool = "get_balance"
        result = post_execution_validator(base_state)
        assert "response_not_json" in result.error_message
    
    def test_missing_status_field(self, base_state):
        """Response missing 'status' or 'error' field should fail."""
        base_state.messages.append(ToolMessage(
            tool_call_id="call-001",
            content='{"data": "something"}',
            name="get_balance"
        ))
        base_state.requested_tool = "get_balance"
        result = post_execution_validator(base_state)
        assert "response_schema_invalid" in result.error_message


class TestBudgetGuard:
    """Test Node 10: Budget Guard (per-session quotas)."""
    
    def test_under_budget(self, base_state):
        """State within budget should pass."""
        base_state.budget_calls = 5
        base_state.budget_tokens = 5000
        base_state.budget_cents = 50
        result = budget_guard(base_state, max_calls=12, max_tokens=12000, max_cents=200)
        assert result.error_message is None
    
    def test_calls_budget_exceeded(self, base_state):
        """Exceeding call limit should trip circuit breaker."""
        base_state.budget_calls = 15
        result = budget_guard(base_state, max_calls=12)
        assert "budget_calls_exceeded" in result.error_message
    
    def test_tokens_budget_exceeded(self, base_state):
        """Exceeding token limit should trip circuit breaker."""
        base_state.budget_tokens = 15000
        result = budget_guard(base_state, max_tokens=12000)
        assert "budget_tokens_exceeded" in result.error_message
    
    def test_cost_budget_exceeded(self, base_state):
        """Exceeding cost limit should trip circuit breaker."""
        base_state.budget_cents = 300
        result = budget_guard(base_state, max_cents=200)
        assert "budget_cost_exceeded" in result.error_message
    
    def test_fanout_limit_exceeded(self, base_state):
        """Exceeding fanout limit should trip circuit breaker."""
        base_state.fanout_count = 10
        result = budget_guard(base_state, max_fanout=4)
        assert "fanout_limit_exceeded" in result.error_message


class TestKillSwitch:
    """Test Node 12: Kill Switch (abort & revoke)."""
    
    def test_kill_switch_on_error(self, base_state):
        """Kill switch should log revocation when error is present."""
        base_state.error_message = "some_failure"
        base_state.scoped_token_ref = "jit-token-to-revoke"
        result = kill_switch(base_state)
        # In production, would actually revoke token; here just verify state
        assert result.error_message == "some_failure"


# ============================================================================
# INTEGRATION TESTS: Full Graph Execution
# ============================================================================

class TestFullGraphExecution:
    """Integration tests for complete graph execution."""
    
    def test_successful_read_flow(self):
        """Happy path: read-only operation should succeed."""
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="What is my balance?",
            requested_tool="get_balance",
            tool_args={"account_id": "ACC12345678"},
        )
        
        assert result.error_message is None
        assert result.budget_calls == 1
        assert len(result.messages) > 1  # at least input + tool response
    
    def test_invalid_caller_fails_at_ingress(self):
        """Graph should fail closed at ingress for missing caller context."""
        result = invoke_secure_agent(
            user_id="",  # empty
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="What is my balance?",
        )
        
        assert result.error_message == "missing_caller_context"
    
    def test_invalid_args_fails_at_validator(self):
        """Graph should fail closed at arg validator for bad args."""
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="What is my balance?",
            requested_tool="get_balance",
            tool_args={"account_id": "SHORT"},  # too short
        )
        
        assert "schema_validation_failed" in result.error_message
    
    def test_tool_not_allowed_for_intent(self):
        """Graph should fail if tool not in approved set for intent."""
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="What is my balance?",  # maps to READ_DATA
            requested_tool="transfer_funds",  # NOT allowed for READ_DATA
            tool_args={"from_account": "ACC1", "to_account": "ACC2", "amount_cents": 1000, "currency": "USD", "memo": "test"},
        )
        
        assert "tool_not_allowed_for_intent" in result.error_message


class TestSecurityInvariants:
    """Tests validating OWASP security invariants."""
    
    def test_fail_closed_missing_context(self):
        """Missing user context should fail closed, not warn."""
        result = invoke_secure_agent(
            user_id="",
            session_id="",
            tenant_id="tenant-001",
            message_content="test",
        )
        assert result.error_message is not None
    
    def test_no_raw_tokens_in_state(self):
        """Tokens in state should always be references, not raw."""
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="transfer funds",
            requested_tool="transfer_funds",
            tool_args={
                "from_account": "ACC12345678",
                "to_account": "ACC87654321",
                "amount_cents": 50000,
                "currency": "USD",
                "memo": "test",
            },
        )
        
        if result.scoped_token_ref:
            assert not result.scoped_token_ref.startswith("eyJ")  # not JWT
    
    def test_budget_prevents_runaway_execution(self):
        """Budget guard should prevent cascading failures."""
        # Simulate high budget usage
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="test",
        )
        result.budget_calls = 100  # exceed default limit
        
        # Simulate budget check
        checked = budget_guard(result, max_calls=12)
        assert "budget_calls_exceeded" in checked.error_message


# ============================================================================
# POLICY & SERVICE UNIT TESTS
# ============================================================================

class TestPolicyService:
    """Unit tests for PolicyDecisionPoint service."""
    
    def test_policy_fail_closed_on_missing_context(self):
        """PDP should fail closed on missing subject or tool."""
        service = PolicyDecisionPoint()
        
        # Missing user
        decision = service.decide(
            user_id="",
            tool_name="get_balance",
            risk_tier=RiskTier.LOW,
            args={},
            session_id="sess-001",
        )
        assert not decision.allow
    
    def test_policy_fail_closed_on_unknown_tool(self):
        """PDP should fail closed on unknown tool."""
        service = PolicyDecisionPoint()
        decision = service.decide(
            user_id="user-001",
            tool_name="unknown_xyz",
            risk_tier=RiskTier.LOW,
            args={},
            session_id="sess-001",
        )
        assert not decision.allow


class TestTokenBroker:
    """Unit tests for TokenBroker service."""
    
    def test_token_has_ttl(self):
        """Issued tokens should have time-limited validity."""
        broker = TokenBroker()
        token_ref = broker.issue_token(
            subject="user-001",
            session_id="sess-001",
            scope="tool:get_balance:execute",
            audience="get_balance",
            ttl_seconds=300,
        )
        assert token_ref is not None
        assert len(token_ref) > 0
    
    def test_token_validation(self):
        """Token broker should validate tokens."""
        broker = TokenBroker()
        token_ref = broker.issue_token(
            subject="user-001",
            session_id="sess-001",
            scope="tool:get_balance:execute",
            audience="get_balance",
            ttl_seconds=300,
        )
        # Stub: always valid in demo
        assert broker.validate_token(token_ref)


# ============================================================================
# COMPLIANCE & MAPPING TESTS
# ============================================================================

class TestOWASPCompliance:
    """Tests verifying OWASP GenAI Security compliance."""
    
    def test_asi02_least_agency_enforced(self):
        """ASI02: Capability guard limits tool access per intent."""
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="What is my balance?",  # READ_DATA intent
        )
        # After intent classifier, approved_tools should be narrow
        assert "get_balance" in result.approved_tools
        # transfer_funds should NOT be in approved set for READ_DATA
        # (This would be validated if we let the LLM auto-choose tool)
    
    def test_asi03_privilege_isolation_enforced(self):
        """ASI03: Each action gets fresh time-bound credentials."""
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="transfer funds",
            requested_tool="transfer_funds",
            tool_args={
                "from_account": "ACC12345678",
                "to_account": "ACC87654321",
                "amount_cents": 50000,
                "currency": "USD",
                "memo": "test",
            },
        )
        # Token should be issued
        if result.scoped_token_ref:
            # In production, token would expire quickly and be one-time-use
            assert result.scoped_token_ref.startswith("jit-")
    
    def test_mcp_schema_validation_enforced(self):
        """MCP §3: All inputs validated against strict schema."""
        # Send invalid args
        result = invoke_secure_agent(
            user_id="user-001",
            session_id="sess-001",
            tenant_id="tenant-001",
            message_content="check balance",
            requested_tool="get_balance",
            tool_args={"account_id": "INVALID"},  # too short
        )
        assert "schema_validation_failed" in result.error_message


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
