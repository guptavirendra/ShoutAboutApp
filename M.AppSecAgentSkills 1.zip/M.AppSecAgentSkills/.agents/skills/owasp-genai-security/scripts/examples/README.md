# LangGraph Secure Agent Reference Implementation

**Production-ready secure agent orchestration** aligned to OWASP GenAI Security controls and modern LangChain/LangGraph idioms.

## Overview

This directory contains two files:

- **`langgraph_secure_agent_reference.py`** — 12-node secure orchestration architecture with policy enforcement, human-in-the-loop, JIT credentials, and immutable auditing.
- **`test_secure_agent.py`** — Comprehensive pytest suite validating all security controls and OWASP compliance.

## Architecture

The reference implements a **12-node linear pipeline** with fail-closed defaults and centralized policy enforcement:

```
START
  ↓
1. ingress_guard (caller identity validation)
  ↓
2. intent_classifier (constrained intent taxonomy)
  ↓
3. capability_guard (minimal tool allowlist per intent)
  ↓
4. policy_decision_point (centralized PDP)
  ↓
5. arg_schema_validator (strict pydantic validation)
  ↓
6. approval_gate (human-in-the-loop)
  ↓
7. jit_token_broker (short-lived scoped credentials)
  ↓
8. tool_executor_sandbox (isolated execution)
  ↓
9. post_execution_validator (response safety)
  ↓
10. budget_guard (per-session quotas + circuit breaker)
  ↓
11. audit_logger_node (immutable signed events)
  ↓
12. kill_switch (abort + token revocation)
  ↓
END
```

## Security Controls Mapped

### OWASP Agentic Top 10 (ASI)

| Entry | Risk | Mitigated by |
|-------|------|-------------|
| **ASI01** | Agent Goal Hijack | intent_classifier (constrained taxonomy), policy_decision_point, audit_logger_node |
| **ASI02** | Tool Misuse & Exploitation | capability_guard, arg_schema_validator, approval_gate, budget_guard, post_execution_validator |
| **ASI03** | Identity & Privilege Abuse | ingress_guard, policy_decision_point, jit_token_broker, audit_logger_node |
| **ASI04** | Supply Chain Vulnerabilities | Tool registry with signed manifests (stubs in this demo) |
| **ASI05** | Unexpected Code Execution | tool_executor_sandbox, arg_schema_validator, post_execution_validator |
| **ASI08** | Cascading Failures | budget_guard, kill_switch |
| **ASI10** | Rogue Agents | audit_logger_node, kill_switch, monitoring hooks |

### MCP Server Security (§)

| Section | Area | Mitigated by |
|---------|------|-------------|
| **MCP §2** | Safe Tool Design | Tool registry with risk tiers, arg schema, approval flags |
| **MCP §3** | Data Validation | arg_schema_validator, post_execution_validator, size bounds |
| **MCP §5** | Authentication & Authorization | jit_token_broker, policy_decision_point, token validation |
| **MCP §7** | Governance & Audit | audit_logger_node, kill_switch, trace IDs |

## Installation

### Prerequisites

```bash
pip install langchain langgraph pydantic pytest pytest-cov
```

### Setup

```bash
# Clone or copy the files to your project
cp langgraph_secure_agent_reference.py /path/to/your/project/
cp test_secure_agent.py /path/to/your/project/tests/
```

## Usage

### Basic Invocation

```python
from langgraph_secure_agent_reference import invoke_secure_agent

result = invoke_secure_agent(
    user_id="alice@example.com",
    session_id="sess-12345",
    tenant_id="tenant-001",
    message_content="What is the balance for account ACCT0001?",
    requested_tool="get_balance",
    tool_args={"account_id": "ACCT0001"},
)

print(f"Trace ID: {result.trace_id}")
print(f"Error: {result.error_message}")
print(f"Messages: {result.messages}")
print(f"Tool calls: {result.budget_calls}")
```

### Building Custom Graphs

```python
from langgraph_secure_agent_reference import build_secure_agent_graph, SecureAgentState
from langchain_core.messages import HumanMessage

graph = build_secure_agent_graph()

initial_state = SecureAgentState(
    messages=[HumanMessage(content="Get my balance")],
    user_id="alice@example.com",
    session_id="sess-12345",
    tenant_id="tenant-001",
    requested_tool="get_balance",
    tool_args={"account_id": "ACCT0001"},
)

final_state = graph.invoke(initial_state)
```

## Testing

### Run All Tests

```bash
pytest test_secure_agent.py -v
```

### Run with Coverage

```bash
pytest test_secure_agent.py -v --cov=langgraph_secure_agent_reference --cov-report=html
```

### Run Specific Test Class

```bash
pytest test_secure_agent.py::TestCapabilityGuard -v
```

### Expected Test Results

All tests validate security invariants:

- ✅ **Fail-closed behavior**: missing context, invalid args, denied policies all fail before execution.
- ✅ **Least agency**: tool allowlists are minimal per intent.
- ✅ **Least privilege**: each action gets fresh short-lived credentials.
- ✅ **Budget enforcement**: per-session quotas prevent runaway execution.
- ✅ **Audit trail**: every decision and tool call is logged immutably.
- ✅ **Human approval**: destructive actions require explicit confirmation.

## Customization Guide

### 1. Add a Custom Tool

```python
from pydantic import BaseModel, Field
from langchain_core.tools import tool

class YourToolArgs(BaseModel):
    param1: str = Field(min_length=1, max_length=100)
    param2: int = Field(gt=0)

@tool
def your_tool(param1: str, param2: int) -> str:
    """Your tool description."""
    return f"Result for {param1} and {param2}"

# Register in TOOL_REGISTRY
TOOL_REGISTRY["your_tool"] = {
    "tool": your_tool,
    "risk_tier": RiskTier.MEDIUM,
    "requires_approval": True,
    "args_schema": YourToolArgs,
    "max_timeout_s": 10,
}
```

### 2. Customize Intent Taxonomy

Edit `intent_classifier` node to add your intents:

```python
def intent_classifier(state: SecureAgentState) -> SecureAgentState:
    content = state.messages[-1].content.lower()
    if "your_keyword" in content:
        state.intent = Intent.YOUR_CUSTOM_INTENT
    # ...
```

### 3. Replace Stub Services

Replace `PolicyDecisionPoint`, `ApprovalService`, `TokenBroker`, `AuditLogger` with real implementations:

```python
class RealPolicyDecisionPoint(PolicyDecisionPoint):
    def decide(self, user_id, tool_name, risk_tier, args, session_id):
        # Call real OAuth/ABAC service
        return oauth_policy_engine.evaluate(user_id, tool_name, resource=args)

# Update global instance
pdp = RealPolicyDecisionPoint()
```

### 4. Add Budget Customization

Pass custom budget limits to nodes:

```python
def custom_budget_guard(state: SecureAgentState) -> SecureAgentState:
    return budget_guard(
        state,
        max_calls=20,           # increase from 12
        max_tokens=25_000,       # increase from 12k
        max_cents=500,           # increase from 200
        max_fanout=10,           # increase from 4
    )
```

## Production Deployment Checklist

- [ ] Replace all stub services (PolicyDecisionPoint, ApprovalService, TokenBroker, AuditLogger) with real implementations.
- [ ] Integrate with OAuth 2.1/OIDC token broker; tokens must be short-lived and scoped.
- [ ] Connect to centralized audit sink (append-only log, blockchain ledger, or SIEM).
- [ ] Set up human approval workflow (integrate with ticketing, Slack, DAM system).
- [ ] Implement tool sandbox (Docker containers, separate compute, network allowlist).
- [ ] Add monitoring and alerting on policy denials and budget breaches.
- [ ] Load test graph under realistic budget and concurrency constraints.
- [ ] Run full pytest suite with code coverage > 90%.
- [ ] Perform security review with AppSec/InfoSec team.
- [ ] Document all customizations and deviations from reference architecture.

## Common Patterns

### Pattern 1: Read-Only Agent (LOW-RISK)

```python
# Agent can call read-only tools without approval
TOOL_REGISTRY["read_only_tool"] = {
    "risk_tier": RiskTier.LOW,
    "requires_approval": False,
    ...
}
```

### Pattern 2: High-Risk Destructive Operations

```python
# Require approval + dual control
TOOL_REGISTRY["delete_data"] = {
    "risk_tier": RiskTier.CRITICAL,
    "requires_approval": True,
    ...
}
# In approval_gate, call 2FA or multi-person approval
```

### Pattern 3: Multi-Agent Workflows

Add inter-agent communication node:

```python
def inter_agent_gateway(state: SecureAgentState) -> SecureAgentState:
    """Validate multi-agent messages before delegation."""
    # Check target agent NHI, message signing, delegation scope
    return state
```

### Pattern 4: Long-Running Workflows

Implement persistent state + resumption:

```python
# Store state to database after each node
# On interrupt, resume from checkpoint with fresh credentials
```

## References

- **OWASP Top 10 for Agentic Applications 2026** — https://genai.owasp.org/
- **OWASP Practical Guide for Secure MCP Server Development v1.0** — https://genai.owasp.org/
- **LangGraph Documentation** — https://docs.langchain.com/oss/python/langgraph/overview
- **LangChain Tools** — https://docs.langchain.com/oss/python/langchain/tools
- **OAuth 2.1 / OIDC** — https://www.rfc-editor.org/rfc/rfc9110.html, https://openid.net/specs/openid-connect-core-1_0.html
- **NIST SP 800-218 (SSDF)** — https://csrc.nist.gov/publications/detail/sp/800-218/final
- **NIST SP 800-218A** — https://csrc.nist.gov/publications/detail/sp/800-218a/final

## Compliance Notes

This reference implementation is aligned to:

- ✅ **NIST SP 800-218 (SSDF)** practices: PW.4 (supply chain), PW.5 (secure coding), PW.7 (encoding/output handling), PW.8 (memory), RV.3 (threat model)
- ✅ **NIST SP 800-218A** controls: PO.5, PS.1 (IAM/NHI)
- ✅ **Molina AppSec Program** gate requirements: suitable for PRE (architecture), P2D (design/build evidence), P2B (test/validation)
- ✅ **Molina AppSec OAuth patterns** (Pattern A/B/C): uses OAuth 2.1/OIDC, no token passthrough, scoped JIT tokens

## Support & Feedback

For questions, issues, or customization guidance:

1. Review the OWASP GenAI Security skill at `../SKILL.md`
2. Check the OWASP checklists: `../Agentic-Top10-Checklist.md`, `../MCP-Server-Security-Checklist.md`
3. File an issue or open a discussion.

---

**Last updated:** May 2026  
**License:** Aligned to Molina AppSec governance and OWASP IP policy  
**Maintainer:** AppSec AI Skills Team
