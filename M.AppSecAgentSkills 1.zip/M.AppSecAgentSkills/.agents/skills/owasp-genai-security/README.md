# owasp-genai-security

Single Molina AppSec skill consolidating the three authoritative **OWASP Gen AI Security Project** artifacts:

1. **OWASP Top 10 for LLM Applications 2025** (LLM01–LLM10)
2. **OWASP Top 10 for Agentic Applications 2026** (ASI01–ASI10) — Agentic Security Initiative
3. **OWASP Practical Guide for Secure MCP Server Development v1.0** (Feb 2026)

These three layers form a defense-in-depth stack:
`LLM Top 10 (model)` → `ASI Top 10 (agent autonomy & orchestration)` → `MCP Guide (tool / server runtime)`.

## Contents

| File | Purpose |
|------|---------|
| [SKILL.md](SKILL.md) | Skill manifest, routing tables, output template, cross-framework integration |
| [Agentic-Top10-Checklist.md](references/Agentic-Top10-Checklist.md) | ASI01–ASI10 entries with required mitigations and T-code / AIVSS mappings |
| [MCP-Server-Security-Checklist.md](references/MCP-Server-Security-Checklist.md) | 8 MCP control areas + the **MCP Security Minimum Bar** review checklist |
| [LLM-Top10-Reference.md](references/LLM-Top10-Reference.md) | LLM01:2025 – LLM10:2025 reference index with cross-pointers to ASI / MCP |

## When to use this skill

Activate when the request involves:

- LLM application security (prompts, RAG, output handling).
- AI agents — single agent, planner+executor, or multi-agent.
- MCP servers, MCP clients/hosts, A2A protocols, agent registries.
- Tool design and tool governance for AI agents.
- AI supply chain (models, weights, plugins, MCP packages, AIBOM).
- Prompt injection, tool poisoning, agent goal hijack, rogue agents.
- AI identity/NHI, OAuth delegation for agents.

## How it integrates with the other skills

- **[nist-ssdf](../nist-ssdf/SKILL.md)** — provides the SDLC practices (PO/PS/PW/RV) that ASI/LLM/MCP findings should be remediated under.
- **[nist-218a](../nist-218a/SKILL.md)** — AI-specific 218A practices (training data, model weights, AI pipelines) that complement model-layer LLM Top 10 findings.
- **[molina-application-security](../molina-application-security/SKILL.md)** — PRE / P2D / P2B gates where ASI/LLM/MCP findings become gate-blockers or conditional approvals.

## Authoritative sources

- OWASP Top 10 for LLM Applications 2025 — <https://genai.owasp.org/llm-top-10/>
- OWASP Top 10 for Agentic Applications 2026 — OWASP Gen AI Security Project, ASI, Dec 2025 (CC BY-SA 4.0)
- OWASP Practical Guide for Secure MCP Server Development v1.0 — OWASP Gen AI Security Project, Feb 2026 (CC BY-SA 4.0)
- OWASP Agentic AI – Threats and Mitigations (T-codes)
- OWASP AI Vulnerability Scoring System (AIVSS)
- OWASP Non-Human Identities (NHI) Top 10 (2025)
- OWASP CycloneDX / AIBOM
