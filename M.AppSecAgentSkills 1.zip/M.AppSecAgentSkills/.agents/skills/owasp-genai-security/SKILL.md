---
name: owasp-genai-security
license: MIT
description: "Applies OWASP GenAI security guidance covering LLM Top 10 (2025), Agentic Top 10 (ASI01–ASI10, 2026), and the MCP Server Security Guide for LLM apps, AI agents, and MCP servers. WHEN: \"OWASP LLM\", \"agentic AI security\", \"MCP security\", \"prompt injection\", \"tool poisoning\", \"agent goal hijack\", \"AI supply chain\", \"AIBOM\"."
allowed-tools: Read
compatibility: "Designed for Claude Code. Applicable to LLM applications, agentic systems, and MCP server development."
metadata:
  author: peaceful-robot
  version: "1.0"
  source-frameworks: "OWASP LLM Top 10 2025, OWASP ASI Top 10 2026, OWASP MCP Server Guide v1.0"
---

# OWASP GenAI Security (LLM, Agentic, MCP)

Single skill consolidating the three authoritative OWASP GenAI Security Project artifacts that govern AI application AppSec at Molina:

- **OWASP Top 10 for LLM Applications 2025** — model-level risks (LLM01–LLM10).
- **OWASP Top 10 for Agentic Applications 2026 (ASI Top 10)** — agent-level risks (ASI01–ASI10) that *amplify and extend* LLM Top 10 into autonomous, multi-step, tool-using systems.
- **OWASP Practical Guide for Secure MCP Server Development v1.0** — concrete build/runtime controls for MCP servers that broker tools and data to AI agents.

These three layers form a defense-in-depth stack:
`LLM Top 10 (model)` → `ASI Top 10 (agent autonomy & orchestration)` → `MCP Guide (tool/server runtime)`.

## Gotchas

- **LLM Top 10 (2025) ≠ ASI Top 10 (2026).** They cover different attack layers. LLM01 (prompt injection at model level) and ASI01 (agent goal hijack including indirect injection via tool responses) are related but distinct — don't merge them. Both apply to agent systems.
- **MCP Security Minimum Bar is non-negotiable.** The minimum bar in the MCP checklist is a ship-blocker regardless of other controls. Complete it before treating any MCP server as production-ready.
- **"Agentic" scope is determined by autonomy, not by the word "agent."** A chatbot that calls one read-only API is not in ASI scope. An LLM that plans, delegates to sub-agents, and writes to systems is fully in scope.
- **AIBOM is required for ASI04 compliance**, not optional. Treat missing AIBOM the same as a missing SBOM in traditional supply chain security.

## How to use this skill

**Skill check:** Before answering, read the relevant section(s) of this skill and the linked checklist. In your output, include a `Skills used:` line naming the skill and the specific section(s) and entry IDs (e.g., `ASI01`, `LLM06:2025`, `MCP §5`) relied upon. Only ask follow-up questions if the guidance still leaves you needing more input.

1. Identify whether the request is **model-level**, **agent-level**, or **MCP/tool-level** (often more than one).
2. Route to the correct entry in the topic routing tables below.
3. Read the linked checklist file(s) and apply the listed mitigations.
4. Track compliance with [Agentic-Top10-Checklist.md](references/Agentic-Top10-Checklist.md) and [MCP-Server-Security-Checklist.md](references/MCP-Server-Security-Checklist.md).

## Cross-framework integration

Use this section when the request spans this skill **and** the SSDF / 218A / Molina skills.

- **Map ASI/LLM risks → SSDF practices:** ASI04/LLM03 (supply chain) → SSDF `PW.4`, `PS.3`; ASI05/LLM05 (RCE / improper output handling) → `PW.5`, `PW.7`, `PW.8`; ASI03 (identity & privilege abuse) → `PO.5`, `PS.1`; ASI08 (cascading failures) → `RV.3`.
- **Map ASI/LLM/MCP risks → 218A:** ASI06 (memory & context poisoning) and LLM04 (data & model poisoning) align with 218A data/model protection controls; MCP §5 (auth) and §7 (governance) align with 218A `PO.5` and `PS.1`.
- **Map to Molina gates:** treat ASI/LLM/MCP findings as **PRE** (architecture/threat model), **P2D** (design/build evidence), and **P2B** (test/validation) inputs. High/critical ASI or LLM findings are gate-blockers unless an exception is recorded.

## Project onboarding addendum (AI / agentic scope)

Confirm before detailed routing:

- **Surface:** plain LLM app, RAG, single agent, multi-agent, MCP server author, MCP client/host, or all of the above.
- **Autonomy level:** chat-only, tool-using, planner+executor, multi-agent with delegation, or self-modifying.
- **Tool exposure:** code execution, shell, file system, network/HTTP, email/calendar, internal CRM/DB, money movement, PHI/PII access.
- **Memory model:** stateless, short-term context, persistent per-user memory, shared cross-tenant memory, RAG store.
- **Identity model:** user-only, agent service account, OAuth on-behalf-of, shared NHI, per-agent NHI.
- **Trust boundary count:** how many distinct agents / MCP servers / external tools sit on the call path.

## Output template

```markdown
Skills used: owasp-genai-security (Topic routing — <area>; <entry IDs>)

Scope:
- Layer(s): <LLM | Agentic | MCP>
- Surface: <RAG | single-agent | multi-agent | MCP server | MCP client>
- Autonomy: <chat-only | tool-using | planner+executor | multi-agent>

Findings (by entry):
- <ASI/LLM/MCP id>: <gap, evidence, severity>

Required mitigations:
- <control>: <owner> | <due> | <evidence artifact>

Decision:
- Gate: <PRE | P2D | P2B | Release>
- Result: <PASS | CONDITIONAL | FAIL>
```

## Topic routing — Agentic Top 10 (ASI)

Source: OWASP Top 10 for Agentic Applications 2026.

| Entry | Risk | Read |
|------|------|------|
| ASI01 | Agent Goal Hijack (incl. indirect prompt injection, T06/T07) | [Agentic-Top10-Checklist.md#asi01](references/Agentic-Top10-Checklist.md#asi01-agent-goal-hijack) — read when prompt injection, goal hijack, or indirect instruction via tool responses is in scope |
| ASI02 | Tool Misuse & Exploitation (legit tool, unsafe use) | [Agentic-Top10-Checklist.md#asi02](references/Agentic-Top10-Checklist.md#asi02-tool-misuse--exploitation) — read when tool calls, API abuse, or unbounded resource consumption is in scope |
| ASI03 | Identity & Privilege Abuse (delegation, confused deputy, NHI) | [Agentic-Top10-Checklist.md#asi03](references/Agentic-Top10-Checklist.md#asi03-identity--privilege-abuse) — read when agent identity, OAuth delegation, confused deputy, or NHI management is in scope |
| ASI04 | Agentic Supply Chain Vulnerabilities (tools, MCP, registries, AIBOM) | [Agentic-Top10-Checklist.md#asi04](references/Agentic-Top10-Checklist.md#asi04-agentic-supply-chain-vulnerabilities) — read when third-party tools, MCP registries, or AIBOM requirements are in scope |
| ASI05 | Unexpected Code Execution / RCE (vibe-coding, eval, deserialization) | [Agentic-Top10-Checklist.md#asi05](references/Agentic-Top10-Checklist.md#asi05-unexpected-code-execution-rce) — read when code execution, eval, shell access, or deserialization is in scope |
| ASI06 | Memory & Context Poisoning (RAG, long-term memory, cross-tenant) | [Agentic-Top10-Checklist.md#asi06](references/Agentic-Top10-Checklist.md#asi06-memory--context-poisoning) — read when RAG retrieval, long-term memory, or cross-tenant context isolation is in scope |
| ASI07 | Insecure Inter-Agent Communication (A2A, MCP, message integrity) | [Agentic-Top10-Checklist.md#asi07](references/Agentic-Top10-Checklist.md#asi07-insecure-inter-agent-communication) — read when agent-to-agent messaging, MCP transport security, or message signing is in scope |
| ASI08 | Cascading Failures (fan-out, feedback loops, blast radius) | [Agentic-Top10-Checklist.md#asi08](references/Agentic-Top10-Checklist.md#asi08-cascading-failures) — read when multi-agent fan-out, retry storms, or blast radius limiting is in scope |
| ASI09 | Human-Agent Trust Exploitation (automation bias, fake explainability) | [Agentic-Top10-Checklist.md#asi09](references/Agentic-Top10-Checklist.md#asi09-human-agent-trust-exploitation) — read when human oversight, automation bias, or explainability accuracy is in scope |
| ASI10 | Rogue Agents (behavioral drift, scheming, self-replication) | [Agentic-Top10-Checklist.md#asi10](references/Agentic-Top10-Checklist.md#asi10-rogue-agents) — read when behavioral drift, goal deviation, or agent self-modification is in scope |

## Topic routing — MCP Server Security

Source: OWASP Practical Guide for Secure MCP Server Development v1.0 (Feb 2026).

| § | Area | Read |
|---|------|------|
| 1 | Secure MCP Architecture (local vs remote, isolation, trusted clients) | [MCP-Server-Security-Checklist.md#1-secure-mcp-architecture](references/MCP-Server-Security-Checklist.md#1-secure-mcp-architecture) — read when reviewing MCP server deployment topology or client trust model |
| 2 | Safe Tool Design (signed manifests, onboarding, description vs behavior) | [MCP-Server-Security-Checklist.md#2-safe-tool-design](references/MCP-Server-Security-Checklist.md#2-safe-tool-design) — read when designing or auditing MCP tool manifests, descriptions, or onboarding |
| 3 | Data Validation & Resource Management (schemas, quotas, sanitization) | [MCP-Server-Security-Checklist.md#3-data-validation--resource-management](references/MCP-Server-Security-Checklist.md#3-data-validation--resource-management) — read when reviewing input validation, output sanitization, or quota enforcement |
| 4 | Prompt Injection Controls (HITL, LLM-as-judge, structured tool calls) | [MCP-Server-Security-Checklist.md#4-prompt-injection-controls](references/MCP-Server-Security-Checklist.md#4-prompt-injection-controls) — read when assessing prompt injection risk in MCP tool responses or tool descriptions |
| 5 | Authentication & Authorization (OAuth 2.1/OIDC, no token passthrough) | [MCP-Server-Security-Checklist.md#5-authentication--authorization](references/MCP-Server-Security-Checklist.md#5-authentication--authorization) — read when designing or auditing MCP server auth flows, token handling, or scopes |
| 6 | Secure Deployment & Updates (vaults, containers, supply chain, CI/CD gates) | [MCP-Server-Security-Checklist.md#6-secure-deployment--updates](references/MCP-Server-Security-Checklist.md#6-secure-deployment--updates) — read when reviewing MCP server build pipeline, secrets management, or deployment process |
| 7 | Governance (signing, peer review, audit logs, NHI governance) | [MCP-Server-Security-Checklist.md#7-governance](references/MCP-Server-Security-Checklist.md#7-governance) — read when establishing MCP server governance, audit logging, or NHI lifecycle management |
| 8 | Tools & Continuous Validation (SAST/SCA, runtime, SIEM, OSV) | [MCP-Server-Security-Checklist.md#8-tools--continuous-validation](references/MCP-Server-Security-Checklist.md#8-tools--continuous-validation) — read when setting up continuous security scanning or runtime monitoring for MCP servers |
| ✓ | MCP Security Minimum Bar (review checklist) | [MCP-Server-Security-Checklist.md#mcp-security-minimum-bar-review-checklist](references/MCP-Server-Security-Checklist.md#mcp-security-minimum-bar-review-checklist) — **read before any MCP server ships**; this is a required gate |

## Topic routing — LLM Top 10 (2025)

Source: OWASP Top 10 for LLM Applications 2025. Use as the model-layer baseline that ASI/MCP build on.

See [LLM-Top10-Reference.md](references/LLM-Top10-Reference.md) for the full table; quick map:

| ID | Risk | Most-related ASI / MCP control |
|----|------|--------------------------------|
| LLM01:2025 | Prompt Injection | ASI01, ASI06, MCP §3, §4 |
| LLM02:2025 | Sensitive Information Disclosure | ASI03, ASI10, MCP §3, §7 |
| LLM03:2025 | Supply Chain Vulnerabilities | ASI04, MCP §6, §8 |
| LLM04:2025 | Data & Model Poisoning | ASI06, ASI08 |
| LLM05:2025 | Improper Output Handling | ASI05, MCP §3 |
| LLM06:2025 | Excessive Agency | ASI02, ASI03, ASI10, MCP §2, §5 |
| LLM07:2025 | System Prompt Leakage | ASI01, ASI03 |
| LLM08:2025 | Vector & Embedding Weaknesses | ASI06 |
| LLM09:2025 | Misinformation | ASI09 |
| LLM10:2025 | Unbounded Consumption | ASI02, ASI08, MCP §3 |

## Templates and related skills

- Agentic Top 10 checklist: [Agentic-Top10-Checklist.md](Agentic-Top10-Checklist.md)
- MCP Server Security checklist + minimum bar: [MCP-Server-Security-Checklist.md](MCP-Server-Security-Checklist.md)
- LLM Top 10 reference: [LLM-Top10-Reference.md](LLM-Top10-Reference.md)
- SSDF practices (PO/PS/PW/RV): [../nist-ssdf/SKILL.md](../nist-ssdf/SKILL.md)
- AI-specific 218A controls: [../molina-nist-218a/SKILL.md](../molina-nist-218a/SKILL.md)
- Molina gate operations (PRE/P2D/P2B): [../molina-application-security/SKILL.md](../molina-application-security/SKILL.md)

## Available resources

Reference files (load only when explicitly needed):
- [Agentic-Top10-Checklist.md](Agentic-Top10-Checklist.md) — full ASI01–ASI10 checklist with mitigations; load when any ASI entry is in scope
- [MCP-Server-Security-Checklist.md](MCP-Server-Security-Checklist.md) — §1–§8 controls and minimum bar; load when any MCP server is in scope
- [LLM-Top10-Reference.md](LLM-Top10-Reference.md) — LLM01–LLM10 reference with mitigations; load when model-layer risks are in scope without an ASI/MCP mapping

## References

- OWASP Top 10 for LLM Applications 2025 — <https://genai.owasp.org/llm-top-10/>
- OWASP Top 10 for Agentic Applications 2026 — <https://genai.owasp.org/>
- OWASP Practical Guide for Secure MCP Server Development v1.0 — <https://genai.owasp.org/>
- OWASP Agentic AI – Threats and Mitigations (T1–T17 taxonomy)
- OWASP AI Vulnerability Scoring System (AIVSS)
- OWASP Non-Human Identities (NHI) Top 10 (2025)
- OWASP CycloneDX / AIBOM
