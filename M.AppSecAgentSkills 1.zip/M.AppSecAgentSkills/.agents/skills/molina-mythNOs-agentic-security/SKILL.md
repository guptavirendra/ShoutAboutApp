---
name: molina-mythNOs-agentic-security
license: MIT
description: "Unified agentic AppSec skill combining governance, application defense, and platform operations. Implements harness-first architecture for secure AppSec agent workflows across GitHub and Azure DevOps with least-privilege tool contracts, audit evidence, human gate enforcement, and end-to-end defense-in-depth. WHEN: \"agentic security\", \"application defense\", \"agent governance\", \"agent threat model\", \"tool contracts\", \"agentic AppSec\", \"anti-mythos\", \"runtime resilience\", \"incident containment\", \"attack surface\", \"secure-by-design\", \"threat inventory\", \"breach readiness\", \"security monitoring\", \"agentic threat model\", \"tool misuse prevention\", \"agent workflow governance\", \"harness-first\"."
allowed-tools: Read
user-invocable: true
argument-hint: "--context architecture|pipeline|policy|agentic --risk low|moderate|high"
compatibility: "Designed for Claude Code. Requires GitHub or Azure DevOps access. Works alongside molina-application-security, molina-nist-218a, nist-ssdf, and owasp-genai-security."
metadata:
  author: M.AppSecAgentSkills
  version: "1.0"
---

# Molina MythNOs Agentic Security

Unified skill for defensive governance, application-level security reviews, and agentic platform operations. Combines three complementary layers — governance, application defense, and operations — into a single routing surface.

Control precedence for this skill:
1. Molina AppSec Program
2. NIST SP 800-218A
3. NIST SP 800-218
4. OWASP guidance (supplemental)

---

## 3-Layer Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ Layer 1: GOVERNANCE (Tier 0–2 + Prohibited)                 │
│ → Policy gates, secure-by-design defaults, risk acceptance │
└─────────────────────────────────────────────────────────────┘
               ↓ governs decisions escalated from
┌─────────────────────────────────────────────────────────────┐
│ Layer 2: APPLICATION DEFENSE (Stages A–E)                   │
│ → Per-app threat inventory, control baseline, resilience   │
└─────────────────────────────────────────────────────────────┘
               ↓ routes AI/agentic systems to
┌─────────────────────────────────────────────────────────────┐
│ Layer 3: AGENTIC OPERATIONS (Harness DAG, Tool Contracts)  │
│ → Platform-specific tool schemas, observability contracts, │
│   evidence collection, ASI crosswalks, eval harness        │
└─────────────────────────────────────────────────────────────┘
```

**When to activate each layer:**
- **Layer 1 (Governance):** Policy questions, capability tier checks, risk acceptance, security architecture reviews.
- **Layer 2 (Application Defense):** Per-application security review, threat modeling, control baseline design, runtime observability setup.
- **Layer 3 (Agentic Operations):** Agentic systems only; tool contract design, harness workflow execution, evidence collection, ASI threat mapping.

---

## How to use this skill

**Skill check:**
- Before making a decision, read the relevant layer(s) below.
- Use alongside: molina-application-security, molina-nist-218a, nist-ssdf, owasp-genai-security.
- In output, include: `Skills used: molina-mythNOs-agentic-security` and applied layers/sections.

---

## Layer 1 — Governance

Enforce secure-by-design posture through capability tiers, prohibited actions, and human gates for high-impact decisions.

### Capability governance model

**Capability tiers:**
- **Tier 0**: Read-only analysis, requirement traceability, risk framing
- **Tier 1**: Security design review, threat identification, control recommendation
- **Tier 2**: Defensive recommendations, control hardening guidance, compensating controls
- **Prohibited**: Exploit paths, bypass guidance, evasion tactics, offensive simulation

### Allowed actions
- Evaluate trust boundaries and data flows for security weaknesses
- Recommend least-privilege, segmentation, and secure defaults
- Identify policy gaps and propose compliant remediation
- Require human review for high-impact architectural changes

### Prohibited actions
- Generate exploit paths, payloads, or attack playbooks
- Recommend control bypasses or temporary security weakening
- Provide evasion guidance for detections, reviews, or policies
- Simulate attacker tactics beyond defensive risk framing

### Safe autonomy contract

**Hard rules:**
1. Default to analysis-only mode.
2. If context is ambiguous for security posture, stop and escalate.
3. Never recommend actions that weaken defense-in-depth.

**Human review required for:**
- AuthN/AuthZ model changes
- Key management or encryption boundary changes
- Multi-tenant boundary changes
- Formal non-leakage proof boundary or invariant changes (tenant, session, identity, memory)
- Risk acceptance or policy deviation requests

### Preventable-design checks

Evaluate and report on all of:
- Trust-boundary confusion and ambiguous ownership
- Implicit authentication assumptions
- Over-privileged service identities and role grants
- Irreversible workflows lacking compensation or rollback
- Excess capability removable rather than hardened

### Stop conditions (Layer 1)

Stop and escalate when any condition is true:
- Missing architecture context or data-flow visibility
- Conflicting security requirements without governance decision
- Regulatory or policy ambiguity affecting control choice
- Confidence below acceptable level for high-impact recommendation

### Layer 1 output template

```text
Decision Summary:
Assumptions:
Security Trade-offs:
What Could Go Wrong:
Decision (Proceed / Stop):
Escalation Owner (if Stop):
Evidence to Capture:
```

**Note:** Compliance mapping to SSDF, 218A, and Molina is optional unless explicitly requested.

---

## Layer 2 — Application Defense Workflow

Structured defensive security review for one application at a time. Covers both traditional and AI/agentic applications.

### Use this layer when
- You need a structured app-level security review
- You need to reduce attack surface before release
- You need runtime resilience and incident-readiness checks
- You need a clear gate decision with evidence-backed rationale

### Do not use this layer for
- Exploit development or bypass guidance
- Red-team simulation playbooks
- Offensive payload generation

*If the request is offensive, refuse and redirect to defensive design and risk reduction.*

---

### Stage A — Application profiling

**Goal:** Establish context and risk tier.

**Required inputs:**
- Business criticality and data sensitivity
- Exposure model (internal, partner, public)
- Tenant model (single-tenant or multi-tenant)
- Trust boundaries and privilege boundaries
- Deployment footprint and key dependencies
- Proof model for non-leakage assurance (structural, behavioral, formal)

**Completion checks:**
- Scope is explicit and bounded to one application/system
- Critical assets and trust boundaries are documented
- Owner and escalation contact are assigned

**Stop conditions:**
- Trust boundaries are unclear
- No accountable owner is identified

---

### Stage B — Threat inventory (defensive)

**Goal:** Identify realistic abuse paths and fragile boundaries without offensive detail.

**Process:**
1. Enumerate entry points, identity surfaces, data ingress paths, and admin/control paths
2. Map likely threat categories (spoofing, tampering, information disclosure, denial of service, privilege abuse)
3. Score each threat by impact and reachability (low, moderate, high)
4. Capture existing controls and residual risk per threat

**Completion checks:**
- Each critical boundary has at least one documented threat scenario
- High-impact scenarios include explicit mitigating controls or clear gaps
- Residual risk is stated for each high-priority scenario

**Stop conditions:**
- Threat scenarios cannot be tied to concrete boundaries
- High-impact scenarios are present but unowned

---

### Stage C — Control baseline and resilience design

**Goal:** Reduce exploitability and blast radius through preventive, detective, and compensating controls.

**Minimum control families to review:**
- Identity and access (least privilege, scoped credentials, rotation)
- Input and output controls (validation, normalization, safe rendering)
- Data and crypto controls (classification, encryption, key handling)
- Isolation and segmentation (network and workload boundaries)
- Dependency and supply chain controls (integrity, provenance, update policy)
- Abuse controls (rate limiting, throttling, fail-safe defaults)
- Proof and verification controls (invariants, evidence generation, independent verifier)

**Non-leakage proof design requirements:**
- Define every critical isolation boundary (tenant, session, identity, inter-agent channel, memory domain)
- Select proof class per boundary:
  - Structural proof: architecture or configuration constraints proving isolation by construction
  - Behavioral proof: runtime telemetry proving no cross-boundary leakage in an observation window
  - Formal proof: machine-checkable invariant or non-interference claim with verifier output
- Require formal proof for critical boundaries; evidence-only proof is allowed for non-critical boundaries when risk is documented
- Bind each proof artifact to an owner, verifier, evidence pointer, and re-verification trigger

**Branch checks:**

*Traditional apps:*
- API authorization coverage and privilege-boundary tests
- Dangerous function/use path inventory

*AI/agentic apps:*
- Prompt and tool input validation boundaries
- Tool permission scoping and explicit allowlists
- Output handling safeguards and unsafe action confirmation gates

**Completion checks:**
- Gaps are mapped to concrete control changes
- Each change has an owner and target date
- Compensating controls exist for deferred fixes

**Stop conditions:**
- Critical control gaps exist without mitigation plan
- Proposed controls weaken trust boundaries

---

### Stage D — Runtime observability and incident readiness

**Goal:** Ensure attacks are detectable and containment is executable.

**Required runtime capabilities:**
- Security-relevant event logging across critical boundaries
- Alerts for abuse patterns, auth anomalies, privilege escalation signals, and data exfiltration indicators
- On-call ownership and escalation path
- Containment runbook (detect, isolate, preserve evidence, recover)
- Leakage detection indicators across boundaries (cross-tenant access attempts, stale session access reuse, memory cross-domain reads)
- Immutable trace records for proof-of-non-leakage evidence

**Quality checks:**
- Alert-to-owner mapping is complete
- Runbook has clear trigger conditions and first actions
- Evidence retention expectations are defined
- Proof records include boundary ID, detection method, evidence link, verifier, and status

**Stop conditions:**
- No actionable alerting coverage for high-impact scenarios
- No tested containment path

---

### Stage E — Gate decision and evidence package

**Goal:** Produce a clear release/security posture decision.

**Decision logic:**
- **PASS:** No critical unmitigated gaps; monitoring and containment ready
- **CONDITIONAL:** Bounded high/moderate gaps with compensating controls, owner, and due date
- **FAIL:** Critical unmitigated gaps, missing ownership, missing detection or containment readiness, or missing invalid non-leakage proof artifacts for critical boundaries

**Required output fields:**
- Skills used and sections applied
- Scope and assumptions
- Top risks and control gaps
- Decision (PASS, CONDITIONAL, FAIL) with rationale
- Required actions with owner and due date
- Evidence pointers and escalation owner
- Non-leakage proof coverage summary (boundary, proof class, status, verifier, artifact link)

**P2D and P2B proof output snippet (required when gate reporting is in scope):**

```markdown
Proof-of-Non-Leakage Coverage:
| boundary_id | criticality | proof_class | proof_status | verifier | artifact_link |
|---|---|---|---|---|---|
| <id> | <Critical|High|Medium> | <Structural|Behavioral|Formal> | <VERIFIED|CONDITIONAL|FAILED|INDETERMINATE> | <name/role> | <link> |

Gate enforcement notes:
- P2D: Any Critical boundary missing formal-proof design or artifact plan => FAIL.
- P2B: Any Critical boundary in FAILED or INDETERMINATE status => FAIL.
```

---

### Layer 2 handoff rules
- Route governance/policy deviation decisions to **Layer 1 Governance** (this skill)
- Route Molina PRE/P2D/P2B formal gate outputs to **molina-application-security**
- Route agent harness/tool-contract architecture to **Layer 3 Agentic Operations** (this skill)
- Add SSDF, 218A, or OWASP mapping only when explicitly requested

---

## Layer 3 — Agentic & Platform Operations

Operationalize governance and application defense for agentic systems with harness specifications, tool contracts, platform adapters, and evidence collection.

### Core operating principles
- **Least-agency:** Remove unneeded autonomy before adding controls
- **Least-privilege:** Every tool call runs with bounded identity and scope
- **Fail-closed:** Missing required inputs or unclear intent must stop execution
- **Human gates:** High-impact actions require explicit approval
- **Audit-first:** Every decision and tool call must be traceable

---

### Getting Started (7 steps)

1. **Choose platform configuration** — See [assets/Platform-Adoption-Matrix.md](assets/Platform-Adoption-Matrix.md) for minimum controls by deployment type (GitHub-only, ADO-only, dual)
2. **Follow implementation roadmap** — See [references/Implementation-Roadmap.md](references/Implementation-Roadmap.md) for 5-increment Ralph Wiggum adoption sequence
3. **Run AppSec review** — Use the DAG at [references/AppSec-Review-Harness-DAG.md](references/AppSec-Review-Harness-DAG.md) as your workflow guide
4. **Collect evidence** — Use platform checklist ([GitHub](assets/GitHub-Evidence-Collection-Checklist.md) or [Azure DevOps](assets/Azure-DevOps-Evidence-Collection-Checklist.md)), then fill [assets/Agent-Evidence-Pack-Template.md](assets/Agent-Evidence-Pack-Template.md)
5. **Document findings** — Use [assets/Agentic-Findings-Schema.yaml](assets/Agentic-Findings-Schema.yaml) for normalized finding records
6. **Review agentic threats** — Run [references/Agentic-Threat-Modeling-Extension.md](references/Agentic-Threat-Modeling-Extension.md) at design time (SSDF PW.1 / 218A PW.1.1)
7. **Govern ongoing operations** — See [assets/Governance-and-Maintenance-Runbook.md](assets/Governance-and-Maintenance-Runbook.md) for review cadence and SLAs

---

### Harness specifications

- **AppSec review workflow DAG:** [references/AppSec-Review-Harness-DAG.md](references/AppSec-Review-Harness-DAG.md) — 7-stage deterministic workflow with platform adapter hooks and gate logic
- **Evaluation and regression safety:** [references/Evaluation-Harness-Spec.md](references/Evaluation-Harness-Spec.md) — Eval harness spec, test case format, regression criteria, production parity requirements
- **Strict tool contract patterns:** [references/Tool-Contract-Patterns.md](references/Tool-Contract-Patterns.md) — Fail-closed tool schemas with field validation and error handling
- **Observability and evidence contract:** [references/Observability-and-Evidence-Contract.md](references/Observability-and-Evidence-Contract.md) — Trace schema for decision records, tool calls, retrieval snapshots, evidence packaging
- **Formal non-leakage evidence contract:** [references/proof-of-non-leakage-evidence-contract.md](references/proof-of-non-leakage-evidence-contract.md) — Proof classes, critical-boundary requirements, acceptance criteria, and fail-closed semantics
- **Formal isolation proof profile:** [references/formal-isolation-proof-profile.md](references/formal-isolation-proof-profile.md) — Required formal deliverables, model assumptions, and re-verification triggers
- **GitHub adapter requirements:** [references/Platform-Adapter-GitHub.md](references/Platform-Adapter-GitHub.md) — Required permissions, API call contracts, PR action boundaries
- **Azure DevOps adapter requirements:** [references/Platform-Adapter-Azure-DevOps.md](references/Platform-Adapter-Azure-DevOps.md) — Pipeline access model, work item write constraints

---

### Control mappings and evidence templates

- **OWASP Agentic Top 10 crosswalk:** [assets/OWASP-Agentic-Top-10-Mapping.md](assets/OWASP-Agentic-Top-10-Mapping.md) — All 10 ASI → Molina / SSDF / 218A controls with prevent/detect/respond mitigations
- **Agentic threat modeling extension:** [references/Agentic-Threat-Modeling-Extension.md](references/Agentic-Threat-Modeling-Extension.md) — Extends SSDF PW.1 / 218A PW.1.1 with per-ASI attack surface questions
- **Evidence pack template:** [assets/Agent-Evidence-Pack-Template.md](assets/Agent-Evidence-Pack-Template.md) — Assemble evidence artifacts for agentic review gates (Molina phase gates + ASI control status)
- **Agentic findings schema:** [assets/Agentic-Findings-Schema.yaml](assets/Agentic-Findings-Schema.yaml) — Normalized YAML schema for agentic security findings (source platform, severity, status, framework mapping)
- **Fail-closed tool schema starter patterns:** [assets/Tool-Schema-Template.yaml](assets/Tool-Schema-Template.yaml) — Reusable patterns with field validation, error schema, and examples

---

### Evidence collection and checklists

- **GitHub evidence checklist:** [assets/GitHub-Evidence-Collection-Checklist.md](assets/GitHub-Evidence-Collection-Checklist.md) — DAG stages 1 & 5: repository metadata, code scanning, workflows, PRs, supply chain, evidence packaging
- **Azure DevOps evidence checklist:** [assets/Azure-DevOps-Evidence-Collection-Checklist.md](assets/Azure-DevOps-Evidence-Collection-Checklist.md) — DAG stages 1 & 5: repository, pipeline, security scans, work items, supply chain, evidence packaging

---

### Adoption enablement and governance

- **Platform adoption matrix:** [assets/Platform-Adoption-Matrix.md](assets/Platform-Adoption-Matrix.md) — Minimum controls, evidence artifacts, SLA targets by configuration (GitHub-only, ADO-only, dual)
- **Implementation roadmap:** [references/Implementation-Roadmap.md](references/Implementation-Roadmap.md) — 5-increment Ralph Wiggum adoption sequence with acceptance criteria
- **Change management and harness updates:** [references/Change-Management-and-Harness-Updates.md](references/Change-Management-and-Harness-Updates.md) — Rules for updating and versioning the harness
- **Governance and maintenance runbook:** [assets/Governance-and-Maintenance-Runbook.md](assets/Governance-and-Maintenance-Runbook.md) — Review cadence, SLAs, escalation procedures, incident playbooks

---

### Gotchas

- **Human-in-the-loop without veto authority is theater, not a gate.** A human notified but unable to stop an action provides no safety guarantee. Gates require actual blocking capability.
- **Audit trails must be append-only.** An agent that can modify its own execution logs is self-auditing. Logs must be written to a sink the agent cannot access with write permissions.
- **Tool contract violations in test ≠ tool contract violations in production.** The eval harness must mirror production tool constraints exactly. If prod tools have rate limits, the eval harness must too.
- **Scope ambiguity is a stop condition, not a recoverable error.** If task scope is unclear (could trigger different risk tiers), stop and escalate — do not pick the interpretation that allows the action.

---

## Stop conditions (Layer 3)

Stop and escalate when any of the following are true:
- Scope is ambiguous and could change risk tier
- Tool inventory or identity model is incomplete
- Required evidence cannot be produced for a gate decision
- Proposed action affects production posture without human approval

---

## Unified output contract

**All layers use a consistent PASS / CONDITIONAL / FAIL decision model:**

- **PASS:** No critical unmitigated gaps; all required evidence and approvals in place; proceed to next phase
- **CONDITIONAL:** Bounded gaps with compensating controls, owner, and due date; escalation path clear; human approval recorded
- **FAIL:** Critical unmitigated gaps, missing ownership, blocked on required evidence, or human rejection; remediation plan required before re-review

**Required output fields (all layers):**
- Skills used and sections applied (e.g., "molina-mythNOs-agentic-security: Layer 1 Governance + Layer 3 Evidence Collection")
- Scope and assumptions
- Gate decision with rationale
- Required evidence pointers
- Escalation owner and next action

---

## Routing and handoffs

| Destination | Use When |
|---|---|
| **molina-application-security** | Formal Molina PRE/P2D/P2B gate decision or RITM tracking required |
| **molina-nist-218a** | Training data protection, model weight security, or AI pipeline controls needed |
| **nist-ssdf** | SSDF practice mapping or federal compliance audit required |
| **owasp-genai-security** | LLM-specific risks (prompt injection, model extraction) or MCP server security |
| **application-defense-workflow** (deprecated) | Superseded by Layer 2; do not use new projects |
| **defensive-governance** (deprecated) | Superseded by Layer 1; do not use new projects |
| **anti-mythos-agentic-security** (deprecated) | Superseded by Layer 3; do not use new projects |

---

## Defensive-Governance Checklist

Use [assets/Defensive-Governance-Checklist.md](assets/Defensive-Governance-Checklist.md) during architecture and policy decisions to keep outcomes secure-by-design and audit-ready.

---

## Activation triggers

Activate this skill when the user mentions or requests:
- Agentic AppSec, AppSec agent, agentic security
- Application defense, runtime resilience, incident containment
- Attack surface reduction, secure-by-design, threat inventory
- Breach readiness, security monitoring, security resilience
- Agentic threat model, agent threat modeling
- Tool misuse prevention, tool contracts, tool schema
- Agent workflow governance, agent operations, harness-first
- Defensive governance, policy checks, risk acceptance
- Anti-mythos (direct reference to deprecated skill)

---

## Non-goals and prohibited uses

- Not an exploit generator
- Not a penetration-testing replacement
- Not a red-team assistant
- Not a policy-evasion advisor
- Not for offensive simulation beyond defensive risk framing
