# Molina MythNOs Agentic Security

Unified agentic AppSec skill combining governance, application defense, and platform operations into a single routing surface.

## Package overview

This skill consolidates three complementary AppSec workflows:

- **Layer 1 — Governance:** Policy gates, secure-by-design defaults, and risk acceptance decisions
- **Layer 2 — Application Defense Workflow:** Per-application threat inventory, control baseline design, and runtime resilience
- **Layer 3 — Agentic & Platform Operations:** Harness DAG, tool contracts, platform adapters, and evidence collection for agentic systems

All layers follow a **PASS / CONDITIONAL / FAIL** decision model with audit-first outputs and human gate enforcement.

Control precedence: **Molina AppSec > NIST SP 800-218A > NIST SP 800-218 > OWASP (supplemental)**

## Files included

### Main entry point
- `SKILL.md` — Unified 3-layer skill definition with frontmatter, routing, and all layer specifications

### Layer 1 governance
- `assets/Defensive-Governance-Checklist.md` — Execution checklist for capability and preventable-design checks

### Layer 2 evidence templates and schemas
- `assets/Agent-Evidence-Pack-Template.md` — Evidence pack template for agentic review gates (Molina phase gates + ASI control status)
- `assets/Agentic-Findings-Schema.yaml` — Normalized YAML schema for agentic findings (source platform, severity, status, framework mapping)
- `assets/GitHub-Evidence-Collection-Checklist.md` — Artifact collection checklist for GitHub repositories
- `assets/Azure-DevOps-Evidence-Collection-Checklist.md` — Artifact collection checklist for Azure DevOps pipelines

### Layer 3 harness specifications
- `references/AppSec-Review-Harness-DAG.md` — 7-stage deterministic DAG for AppSec review workflow
- `references/Evaluation-Harness-Spec.md` — Eval harness specification, test case format, regression criteria
- `references/Tool-Contract-Patterns.md` — Fail-closed tool contract patterns with validation examples
- `references/Observability-and-Evidence-Contract.md` — Trace schema for decision records and tool calls
- `references/proof-of-non-leakage-evidence-contract.md` — Proof classes, gate acceptance criteria, and fail-closed non-leakage requirements
- `references/formal-isolation-proof-profile.md` — Formal verification deliverables, invariant profile, and counterexample handling

### Layer 3 control mappings and threat modeling
- `assets/OWASP-Agentic-Top-10-Mapping.md` — ASI01–ASI10 → Molina / SSDF / 218A crosswalk with mitigations
- `references/Agentic-Threat-Modeling-Extension.md` — Extends SSDF PW.1 / 218A PW.1.1 with per-ASI attack surface questions

### Layer 3 platform adapters
- `references/Platform-Adapter-GitHub.md` — Required permissions, API contracts, PR action boundaries
- `references/Platform-Adapter-Azure-DevOps.md` — Pipeline access model, work item write constraints

### Layer 3 adoption and governance
- `assets/Platform-Adoption-Matrix.md` — Minimum controls by deployment type (GitHub-only, ADO-only, dual)
- `references/Implementation-Roadmap.md` — 5-increment Ralph Wiggum adoption roadmap
- `references/Change-Management-and-Harness-Updates.md` — Rules for harness versioning and updates
- `assets/Governance-and-Maintenance-Runbook.md` — Review cadence, SLAs, escalation procedures

### Layer 3 tool schemas and templates
- `assets/Tool-Schema-Template.yaml` — Reusable fail-closed tool contract patterns
- `assets/evaluation-testcases-template.yaml` — Eval test case format template

### Regression suite
- `evals/evals.json` — Regression and evaluation testcases for harness validation

## 3-layer architecture

```
Governance (Layer 1)
  ↓ governs decisions escalated from
Application Defense (Layer 2)
  ↓ routes AI/agentic systems to
Agentic Operations (Layer 3)
```

**When to activate each layer:**
- **Layer 1:** Architecture and policy questions, capability tier checks, risk acceptance, security design reviews
- **Layer 2:** Per-application threat modeling, control baseline design, runtime observability setup, app-level gate decisions
- **Layer 3:** Agentic systems only; tool contract design, harness execution, ASI threat mapping, evidence collection

## How to use

1. **Read SKILL.md** — Start with the unified skill definition to understand the 3-layer structure
2. **Choose your layer** — Governance, application defense, or agentic operations
3. **Follow the referenced files** — Each layer points to specific templates, checklists, and specifications
4. **Output a decision** — Use the unified PASS / CONDITIONAL / FAIL contract with audit-first evidence

## Superseded skills

This skill consolidates:
- `anti-mythos-agentic-security` → Layer 3 (deprecated, marked in-place)
- `application-defense-workflow` → Layer 2 (deprecated, marked in-place)
- `defensive-governance` → Layer 1 (deprecated, marked in-place)

Existing projects using the deprecated skills should migrate to this unified skill. A deprecation notice has been added to each source skill.

## Non-goals

- Not an exploit generator
- Not a penetration-testing replacement
- Not a red-team assistant
- Not a policy-evasion advisor

---

For full details, see `SKILL.md`.
