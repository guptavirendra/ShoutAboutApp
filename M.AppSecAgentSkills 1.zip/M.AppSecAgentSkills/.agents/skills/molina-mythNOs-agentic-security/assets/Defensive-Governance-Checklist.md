# Defensive Governance Checklist

Use this checklist during architecture and policy decisions to keep outcomes secure-by-design and audit-ready.

## Capability and boundary checks

- [ ] Action is classified into Tier 0, 1, or 2 capability.
- [ ] Requested action is not in prohibited capability class.
- [ ] Non-goals have been reviewed and remain enforced.

## Preventable-design checks

- [ ] Trust boundaries are explicit and validated.
- [ ] Authentication and authorization assumptions are explicit.
- [ ] Privilege model is least-privilege and time-bounded.
- [ ] Irreversible operations include rollback or compensating controls.
- [ ] Unnecessary capability has been removed where feasible.

## Stop-condition checks

- [ ] Architecture context is sufficient for decision confidence.
- [ ] Security requirements are not contradictory.
- [ ] Policy or regulatory interpretation is unambiguous.
- [ ] High-impact recommendations have adequate evidence.

If any item above fails, return:

`Insufficient information - human AppSec review required`

## Audit-first output checks

- [ ] Decision summary is explicit.
- [ ] Assumptions and context gaps are documented.
- [ ] Security trade-offs are documented.
- [ ] Potential failure modes are documented.
- [ ] Proceed/stop outcome is explicit.
- [ ] Escalation owner and next action are recorded when stopped.
- [ ] Evidence artifacts to capture are listed.
