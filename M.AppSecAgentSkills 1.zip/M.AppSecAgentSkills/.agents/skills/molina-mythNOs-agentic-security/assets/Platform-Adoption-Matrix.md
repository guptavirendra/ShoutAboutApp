# Platform Adoption Matrix

Reference this matrix when selecting the minimum controls, required evidence artifacts, SLA targets, and migration criteria for a given deployment configuration.

Control precedence: **Molina AppSec > NIST SP 800-218A > NIST SP 800-218 > OWASP (supplemental)**

## Deployment Configurations

| Configuration | Description |
|---|---|
| GitHub-only | All source control, CI/CD, and scanner results are in GitHub |
| Azure DevOps-only | All source control, pipelines, and scanner results are in Azure DevOps |
| Dual-platform | Source or work items split across both platforms |

## Minimum Controls by Configuration

### GitHub-Only

| Control Area | Minimum Required | Evidence Artifact | Waiver Path |
|---|---|---|---|
| Source control | Repository with branch protection (require PR + status checks) | Branch policy screenshot or API export | APPSEC-APR exception form |
| SAST | GitHub Advanced Security code scanning enabled | Code scanning alert export or link | APPSEC-APR with compensating control |
| Secret scanning | GitHub Advanced Security secret scanning enabled | Secret scanning status report | APPSEC-APR with compensating control |
| Dependency scanning | Dependabot or equivalent enabled | Dependency alert triage export | APPSEC-APR with compensating control |
| Supply chain | Actions pinned to SHA; SBOM generated | SBOM file linked in evidence pack | APPSEC-APR exception form |
| Workflow safety | No `continue-on-error: true` on security gates | Workflow file review or scan output | None — architectural requirement |
| Agentic tool scope | Tool contracts defined with least-privilege scope | Tool-Schema-Template instantiated per tool | None — architectural requirement |
| Evidence collection | Platform adapter configured | Platform-Adapter-GitHub.md compliance | APPSEC-APR with timeline |
| Gate decision | HITL confirmation before P2B decision | Approval record with APPSEC-APR-\<id\> | None — mandatory |

### Azure DevOps-Only

| Control Area | Minimum Required | Evidence Artifact | Waiver Path |
|---|---|---|---|
| Source control | Repository with branch policies (min reviewers, linked work items) | Branch policy export | APPSEC-APR exception form |
| SAST | SonarQube quality gate configured; gate passes | SonarQube project key + quality gate status | APPSEC-APR with compensating control |
| Supply chain scan | Wiz or equivalent supply chain scan completed | Wiz scan artifact linked in evidence pack | APPSEC-APR with compensating control |
| Work item linkage | Each finding has an ADO work item with RITM | Work item ID and status export | None — Molina program requirement |
| Pipeline safety | No `continueOnError: true` on security tasks | Pipeline definition review | None — architectural requirement |
| Artifact retention | Build artifacts retained per AppSec review window | Retention policy screenshot | APPSEC-APR exception form |
| PAM service connection | Service connections use PAM-managed credentials | PAM evidence or attestation | APPSEC-APR with timeline |
| Agentic tool scope | Tool contracts defined with least-privilege scope | Tool-Schema-Template instantiated per tool | None — architectural requirement |
| Evidence collection | Platform adapter configured | Platform-Adapter-Azure-DevOps.md compliance | APPSEC-APR with timeline |
| Gate decision | HITL confirmation before P2B decision | Approval record with APPSEC-APR-\<id\> | None — mandatory |

### Dual-Platform

All controls from both GitHub-only and Azure DevOps-only apply.

| Additional Control | Minimum Required | Evidence Artifact |
|---|---|---|
| Cross-platform normalization | Findings normalized using shared schema | Agentic-Findings-Schema.yaml populated with source_platform fields |
| Unified evidence pack | Single Agent-Evidence-Pack-Template covering both platforms | Evidence pack with both platform sections populated |
| Consistent RITM tracking | One RITM per finding regardless of source platform | RITM IDs cross-linked in ADO work items |

## SLA Targets

| Activity | Target | Notes |
|---|---|---|
| PRE gate review | 2 business days | From RITM submission |
| P2D gate review | 3 business days | From all P2D artifacts submitted |
| P2B gate review | 5 business days | From all P2B artifacts submitted |
| Critical finding response | 1 business day | Assign owner and RITM within 1 day |
| High finding response | 3 business days | Assign owner and RITM within 3 days |
| CONDITIONAL exception | 5 business days | APPSEC-APR filed and acknowledged |
| HITL escalation | 4 business hours | For decisions blocked on human approval |

## Escalation Paths

| Scenario | Escalation Owner | Action |
|---|---|---|
| Missing required artifact | IT Security Owner listed in evidence pack | Block gate; request artifact |
| CONDITIONAL finding unresolved at gate | Molina AppSec Program | Review waiver or extend timeline |
| FAIL at gate | IT Security Owner + Business Owner | Stop advancement; remediation plan required |
| HITL approval unavailable | Backup approver defined in evidence pack | Use backup; log in approval record |

## Migration Criteria

A project may migrate between configurations when all of the following are met:

1. All open findings in the current configuration are in REMEDIATE or CLOSED status.
2. The target platform's minimum controls are fully deployed and evidenced.
3. Cross-platform normalization schema is populated (for dual-platform).
4. A migration plan is reviewed at P2D gate before migration begins.
5. Post-migration gate review is scheduled within 10 business days.
