# GitHub Evidence Collection Checklist

Use this checklist at DAG stage 1 (intake/triage) and stage 5 (evidence mapping) to verify GitHub artifacts are available and complete before gate decisions.

## Repository Metadata

- [ ] Repository URL and owner/name confirmed
- [ ] Target branch or PR ref confirmed
- [ ] Default branch is known and matches deployment target
- [ ] Repository visibility (public/internal/private) matches data sensitivity classification

## Code Scanning (SAST / Secret Scanning)

- [ ] GitHub Advanced Security or equivalent is enabled for the repository
- [ ] Latest code scanning run completed without workflow failures
- [ ] Code scanning alerts exported or linked for the target ref
- [ ] No open Critical or High severity alerts without accepted exception
- [ ] Secret scanning enabled; no active detected secrets without remediation
- [ ] Dependency scanning / Dependabot alerts reviewed and triaged

## Workflow and Pipeline Metadata

- [ ] Relevant workflow run IDs recorded for the target ref
- [ ] Pipeline execution status confirmed (passed / failed / skipped)
- [ ] Scanner configuration files (e.g., `.github/workflows/security.yml`) reviewed for bypass flags or `continue-on-error: true` patterns that could mask failures
- [ ] Branch protection rules confirmed (require status checks, require PR reviews)

## Pull Request Context (when in-scope)

- [ ] PR number and source/target branch recorded
- [ ] PR review history available (approvals, change requests, comments)
- [ ] All required reviewers have approved
- [ ] No unresolved security-flagged review comments

## Supply Chain Artifacts

- [ ] Software Bill of Materials (SBOM) available or generated for the release
- [ ] Dependency provenance attestations available where applicable
- [ ] Third-party action pinning verified (actions pinned to full SHA, not floating tag)
- [ ] No untrusted or unverified GitHub Actions in scope workflows

## Evidence Packaging

- [ ] All artifact links recorded in [Agent-Evidence-Pack-Template.md](Agent-Evidence-Pack-Template.md) or AppSec-Remediation-Tracker-Template
- [ ] Scanner run IDs recorded in observability trace (run_id field per tool-call record)
- [ ] Missing artifact gaps documented with explicit STOP or CONDITIONAL note

## Fail-Closed Rule

If any required artifact is unavailable, return a structured `missing_artifact` error and do not infer the outcome. Escalate to STOP when missing artifacts block a mandatory gate decision.
