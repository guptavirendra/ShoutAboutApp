# Governance and Maintenance Runbook

Operational playbook for maintaining the Anti-Mythos Agentic Security skill package in steady-state. Use this runbook to drive recurring review cadence, ensure SLA compliance, and manage the harness lifecycle.

Control precedence: **Molina AppSec > NIST SP 800-218A > NIST SP 800-218 > OWASP (supplemental)**

## Roles and Responsibilities

| Role | Responsibilities |
|---|---|
| IT Security Owner | Gate decision authority; escalation approvals; harness review lead |
| Molina AppSec Program | Program-level compliance tracking; RITM and APPSEC-APR lifecycle |
| Platform AppSec Engineers | GitHub and ADO adapter maintenance; platform-specific triage |
| AI/ML Architect | Tool contract review; agentic threat model updates |
| Project Business Owner | Named in evidence pack; required approver for CONDITIONAL or FAIL outcomes |

## Review Cadence

### Weekly — Scan Result Triage

**Who**: Platform AppSec Engineers  
**When**: Every Monday  
**Scope**: All open findings (status: OPEN) from the prior 7 days

Checklist:
- [ ] Review new findings in Agentic-Findings-Schema.yaml and cross-reference with ADO work items
- [ ] Confirm all Critical and High findings have an assigned owner and due date
- [ ] Confirm no finding has been in OPEN status past its due date without escalation
- [ ] Update finding statuses that have moved to REMEDIATE or CLOSED since last review
- [ ] Flag any new agentic threat category patterns not covered by existing controls

**Output**: Updated findings register or ADO work item state changes

### Monthly — Harness Health Check

**Who**: IT Security Owner; Platform AppSec Engineers  
**When**: First business day of each month  
**Scope**: Harness configuration and observable behavior

Checklist:
- [ ] Confirm all tooling referenced in Platform-Adapter-GitHub.md and Platform-Adapter-Azure-DevOps.md is still active and accessible
- [ ] Confirm evaluation testcases in `evaluation-testcases-template.yaml` are still runnable
- [ ] Review any new ASI, SSDF, or 218A updates released in the prior month; flag for quarterly action if significant
- [ ] Review open CONDITIONAL exceptions and confirm they are still valid or require escalation
- [ ] Confirm HITL approval queue is empty or SLA-compliant (≤ 4 business hours outstanding)

**Output**: Monthly health check note committed to repo (or added to governance tracker)

### Quarterly — Harness Retrospective and Regression Baseline Update

**Who**: IT Security Owner; AI/ML Architect; Platform AppSec Engineers  
**When**: First full week of each quarter  
**Scope**: Full harness review

Checklist:
- [ ] Run full regression baseline (all testcases in `evaluation-testcases-template.yaml`)
- [ ] Review any new findings patterns from pilot usage; add new testcases where needed
- [ ] Review SKILL.md routing for stale or missing entries
- [ ] Review OWASP-Agentic-Top-10-Mapping.md and Agentic-Threat-Modeling-Extension.md for framework drift
- [ ] Review Platform-Adoption-Matrix.md for any SLA or escalation path changes
- [ ] Review all CONDITIONAL exceptions; close resolved ones; re-evaluate open ones
- [ ] Update Implementation-Roadmap.md increment statuses
- [ ] Draft any needed minor version bumps per Change-Management-and-Harness-Updates.md

**Output**: Quarterly retrospective notes; any harness updates committed on a feature branch; updated version markers in SKILL.md

### Annual — Full Framework Alignment

**Who**: IT Security Owner; Molina AppSec Program; AI/ML Architect  
**When**: Q4 annually (or as triggered by major framework releases)  
**Scope**: End-to-end framework alignment

Checklist:
- [ ] Compare current OWASP ASI Top 10 version to skill content; update any new or changed entries
- [ ] Compare current NIST SP 800-218A and SP 800-218 versions to crosswalk tables
- [ ] Compare current Molina AppSec gate controls to PRE/P2D/P2B rows in templates
- [ ] Review allowed-tools declarations in all SKILL.md files
- [ ] Assess whether a major version bump is required (breaking change criteria in Change-Management-and-Harness-Updates.md)
- [ ] Confirm APPSEC-APR reference number series is current year

**Output**: Annual framework alignment review committed; SKILL.md version bumped if warranted; Molina AppSec Program notified

## SLA Reference

| Decision Type | Target | Escalation If Missed |
|---|---|---|
| PRE gate review | 2 business days from RITM | IT Security Owner → Business Owner |
| P2D gate review | 3 business days from artifacts submitted | IT Security Owner → Molina AppSec |
| P2B gate review | 5 business days from artifacts submitted | IT Security Owner → Molina AppSec |
| Critical finding response | 1 business day | IT Security Owner → Business Owner |
| High finding response | 3 business days | Platform AppSec Engineer → IT Security Owner |
| HITL escalation (blocked gate) | 4 business hours | IT Security Owner |
| CONDITIONAL exception acknowledgment | 5 business days | Molina AppSec Program |

## Escalation Playbook

### Gate FAIL decision

1. IT Security Owner issues FAIL decision with rationale and required remediation.
2. Business Owner acknowledges within 1 business day.
3. Project team submits remediation plan with RITM within 3 business days.
4. Re-review scheduled after remediation evidence is available.
5. If remediation plan not received within 5 business days, escalate to Molina AppSec Program.

### HITL approval unavailable

1. Check backup approver listed in evidence pack.
2. If backup also unavailable, document in trace log and hold gate decision.
3. Escalate to IT Security Owner; target 4-hour resolution.
4. Do not auto-approve; fail closed until approval is obtained.

### Skill package supply chain incident

1. Immediately remove compromised skill or tool reference from SKILL.md on a hotfix branch.
2. File an APPSEC-APR exception for any open reviews using the affected content.
3. Notify IT Security Owner and Molina AppSec Program within 4 business hours.
4. Run regression baseline after hotfix is applied.
5. Document incident in governance tracker.

## Artifact Locations Quick Reference

| Artifact | Location |
|---|---|
| Skill entrypoint | `.agents/skills/anti-mythos-agentic-security/SKILL.md` |
| Review workflow DAG | `references/AppSec-Review-Harness-DAG.md` |
| Threat modeling extension | `references/Agentic-Threat-Modeling-Extension.md` |
| Evidence pack template | `assets/Agent-Evidence-Pack-Template.md` |
| Findings schema | `assets/Agentic-Findings-Schema.yaml` |
| Tool schema patterns | `assets/Tool-Schema-Template.yaml` |
| Platform adoption matrix | `assets/Platform-Adoption-Matrix.md` |
| Implementation roadmap | `references/Implementation-Roadmap.md` |
| Regression testcases | `assets/evaluation-testcases-template.yaml` |
| Change management guide | `references/Change-Management-and-Harness-Updates.md` |
