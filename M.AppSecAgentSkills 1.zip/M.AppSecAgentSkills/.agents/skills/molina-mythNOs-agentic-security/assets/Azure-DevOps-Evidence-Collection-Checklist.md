# Azure DevOps Evidence Collection Checklist

Use this checklist at DAG stage 1 (intake/triage) and stage 5 (evidence mapping) to verify Azure DevOps artifacts are available and complete before gate decisions.

## Repository Metadata

- [ ] Organization, project, and repository name confirmed
- [ ] Target branch or PR ref confirmed
- [ ] Repository type (Git) and visibility confirmed
- [ ] Default branch matches deployment target

## Pipeline Metadata

- [ ] Relevant pipeline run IDs recorded for the target ref
- [ ] Pipeline execution status confirmed (succeeded / failed / partially succeeded)
- [ ] No `continueOnError: true` task settings that could mask security scan failures
- [ ] Build artifact retention policy confirmed (artifacts not expired before review)
- [ ] Branch policies confirmed (require a minimum number of reviewers, require linked work items)

## Security Scan Artifacts

- [ ] SAST results available (SonarQube project key and quality gate status, or equivalent)
- [ ] SonarQube quality gate passed; no unresolved Critical/High security issues
- [ ] Wiz supply chain scan completed; findings triaged
- [ ] DAST scan results available and linked (web services, API, UI)
- [ ] Container/image scan results available if containers are in scope
- [ ] Secret detection scan executed; no active secrets without remediation

## Work Item and Remediation Linkage

- [ ] Work items created for each open security finding (RITM or ADO work item ID)
- [ ] Work items linked to pipeline runs for traceability
- [ ] Work item state reflects current remediation status (OPEN / REMEDIATE / CLOSED equivalent)
- [ ] Changes inventory sheet available (UI URLs, API URLs, DevOps repo link per Molina P2B-02)

## Pull Request Context (when in-scope)

- [ ] PR ID and source/target branch recorded
- [ ] PR review history available (approvals, comment threads)
- [ ] All required reviewers have approved
- [ ] No unresolved security-flagged comment threads

## Supply Chain Artifacts

- [ ] SBOM or software supply chain report available (Wiz or equivalent per Molina P2B-04)
- [ ] Third-party package provenance verified
- [ ] Open source components inventoried per Molina P2D-09 (OSS management)

## Evidence Packaging

- [ ] All artifact links recorded in [Agent-Evidence-Pack-Template.md](Agent-Evidence-Pack-Template.md) or AppSec-Remediation-Tracker-Template
- [ ] Pipeline run IDs and scan artifact IDs recorded in observability trace
- [ ] Missing artifact gaps documented with explicit STOP or CONDITIONAL note

## Fail-Closed Rule

If any required artifact is unavailable, return a structured `missing_artifact` error and do not infer the outcome. Escalate to STOP when missing artifacts block a mandatory gate decision.
