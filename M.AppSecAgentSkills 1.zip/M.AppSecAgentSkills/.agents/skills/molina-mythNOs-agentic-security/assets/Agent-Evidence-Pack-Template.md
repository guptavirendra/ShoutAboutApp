# Agent Evidence Pack Template

Use this template to document control evidence and remediation status for an agentic system under AppSec review.

## Project Metadata

| Field | Value |
|---|---|
| Project Name | |
| RITM ID | RITM-\<id\> |
| Agentic System Name | |
| Initiative / Release | |
| Gate Phase | PRE / P2D / P2B |
| Business Owner | |
| IT Security Owner | |
| AI/ML Engineer | |
| Last Updated | |

## Agentic System Scope

| Field | Value |
|---|---|
| Agent type | autonomous / semi-autonomous / tool-calling only |
| Tool inventory | list tools with operation and purpose |
| Memory model | session-only / cross-session / none |
| Retrieval sources | list RAG or external sources, if any |
| Platform | GitHub / Azure DevOps / both |
| Data sensitivity | PHI / PII / internal / public |
| Approval gates (HITL) | yes / no — describe |

## Control Assessment Summary

### Molina Phase Gates

| Control ID | Molina Line Item | Status (PASS / CONDITIONAL / FAIL) | Evidence Pointer |
|---|---|---|---|
| PRE-01 | Lack of Application Team SharePoint URL | | |
| PRE-02 | Lack of AppSec review request ticket in iServe | | |
| PRE-03 | Lack of Design Authority Review | | |
| PRE-04 | Lack of previous AppSec remediation plan | | |
| PRE-05 | Lack of stakeholder information | | |
| P2D-01 | Lack of project changes description | | |
| P2D-04 | Lack of architecture diagram | | |
| P2D-06 | Lack of data flow diagram | | |
| P2D-08 | Lack of end-to-end OAuth including last mile | | |
| P2D-09 | Lack of open source software management | | |
| P2B-01 | Lack of remediated threats from threat model | | |
| P2B-04 | Lack of software supply chain report | | |
| P2B-07 | Lack of penetration testing | | |

### Agentic Security Coverage (OWASP ASI Crosswalk)

| ASI ID | Category | Control Status | Evidence Pointer |
|---|---|---|---|
| ASI01 | Agent Goal Hijack | OPEN / REMEDIATE / CLOSED | |
| ASI02 | Tool Misuse & Exploitation | OPEN / REMEDIATE / CLOSED | |
| ASI03 | Identity & Privilege Abuse | OPEN / REMEDIATE / CLOSED | |
| ASI04 | Agentic Supply Chain Vulnerabilities | OPEN / REMEDIATE / CLOSED | |
| ASI05 | Unexpected Code Execution | OPEN / REMEDIATE / CLOSED | |
| ASI06 | Memory & Context Poisoning | OPEN / REMEDIATE / CLOSED | |
| ASI07 | Insecure Inter-Agent Communication | OPEN / REMEDIATE / CLOSED | |
| ASI08 | Cascading Failures | OPEN / REMEDIATE / CLOSED | |
| ASI09 | Human-Agent Trust Exploitation | OPEN / REMEDIATE / CLOSED | |
| ASI10 | Rogue Agents | OPEN / REMEDIATE / CLOSED | |

For full control-to-framework mapping see [OWASP-Agentic-Top-10-Mapping.md](OWASP-Agentic-Top-10-Mapping.md).

## Findings and Remediation Status

| Finding ID | ASI Category | Molina Line Item | Source | Severity | Status | Owner | Due Date | Evidence Link | Verifier | Verified Date |
|---|---|---|---|---|---|---|---|---|---|---|
| F-001 | ASI02 | P2B-04 | SonarQube \<id\> | Critical | OPEN | | | | | |
| F-002 | ASI01 | P2B-01 | Threat model review | High | REMEDIATE | | | | | |
| F-003 | ASI04 | P2D-09 | Wiz supply chain scan | Medium | CLOSED | | | | Verified | |

Status vocabulary: `OPEN` = not remediated. `REMEDIATE` = in progress or pending verification. `CLOSED` = verified and evidenced.

## Approvals and Exception References

If a finding cannot be closed before gate decision, file an approval request using [../../molina-application-security/AppSec-Request-for-Approval-Form-Template.md](../../molina-application-security/AppSec-Request-for-Approval-Form-Template.md).

| Approval ID | Finding ID | Disposition | Approver | Decision Date | Conditions |
|---|---|---|---|---|---|
| APPSEC-APR-\<yyyy\>-\<nnn\> | F-001 | approve with conditions | | | |

## Observability and Audit Trail

| Artifact | Location / Link | Coverage |
|---|---|---|
| Decision trace log | | All workflow stages |
| Tool-call audit log | | All tool invocations |
| Retrieval snapshot log | | All RAG/retrieval calls |
| Scanner run artifacts | | SAST, secrets, dependencies |
| Approval records | | High-impact human gates |

Minimum fields per trace record: see [../references/Observability-and-Evidence-Contract.md](../references/Observability-and-Evidence-Contract.md).

## Proof-of-Non-Leakage Verification

| Isolation Boundary ID | Boundary Description | Criticality | Proof Class (Structural / Behavioral / Formal) | Status (VERIFIED / CONDITIONAL / FAILED) | Evidence Pointer | Verifier | Verified Date |
|---|---|---|---|---|---|---|---|
| B-001 | tenant-a to tenant-b isolation | Critical | Formal | | | | |
| B-002 | session transition cleanup | High | Behavioral | | | | |
| B-003 | memory domain segmentation | Critical | Formal | | | | |

### Proof acceptance checklist
- [ ] Every critical boundary has a proof artifact and verifier.
- [ ] No critical boundary is in FAILED or indeterminate status at gate decision time.
- [ ] Formal proof artifacts for critical boundaries include tool version and run ID.
- [ ] Leakage detection traces are immutable and linked to boundary IDs.
- [ ] Independent reviewer sign-off is attached for P2B decisions.

## Gate Decision

| Gate | Result | Blockers | Next Action |
|---|---|---|---|
| PRE | PASS / CONDITIONAL / FAIL | | |
| P2D | PASS / CONDITIONAL / FAIL | | |
| P2B | PASS / CONDITIONAL / FAIL | | |
