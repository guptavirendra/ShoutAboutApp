# Anti-Mythos Implementation Roadmap

This roadmap sequences skill adoption using the Ralph Wiggum loop pattern: scope one increment, implement fully, verify against acceptance criteria, then ship or queue explicit feedback for the next loop.

Control precedence: **Molina AppSec > NIST SP 800-218A > NIST SP 800-218 > OWASP (supplemental)**

## Increment Structure

Each increment below defines:
- **Scope**: what is implemented and bounded by what
- **Dependencies**: what must be complete before starting
- **Acceptance criteria**: the verifiable conditions for completion
- **Completion evidence**: artifacts or states that prove completion
- **Handoff owners**: who reviews and approves before advancing

## Increment 1 — Harness-First Specifications (Phase 1)

**Scope**: Deploy the shared AppSec review DAG, evaluation harness, tool contracts, observability contract, and platform adapters.

**Dependencies**: M.AppSecAgentSkills repository access; base Molina AppSec skill package deployed.

**Acceptance criteria**:
- `AppSec-Review-Harness-DAG.md` published with all 7 stages and platform adapter hooks
- `Evaluation-Harness-Spec.md` published with 4 testcase classes and metrics
- `Tool-Contract-Patterns.md` published with at least repo.read and scanner.run contracts
- `Observability-and-Evidence-Contract.md` published with required trace fields
- Platform adapters for GitHub and Azure DevOps published and linked from SKILL.md

**Completion evidence**: Commit merged to `feature/agents-skills-migration`; SKILL.md routing map includes all 6 references.

**Handoff owners**: IT Security Owner; AI/ML Architect

**Status**: COMPLETE — commit 439310d

## Increment 2 — Control Mappings and Evidence Templates (Phase 2)

**Scope**: Deploy OWASP ASI crosswalk, threat modeling extension, evidence pack templates, findings schema, tool schema patterns, and platform evidence checklists.

**Dependencies**: Increment 1 complete; `owasp-genai-security` skill deployed with Agentic-Top10-Checklist.md.

**Acceptance criteria**:
- `OWASP-Agentic-Top-10-Mapping.md` covers ASI01–ASI10 with Molina gate, SSDF, 218A, and Anti-Mythos control columns
- `Agentic-Threat-Modeling-Extension.md` covers all 10 threat categories with attack surface questions and key controls
- `Agent-Evidence-Pack-Template.md` covers all required gate phases and ASI categories
- `Agentic-Findings-Schema.yaml` includes required/optional fields and 3 sample findings
- `Tool-Schema-Template.yaml` includes repo.read and scanner.run with valid/invalid examples
- Evidence collection checklists published for both GitHub and Azure DevOps

**Completion evidence**: Branch `feature/anti-mythos-phase2` pushed to origin; SKILL.md routing map updated to v0.2.

**Handoff owners**: IT Security Owner; Platform AppSec Engineers (GitHub, Azure DevOps)

**Status**: COMPLETE — commit f9dd0f8

## Increment 3 — Adoption Enablement and Governance (Phase 3)

**Scope**: Deploy platform adoption matrix, this roadmap, change management guidance, governance runbook, and final SKILL.md with Getting Started section.

**Dependencies**: Increment 2 complete.

**Acceptance criteria**:
- `Platform-Adoption-Matrix.md` defines minimum controls, SLAs, and migration criteria for GitHub-only, ADO-only, and dual-platform
- `Implementation-Roadmap.md` (this file) published with all 5 increments
- `Change-Management-and-Harness-Updates.md` published with versioning scheme, regression baseline, and supply chain review checklist
- `Governance-and-Maintenance-Runbook.md` published with weekly/monthly/quarterly/annual cadence
- SKILL.md updated to v0.3 with Phase 3 routing and Getting Started section

**Completion evidence**: Branch `feature/anti-mythos-phase3` pushed to origin; SKILL.md version bumped to 0.3.

**Handoff owners**: IT Security Owner; Molina AppSec Program; Platform Leads

**Status**: IN PROGRESS

## Increment 4 — Live Pilot (Platform Teams)

**Scope**: Run one real AppSec review per platform (GitHub and Azure DevOps) using the Anti-Mythos skill package. Capture feedback and update any failing criteria.

**Dependencies**: Increment 3 complete; at least one real project RITM in each platform.

**Acceptance criteria**:
- One GitHub-hosted agentic project completes PRE → P2D → P2B gates using Anti-Mythos skill artifacts
- One Azure DevOps-hosted agentic project completes same gates
- Evaluation testcases from `assets/evaluation-testcases-template.yaml` are run; all pass or explicit regression notes filed
- Findings produced conform to `Agentic-Findings-Schema.yaml`

**Completion evidence**: Two completed gate decision records (PASS, CONDITIONAL, or FAIL with documented rationale); updated evidence packs committed to platform project repositories.

**Handoff owners**: IT Security Owner; Project Business Owners; Molina AppSec Program

**Status**: NOT STARTED — awaiting Increment 3

## Increment 5 — Steady-State Operations

**Scope**: Transition to recurring governance cadence defined in `Governance-and-Maintenance-Runbook.md`.

**Dependencies**: Increment 4 complete; at least one CONDITIONAL finding remediated through full RITM lifecycle.

**Acceptance criteria**:
- Weekly scan review running on schedule
- Quarterly harness retrospective meeting cadence confirmed
- Annual SKILL.md version review scheduled
- Regression baseline updated with Increment 4 pilot learnings

**Completion evidence**: Cadence calendar entries confirmed; governance runbook linked in AppSec program tracker.

**Handoff owners**: Molina AppSec Program; Platform Security Leads

**Status**: NOT STARTED — awaiting Increment 4
