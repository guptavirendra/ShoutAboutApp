# Platform Adapter Specification - Azure DevOps

## Purpose
Define Azure DevOps-specific adapter responsibilities while preserving shared Anti-Mythos gate logic.

## Required adapter capabilities

- Repository metadata intake
  - project and repository identity
  - target branch/ref and pull request context

- Artifact collection surfaces
  - pipeline run metadata
  - security scan artifacts and logs
  - work item references for findings/remediation

- Feedback surfaces
  - pull request comments
  - work item update linkage for remediation lifecycle

## Normalization requirements

Adapter outputs must normalize to shared fields:
- source_platform: azure-devops
- source_artifact_id
- finding_id
- severity
- location
- evidence_link
- remediation_owner

## Security controls

- Use least-privilege service connection scopes.
- Validate project/repository/ref binding before reads.
- Reject write operations outside approved workflow stages.

## Failure handling

- If required Azure DevOps artifacts are unavailable, return structured missing_artifact errors.
- Do not infer missing pipeline or scan outcomes.
- Escalate to STOP when missing artifacts block a mandatory gate decision.
