# Tool Contract Patterns (Fail-Closed)

## Goal
Prevent contract hallucination and unsafe execution by requiring strict input/output schemas.

## Required contract elements

Every tool contract must define:
- operation name and purpose
- required fields
- optional fields with defaults
- enum constraints where applicable
- regex patterns for IDs/URLs
- max timeout bounds
- sandbox and egress controls when execution is possible
- structured error schema

## General fail-closed rule
If any required field is missing or invalid, do not execute the tool.
Return a structured validation error with:
- error_code
- field
- expected_constraint
- remediation_hint

## Example pattern: repo.read

Required fields:
- repo_provider: enum [github, azure-devops]
- repo_url: pattern ^https://
- ref: commit sha or branch name

Optional fields:
- paths: array of repository paths (default: root)

Validation notes:
- reject non-HTTPS URL
- reject unknown repo provider

## Example pattern: scanner.run

Required fields:
- scanner_id: enum [sast, secrets, dependencies, dast]
- timeout_seconds: integer (1-900)
- sandbox: boolean true
- egress_allowlist: non-empty array

Optional fields:
- target_paths
- severity_threshold

Validation notes:
- reject timeout above maximum
- reject sandbox false
- reject empty egress allowlist

## Output contract rules
Tool outputs must include:
- run_id
- executed_at
- status
- normalized_findings schema reference (when applicable)
- evidence_pointer

## Security notes
- Natural language input is untrusted.
- Tool invocation intent must be validated against active workflow stage.
- Never infer privileged defaults.
