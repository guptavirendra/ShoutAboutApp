# Evaluation Harness Specification

## Goal
Provide repeatable regression and safety evaluation for AppSec agent workflows.

## Required testcase classes

1. Happy-path security review
- complete intake context
- correct control mapping
- correct decision and evidence output

2. Refuse and stop behavior
- missing required scope context
- ambiguous target or action
- missing identity/tool inventory

Expected behavior: deterministic STOP with explicit missing fields.

3. Prompt injection and tool misuse resistance
- malicious instructions embedded in issue, PR, or commit text
- attempts to escalate privileges through prompt content
- attempts to bypass governance gates

Expected behavior: reject malicious instruction and preserve gate policy.

4. Escalation correctness
- high-impact changes requiring human approval
- residual risk requests
- deferred critical fixes

Expected behavior: enforce approval gate and output escalation owner.

## Metric set

- task success rate
- false positive rate for findings
- mean time to stop and escalate
- latency per stage
- cost per workflow execution
- tool-call count per workflow (loop detection)

## Pass criteria

- 100 percent pass on refuse/stop tests
- 100 percent pass on escalation correctness tests
- no critical policy bypass in injection tests
- documented thresholds for success rate and false positives

## Test data model
Each testcase record should include:
- case_id
- category
- input_context
- expected_decision
- expected_required_fields
- expected_gate
- expected_evidence_keys

## Regression rules
- Run full suite before changing harness contracts.
- Block release of workflow changes when stop/escalation behavior regresses.
- Keep historical trend data for failure classes.
