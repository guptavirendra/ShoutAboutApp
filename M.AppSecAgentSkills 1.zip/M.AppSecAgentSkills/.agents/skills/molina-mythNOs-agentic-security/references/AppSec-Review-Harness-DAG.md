# AppSec Review Harness DAG (GitHub + Azure DevOps)

## Goal
Provide a deterministic review workflow for AppSec agent operations with shared core stages and platform-specific adapters.

## Shared core DAG

1. Intake and risk triage
2. Agentic threat model (conditional)
3. Secure design review
4. Secure code and scanner normalization
5. Evidence mapping and trace packaging
6. Governance gate and human approval checks
7. Decision output and handoff

## Stage definitions

### 1) Intake and risk triage
Required inputs:
- repository identity
- target branch/ref
- deployment target
- data sensitivity (PHI, PII, internal, public)
- in-scope systems

Output:
- triage summary
- risk tier recommendation
- required artifact checklist

Fail-closed rules:
- missing repository identity or branch/ref -> STOP
- unknown sensitivity with possible tier change -> STOP

### 2) Agentic threat model (conditional)
Run this stage when the system includes one or more of:
- autonomous or semi-autonomous decisions
- tool invocation from model output
- persistent memory or retrieval stores
- inter-agent messaging

Output:
- ranked agentic risk list
- required mitigations by prevent/detect/respond
- decision on proceed vs stop

### 3) Secure design review
Checks:
- trust boundaries and data flow
- identity and privilege model
- key and secret handling
- tenancy boundaries and isolation controls

Output:
- design gaps
- compensating controls
- architecture readiness status

### 4) Secure code and scanner normalization
Checks:
- scanner run completeness
- findings deduplication
- severity normalization
- evidence pointers per finding

Output:
- findings table
- remediation backlog
- unresolved blocker list

### 5) Evidence mapping and trace packaging
Map evidence to:
- Molina PRE/P2D/P2B controls
- SSDF PO/PS/PW/RV controls
- 218A controls when AI is in scope

Output:
- evidence pack summary
- gap status by control

### 6) Governance gate and human approval checks
Apply gate logic:
- PASS: all required controls evidenced
- CONDITIONAL: non-critical gaps with approved due dates
- FAIL: missing mandatory evidence or unresolved blockers

Mandatory approval examples:
- deferred critical remediation
- high-impact runtime permission changes
- residual risk acceptance

### 7) Decision output and handoff
Output contract:
- decision and rationale
- blockers and owners
- evidence links
- required next workflow

## Platform adapter hooks
- GitHub adapter: repo metadata, PR context, GitHub security artifacts
- Azure DevOps adapter: repo metadata, PR/work item context, pipeline artifacts

Adapters must only supply data surfaces and must not weaken shared gate logic.
