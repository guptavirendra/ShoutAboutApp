# Proof-of-Non-Leakage Evidence Contract

## Goal
Define a fail-closed, gate-ready assurance model proving that critical runtime boundaries do not leak data or identity context across tenants, sessions, domains, or agent channels.

## Scope
This contract covers runtime state and entity isolation assurance only.

Out of scope:
- Artifact provenance and software supply chain lineage controls
- Generic vulnerability scan coverage without boundary-specific leakage claims

## Boundary taxonomy

Each assessed system must define and version a boundary matrix covering at minimum:
- Tenant boundary
- Session boundary
- Identity and delegation boundary
- Memory and context domain boundary
- Inter-agent communication boundary

Each boundary must have:
- boundary_id
- criticality (Critical, High, Medium)
- owner
- proof_class
- verifier
- re_verification_trigger

## Accepted proof classes

### Structural proof
Evidence that architecture and configuration enforce isolation by construction.

Required artifacts:
- Architecture diagram with trust and privilege boundaries
- Configuration export (policy, RBAC, allowlist, namespace controls)
- Mapping from boundary_id to control points

### Behavioral proof
Evidence from runtime telemetry and tests that no cross-boundary leakage occurs in the observation window.

Required artifacts:
- Leakage detection trace logs keyed by boundary_id
- Negative test results for cross-boundary access attempts
- Observation window definition and retention metadata

### Formal proof
Machine-checkable proof for critical boundaries using invariants or non-interference claims.

Required artifacts:
- Versioned model specification
- Invariant and safety property definitions
- Tool output for pass or counterexample
- Run metadata (tool version, run id, commit hash)

## Gate acceptance criteria

### P2D
- Every critical boundary has selected proof class and required artifact list.
- Every critical boundary has a verifier and re-verification trigger.
- Missing formal-proof design for a critical boundary is a FAIL.

### P2B
- Every critical boundary has current proof artifacts with verifier attribution.
- No critical boundary is FAILED or INDETERMINATE.
- Evidence traceability from boundary_id to decision record is complete.

## Fail-closed rules
- If any critical boundary lacks required artifacts, gate result is FAIL.
- If proof artifact integrity cannot be verified, gate result is FAIL.
- If formal proof produces a counterexample without accepted remediation, gate result is FAIL.

## Output contract

Minimum output fields:
- boundary_id
- proof_class
- proof_status (VERIFIED, CONDITIONAL, FAILED, INDETERMINATE)
- evidence_pointer
- verifier
- verification_date
- escalation_owner when status is not VERIFIED

## Re-verification triggers

Re-run applicable proofs when any trigger occurs:
- Architecture boundary change
- Identity or delegation model change
- Memory model or retention policy change
- Tool contract or policy engine change
- Platform adapter change affecting execution path

## Dry-run decision example

Use this example to test deterministic gate behavior:

### Example boundary proof states
- B-001 (Critical): Formal, VERIFIED
- B-002 (Critical): Formal, INDETERMINATE
- B-003 (High): Behavioral, CONDITIONAL

### Expected outcomes
- P2D: FAIL if B-002 has no accepted remediation plan and owner.
- P2B: FAIL while B-002 remains INDETERMINATE.

If B-002 transitions to VERIFIED and all remaining Critical boundaries are VERIFIED:
- P2D: PASS or CONDITIONAL based on non-critical gaps.
- P2B: PASS or CONDITIONAL based on non-critical gaps.