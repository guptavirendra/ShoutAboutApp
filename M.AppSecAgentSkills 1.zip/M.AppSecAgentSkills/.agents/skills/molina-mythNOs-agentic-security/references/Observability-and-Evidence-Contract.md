# Observability and Evidence Contract

## Goal
Ensure every AppSec agent decision is auditable, reproducible, and mapped to governance controls.

## Required trace records

### Decision record
Each decision must capture:
- decision_id
- timestamp_utc
- workflow_stage
- input_scope_summary
- assumptions
- decision_result (PASS, CONDITIONAL, FAIL, STOP)
- rationale
- escalation_required (true or false)
- escalation_owner

### Tool call record
Each tool call must capture:
- decision_id linkage
- tool_name
- validated_input_hash
- execution_identity
- start_time_utc
- end_time_utc
- execution_status
- output_hash
- evidence_pointer

### Retrieval snapshot record
When retrieval is used, capture:
- source identifier
- retrieval timestamp
- retrieval query
- ranked results metadata
- selected snippets reference

### Leakage detection trace record
For non-leakage assurance, capture:
- leakage_event_id
- boundary_id
- boundary_crossed (expected none for verified boundaries)
- detection_method (alert, behavioral-test, audit-gap, formal-counterexample)
- event_time_utc
- severity
- proof_status (proof_intact, proof_violated, proof_indeterminate)
- evidence_pointer
- verifier
- verification_time_utc

## Evidence packaging

Minimum evidence pack sections:
- project and scope metadata
- gate decision summary
- findings and remediation status
- control mapping summary
- trace and artifact pointers
- approvals and exception references
- non-leakage proof matrix (boundary, proof class, status, verifier)

## Integrity requirements
- Preserve immutable log history for decision records and tool calls.
- Do not overwrite historical decision outcomes.
- Include version metadata for workflow/harness definitions used at runtime.
- Ensure leakage detection trace records are append-only and tamper-evident.
- Formal proof outputs for critical boundaries must be preserved with tool version and run identifier metadata.

## Retention and review
- Retain evidence per enterprise policy.
- Review trace completeness at each governance gate.
- Block gate progression when mandatory evidence fields are missing.
