# Agentic Threat Modeling Extension

Extends SSDF PW.1 (Secure Design) and NIST SP 800-218A PW.1.1 (AI threat modeling) with agentic-specific threat categories, attack patterns, and mitigation strategies.

Authoritative source for agentic threats: [../../../owasp-genai-security/Agentic-Top10-Checklist.md](../../../owasp-genai-security/Agentic-Top10-Checklist.md).

## Required Inputs (STOP if any are missing)

- Tool inventory: every tool the agent can invoke, its operation, and its privilege scope
- Identity model: how the agent authenticates and what delegated permissions it can acquire
- Memory model: session-only, cross-session, cross-user, or none
- Retrieval sources: all RAG, file, web, or external API sources the agent can query
- Approval gates: which actions require human-in-the-loop confirmation
- Deployment context: GitHub, Azure DevOps, both, or other
- Isolation boundary matrix: critical boundaries (tenant, session, identity, memory, inter-agent channel)
- Proof profile selection: structural, behavioral, formal, or hybrid per boundary

## Threat Categories to Assess

For each category, assess: (a) attack surface in this system, (b) existing controls, (c) residual risk, (d) required mitigations.

### Goal Hijack (ASI01)

Attack surface questions:
- Can user-supplied text, uploaded documents, RAG results, or peer-agent messages influence the agent's goal or planning step?
- Is the system prompt mutable at runtime without human approval?
- Are there unsigned or unsigned-equivalent goal-change mechanisms?

Key controls to verify:
- All NL inputs treated as untrusted before reaching goal/planning layer
- System prompt under configuration management
- Intent validation at runtime before goal-changing tool calls

### Tool Misuse (ASI02)

Attack surface questions:
- Do any tools have unbounded egress, rate, or cost?
- Can the agent chain tool calls in a sequence that was not explicitly authorized?
- Are there destructive tool operations (delete, publish, transfer) without dry-run preview?

Key controls to verify:
- Per-tool least-privilege profiles (scopes, rate limits, egress allowlists)
- Intent gate (PEP/PDP) validates arguments before invocation
- Dry-run / diff preview before destructive actions

### Identity and Privilege Abuse (ASI03)

Attack surface questions:
- Can the agent inherit credentials from a user session beyond the current task scope?
- Are tokens long-lived or broad-scoped?
- Can a downstream agent receive elevated permissions from an upstream agent?

Key controls to verify:
- Task-scoped short-lived tokens per operation
- Per-session identity isolation; wipe state between tasks
- Re-auth required on context switch

### Supply Chain (ASI04)

Attack surface questions:
- Are third-party tools, plugins, models, or peer agents used without provenance verification?
- Are skill files, prompt templates, or scripts reviewed before deployment?
- Is there a content-hash pinning mechanism for tools and model artifacts?

Key controls to verify:
- SBOM/AIBOM generation and attestation
- Allowlist with content-hash pinning
- Continuous signature/hash validation at runtime

### Unexpected Code Execution (ASI05)

Attack surface questions:
- Does the agent generate code that is executed in the same session?
- Are there `eval` calls or unsafe deserialization paths reachable from agent output?
- Is the execution environment isolated from production?

Key controls to verify:
- Code generation separated from execution with validation gate
- Sandboxed container with no-root execution
- Pre-execution static scan before any generated code runs

### Memory and Context Poisoning (ASI06)

Attack surface questions:
- Can external data sources write to agent memory without validation?
- Can the agent's own outputs be re-ingested into trusted memory?
- Is memory segmented by user session and domain context?

Key controls to verify:
- Content validation on every memory write
- Prevention of self-ingestion (bootstrap poisoning)
- Memory segmented by session; encrypt at rest
- Proof-of-non-leakage claim defined per critical memory boundary
- Formal invariant for critical memory boundaries with verifier output artifact

### Inter-Agent Communication (ASI07)

Attack surface questions:
- Are messages between agents signed and authenticated?
- Can a peer agent send instructions that override this agent's policy?
- Is the communication channel encrypted end-to-end?

Key controls to verify:
- mTLS and message signing between agents
- Typed schema contracts with per-message audience binding
- Anti-replay: nonces and session IDs tied to task windows
- Non-interference claim for cross-agent channels when marked critical
- Formal verification or equivalent machine-check evidence for channel isolation

### Cascading Failures (ASI08)

Attack surface questions:
- Can a single faulty tool call or hallucination propagate across multiple agents or tenants?
- Are there rate limits or circuit breakers between planner and executor?
- Is there a kill-switch mechanism to halt propagation rapidly?

Key controls to verify:
- Circuit breakers between planner and executor
- Rate limiting with auto-throttle on anomalies
- Rapid kill-switch and quarantine capability

### Human-Agent Trust Exploitation (ASI09)

Attack surface questions:
- Can the agent present recommendations in ways that bypass human scrutiny?
- Is there a confirmation step before the agent acts on sensitive data or high-risk operations?
- Are agent-generated rationales distinguishable from verified evidence?

Key controls to verify:
- HITL confirmation required for sensitive/risky actions
- Preview separated from effect (no side effects during preview)
- Risk badge with provenance displayed to human approver

### Rogue Agent Behavior (ASI10)

Attack surface questions:
- Is there continuous monitoring of agent behavior against a baseline?
- Are agent behavioral manifests signed and verified before each action cycle?
- Is there a kill-switch and forensic quarantine process?

Key controls to verify:
- Watchdog layer validating agent behavior against signed manifest
- Immutable audit log of all actions and tool calls
- Rapid kill-switch, credential revocation, and quarantine process

## Output Contract

After completing the agentic threat model, produce:

- Attack surface summary (per threat category with risk rating)
- Ranked risk list (by impact × likelihood)
- Required mitigations by prevent / detect / respond
- Required telemetry (what to log per risk)
- Gate decision: Proceed / Stop + escalation owner + conditions
- Proof matrix: boundary ID, criticality, proof class, artifact link, verifier, verification date

## Cross-Framework Mapping

| Threat Category | SSDF | 218A | Molina Gate |
|---|---|---|---|
| Goal Hijack | PW.1, PW.2, RV.1 | PO.4.1, PW.1.1, RV.1.1–3 | P2D-08, P2B-01 |
| Tool Misuse | PO.5, PW.1, PW.8 | PO.4.1, PO.5.1, PW.8.1–2 | P2D-04, P2B-05/06 |
| Identity / Privilege Abuse | PO.5.1–2, PW.1, PW.2 | PS.1.3, PO.5.1 | P2D-08, P2D-03 |
| Supply Chain | PS.1–3, PW.4 | PS.1.1–3, PS.2.1, PS.3.1, PW.3.1–3, PW.4.1–2 | P2D-09, P2B-04 |
| Unexpected Code Execution | PW.5, PW.6, PW.7, PW.8 | PW.5.1, PW.7.1–2, PW.8.1–2 | P2B-03, P2B-07 |
| Memory / Context Poisoning | PO.5.1–3, PW.1, RV.1 | PO.5.1–3, PS.1.2, RV.1.1–3 | P2D-02, P2D-06 |
| Inter-Agent Communication | PO.5, PW.1, PW.2 | PO.5.1, PW.1.1 | P2D-04, P2D-08 |
| Cascading Failures | PO.5, PW.1, RV.1, RV.2 | PO.5.3, RV.1.1, RV.2.1 | P2D-04, P2B-07 |
| Human-Agent Trust | PO.2, PO.4.1, PW.1 | PO.4.1, PO.2.1–2, RV.1.2 | PRE-05, P2B-01 |
| Rogue Agents | PO.5, RV.1–3 | PO.5.3, RV.1.1–3, RV.2.1–2 | P2D-04, P2B-07 |
