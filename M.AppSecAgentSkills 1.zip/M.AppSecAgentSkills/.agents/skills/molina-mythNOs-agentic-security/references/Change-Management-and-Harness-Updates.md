# Change Management and Harness Updates

Governs how Anti-Mythos skill artifacts are versioned, reviewed, and updated over time while maintaining backward compatibility with existing gate records and regression baselines.

## Versioning Scheme

Artifact versioning follows semantic versioning applied to governance docs:

| Change Type | Version Impact | Example |
|---|---|---|
| New control/reference added | Minor increment | 0.1 → 0.2 |
| Mandatory field added to schema or contract | Minor increment | 0.2 → 0.3 |
| Field removed or renamed (breaking) | Major increment | 0.x → 1.0 |
| Typo, wording clarification, non-structural edit | Patch increment | 0.2.0 → 0.2.1 |

Version is recorded in:
- SKILL.md frontmatter `version` field
- Top-level `version:` field in YAML schemas

## Backward Compatibility Rules

1. **Never remove a required field** from `Agentic-Findings-Schema.yaml` or `Tool-Schema-Template.yaml` without a major version bump and a 90-day migration window.
2. **Never rename a gate control ID** (e.g. `PRE-01`, `P2B-04`) without cross-referencing both old and new IDs in `Agent-Evidence-Pack-Template.md` for at least one release cycle.
3. **Never remove a routing entry** from `SKILL.md` without redirecting it or marking it deprecated with a pointer to the replacement.
4. **Gate record IDs** (RITM, APPSEC-APR-*) are immutable once created — do not renumber or remove historical records.
5. When adding a new ASI row to `OWASP-Agentic-Top-10-Mapping.md`, check if the crosswalk in `Agentic-Threat-Modeling-Extension.md` needs a matching new section.

## Regression Baseline

The regression baseline is the set of `evaluation-testcases-template.yaml` cases plus any testcases added during live pilots.

| Event | Required Action |
|---|---|
| Any SKILL.md update | Re-run all baseline testcases; confirm no STOP/FAIL regressions |
| New tool contract added | Add at least one happy-path and one refuse/stop testcase |
| New platform adapter added | Add at least one happy-path and one missing-artifact testcase |
| Framework update (ASI, SSDF, 218A, Molina) | Review all crosswalk tables; update affected rows; note version and rationale |
| Critical finding from live pilot | Add a reproduce testcase within 5 business days |

Baseline testcases live at: [assets/evaluation-testcases-template.yaml](../assets/evaluation-testcases-template.yaml)

When a regression is found, do not ship the update until either:
- The testcase passes with the update applied, or
- An explicit waiver is recorded in the commit message with an APPSEC-APR approval ID.

## Skill and Script Supply Chain Review Checklist

Before any update to skill files, YAML schemas, or reference documents is merged:

- [ ] Change is scoped to a single increment (no mixed-intent changes)
- [ ] All affected routing entries in SKILL.md are updated in the same change
- [ ] If a YAML schema field is added or modified, samples in the same file are updated
- [ ] README.md and TODO.md reflect the new state (if applicable)
- [ ] No credentials, tokens, or sensitive internal data are present in any added content
- [ ] No third-party URLs or tool references are added without review
- [ ] Regression testcases are run (or a waiver with APPSEC-APR ID is recorded)
- [ ] Change is committed on a named feature branch with a clear commit message
- [ ] PR is opened against `feature/agents-skills-migration` (or `main` after Phase 1 is merged)

## Scheduled Review Calendar

See [Governance-and-Maintenance-Runbook.md](Governance-and-Maintenance-Runbook.md) for the full review cadence.

| Cadence | Review Type |
|---|---|
| Weekly | Scan result triage and open-findings review |
| Monthly | Harness health check; new findings patterns |
| Quarterly | Full harness retrospective; regression baseline update |
| Annual | SKILL.md version review; framework alignment (ASI, SSDF, 218A, Molina) |
