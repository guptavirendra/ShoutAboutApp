# Platform Adapter Specification - GitHub

## Purpose
Define GitHub-specific adapter responsibilities while preserving shared Anti-Mythos gate logic.

## Required adapter capabilities

- Repository metadata intake
  - repository URL
  - owner/name
  - target ref and PR context

- Artifact collection surfaces
  - code scanning results
  - dependency/security advisory context
  - workflow run metadata

- Feedback surfaces
  - pull request review comments
  - issue references for remediation tracking

## Normalization requirements

Adapter outputs must normalize to shared fields:
- source_platform: github
- source_artifact_id
- finding_id
- severity
- location
- evidence_link
- remediation_owner

## Security controls

- Use least-privilege token scope.
- Validate repository and ref ownership before artifact reads.
- Reject writes when governance stage does not permit output actions.

## Failure handling

- If required GitHub artifacts are unavailable, return structured missing_artifact errors.
- Do not infer missing scanner outcomes.
- Escalate to STOP when missing artifacts block a mandatory gate decision.
