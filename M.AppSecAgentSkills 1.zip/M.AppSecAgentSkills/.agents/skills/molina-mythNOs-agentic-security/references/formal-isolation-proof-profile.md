# Formal Isolation Proof Profile

## Purpose
Define the minimum formal verification profile required for critical non-leakage boundaries.

## Required deliverables

For each critical boundary, provide:
1. Model specification artifact with version and owner
2. Isolation invariants or non-interference claims
3. Verification run output (pass or counterexample)
4. Counterexample triage record when verification fails

## Modeling expectations

- Model must include explicit identities, state transitions, and permitted data flows.
- Boundary claims must be traceable to boundary_id values in the evidence pack.
- Assumptions must be explicit and reviewed.

## Invariant template

Use this structure for each claim:
- claim_id
- boundary_id
- statement
- threat_mapping (ASI06, ASI07, or both)
- proof_method
- expected_result

## Verification run metadata

Capture at minimum:
- run_id
- tool_name
- tool_version
- commit_hash
- execution_time_utc
- result
- artifact_link

## Counterexample handling

When a counterexample is produced:
- Create a finding record with status OPEN.
- Link affected boundary_id values.
- Document remediation action and owner.
- Re-run verification after remediation and update verification_date.

## Minimum completeness standard

- All Critical boundaries: Formal proof required.
- High boundaries: Structural plus Behavioral, Formal recommended.
- Medium boundaries: Structural or Behavioral acceptable with justification.

## P2D and P2B enforcement

### P2D
- Boundary claims and verification plan must exist for all Critical boundaries.

### P2B
- Latest formal run output must be attached for all Critical boundaries.
- Any unresolved counterexample causes FAIL.