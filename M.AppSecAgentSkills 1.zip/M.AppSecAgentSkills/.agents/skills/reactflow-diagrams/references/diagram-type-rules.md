# Diagram Type Rules

Load this file after identifying the source diagram type and before extracting architecture, activity, data-flow, or sequence-specific semantics.

Infer the diagram type from visual grammar before generating artifacts.

| Source visual cues | Use `diagram.type` | Viewer rendering | JSON/rendering intent |
|---|---|---|---|
| Vertical participant lifelines, horizontal request/response arrows, top-to-bottom time order | `sequence` | `sequenceDiagram` | Participants in `nodes[]`, participant order in `diagram.participants[]`, ordered messages in `edges[]` with `sequenceOrder` |
| Start/end states, actions, diamonds, branch labels, loops, high-level workflow | `flow` | `flowchart` | Activities and decisions as nodes, control-flow edges |
| Systems/components connected by named payloads, databases, stores, data labels between components | `data-flow` | `flowchart` | Components plus yellow data-object nodes between senders/receivers |
| Network zones, cloud/on-prem boundaries, firewalls, gateways, services, databases, vendor/public systems | `architecture` | `flowchart` or `C4Context` | Components inside visible boundaries, external objects outside Molina boundary |

If the source image and any provisional sketch disagree, prefer the source image for visual grammar. The final JSON must be capable of rendering faithfully in the shared React Flow picker.

## Architecture diagrams

Architecture diagrams must show where systems live and which network or ownership boundary controls them.

Required JSON behavior:

1. Create a Molina-controlled `groups[]` boundary whenever Molina-hosted, Molina-managed, or Molina internal components appear.
2. Keep Akamai, public internet, users, vendors, SaaS, external APIs, and third-party systems outside the Molina group unless the source explicitly shows them inside.
3. Use separate groups for DMZ, PaaS, ASE, internal network, database layer, external network, or vendor network when visible.
4. Use only approved `visual.icon` identifiers from the descriptor contract. Record recognizable source icon names such as Akamai, Apigee, Redis, SQL, Azure, F5, APIM, LLM, firewall, load balancer, and web app in `metadata.technology`, `metadata.sourceText`, `description`, or `notes`.
5. Use `type: "datastore"` with `visual.shape: "cylinder"` for databases and persistent stores.
6. Use supported semantic node types such as `gateway`, `api`, `application`, `internal`, `external`, `identity`, `ai`, `observability`, or `datastore` for gateways, APIs, app services, and integration points.
7. Preserve important labels such as URLs, IPs, DNS names, and environment names only when they are non-secret and relevant to architecture review.
8. Include one Molina-controlled group at minimum, such as `molina-network`, `molina-internal-network`, or `molina-cloud-zone`, and separate groups for external/public/vendor zones when visible.
9. When the Molina-controlled group visually contains sub-zones such as DMZ, PaaS, ASE, application tier, or database layer, set those sub-zone groups' `parentGroupId` to the Molina-controlled group rather than making them independent top-level groups.
10. Put component IDs in their immediate sub-zone group and leave the parent `nodeIds` empty unless it directly contains visible components.

The shared React Flow viewer uses `groups[]` as draggable parent boundaries with child nodes attached to the parent container.

## Activity diagrams

Activity diagrams describe high-level workflow, not infrastructure.

Required JSON behavior:

1. Include explicit start and end/stop nodes when the source shows them or the workflow clearly implies them.
2. Use the closest supported semantic node type for activities, usually `application`, `internal`, `external`, `data`, or `document`.
3. Use `type: "decision"` with `visual.shape: "diamond"` for branch points.
4. Use `type: "finish"` with `visual.shape: "octagon"` for cancel, stop, failure, or terminal exception states when the source uses a distinct stop/error shape.
5. Label branch edges clearly, such as `Yes`, `No`, `Cancel`, `Retry`, `Eligible`, or `Not eligible`.
6. Keep activity diagrams high-level; do not turn them into network architecture diagrams or sequence diagrams.

## Data-flow diagrams

Data-flow diagrams show what data moves, where it moves, and which components touch it.

Required JSON behavior:

1. Every meaningful payload or data object must be a yellow data node, not just an edge label.
2. Use `component -> data node -> component` chains to show where the data passes.
3. Use `type: "data"` or `type: "document"`, `visual.shape: "document"`, and `visual.color: "data"` for data nodes.
4. Use `type: "datastore"`, `visual.shape: "cylinder"` for databases, caches, queues, and persistence.
5. Use `groups[]` when the source shows boundaries such as user devices, application tier, AI/orchestration layer, service integration, persistence, Molina internal network, or external network.
6. Do not force network-detail boundaries into a simple data-flow sketch unless they are part of the source.
7. If the source labels data beside an arrow, convert that label into a data node placed between sender and receiver.

Examples of first-class data objects include `NLP query/search params`, `provider search results`, `PCP change request`, `ePortal DB update`, `QNXt update`, `eligibility response`, payloads, parameters, query text, search results, tokens, updates, and records.

## Sequence diagrams

Sequence diagrams require a two-pass extraction:

1. Extract participants/lifelines from the original image in visible left-to-right order.
2. Extract messages top-to-bottom, preserving direction, request/response style, labels, return messages, activation-like spans, zones, and source-image layout.
3. If a provisional sequence draft exists, use it as a consistency check, not as the only source of truth.
4. Make the JSON richer than any provisional draft when the image contains extra semantics: network zones, gateway ownership uncertainty, technology names, database ownership, activation notes, confidence, and assumptions.
5. Preserve participant order and message order in the final JSON exactly.
6. Use `style.line: "solid"` for calls/requests and `style.line: "dashed"` for responses or returns.
7. The shared viewer automatically renders sequence JSON as horizontal participant lifelines with vertical message progression.