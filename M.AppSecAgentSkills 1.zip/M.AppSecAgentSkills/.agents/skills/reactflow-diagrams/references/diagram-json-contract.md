# Diagram JSON Contract

Load this file before writing or validating any JSON descriptor, when checking supported node/edge/group fields, when handling sequence participants, or when deciding how to record uncertainty.

The JSON descriptor is the semantic source of truth for Mermaid, Markdown, and the React Flow + elk.js viewer. Do not put renderer implementation code, CSS, HTML, JSX, JavaScript, or Mermaid syntax inside the descriptor.

## Required top-level structure

Always output a single valid JSON object with this minimum structure:

```json
{
  "schemaVersion": "1.1",
  "title": "Diagram title",
  "diagram": {
    "type": "flow",
    "direction": "LR"
  },
  "navigation": {
    "label": "Short tab label"
  },
  "source": {},
  "quality": {},
  "nodes": [],
  "edges": [],
  "groups": [],
  "assumptions": [],
  "annotations": []
}
```

Use only these generated JSON direction values:

- `LR`: left to right
- `RL`: right to left
- `TB`: top to bottom
- `BT`: bottom to top

The renderer translates these values into ELK directions. Do not emit ELK-specific direction names.

Use `navigation.label` for concise picker tab text. Keep it short enough for tab navigation, usually 2-5 words, while keeping `title` as the full human-readable diagram title. If `navigation.label` is absent, the picker falls back to `navigation.shortLabel`, `tabLabel`, `shortTitle`, `title`, and then the filename.

## Legacy exclusions

The descriptor must remain format-neutral enough to support React Flow and future renderers, but it must not reintroduce legacy-only fields or enums that conflict with the HTML template contract.

- Do not emit the older `schemaVersion: "1.0"` structure.
- Do not require `slug`, `diagram.layoutEngine`, `diagram.mermaidKind`, node `groupId`, or top-level `styles` fields.
- Use `groups[].nodeIds` for containment instead of node-level group assignment.
- Use `diagram.participants[]` and edge-level `sequenceOrder` for sequence ordering.
- Use only approved `visual.icon` identifiers. Preserve source-specific product names, vendors, or technologies in `metadata.technology`, `metadata.sourceText`, `description`, or `notes`, not as icon identifiers.

## Identifier integrity

- Every node must have a non-empty string `id`.
- Every edge must have a non-empty string `id`.
- Every group must have a non-empty string `id`.
- Node IDs must be unique among nodes.
- Edge IDs must be unique among edges.
- Group IDs must be unique among groups.
- Every edge `source` and `target` must reference an existing node ID.
- Use stable, descriptive, kebab-case IDs whenever practical.
- Never encode display text, HTML, URLs, or executable content into IDs.

## Nodes

Each node should use this shape:

```json
{
  "id": "component-name",
  "label": "Component Name",
  "type": "application",
  "description": "Concise description",
  "metadata": {
    "technology": "Description from diagram",
    "owner": "Description from diagram"
  },
  "notes": [
    "Concise notes"
  ],
  "visual": {
    "shape": "rectangle",
    "color": "gateway",
    "icon": "gateway"
  }
}
```

Keep labels concise. Put secondary explanatory text in `description` or `notes`, not in the label.

Supported semantic node types:

- `actor`
- `application`
- `api`
- `gateway`
- `identity`
- `ai`
- `external`
- `internal`
- `datastore`
- `data`
- `document`
- `observability`
- `decision`
- `start`
- `finish`

Supported visual shapes:

- `rectangle`
- `diamond`
- `octagon`
- `document`
- `cylinder`
- `cloud`

Approved `visual.icon` identifiers:

- `actor`
- `application`
- `api`
- `gateway`
- `database`
- `document`
- `cloud`
- `identity`
- `shield`
- `ai`
- `observability`
- `decision`
- `start`
- `finish`
- `default`

Do not output arbitrary icon URLs, remote image URLs, data URLs, SVG markup, HTML, emoji, CSS classes, or invented icon identifiers. If no approved icon is appropriate, use `default` or omit `visual.icon`.

## Edges

Each edge should use this shape:

```json
{
  "id": "edge-id",
  "source": "source-node-id",
  "target": "target-node-id",
  "label": "edge label",
  "type": "edge-type",
  "direction": "directed",
  "sequenceOrder": 1,
  "style": {
    "line": "solid",
    "arrow": "closed"
  },
  "metadata": {}
}
```

Rules:

- `source` and `target` must always reference existing nodes.
- Keep edge labels short and action-oriented.
- Use `direction: "undirected"` only when the relationship truly has no direction.
- Use `style.arrow: "none"` only when no arrowhead should be rendered.
- Supported `style.line` values are `solid`, `bold`, `dashed`, and `dotted`.
- A self-message or self-loop is represented normally by setting `source` and `target` to the same node ID. Do not invent a separate loop node.

## Groups and trust boundaries

Use groups for real semantic boundaries such as networks, trust zones, ownership boundaries, environments, subsystems, or deployment areas. Do not create groups solely as decorative backgrounds.

Flat group example:

```json
{
  "id": "internal-network",
  "label": "Internal Network",
  "type": "trust-zone",
  "nodeIds": ["api-gateway", "member-service", "member-db"],
  "parentGroupId": null,
  "visual": {
    "color": "zone-molina"
  }
}
```

Nested group example:

```json
{
  "id": "application-zone",
  "label": "Application Zone",
  "type": "trust-zone",
  "nodeIds": ["api-gateway", "member-service"],
  "parentGroupId": "molina-network",
  "visual": {
    "color": "zone-molina"
  }
}
```

Rules:

- Every `nodeIds` entry must reference an existing node.
- A node may belong to only one immediate group.
- Use `parentGroupId` for nesting.
- `parentGroupId` must reference an existing group or be `null`.
- Circular group nesting is forbidden.
- Do not place the same node directly in both a parent group and one of its child groups.
- When a visible parent boundary contains smaller boundaries, represent each smaller boundary as its own `groups[]` item with `parentGroupId` set to the containing parent group. The parent group may have an empty `nodeIds` array when it contains only child groups.
- Put each node only in its immediate containing group. Do not list a child group's nodes again in the parent group's `nodeIds`; the renderer derives parent containment through `parentGroupId`.
- External, public, vendor, SaaS, Akamai, internet, and third-party groups must be top-level sibling groups with `parentGroupId: null` unless the source explicitly shows them inside the Molina-controlled boundary. They must not be nested inside the Molina group by default.
- Prefer the shallowest hierarchy that accurately represents the source.
- Cross-boundary edges are allowed and expected in architecture and data-flow diagrams. Keep those edges connected to their true source and target nodes. Do not route them through fake gateway, note, or boundary nodes only to satisfy layout.
- The HTML template attempts compound ELK layout first. If ELK cannot lay out cross-group edges, the template records a review warning and falls back to flat ELK layout with draggable group boundaries while preserving nested parent/child group containment. This fallback is acceptable only when validation confirms the HTML renders successfully and the warning appears in the Diagram Inventory panel.

## Sequence diagrams

For sequence diagrams, explicitly declare participant order:

```json
{
  "diagram": {
    "type": "sequence",
    "direction": "LR",
    "participants": [
      "user",
      "web-application",
      "api-gateway",
      "member-service",
      "member-database"
    ]
  }
}
```

Rules:

- Every participant ID must reference an existing node.
- Participant IDs must not be duplicated.
- Participant array order is the intentional left-to-right display order.
- Every sequence message must reference declared participants.
- Every sequence message must have a numeric `sequenceOrder`.
- `sequenceOrder` values should begin at 1 and increase deterministically.
- Use the same source and target for a self-message.
- Do not generate synthetic nodes for message labels, activation points, or self-loop geometry; the renderer handles those.

For sequence diagrams, `nodes[]` represent participants or lifelines, not individual message steps. Preserve the left-to-right order seen in the source image in `diagram.participants[]`. Include technology/owner details from the source image even when participant display labels are shorter.

For sequence diagrams, `edges[]` represent ordered messages. Set `type` to `sequence`, use `source` and `target` as participant IDs, preserve the exact message text in `label`, and add edge-level `sequenceOrder` as a 1-based integer. Use `style.line: "solid"` for calls/requests and `style.line: "dashed"` for responses or returns. If the original image shows a message missing from a provisional draft, include it in JSON.

For sequence diagrams, use `groups[]` for visual or trust zones such as Public Facing, Molina Internal Network, and External Network. The React Flow renderer uses participant nodes for layout, but groups preserve source-image semantics for review notes and future renderers where appropriate.

Preferred participant metadata shape:

```json
"metadata": {
  "sourceText": "MyMolina Desktop/Mobile",
  "technology": "Portal/mobile app",
  "owner": "MyMolina",
  "sequenceOrder": 2
}
```

Preferred message metadata shape:

```json
"metadata": {
  "sequence": 7,
  "sourceRow": "top-to-bottom message order from image"
}
```

## Quality and review metadata

Use confidence values from `0` to `1`.

```json
{
  "quality": {
    "overallConfidence": 0.91,
    "reviewNotes": [
      "The original image did not identify the database technology."
    ]
  },
  "assumptions": [
    "The unlabeled cylinder represents a relational database."
  ]
}
```

Do not silently invent uncertain facts. Record uncertainty in `assumptions`, `quality.reviewNotes`, node `confidence`, or edge metadata.

Use semantically accurate timestamp fields:

```json
{
  "source": {
    "type": "PowerPoint",
    "summary": "Application authentication and data-access flow.",
    "reviewedAt": "2026-08-05"
  },
  "attribution": {
    "text": "React Flow diagrams provided by Molina Application Security team."
  }
}
```

Do not label a review date as a generation date. Use `generatedAt` only when it truly represents generation time.

## JSON file output

Write each descriptor as a standalone formatted JSON file under `./design/diagrams/React Flow/data/`. The shared picker loads these JSON files with `fetch()` and derives navigation tab labels from each descriptor's `navigation.label`, falling back to `title`.

Rules:

- Do not embed descriptor JSON in `diagram-viewer.html`.
- Do not write per-diagram React Flow `.html` artifacts. React Flow uses JSON descriptors plus the single shared picker only.
- Do not hardcode diagram labels, titles, summaries, nodes, edges, groups, or source metadata in the HTML picker.
- Keep every JSON file parseable with `JSON.parse`.
- Use relative viewer paths such as `data/{title}-diagram.json` in `DIAGRAM_JSON_FILES`.

## Prohibited descriptor content

The JSON descriptor must not contain:

- HTML elements
- `<script>` content
- JavaScript expressions
- React or JSX
- CSS
- Event handlers
- Arbitrary SVG markup
- Remote asset URLs
- Data URLs
- Executable code
- Mermaid syntax embedded as a substitute for semantic nodes and edges

The renderer owns presentation and behavior. The JSON must contain only diagram semantics, review metadata, and approved visual identifiers.