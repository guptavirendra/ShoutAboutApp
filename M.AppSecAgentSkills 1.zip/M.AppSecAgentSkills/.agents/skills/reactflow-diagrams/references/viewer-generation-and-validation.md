# Viewer Generation and Validation

Load this file before generating Mermaid, Markdown, the React Flow picker, shared viewer assets, or final validation results.

## JSON descriptor output

Write one JSON file per diagram as the machine-readable diagram view.

Requirements:

- Generate the JSON descriptor from the source image, not from a separate mental model.
- Use the diagram type that best preserves the original meaning.
- For sequence diagrams, participant order must come from `diagram.participants[]` and message order must come from `edges[].sequenceOrder` in the JSON descriptor.
- Preserve labels, direction, boundaries, and important annotations.
- Keep JSON readable and maintainable with stable IDs, concise labels, and uncertainty recorded in `assumptions`, `quality.reviewNotes`, `confidence`, or `notes`.
- Include enough `source.summary`, `summary.ai`, or `aiSummary` metadata for the viewer's collapsible summary panel.

## Mermaid output

Write `{title}-diagram.mmd` as the Mermaid diagram view generated from the JSON descriptor.

Requirements:

- Generate Mermaid from the JSON descriptor, not from a separate mental model.
- Use the Mermaid diagram type that best preserves the original meaning.
- For `sequenceDiagram`, participant order must come from `diagram.participants[]` and message order must come from `edges[].sequenceOrder` in the JSON descriptor.
- Preserve labels, direction, boundaries, and important annotations.
- Use Mermaid subgraphs for JSON `groups[]` when the selected Mermaid type supports them.
- Keep Mermaid readable and maintainable; avoid excessive styling unless source colors carry meaning.
- Include comments only when they clarify ambiguity or source assumptions.

## Markdown wrapper

Write `{title}-diagram.md` as a lightweight wrapper around the Mermaid output.

Required structure:

````markdown
# <Human Diagram Title>

Source: <source type and filename, if known>

Summary: <one sentence summary>

```mermaid
<exact Mermaid diagram contents from {title}-diagram.mmd>
```

## Notes

- <assumption, ambiguity, or validation note; use "None" if not needed>
````

## React Flow + elk.js picker

Write exactly one shared `diagram-viewer.html` for the diagram set. It loads JSON descriptor files, creates one navigation tab per descriptor, and renders the selected descriptor with the shared React Flow viewer.

Use `templates/diagram-viewer.html` as the fixed shell for the generated picker. The generated picker should differ only in the `window.DIAGRAM_JSON_FILES` array. Copy `templates/_assets/diagram-viewer.css`, `templates/_assets/diagram-viewer.js`, `templates/_assets/diagram-picker.js`, and `templates/_assets/vendor/` to `./design/diagrams/React Flow/_assets/` only when those shared assets are absent, unless the user explicitly approves refreshing them. Do not regenerate custom React/JavaScript or CSS per diagram unless the user explicitly requests a different renderer.

The React Flow output bundle must include:

- `./design/diagrams/React Flow/diagram-viewer.html` with a populated `DIAGRAM_JSON_FILES` array.
- `./design/diagrams/React Flow/data/{title}-diagram.json` for every diagram.
- Local `<link rel="stylesheet" href="_assets/diagram-viewer.css">` and `<script src="_assets/diagram-picker.js"></script>` references. The picker script loads `_assets/diagram-viewer.js` after browser dependencies initialize.
- Local vendored dependencies under `_assets/vendor/`: `diagram-vendor.js` bundles React, ReactDOM, React Flow, and elk.js; `xyflow-react.css` contains the React Flow stylesheet; `diagram-vendor.js.LEGAL.txt` preserves linked legal comments.
- No generated viewer HTML may reference external CDN library URLs.
- The shared local viewer script converts JSON nodes and edges into positioned React Flow nodes and edges.
- Navigation tabs derived from JSON descriptor `navigation.label` values, falling back to JSON descriptor titles, not hardcoded HTML labels.
- Visible native multi-select JSON file selection and drag-and-drop fallbacks for `file://` use when browser security blocks automatic `fetch()` of descriptor files.
- A shared custom node renderer that uses descriptor fields for label, type, shape, group, confidence, technology, and notes.
- React Flow `<Controls />`, `<MiniMap />`, `<Background />`, and a top-level `<Panel />` or equivalent header/status area.
- Edge labels and arrow markers where present in JSON.
- Responsive full-viewport layout with no framework build step required.
- A modern visual design suitable for executive and engineering review: clear hierarchy, restrained color, strong spacing, legible typography, subtle shadows, and accessible contrast.
- A concise 1-3 line AI summary in the top-left canvas panel. Prefer `summary.ai` or `aiSummary` in the JSON descriptor; fall back to `source.summary` only when a dedicated AI summary is absent.
- A collapsible top-left canvas summary panel.
- A hidden-by-default Diagram Inventory panel toggled with `Ctrl+Option+A` / `Ctrl+Alt+A`, preserving the Molina Application Security attribution footer at the bottom of the panel.
- Defensive error handling: if JSON loading, JSON parsing, library loading, layout, or rendering fails, show a clear in-page error message using `textContent`, not unsafe `innerHTML`.

React Flow implementation guidance:

- Use React Flow's node and edge model as the render target: `nodes[]` with `id`, `type`, `position`, `data`, and optional style; `edges[]` with `id`, `source`, `target`, `label`, `type`, `markerEnd`, and style.
- Use elk.js to compute layout dimensions and positions before rendering. Prefer layered layout with direction derived from `diagram.direction`.
- Use multiple handles or side-specific handles when the source diagram has meaningful directionality or when ELK can reduce edge crossings.
- Use `fitView` after layout completes and React has painted the layouted node positions. Schedule it after `setNodes(layoutedNodes)` with `requestAnimationFrame` plus a short timeout, and allow low zoom, around `0.08`, so tall activity diagrams are visible on first load.
- Use `MiniMap` for overview, `Controls` for zoom and fit, and `Background` with dots or lines for spatial orientation.
- Keep the HTML portable. Do not require `npm install`, a bundler, a local dev server, or project framework integration.

## Required viewer validation before reporting success

- Parse every generated JSON descriptor file with `JSON.parse`.
- Confirm `diagram-viewer.html` contains the generated descriptor paths in `window.DIAGRAM_JSON_FILES` and does not hardcode descriptor titles, summaries, nodes, edges, groups, CSS, or viewer logic.
- Confirm `_assets/diagram-viewer.css`, `_assets/diagram-viewer.js`, `_assets/diagram-picker.js`, `_assets/vendor/diagram-vendor.js`, `_assets/vendor/diagram-vendor.js.LEGAL.txt`, and `_assets/vendor/xyflow-react.css` exist in `./design/diagrams/React Flow/` and that the HTML references local relative paths only.
- Syntax-check `_assets/diagram-viewer.js` and `_assets/diagram-picker.js`; there must be no literal line breaks inside quoted strings.
- Confirm `diagram-viewer.html` contains no external CDN library URLs.
- Open the generated HTML in a browser or browser automation and confirm there are no console/page errors.
- Confirm the page does not show `Diagram load failed`, `Diagram render failed`, or `Diagram initialization failed`.
- Confirm navigation tabs are populated from JSON descriptor titles and each tab renders the corresponding JSON descriptor.
- If validating from a `file://` URL, confirm the visible JSON file input or drag-and-drop can load one or more generated JSON descriptor files and populate the same tab/rendering experience.
- Confirm `.react-flow__node` and `.react-flow__edge` elements are present and that at least one node is visible in the initial viewport.
- For sequence diagrams, confirm `.sequence-lane` count matches participant count, `.sequence-message-label` count matches sequence message count, message labels are readable, labels float above participant columns instead of being hidden behind lanes, and initial viewport opens at a readable zoom even when not every participant is visible at once.
- For data-flow diagrams, confirm every meaningful data payload from the source appears as a yellow data/document node and not merely as an edge label.
- For activity diagrams, confirm decision nodes render with diamond shapes and terminal/error/cancel states render with octagon or otherwise distinct terminal styling when present.
- For architecture diagrams, confirm visible group boundaries exist for the Molina-controlled network/zone and any external zones, and confirm recognizable source icons render as icon placeholders until real icon assets are available.
- For architecture diagrams with external/public/vendor groups, confirm those groups render outside the Molina-controlled group by default unless the source explicitly shows them contained inside Molina.
- For diagrams with `groups[]`, confirm group boundaries are draggable and that child nodes move with the group in React Flow.
- For nested groups, confirm child group boundaries are visually contained by the parent group, dragging the parent moves child groups and their nodes, and child groups/nodes cannot be dragged outside the parent boundary.
- If the Diagram Inventory panel includes a `Compound ELK group layout failed; rendered with flat fallback...` review note, treat the descriptor as PASS with renderer fallback only when nodes, edges, nested group boundaries, and labels still render. Do not remove semantic groups just to avoid the warning.