---
name: molina-diagrams
description: "Reviews image-based diagrams and converts drawings, PowerPoint exports, screenshots, whiteboards, architecture images, and process diagrams into canonical diagram artifacts. Outputs Mermaid and Markdown under ./design/diagrams/Mermaid, plus JSON descriptors and a shared React Flow + elk.js diagram picker under ./design/diagrams/React Flow. WHEN: \"diagram from image\", \"review this diagram\", \"convert screenshot to mermaid\", \"PowerPoint diagram\", \"draw this as React Flow\", \"create diagram JSON\", \"architecture diagram\", \"process flow diagram\", \"design diagram\"."
license: MIT
compatibility: "Designed for VS Code Copilot and image-capable coding agents that can inspect visual attachments and write project files. HTML output uses copied local viewer CSS/JS and vendored local React, ReactDOM, React Flow, and elk.js browser assets."
metadata:
  author: M.AppSecAgentSkills
  version: "1.1"
  source-reactflow-examples: "https://reactflow.dev/examples"
  source-reactflow-components: "https://reactflow.dev/api-reference/components"
  argument-hint: "<title> [source image or diagram description]"
  user-invocable: "true"
allowed-tools: Read Write Bash(pwsh:*) Bash(node:*)
---

# Molina Diagrams

This skill converts image-based diagrams into durable, reusable diagram artifacts. It is for drawings, screenshots, exported PowerPoint slides, whiteboard photos, architecture diagrams, process flows, sequence-like diagrams, network diagrams, data-flow diagrams, and UI/workflow sketches.

**Skills used:** molina-diagrams (always include this line in output)

## Gotchas

- **The JSON descriptor is the master source of truth.** Mermaid, Markdown, and the HTML viewer are generated views. Do not treat screenshots, provisional sketches, Mermaid, Markdown, or the viewer shell as the authoritative model once the JSON descriptor exists.
- **Always write generated output to the consuming project's root-relative `./design/diagrams/` directory.** Do not write generated diagram artifacts inside `.agents/skills/`.
- **Create all three per-diagram artifacts.** For each diagram, create `Mermaid/{title}-diagram.mmd`, `Mermaid/{title}-diagram.md`, and `React Flow/data/{title}-diagram.json`.
- **Use one shared React Flow picker for the diagram set.** Create or update `React Flow/diagram-viewer.html`; copy `React Flow/_assets/diagram-viewer.css`, `React Flow/_assets/diagram-viewer.js`, `React Flow/_assets/diagram-picker.js`, and `React Flow/_assets/vendor/` from `templates/_assets/` only when missing or when the user explicitly approves refreshing shared viewer assets.
- **Do not overwrite existing diagram artifacts without explicit user approval.** If a diagram-specific collision exists and approval is absent, use a deterministic suffix such as `{title}-diagram-v2.*` and state the reason.
- **Image interpretation must preserve uncertainty.** If a label, direction, boundary, or relationship is ambiguous, encode `confidence` and add a concise note in the JSON descriptor rather than inventing certainty.
- **The React Flow output must be portable and local.** Keep JSON in standalone descriptor files and reference only copied local `_assets/` files. Do not link generated HTML to external CDN libraries.
- **Use the bundled picker template and assets.** Generate `diagram-viewer.html` from `templates/diagram-viewer.html` by replacing only the `window.DIAGRAM_JSON_FILES` array with generated descriptor paths. Do not hardcode tab labels, titles, summaries, nodes, edges, groups, CSS, or viewer logic in HTML.
- **Local disk viewing requires user-mediated file loading.** Browsers usually block `fetch()` of sibling JSON files from `file://` pages. The bundled picker must keep visible native multi-select JSON file selection and drag-and-drop controls.
- **Do not emit raw newlines inside JavaScript string literals.** Use escaped `\n`, template literals, or DOM `textContent`.
- **Viewer render failure is a validation failure, not a JSON workaround request.** If the picker shows `Diagram load failed`, `Diagram render failed`, or `Diagram initialization failed`, validate descriptor references and template behavior before changing diagram semantics.
- **Do not collapse semantic trust boundaries to work around renderer failures.** Architecture and data-flow diagrams commonly have cross-boundary edges; keep the semantic `groups[]` model faithful to the source.
- **Use elk.js for layout.** Do not hard-code fragile absolute positions except as a fallback when preserving a source image's exact spatial arrangement is more important than clean graph layout.

## How to use this skill

**Skill check:** Read this file before analyzing any image-based diagram or creating diagram artifacts. In all output, include `Skills used: molina-diagrams` and list the artifacts created.

Execution flow:

1. **Identify the source and title** - Determine the source artifact type and a concise human title. If the user did not provide a title, derive one from the diagram subject.
2. **Normalize the title** - Create a filesystem-safe lowercase slug: trim whitespace, replace spaces with hyphens, remove punctuation except hyphens, collapse duplicate hyphens, and keep it stable for the JSON descriptor filename.
3. **Resolve output directories** - From the consuming project root, ensure `./design/diagrams/Mermaid/`, `./design/diagrams/React Flow/data/`, and `./design/diagrams/React Flow/_assets/` exist. Preserve any existing `./design/` content.
4. **Review the image** - Identify every visible object, label, boundary, group, icon, actor, system, datastore, decision point, process step, connector, annotation, color, direction, containment relationship, and uncertainty.
5. **Infer the diagram type** - Use visual grammar to choose `sequence`, `flow`, `data-flow`, or `architecture`. Read [references/diagram-type-rules.md](references/diagram-type-rules.md) after identifying the likely source diagram type and before extracting type-specific semantics.
6. **Create the JSON descriptor** - Read [references/diagram-json-contract.md](references/diagram-json-contract.md) before writing or validating any descriptor. Write formatted JSON to `./design/diagrams/React Flow/data/{title}-diagram.json`. Do not embed descriptor JSON in HTML.
7. **Generate Mermaid from JSON** - Read [references/viewer-generation-and-validation.md](references/viewer-generation-and-validation.md) before generating Mermaid, Markdown, or viewer artifacts. Write `./design/diagrams/Mermaid/{title}-diagram.mmd` from the JSON descriptor.
8. **Generate the Markdown wrapper** - Write `./design/diagrams/Mermaid/{title}-diagram.md` with a title, source summary, embedded Mermaid fenced block containing the exact contents of `{title}-diagram.mmd`, and notes for assumptions or validation concerns.
9. **Generate or update the shared picker** - Copy `templates/diagram-viewer.html` to `./design/diagrams/React Flow/diagram-viewer.html` and replace only `window.DIAGRAM_JSON_FILES` with relative descriptor paths such as `data/{title}-diagram.json`.
10. **Copy shared viewer assets** - Copy `templates/_assets/diagram-viewer.css`, `templates/_assets/diagram-viewer.js`, `templates/_assets/diagram-picker.js`, and `templates/_assets/vendor/` into `./design/diagrams/React Flow/_assets/` only if absent, unless the user explicitly approves refreshing existing shared assets.
11. **Validate artifacts** - Apply the checks in [references/viewer-generation-and-validation.md](references/viewer-generation-and-validation.md) before reporting success. Confirm JSON parses, Markdown embeds exact Mermaid content, the picker references descriptor paths, local assets exist, and the viewer renders without initialization/load/render failures.
12. **Report output** - Summarize what was extracted, where files were written, validation results, and any interpretation assumptions.

## Diagram Extraction Rules

When reviewing the source image, extract:

| Visual element | JSON representation |
|---|---|
| Systems, services, screens, steps, actors, databases, queues, files, data payloads | `nodes[]` |
| Arrows, lines, dependencies, transitions, calls, data flows, control flows | `edges[]` |
| Containers, swimlanes, security zones, layers, cloud/account boundaries | `groups[]` |
| Headings, legends, notes, warnings, callouts | `annotations[]` |
| Color, icon, shape, line style, arrow direction, label position | `visual` and `style` fields |
| Unclear text, hidden direction, ambiguous grouping | `confidence`, `assumptions`, and `notes` |

Use stable IDs that are readable and deterministic, such as `api-gateway`, `claims-db`, or `member-portal`. Avoid opaque generated IDs unless a source object has no meaningful label.

## Reference files (load on demand)

- Read [references/diagram-json-contract.md](references/diagram-json-contract.md) before writing or validating any JSON descriptor, when checking supported node/edge/group fields, when handling sequence participants, or when deciding how to record uncertainty.
- Read [references/diagram-type-rules.md](references/diagram-type-rules.md) after identifying the source diagram type and before extracting architecture, activity, data-flow, or sequence-specific semantics.
- Read [references/viewer-generation-and-validation.md](references/viewer-generation-and-validation.md) before generating Mermaid, Markdown, the React Flow picker, shared viewer assets, or final validation results.

## Artifact Naming and Collision Rules

For a title slug of `claims-intake-flow`, create:

```text
./design/diagrams/Mermaid/claims-intake-flow-diagram.mmd
./design/diagrams/Mermaid/claims-intake-flow-diagram.md
./design/diagrams/React Flow/diagram-viewer.html
./design/diagrams/React Flow/data/claims-intake-flow-diagram.json
./design/diagrams/React Flow/_assets/diagram-viewer.css
./design/diagrams/React Flow/_assets/diagram-viewer.js
./design/diagrams/React Flow/_assets/diagram-picker.js
./design/diagrams/React Flow/_assets/vendor/diagram-vendor.js
./design/diagrams/React Flow/_assets/vendor/diagram-vendor.js.LEGAL.txt
./design/diagrams/React Flow/_assets/vendor/xyflow-react.css
```

If any diagram-specific file already exists:

1. Do not overwrite without explicit approval.
2. If the user wants a new version, use the next available suffix consistently across the Mermaid `.mmd`, Markdown `.md`, and JSON descriptor files, for example `claims-intake-flow-diagram-v2.*`.
3. Keep `diagram-viewer.html` and its `DIAGRAM_JSON_FILES` paths aligned with the final JSON filenames.

For the shared picker HTML:

1. Create `./design/diagrams/React Flow/diagram-viewer.html` if absent.
2. If it already exists, update only the `DIAGRAM_JSON_FILES` array unless the user explicitly approves refreshing the viewer skeleton.
3. Do not hardcode tab labels or descriptor content in the HTML.

For shared viewer assets:

1. Copy `diagram-viewer.css`, `diagram-viewer.js`, `diagram-picker.js`, and the full `vendor/` folder into `./design/diagrams/React Flow/_assets/` only when absent.
2. If any shared asset already exists, reuse it by default.
3. Do not overwrite shared viewer assets unless the user explicitly approves a viewer refresh.

## Quality Bar

A completed diagram conversion must satisfy all of these checks:

- `./design/diagrams/React Flow/`, `./design/diagrams/React Flow/data/`, `./design/diagrams/React Flow/_assets/`, and `./design/diagrams/Mermaid/` exist under the consuming project root.
- Every diagram has one Mermaid `.mmd`, one Markdown `.md`, and one JSON descriptor artifact.
- Mermaid is generated from the JSON descriptor and renders the core structure.
- Markdown embeds the exact Mermaid diagram in a valid `mermaid` fenced block with title, source, summary, and notes.
- `./design/diagrams/React Flow/diagram-viewer.html` exists and lists every JSON descriptor path in `DIAGRAM_JSON_FILES`.
- `./design/diagrams/React Flow/_assets/diagram-viewer.css`, `diagram-viewer.js`, `diagram-picker.js`, and `_assets/vendor/` exist, either copied during this run or reused from a prior diagram generation.
- Every JSON descriptor parses successfully and contains every visible object and relationship from the source image.
- The picker populates tab names from JSON descriptor titles and renders each descriptor through React Flow with elk.js layout using the shared viewer assets.
- The picker remains usable at desktop and mobile viewport widths.
- Any uncertainty from image interpretation is represented in `confidence`, `assumptions`, or `notes`.

## Package validation

When maintaining this skill package, run:

```powershell
pwsh scripts/validate-skill.ps1 -SkillPath .
```

The validator checks frontmatter, progressive disclosure, load triggers, templates, vendored assets, eval coverage, local-only viewer references, and lightweight JavaScript safety/syntax when Node is available.

## Output Contract

Every response using this skill must include:

```markdown
Skills used: molina-diagrams

## Diagram Conversion Summary

**Source:** <image/file/description reviewed>
**Title:** <human title>
**Output directories:** ./design/diagrams/Mermaid/ and ./design/diagrams/React Flow/
**Artifacts created:**
- ./design/diagrams/Mermaid/<title>-diagram.mmd
- ./design/diagrams/Mermaid/<title>-diagram.md
- ./design/diagrams/React Flow/data/<title>-diagram.json
**Viewer:** created | updated | reused
- ./design/diagrams/React Flow/diagram-viewer.html
**Shared viewer assets:** copied | reused | refreshed
- ./design/diagrams/React Flow/_assets/diagram-viewer.css
- ./design/diagrams/React Flow/_assets/diagram-viewer.js
- ./design/diagrams/React Flow/_assets/diagram-picker.js
- ./design/diagrams/React Flow/_assets/vendor/diagram-vendor.js
- ./design/diagrams/React Flow/_assets/vendor/diagram-vendor.js.LEGAL.txt
- ./design/diagrams/React Flow/_assets/vendor/xyflow-react.css

**Descriptor status:** PASS | NEEDS REVIEW
**Mermaid status:** PASS | NEEDS REVIEW
**Viewer status:** PASS | NEEDS REVIEW
**Assumptions:** <none or concise list>
**Validation:** <checks performed and results>
```

If image quality is too poor to extract a reliable diagram, still create a best-effort JSON descriptor only when the user requests it. Otherwise, ask for a clearer source image and state exactly what cannot be read.