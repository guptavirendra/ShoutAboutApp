(async function initializeMolinaDiagramPicker() {
  const tabs = document.querySelector('.tabs');
  const viewerRoot = document.getElementById('root');
  const frameCard = document.querySelector('.frame-card');
  const pickerStatus = document.getElementById('picker-status');
  const jsonFileInput = document.getElementById('json-file-input');
  const diagramJsonFiles = Array.isArray(window.DIAGRAM_JSON_FILES) ? window.DIAGRAM_JSON_FILES : [];
  let activeRequest = 0;
  let loadGeneration = 0;

  function setPickerStatus(message, isError = false) {
    pickerStatus.textContent = message || '';
    pickerStatus.classList.toggle('error-status', Boolean(isError));
  }

  function renderPlainError(message) {
    const errorBox = document.createElement('div');
    errorBox.className = 'error';
    errorBox.textContent = message;
    viewerRoot.replaceChildren(errorBox);
  }

  function loadClassicScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = () => reject(new Error('Unable to load ' + src));
      document.head.appendChild(script);
    });
  }

  async function loadViewerDependencies() {
    if (!window.React || !window.ReactDOM || !window.ReactFlow || !window.ELK) {
      throw new Error('Local vendor dependencies failed to load from _assets/vendor/diagram-vendor.js.');
    }

    await loadClassicScript('_assets/diagram-viewer.js');

    if (!window.MolinaDiagramViewer) {
      throw new Error('Molina diagram viewer failed to initialize.');
    }
  }

  function slugify(value, fallback) {
    return String(value || fallback || 'diagram')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'diagram';
  }

  function titleFromPath(path) {
    return String(path || '')
      .split('/')
      .pop()
      .replace(/\.json$/i, '')
      .replace(/[-_]+/g, ' ')
      .replace(/\b\w/g, char => char.toUpperCase()) || 'Diagram';
  }

  function tabLabelForDescriptor(descriptor, fallbackPath) {
    const navigation = descriptor && descriptor.navigation && typeof descriptor.navigation === 'object'
      ? descriptor.navigation
      : {};
    const candidates = [
      navigation.label,
      navigation.shortLabel,
      descriptor && descriptor.tabLabel,
      descriptor && descriptor.shortTitle,
      descriptor && descriptor.title,
      titleFromPath(fallbackPath)
    ];

    return candidates.find(value => typeof value === 'string' && value.trim()) || 'Diagram';
  }

  async function loadDiagramEntries(paths) {
    setPickerStatus('Loading diagram JSON files...');
    const entries = await Promise.all(paths.map(async (url, index) => {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Unable to load ${url}: ${response.status} ${response.statusText}`);
      }

      const descriptor = await response.json();
      const label = tabLabelForDescriptor(descriptor, url);
      const title = descriptor && descriptor.title ? descriptor.title : titleFromPath(url);
      return {
        id: slugify(title, 'diagram-' + (index + 1)),
        label,
        url,
        descriptor
      };
    }));

    return dedupeEntryIds(entries);
  }

  function readTextFile(file) {
    if (typeof file.text === 'function') return file.text();

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('Unable to read ' + file.name));
      reader.readAsText(file);
    });
  }

  async function loadDiagramEntriesFromFiles(files) {
    const jsonFiles = Array.from(files)
      .filter(file => /\.json$/i.test(file.name))
      .sort((left, right) =>
        String(left.webkitRelativePath || left.name).localeCompare(String(right.webkitRelativePath || right.name))
      );

    if (!jsonFiles.length) {
      throw new Error('No .json descriptor files were selected.');
    }

    setPickerStatus('Loading ' + jsonFiles.length + ' local JSON file' + (jsonFiles.length === 1 ? '' : 's') + '...');

    const entries = await Promise.all(jsonFiles.map(async (file, index) => {
      const text = await readTextFile(file);
      const descriptor = JSON.parse(text);
      const label = tabLabelForDescriptor(descriptor, file.name);
      const title = descriptor && descriptor.title ? descriptor.title : titleFromPath(file.name);
      return {
        id: slugify(title, 'diagram-' + (index + 1)),
        label,
        url: file.name,
        descriptor
      };
    }));

    return dedupeEntryIds(entries);
  }

  function dedupeEntryIds(entries) {
    const seen = new Map();
    entries.forEach((entry, index) => {
      const count = seen.get(entry.id) || 0;
      seen.set(entry.id, count + 1);
      if (count > 0) entry.id = entry.id + '-' + (index + 1);
    });

    return entries;
  }

  async function selectDiagram(diagram, pushState = true) {
    const requestId = ++activeRequest;

    document.querySelectorAll('.tab').forEach(tab => {
      const isSelected = tab.dataset.diagramId === diagram.id;
      tab.setAttribute('aria-selected', String(isSelected));
      tab.tabIndex = isSelected ? 0 : -1;
    });

    if (pushState) {
      const url = new URL(window.location.href);
      url.hash = diagram.id;
      window.history.replaceState(null, '', url);
    }

    try {
      if (requestId !== activeRequest) return;

      window.MolinaDiagramViewer.render(viewerRoot, diagram.descriptor, { updateTitle: false });
    } catch (error) {
      if (requestId !== activeRequest) return;
      window.MolinaDiagramViewer.renderError(
        viewerRoot,
        'Diagram load failed:\n' + (error.message || String(error))
      );
    }
  }

  function renderTabs(diagrams) {
    tabs.replaceChildren();
    diagrams.forEach(diagram => {
      const button = document.createElement('button');
      button.className = 'tab';
      button.type = 'button';
      button.role = 'tab';
      button.dataset.diagramId = diagram.id;
      button.textContent = diagram.label;
      button.title = diagram.url;
      button.addEventListener('click', () => selectDiagram(diagram));
      tabs.appendChild(button);
    });
  }

  function activateDiagrams(diagrams) {
    renderTabs(diagrams);
    tabs.onkeydown = event => onTabsKeyDown(diagrams, event);
    setPickerStatus('Loaded ' + diagrams.length + ' diagram' + (diagrams.length === 1 ? '' : 's') + '.');

    const requestedId = window.location.hash.replace('#', '');
    const initialDiagram = diagrams.find(diagram => diagram.id === requestedId) || diagrams[0];
    selectDiagram(initialDiagram, false);
  }

  function onTabsKeyDown(diagrams, event) {
    const currentIndex = diagrams.findIndex(diagram => diagram.id === document.activeElement.dataset.diagramId);
    if (currentIndex < 0 || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;

    event.preventDefault();
    let nextIndex = currentIndex;
    if (event.key === 'ArrowLeft') nextIndex = (currentIndex - 1 + diagrams.length) % diagrams.length;
    if (event.key === 'ArrowRight') nextIndex = (currentIndex + 1) % diagrams.length;
    if (event.key === 'Home') nextIndex = 0;
    if (event.key === 'End') nextIndex = diagrams.length - 1;

    const nextDiagram = diagrams[nextIndex];
    selectDiagram(nextDiagram);
    document.querySelector(`[data-diagram-id="${nextDiagram.id}"]`).focus();
  }

  async function initializePicker() {
    const generation = ++loadGeneration;

    if (!diagramJsonFiles.length) {
      window.MolinaDiagramViewer.renderError(
        viewerRoot,
        'Diagram picker template is ready. Add generated JSON descriptor paths to DIAGRAM_JSON_FILES, choose JSON files, or drag JSON descriptor files onto this panel.'
      );
      setPickerStatus('Choose one or more JSON files, or drag descriptor files onto the viewer.');
      return;
    }

    if (window.location.protocol === 'file:') {
      window.MolinaDiagramViewer.renderError(
        viewerRoot,
        'Local disk mode: browsers block automatic loading of JSON paths from file:// pages. Choose one or more JSON files, or drag descriptor files onto this panel.'
      );
      setPickerStatus('Local disk mode: choose one or more JSON files, or drag descriptor files here.');
      return;
    }

    try {
      const diagrams = await loadDiagramEntries(diagramJsonFiles);
      if (generation !== loadGeneration) return;
      activateDiagrams(diagrams);
    } catch (error) {
      if (generation !== loadGeneration) return;
      window.MolinaDiagramViewer.renderError(
        viewerRoot,
        'Diagram picker initialization failed:\n' +
          (error.message || String(error)) +
          '\n\nIf this file was opened from local disk, your browser may block automatic JSON loading from file:// URLs. Use the visible JSON files input or drag-and-drop to load generated descriptor files manually.'
      );
      setPickerStatus('Automatic JSON loading failed. Use local JSON selection or a local web server.', true);
    }
  }

  jsonFileInput.addEventListener('change', async event => {
    const files = event.target.files;
    if (!files || !files.length) return;
    const generation = ++loadGeneration;

    try {
      const diagrams = await loadDiagramEntriesFromFiles(files);
      if (generation !== loadGeneration) return;
      activateDiagrams(diagrams);
    } catch (error) {
      if (generation !== loadGeneration) return;
      window.MolinaDiagramViewer.renderError(
        viewerRoot,
        'Local JSON load failed:\n' + (error.message || String(error))
      );
      setPickerStatus('Local JSON load failed: ' + (error.message || String(error)), true);
    } finally {
      jsonFileInput.value = '';
    }
  });

  ['dragenter', 'dragover'].forEach(eventName => {
    frameCard.addEventListener(eventName, event => {
      event.preventDefault();
      frameCard.classList.add('drag-over');
    });
  });

  ['dragleave', 'drop'].forEach(eventName => {
    frameCard.addEventListener(eventName, event => {
      event.preventDefault();
      frameCard.classList.remove('drag-over');
    });
  });

  frameCard.addEventListener('drop', async event => {
    const files = event.dataTransfer && event.dataTransfer.files;
    if (!files || !files.length) return;
    const generation = ++loadGeneration;

    try {
      const diagrams = await loadDiagramEntriesFromFiles(files);
      if (generation !== loadGeneration) return;
      activateDiagrams(diagrams);
    } catch (error) {
      if (generation !== loadGeneration) return;
      window.MolinaDiagramViewer.renderError(
        viewerRoot,
        'Dropped JSON load failed:\n' + (error.message || String(error))
      );
      setPickerStatus('Dropped JSON load failed: ' + (error.message || String(error)), true);
    }
  });

  try {
    await loadViewerDependencies();
    await initializePicker();
  } catch (error) {
    renderPlainError('Diagram picker failed to initialize:\n' + (error.message || String(error)));
    setPickerStatus('Diagram picker failed to initialize: ' + (error.message || String(error)), true);
  }
})();
