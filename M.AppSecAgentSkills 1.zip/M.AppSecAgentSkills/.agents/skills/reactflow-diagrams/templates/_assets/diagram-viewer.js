const VIEWER_VERSION = '1.4.0';
const root = document.getElementById('root');
let descriptor = null;

function showFatalError(message, targetRoot = root) {
  const errorBox = document.createElement('div');
  errorBox.className = 'error';
  errorBox.textContent = message;
  if (targetRoot) targetRoot.replaceChildren(errorBox);
}

try {
  const flowLibrary = window.ReactFlow || window.XYFlow;

  if (!window.React || !window.ReactDOM) {
    throw new Error('React or ReactDOM failed to load.');
  }

  if (!flowLibrary) {
    throw new Error('React Flow global was not found. Expected window.ReactFlow.');
  }

  if (!window.ELK) {
    throw new Error('elk.js failed to load.');
  }

  const {
    ReactFlow,
    Background,
    Controls,
    MiniMap,
    Panel,
    Handle,
    EdgeLabelRenderer,
    Position,
    MarkerType,
    useNodesState,
    useEdgesState
  } = flowLibrary;

  const { useEffect, useMemo, useRef, useState } = React;
  const elk = new ELK();

  const GENERIC_NODE_WIDTH = 260;
  const GENERIC_NODE_HEIGHT = 118;
  const DIAMOND_SIZE = 178;
  const SEQUENCE_LANE_WIDTH = 230;
  const SEQUENCE_LANE_GAP = 130;
  const SEQUENCE_HEADER_HEIGHT = 74;
  const SEQUENCE_ROW_HEIGHT = 58;
  const SEQUENCE_FOOTER_HEIGHT = 64;
  const GROUP_PREFIX = 'group:';

  const palette = {
    actor: '#ecfeff',
    application: '#eff6ff',
    identity: '#f0f9ff',
    gateway: '#fefce8',
    ai: '#f0fdf4',
    external: '#fff7ed',
    internal: '#f1f5f9',
    datastore: '#faf5ff',
    data: '#fef3c7',
    document: '#fef3c7',
    observability: '#f8fafc',
    decision: '#fffbeb',
    start: '#ecfdf5',
    finish: '#eef2ff',
    default: '#ffffff'
  };

  function asObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  }

  function asArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function nonEmptyString(value, fallback = '') {
    return typeof value === 'string' && value.trim() ? value.trim() : fallback;
  }

  function normalizeElkDirection(value) {
    const map = {
      LR: 'RIGHT',
      RL: 'LEFT',
      TB: 'DOWN',
      TD: 'DOWN',
      BT: 'UP',
      RIGHT: 'RIGHT',
      LEFT: 'LEFT',
      DOWN: 'DOWN',
      UP: 'UP'
    };

    return map[String(value || 'LR').toUpperCase()] || 'RIGHT';
  }

  function normalizeDescriptor(parsed) {
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('Diagram data must be a JSON object.');
    }

    const warnings = [];
    const descriptor = {
      ...parsed,
      schemaVersion: nonEmptyString(parsed.schemaVersion, '1.1'),
      title: nonEmptyString(parsed.title, 'Molina Diagram'),
      diagram: asObject(parsed.diagram),
      source: asObject(parsed.source),
      quality: asObject(parsed.quality),
      summary: asObject(parsed.summary),
      attribution: asObject(parsed.attribution),
      nodes: asArray(parsed.nodes).map(node => ({ ...asObject(node) })),
      edges: asArray(parsed.edges).map(edge => ({ ...asObject(edge) })),
      groups: asArray(parsed.groups).map(group => ({ ...asObject(group) })),
      assumptions: asArray(parsed.assumptions),
      annotations: asArray(parsed.annotations)
    };

    descriptor.diagram.direction = normalizeElkDirection(descriptor.diagram.direction);

    const nodeIds = new Set();
    descriptor.nodes.forEach((node, index) => {
      node.id = nonEmptyString(node.id);
      if (!node.id) throw new Error(`Node at index ${index} is missing a non-empty id.`);
      if (nodeIds.has(node.id)) throw new Error(`Duplicate node id: ${node.id}`);
      nodeIds.add(node.id);
      node.label = nonEmptyString(node.label, node.id);
      node.metadata = asObject(node.metadata);
      node.visual = asObject(node.visual);
      node.notes = asArray(node.notes);
    });

    const edgeIds = new Set();
    const validEdges = [];
    descriptor.edges.forEach((edge, index) => {
      edge.id = nonEmptyString(edge.id, `edge-${index + 1}`);
      if (edgeIds.has(edge.id)) throw new Error(`Duplicate edge id: ${edge.id}`);
      edgeIds.add(edge.id);

      edge.source = nonEmptyString(edge.source);
      edge.target = nonEmptyString(edge.target);
      edge.style = asObject(edge.style);
      edge.metadata = asObject(edge.metadata);

      if (!nodeIds.has(edge.source) || !nodeIds.has(edge.target)) {
        warnings.push(
          `Dropped edge "${edge.id}" because source "${edge.source}" or target "${edge.target}" does not reference an existing node.`
        );
        return;
      }

      validEdges.push(edge);
    });
    descriptor.edges = validEdges;

    const groupIds = new Set();
    descriptor.groups.forEach((group, index) => {
      group.id = nonEmptyString(group.id);
      if (!group.id) throw new Error(`Group at index ${index} is missing a non-empty id.`);
      if (groupIds.has(group.id)) throw new Error(`Duplicate group id: ${group.id}`);
      groupIds.add(group.id);
      group.label = nonEmptyString(group.label, group.id);
      group.nodeIds = asArray(group.nodeIds).filter(id => {
        if (nodeIds.has(id)) return true;
        warnings.push(`Removed unknown node "${id}" from group "${group.id}".`);
        return false;
      });
      group.parentGroupId = nonEmptyString(group.parentGroupId) || null;
      group.visual = asObject(group.visual);
    });

    descriptor.groups.forEach(group => {
      if (group.parentGroupId && !groupIds.has(group.parentGroupId)) {
        warnings.push(
          `Removed unknown parentGroupId "${group.parentGroupId}" from group "${group.id}".`
        );
        group.parentGroupId = null;
      }
    });

    const immediateMembership = new Map();
    descriptor.groups.forEach(group => {
      group.nodeIds.forEach(nodeId => {
        if (immediateMembership.has(nodeId)) {
          throw new Error(
            `Node "${nodeId}" belongs to more than one immediate group: "${immediateMembership.get(nodeId)}" and "${group.id}".`
          );
        }
        immediateMembership.set(nodeId, group.id);
      });
    });

    const groupById = new Map(descriptor.groups.map(group => [group.id, group]));
    descriptor.groups.forEach(group => {
      const visited = new Set([group.id]);
      let parentId = group.parentGroupId;
      while (parentId) {
        if (visited.has(parentId)) {
          throw new Error(`Circular group hierarchy detected at group "${group.id}".`);
        }
        visited.add(parentId);
        parentId = groupById.get(parentId)?.parentGroupId || null;
      }
    });

    if (Array.isArray(descriptor.diagram.participants)) {
      const seen = new Set();
      descriptor.diagram.participants = descriptor.diagram.participants.filter(id => {
        if (!nodeIds.has(id)) {
          warnings.push(`Removed unknown sequence participant "${id}".`);
          return false;
        }
        if (seen.has(id)) {
          warnings.push(`Removed duplicate sequence participant "${id}".`);
          return false;
        }
        seen.add(id);
        return true;
      });
    }

    descriptor.__validationWarnings = warnings;
    return descriptor;
  }

  function readDescriptor() {
    const dataElement = document.getElementById('diagram-data');
    if (!dataElement) throw new Error('Missing #diagram-data element.');

    const raw = dataElement.textContent.trim();
    if (!raw) throw new Error('#diagram-data is empty.');

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (error) {
      throw new Error(`Diagram JSON is invalid: ${error.message}`);
    }

    return normalizeDescriptor(parsed);
  }

  const mountedRoots = new WeakMap();

  function render(targetRoot, rawDescriptor, options = {}) {
    if (!targetRoot) {
      throw new Error('A target root element is required to render a diagram.');
    }

    descriptor = normalizeDescriptor(rawDescriptor);
    if (options.updateTitle !== false) {
      document.title = descriptor.title;
    }

    let reactRoot = mountedRoots.get(targetRoot);
    if (!reactRoot) {
      targetRoot.replaceChildren();
      reactRoot = ReactDOM.createRoot(targetRoot);
      mountedRoots.set(targetRoot, reactRoot);
    }

    reactRoot.render(React.createElement(App, { key: descriptor.title + ':' + descriptor.nodes.length + ':' + descriptor.edges.length }));
  }

  function renderError(targetRoot, message) {
    const reactRoot = targetRoot ? mountedRoots.get(targetRoot) : null;
    if (reactRoot) {
      reactRoot.render(
        React.createElement(
          'div',
          { className: 'error' },
          message
        )
      );
      return;
    }

    showFatalError(message, targetRoot);
  }

  function slugClass(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'default';
  }

  function iconNameForData(data) {
    const requested = slugClass(data.icon || data.type || 'default');
    const aliases = {
      actor: 'actor',
      person: 'actor',
      user: 'actor',
      application: 'application',
      app: 'application',
      api: 'api',
      gateway: 'gateway',
      datastore: 'database',
      database: 'database',
      data: 'database',
      document: 'document',
      cloud: 'cloud',
      external: 'cloud',
      identity: 'identity',
      auth: 'identity',
      shield: 'shield',
      security: 'shield',
      ai: 'ai',
      observability: 'observability',
      monitoring: 'observability',
      decision: 'decision',
      start: 'start',
      finish: 'finish',
      end: 'finish'
    };

    return aliases[requested] || aliases[slugClass(data.type)] || 'default';
  }

  function SvgIcon({ name }) {
    const common = {
      viewBox: '0 0 24 24',
      role: 'img',
      'aria-label': name + ' icon'
    };

    const line = (key, props) => React.createElement('line', { key, ...props });
    const path = (key, d) => React.createElement('path', { key, d });
    const rect = (key, props) => React.createElement('rect', { key, ...props });
    const circle = (key, props) => React.createElement('circle', { key, ...props });
    const ellipse = (key, props) => React.createElement('ellipse', { key, ...props });
    let children;

    switch (name) {
      case 'actor':
        children = [
          circle('head', { cx: 12, cy: 7, r: 3 }),
          path('body', 'M5.5 20c.7-4.1 3-6.2 6.5-6.2s5.8 2.1 6.5 6.2')
        ];
        break;
      case 'application':
        children = [
          rect('window', { x: 3, y: 4, width: 18, height: 16, rx: 2 }),
          line('bar', { x1: 3, y1: 8, x2: 21, y2: 8 }),
          circle('dot1', { cx: 6.2, cy: 6.1, r: .5 }),
          circle('dot2', { cx: 8.4, cy: 6.1, r: .5 })
        ];
        break;
      case 'api':
        children = [
          path('left', 'M8 7 3 12l5 5'),
          path('right', 'm16 7 5 5-5 5'),
          line('slash', { x1: 14, y1: 4, x2: 10, y2: 20 })
        ];
        break;
      case 'gateway':
        children = [
          rect('gate', { x: 5, y: 3, width: 14, height: 18, rx: 2 }),
          line('split', { x1: 12, y1: 3, x2: 12, y2: 21 }),
          circle('knob', { cx: 9.5, cy: 12, r: .6 }),
          circle('knob2', { cx: 14.5, cy: 12, r: .6 })
        ];
        break;
      case 'database':
        children = [
          ellipse('top', { cx: 12, cy: 5.5, rx: 7.5, ry: 3 }),
          path('body', 'M4.5 5.5v12.7c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V5.5'),
          path('mid1', 'M4.5 10.2c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3'),
          path('mid2', 'M4.5 14.5c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3')
        ];
        break;
      case 'document':
        children = [
          path('sheet', 'M6 3h8l4 4v14H6z'),
          path('fold', 'M14 3v5h5'),
          line('l1', { x1: 9, y1: 12, x2: 15, y2: 12 }),
          line('l2', { x1: 9, y1: 16, x2: 15, y2: 16 })
        ];
        break;
      case 'cloud':
        children = [path('cloud', 'M7.2 19h10.6a4.2 4.2 0 0 0 .4-8.4A6.5 6.5 0 0 0 5.8 9.2 4.9 4.9 0 0 0 7.2 19Z')];
        break;
      case 'identity':
        children = [
          circle('head', { cx: 12, cy: 8, r: 3 }),
          path('card', 'M4 4h16v16H4z'),
          path('body', 'M7.5 17c.6-2.7 2.1-4 4.5-4s3.9 1.3 4.5 4')
        ];
        break;
      case 'shield':
        children = [
          path('shield', 'M12 3 20 6v5.2c0 5-3.2 8.3-8 9.8-4.8-1.5-8-4.8-8-9.8V6z'),
          path('check', 'm8.5 12 2.2 2.2 4.8-5')
        ];
        break;
      case 'ai':
        children = [
          rect('chip', { x: 6, y: 6, width: 12, height: 12, rx: 2 }),
          circle('core', { cx: 12, cy: 12, r: 2.4 }),
          line('p1', { x1: 9, y1: 2.5, x2: 9, y2: 6 }),
          line('p2', { x1: 15, y1: 2.5, x2: 15, y2: 6 }),
          line('p3', { x1: 9, y1: 18, x2: 9, y2: 21.5 }),
          line('p4', { x1: 15, y1: 18, x2: 15, y2: 21.5 }),
          line('p5', { x1: 2.5, y1: 9, x2: 6, y2: 9 }),
          line('p6', { x1: 18, y1: 9, x2: 21.5, y2: 9 }),
          line('p7', { x1: 2.5, y1: 15, x2: 6, y2: 15 }),
          line('p8', { x1: 18, y1: 15, x2: 21.5, y2: 15 })
        ];
        break;
      case 'observability':
        children = [
          path('eye', 'M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z'),
          circle('pupil', { cx: 12, cy: 12, r: 2.5 })
        ];
        break;
      case 'decision':
        children = [
          path('diamond', 'm12 3 9 9-9 9-9-9z'),
          path('question', 'M9.7 9.2a2.5 2.5 0 1 1 3.3 2.4c-.8.4-1 .9-1 1.7'),
          circle('dot', { cx: 12, cy: 16.8, r: .6 })
        ];
        break;
      case 'start':
        children = [circle('start', { cx: 12, cy: 12, r: 7 }), path('play', 'm10 8 6 4-6 4z')];
        break;
      case 'finish':
        children = [circle('outer', { cx: 12, cy: 12, r: 8 }), circle('inner', { cx: 12, cy: 12, r: 4 })];
        break;
      default:
        children = [
          rect('box', { x: 4, y: 4, width: 16, height: 16, rx: 3 }),
          path('spark', 'm8 13 2.4 2.4L16 9.8')
        ];
    }

    return React.createElement('svg', common, children);
  }

  function genericPortSpec(direction) {
    const normalized = normalizeElkDirection(direction);
    const specs = {
      RIGHT: {
        sourceHandle: 'out-right',
        targetHandle: 'in-left',
        sourcePosition: Position.Right,
        targetPosition: Position.Left,
        sourceSide: 'EAST',
        targetSide: 'WEST'
      },
      LEFT: {
        sourceHandle: 'out-left',
        targetHandle: 'in-right',
        sourcePosition: Position.Left,
        targetPosition: Position.Right,
        sourceSide: 'WEST',
        targetSide: 'EAST'
      },
      DOWN: {
        sourceHandle: 'out-bottom',
        targetHandle: 'in-top',
        sourcePosition: Position.Bottom,
        targetPosition: Position.Top,
        sourceSide: 'SOUTH',
        targetSide: 'NORTH'
      },
      UP: {
        sourceHandle: 'out-top',
        targetHandle: 'in-bottom',
        sourcePosition: Position.Top,
        targetPosition: Position.Bottom,
        sourceSide: 'NORTH',
        targetSide: 'SOUTH'
      }
    };

    return specs[normalized] || specs.RIGHT;
  }

  function CustomNode({ data }) {
    if (data.renderMode === 'group-boundary') {
      return React.createElement(
        'div',
        {
          className:
            'group-boundary ' +
            slugClass(data.type) + ' ' +
            slugClass(data.color) + ' ' +
            slugClass(data.id)
        },
        React.createElement('div', { className: 'group-label' }, data.label || data.id)
      );
    }

    if (data.renderMode === 'sequence-participant') {
      return React.createElement(
        'div',
        { className: 'sequence-lane-shell', style: { height: data.height } },
        React.createElement(
          'div',
          {
            className: 'sequence-lane',
            style: {
              height: data.height,
              background: palette[data.color] || palette[data.type] || palette.default
            }
          },
          React.createElement(
            'div',
            { className: 'sequence-header' },
            React.createElement('div', { className: 'sequence-label' }, data.label || data.id),
            React.createElement(
              'div',
              { className: 'sequence-type' },
              [data.type, data.technology].filter(Boolean).join(' / ')
            )
          ),
          React.createElement(
            'div',
            { className: 'sequence-footer' },
            data.notes && data.notes[0] ? data.notes[0] : data.owner || ''
          )
        ),
        (data.handles || []).map(handle => React.createElement(Handle, {
          key: handle.id,
          id: handle.id,
          type: handle.kind,
          position: handle.position,
          className: 'sequence-step',
          style: { top: handle.top }
        }))
      );
    }

    const note = Array.isArray(data.notes) && data.notes.length
      ? data.notes[0]
      : data.description;
    const shape = data.shape || 'rectangle';
    const wrapperClass = [
      'node-shell',
      'shape-' + shape
    ].join(' ');
    const cardClass = [
      'node-card',
      data.type || 'default',
      'shape-' + shape,
      data.color === 'data' ? 'data-object' : ''
    ].filter(Boolean).join(' ');
    const ports = genericPortSpec(data.direction);
    const icon = data.icon || data.type ? iconNameForData(data) : null;

    return React.createElement(
      'div',
      { className: wrapperClass },
      React.createElement(Handle, {
        id: ports.targetHandle,
        type: 'target',
        position: ports.targetPosition,
        className: 'node-port'
      }),
      React.createElement(
        'div',
        {
          className: cardClass,
          style: {
            background: palette[data.color] || palette[data.type] || palette.default
          }
        },
        icon
          ? React.createElement(
              'div',
              { className: 'icon-frame', title: data.icon || data.type },
              React.createElement(SvgIcon, { name: icon })
            )
          : null,
        React.createElement('div', { className: 'node-label' }, data.label || data.id),
        React.createElement(
          'div',
          { className: 'node-type' },
          [data.type, data.technology].filter(Boolean).join(' / ')
        ),
        note ? React.createElement('div', { className: 'node-note' }, note) : null
      ),
      React.createElement(Handle, {
        id: ports.sourceHandle,
        type: 'source',
        position: ports.sourcePosition,
        className: 'node-port'
      })
    );
  }

  function SequenceEdge(props) {
    const {
      sourceX,
      sourceY,
      targetX,
      targetY,
      markerEnd,
      style,
      data
    } = props;

    const isSelf = Boolean(data && data.selfMessage);
    let pathData;
    let labelX;
    let labelY;

    if (isSelf) {
      const loopWidth = 64;
      const yMid = (sourceY + targetY) / 2;
      pathData = [
        `M ${sourceX} ${sourceY}`,
        `C ${sourceX + loopWidth} ${sourceY}, ${sourceX + loopWidth} ${targetY}, ${targetX} ${targetY}`
      ].join(' ');
      labelX = sourceX + loopWidth + 12;
      labelY = yMid;
    } else {
      pathData = `M ${sourceX} ${sourceY} L ${targetX} ${targetY}`;
      labelX = (sourceX + targetX) / 2;
      labelY = (sourceY + targetY) / 2;
    }

    const label = data && data.label
      ? React.createElement(
          'div',
          {
            className: 'sequence-message-label sequence-message-label-floating nodrag nopan',
            style: {
              transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`
            }
          },
          data.sequence ? `${data.sequence}. ${data.label}` : data.label
        )
      : null;

    return React.createElement(
      React.Fragment,
      null,
      React.createElement(
        'g',
        { className: 'sequence-message-edge' },
        React.createElement('path', {
          className: 'react-flow__edge-path',
          d: pathData,
          markerEnd,
          style
        })
      ),
      label && EdgeLabelRenderer
        ? React.createElement(EdgeLabelRenderer, null, label)
        : null
    );
  }

  const nodeTypes = { custom: CustomNode };
  const edgeTypes = { sequence: SequenceEdge };

  function nodeShape(node) {
    return node.visual && node.visual.shape
      ? node.visual.shape
      : node.type === 'decision'
        ? 'diamond'
        : node.type === 'datastore'
          ? 'cylinder'
          : node.type === 'document' || node.type === 'data'
            ? 'document'
            : 'rectangle';
  }

  function toFlowNode(node) {
    const color = node.visual && node.visual.color
      ? node.visual.color
      : node.type || 'default';
    const shape = nodeShape(node);
    const isDiamond = shape === 'diamond';

    return {
      id: node.id,
      type: 'custom',
      position: { x: 0, y: 0 },
      data: {
        id: node.id,
        label: node.label,
        type: node.type,
        description: node.description,
        technology: node.metadata && node.metadata.technology,
        owner: node.metadata && node.metadata.owner,
        confidence: node.confidence,
        notes: node.notes,
        color,
        shape,
        icon: node.visual && node.visual.icon,
        direction: descriptor.diagram.direction
      },
      style: isDiamond
        ? { width: DIAMOND_SIZE, height: DIAMOND_SIZE }
        : { width: GENERIC_NODE_WIDTH }
    };
  }

  function edgeMarker(edge) {
    if (edge.direction === 'undirected' || (edge.style && edge.style.arrow === 'none')) {
      return undefined;
    }

    return {
      type: MarkerType.ArrowClosed,
      width: 18,
      height: 18,
      color: '#475569'
    };
  }

  function toFlowEdge(edge) {
    const ports = genericPortSpec(descriptor.diagram.direction);
    return {
      id: edge.id,
      source: edge.source,
      target: edge.target,
      sourceHandle: ports.sourceHandle,
      targetHandle: ports.targetHandle,
      label: edge.label || '',
      type: 'smoothstep',
      markerEnd: edgeMarker(edge),
      style: {
        strokeWidth: edge.style && edge.style.line === 'bold' ? 2.4 : 1.6,
        stroke: '#475569',
        strokeDasharray:
          edge.style && (edge.style.line === 'dashed' || edge.style.line === 'dotted')
            ? '6 5'
            : undefined
      },
      labelBgPadding: [8, 4],
      labelBgBorderRadius: 6,
      labelBgStyle: {
        fill: 'rgba(255,255,255,.92)',
        stroke: '#cbd5e1'
      },
      labelStyle: {
        fontSize: 11,
        fill: '#334155',
        fontWeight: 600
      }
    };
  }

  function isSequenceDescriptor() {
    return (
      descriptor.diagram.type === 'sequence' ||
      descriptor.diagram.mermaidKind === 'sequenceDiagram' ||
      descriptor.edges.some(edge => edge.type === 'sequence')
    );
  }

  function sequenceOrder(item, fallback) {
    const metadata = item.metadata || {};
    const candidates = [
      metadata.sequenceOrder,
      metadata.sequence,
      metadata.order,
      metadata.step,
      item.sequenceOrder,
      item.order,
      item.step
    ];

    for (const candidate of candidates) {
      const numeric = Number(candidate);
      if (Number.isFinite(numeric)) return numeric;
    }

    const labelMatch = String(item.label || '').match(/^\s*(\d+)/);
    return labelMatch ? Number(labelMatch[1]) : fallback;
  }

  function orderedSequenceParticipants() {
    const nodeById = new Map(descriptor.nodes.map(node => [node.id, node]));
    const explicit = asArray(descriptor.diagram.participants)
      .map(id => nodeById.get(id))
      .filter(Boolean);

    if (explicit.length) return explicit;

    return descriptor.nodes
      .filter(node => descriptor.edges.some(edge => edge.source === node.id || edge.target === node.id))
      .map((node, index) => ({ node, index }))
      .sort((left, right) => sequenceOrder(left.node, left.index) - sequenceOrder(right.node, right.index))
      .map(entry => entry.node);
  }

  function orderedSequenceMessages(participantIndex) {
    return descriptor.edges
      .filter(edge =>
        edge.source &&
        edge.target &&
        participantIndex.has(edge.source) &&
        participantIndex.has(edge.target)
      )
      .map((edge, index) => ({ edge, index }))
      .sort((left, right) => sequenceOrder(left.edge, left.index) - sequenceOrder(right.edge, right.index));
  }

  function sideForMessage(participantIndex, sourceIndex, targetIndex, role) {
    if (sourceIndex === targetIndex) return Position.Right;
    if (role === 'source') return sourceIndex < targetIndex ? Position.Right : Position.Left;
    return sourceIndex < targetIndex ? Position.Left : Position.Right;
  }

  function buildSequenceFlowModel() {
    const participants = orderedSequenceParticipants();
    const participantIndex = new Map(participants.map((node, index) => [node.id, index]));
    const messages = orderedSequenceMessages(participantIndex);
    const laneHeight =
      SEQUENCE_HEADER_HEIGHT +
      Math.max(messages.length, 1) * SEQUENCE_ROW_HEIGHT +
      SEQUENCE_FOOTER_HEIGHT;
    const handlesByNode = new Map(participants.map(node => [node.id, []]));

    messages.forEach((entry, messageIndex) => {
      const sourceIndex = participantIndex.get(entry.edge.source);
      const targetIndex = participantIndex.get(entry.edge.target);
      const centerTop =
        SEQUENCE_HEADER_HEIGHT +
        messageIndex * SEQUENCE_ROW_HEIGHT +
        Math.round(SEQUENCE_ROW_HEIGHT / 2);
      const selfMessage = sourceIndex === targetIndex;

      handlesByNode.get(entry.edge.source).push({
        id: entry.edge.id + ':source',
        kind: 'source',
        top: selfMessage ? centerTop - 10 : centerTop,
        position: sideForMessage(sourceIndex, sourceIndex, targetIndex, 'source')
      });

      handlesByNode.get(entry.edge.target).push({
        id: entry.edge.id + ':target',
        kind: 'target',
        top: selfMessage ? centerTop + 10 : centerTop,
        position: sideForMessage(targetIndex, sourceIndex, targetIndex, 'target')
      });
    });

    const nodes = participants.map((node, index) => {
      const color = node.visual && node.visual.color
        ? node.visual.color
        : node.type || 'default';

      return {
        id: node.id,
        type: 'custom',
        position: {
          x: index * (SEQUENCE_LANE_WIDTH + SEQUENCE_LANE_GAP),
          y: 0
        },
        data: {
          id: node.id,
          renderMode: 'sequence-participant',
          label: node.label,
          type: node.type,
          description: node.description,
          technology: node.metadata && node.metadata.technology,
          owner: node.metadata && node.metadata.owner,
          confidence: node.confidence,
          notes: node.notes,
          color,
          height: laneHeight,
          handles: handlesByNode.get(node.id) || []
        },
        draggable: true,
        style: {
          width: SEQUENCE_LANE_WIDTH,
          height: laneHeight
        }
      };
    });

    const edges = messages.map((entry, messageIndex) => {
      const edge = entry.edge;
      const dashed = edge.style && (
        edge.style.line === 'dashed' ||
        edge.style.line === 'dotted'
      );

      return {
        id: edge.id,
        source: edge.source,
        target: edge.target,
        sourceHandle: edge.id + ':source',
        targetHandle: edge.id + ':target',
        type: 'sequence',
        markerEnd: edgeMarker(edge),
        style: {
          strokeWidth: dashed ? 1.4 : 1.8,
          stroke: '#334155',
          strokeDasharray: dashed ? '6 5' : undefined
        },
        data: {
          label: edge.label || '',
          sequence: messageIndex + 1,
          selfMessage: edge.source === edge.target
        }
      };
    });

    return {
      mode: 'sequence',
      nodes,
      edges,
      participantCount: participants.length,
      messageCount: messages.length
    };
  }

  function buildGenericFlowModel() {
    return {
      mode: 'generic',
      nodes: descriptor.nodes.map(toFlowNode),
      edges: descriptor.edges.map(toFlowEdge)
    };
  }

  function buildFlowModel() {
    return isSequenceDescriptor()
      ? buildSequenceFlowModel()
      : buildGenericFlowModel();
  }

  function measuredNodeSize(flowNode, measuredById) {
    const measured = measuredById.get(flowNode.id) || flowNode;
    const measuredWidth = Number(
      measured.measured?.width ||
      measured.width ||
      flowNode.style?.width
    );
    const measuredHeight = Number(
      measured.measured?.height ||
      measured.height ||
      flowNode.style?.height
    );

    return {
      width: Number.isFinite(measuredWidth) && measuredWidth > 0
        ? measuredWidth
        : GENERIC_NODE_WIDTH,
      height: Number.isFinite(measuredHeight) && measuredHeight > 0
        ? measuredHeight
        : GENERIC_NODE_HEIGHT
    };
  }

  function waitForNodeMeasurements(instance, nodeIds, maxFrames = 90) {
    return new Promise(resolve => {
      let frame = 0;

      function inspect() {
        const currentNodes = instance.getNodes();
        const byId = new Map(currentNodes.map(node => [node.id, node]));
        const allMeasured = nodeIds.every(id => {
          const node = byId.get(id);
          if (!node) return false;
          const width = Number(node.measured?.width || node.width || node.style?.width);
          const height = Number(node.measured?.height || node.height || node.style?.height);
          return width > 0 && height > 0;
        });

        if (allMeasured || frame >= maxFrames) {
          resolve(currentNodes);
          return;
        }

        frame += 1;
        window.requestAnimationFrame(inspect);
      }

      inspect();
    });
  }

  function elkNodeFromFlowNode(flowNode, measuredById, direction) {
    const size = measuredNodeSize(flowNode, measuredById);
    const ports = genericPortSpec(direction);

    return {
      id: flowNode.id,
      width: size.width,
      height: size.height,
      layoutOptions: {
        'elk.portConstraints': 'FIXED_SIDE'
      },
      ports: [
        {
          id: `${flowNode.id}::${ports.sourceHandle}`,
          width: 2,
          height: 2,
          layoutOptions: { 'elk.port.side': ports.sourceSide }
        },
        {
          id: `${flowNode.id}::${ports.targetHandle}`,
          width: 2,
          height: 2,
          layoutOptions: { 'elk.port.side': ports.targetSide }
        }
      ]
    };
  }

  function elkEdgeFromFlowEdge(flowEdge, direction) {
    const ports = genericPortSpec(direction);
    return {
      id: flowEdge.id,
      sources: [`${flowEdge.source}::${ports.sourceHandle}`],
      targets: [`${flowEdge.target}::${ports.targetHandle}`]
    };
  }

  function makeLayoutOptions(direction, isGroup = false) {
    return {
      'elk.algorithm': 'layered',
      'elk.direction': normalizeElkDirection(direction),
      'elk.spacing.nodeNode': isGroup ? '62' : '82',
      'elk.layered.spacing.nodeNodeBetweenLayers': isGroup ? '86' : '112',
      'elk.edgeRouting': 'ORTHOGONAL',
      'elk.layered.crossingMinimization.strategy': 'LAYER_SWEEP',
      'elk.layered.nodePlacement.strategy': 'BRANDES_KOEPF',
      'elk.layered.considerModelOrder.strategy': 'NODES_AND_EDGES',
      'elk.hierarchyHandling': 'INCLUDE_CHILDREN',
      'elk.padding': isGroup
        ? '[top=54,left=34,bottom=34,right=34]'
        : '[top=20,left=20,bottom=20,right=20]'
    };
  }

  function buildCompoundElkGraph(flowNodes, flowEdges, measuredNodes) {
    const direction = descriptor.diagram.direction;
    const measuredById = new Map(measuredNodes.map(node => [node.id, node]));
    const flowNodeById = new Map(flowNodes.map(node => [node.id, node]));
    const groupById = new Map(descriptor.groups.map(group => [group.id, group]));
    const memberToGroup = new Map();
    descriptor.groups.forEach(group => {
      group.nodeIds.forEach(nodeId => memberToGroup.set(nodeId, group.id));
    });

    const elkGroupById = new Map();
    descriptor.groups.forEach(group => {
      elkGroupById.set(group.id, {
        id: GROUP_PREFIX + group.id,
        layoutOptions: makeLayoutOptions(group.direction || direction, true),
        children: []
      });
    });

    const rootChildren = [];
    descriptor.groups.forEach(group => {
      const elkGroup = elkGroupById.get(group.id);
      if (group.parentGroupId) {
        elkGroupById.get(group.parentGroupId).children.push(elkGroup);
      } else {
        rootChildren.push(elkGroup);
      }
    });

    flowNodes.forEach(flowNode => {
      const elkNode = elkNodeFromFlowNode(flowNode, measuredById, direction);
      const groupId = memberToGroup.get(flowNode.id);
      if (groupId && elkGroupById.has(groupId)) {
        elkGroupById.get(groupId).children.push(elkNode);
      } else {
        rootChildren.push(elkNode);
      }
    });

    return {
      id: 'root',
      layoutOptions: makeLayoutOptions(direction, false),
      children: rootChildren,
      edges: flowEdges.map(edge => elkEdgeFromFlowEdge(edge, direction)),
      __flowNodeById: flowNodeById,
      __groupById: groupById
    };
  }

  function flattenCompoundLayout(result, flowNodeById, groupById) {
    const output = [];

    function visit(children, parentFlowId = null, depth = 0) {
      (children || []).forEach(child => {
        if (child.id.startsWith(GROUP_PREFIX)) {
          const rawGroupId = child.id.slice(GROUP_PREFIX.length);
          const group = groupById.get(rawGroupId) || {};
          const flowGroup = {
            id: child.id,
            type: 'custom',
            position: {
              x: Number(child.x) || 0,
              y: Number(child.y) || 0
            },
            data: {
              renderMode: 'group-boundary',
              id: rawGroupId,
              label: group.label || rawGroupId,
              type: group.type,
              color: group.visual && group.visual.color
            },
            draggable: true,
            dragHandle: '.group-boundary',
            selectable: true,
            connectable: false,
            style: {
              width: Number(child.width) || 360,
              height: Number(child.height) || 240,
              zIndex: Math.max(0, depth)
            }
          };

          if (parentFlowId) {
            flowGroup.parentId = parentFlowId;
            flowGroup.parentNode = parentFlowId;
            flowGroup.extent = 'parent';
          }

          output.push(flowGroup);
          visit(child.children, child.id, depth + 1);
          return;
        }

        const original = flowNodeById.get(child.id);
        if (!original) return;

        const positioned = {
          ...original,
          position: {
            x: Number(child.x) || 0,
            y: Number(child.y) || 0
          },
          style: {
            ...(original.style || {}),
            zIndex: depth + 10
          }
        };

        if (parentFlowId) {
          positioned.parentId = parentFlowId;
          positioned.parentNode = parentFlowId;
          positioned.extent = 'parent';
        }

        output.push(positioned);
      });
    }

    visit(result.children);
    return output;
  }

  function buildFlatElkGraph(flowNodes, flowEdges, measuredNodes) {
    const direction = descriptor.diagram.direction;
    const measuredById = new Map(measuredNodes.map(node => [node.id, node]));
    const flowNodeById = new Map(flowNodes.map(node => [node.id, node]));

    return {
      id: 'root',
      layoutOptions: makeLayoutOptions(direction, false),
      children: flowNodes.map(node => elkNodeFromFlowNode(node, measuredById, direction)),
      edges: flowEdges.map(edge => elkEdgeFromFlowEdge(edge, direction)),
      __flowNodeById: flowNodeById
    };
  }

  function addFlatGroupBoundaries(layoutedNodes) {
    if (!Array.isArray(descriptor.groups) || descriptor.groups.length === 0) {
      return layoutedNodes;
    }

    const nodeById = new Map(layoutedNodes.map(node => [node.id, node]));
    const groupById = new Map(descriptor.groups.map(group => [group.id, group]));
    const childrenByParent = new Map();
    descriptor.groups.forEach(group => {
      if (!group.parentGroupId) return;
      if (!childrenByParent.has(group.parentGroupId)) {
        childrenByParent.set(group.parentGroupId, []);
      }
      childrenByParent.get(group.parentGroupId).push(group);
    });

    function absoluteNodeBounds(node) {
      const width = (node.style && node.style.width) || GENERIC_NODE_WIDTH;
      const height = (node.style && node.style.height) || GENERIC_NODE_HEIGHT;
      return {
        x: node.position.x,
        y: node.position.y,
        width,
        height,
        maxX: node.position.x + width,
        maxY: node.position.y + height
      };
    }

    const groupBoundsById = new Map();
    function computeGroupBounds(group) {
      if (groupBoundsById.has(group.id)) {
        return groupBoundsById.get(group.id);
      }

      const directNodeBounds = asArray(group.nodeIds)
        .map(id => nodeById.get(id))
        .filter(Boolean)
        .map(absoluteNodeBounds);
      const childGroupBounds = asArray(childrenByParent.get(group.id))
        .map(computeGroupBounds)
        .filter(Boolean);
      const childBounds = directNodeBounds.concat(childGroupBounds);

      if (!childBounds.length) {
        groupBoundsById.set(group.id, null);
        return null;
      }

      const minX = Math.min(...childBounds.map(bounds => bounds.x));
      const minY = Math.min(...childBounds.map(bounds => bounds.y));
      const maxX = Math.max(...childBounds.map(bounds => bounds.maxX));
      const maxY = Math.max(...childBounds.map(bounds => bounds.maxY));
      const paddingX = 58;
      const paddingY = 70;
      const bounds = {
        x: minX - paddingX,
        y: minY - paddingY,
        width: maxX - minX + paddingX * 2,
        height: maxY - minY + paddingY * 2
      };
      bounds.maxX = bounds.x + bounds.width;
      bounds.maxY = bounds.y + bounds.height;
      groupBoundsById.set(group.id, bounds);
      return bounds;
    }

    descriptor.groups.forEach(computeGroupBounds);

    function isExternalGroup(group) {
      const text = [group.id, group.label, group.type, group.visual && group.visual.color]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return /external|public|internet|vendor|saas|third[-\s]?party|akamai|zelis/.test(text);
    }

    function isMolinaOrInternalGroup(group) {
      const text = [group.id, group.label, group.type, group.visual && group.visual.color]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return /molina|internal|private|controlled|zone-molina|trust-zone/.test(text) && !isExternalGroup(group);
    }

    function preferredExternalSide(group) {
      const text = [group.id, group.label, group.type, group.visual && group.visual.color]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      if (/public|internet|member|user|client|consumer|akamai/.test(text)) return 'left';
      if (/vendor|saas|third[-\s]?party|zelis|external service|external api/.test(text)) return 'right';
      return null;
    }

    function boundsOverlap(left, right, margin = 24) {
      return !(
        left.maxX + margin <= right.x ||
        right.maxX + margin <= left.x ||
        left.maxY + margin <= right.y ||
        right.maxY + margin <= left.y
      );
    }

    function translateGroupTree(group, dx, dy) {
      const bounds = groupBoundsById.get(group.id);
      if (!bounds) return;
      bounds.x += dx;
      bounds.y += dy;
      bounds.maxX += dx;
      bounds.maxY += dy;

      asArray(group.nodeIds).forEach(nodeId => {
        const node = nodeById.get(nodeId);
        if (!node) return;
        node.position = {
          x: node.position.x + dx,
          y: node.position.y + dy
        };
      });

      asArray(childrenByParent.get(group.id)).forEach(childGroup => {
        translateGroupTree(childGroup, dx, dy);
      });
    }

    function separateExternalRootGroups() {
      const rootGroups = descriptor.groups.filter(group => !group.parentGroupId);
      const anchor = rootGroups
        .filter(group => groupBoundsById.get(group.id) && isMolinaOrInternalGroup(group))
        .sort((left, right) => {
          const leftBounds = groupBoundsById.get(left.id);
          const rightBounds = groupBoundsById.get(right.id);
          return (rightBounds.width * rightBounds.height) - (leftBounds.width * leftBounds.height);
        })[0];
      if (!anchor) return;

      const anchorBounds = groupBoundsById.get(anchor.id);
      rootGroups
        .filter(group => group.id !== anchor.id && groupBoundsById.get(group.id) && isExternalGroup(group))
        .forEach(group => {
          const bounds = groupBoundsById.get(group.id);
          if (!boundsOverlap(bounds, anchorBounds, 36)) return;

          const preferredSide = preferredExternalSide(group);
          const groupCenter = bounds.x + bounds.width / 2;
          const anchorCenter = anchorBounds.x + anchorBounds.width / 2;
          const placeLeft = preferredSide ? preferredSide === 'left' : groupCenter < anchorCenter;
          const desiredX = placeLeft
            ? anchorBounds.x - bounds.width - 96
            : anchorBounds.maxX + 96;
          const dx = desiredX - bounds.x;
          translateGroupTree(group, dx, 0);
          descriptor.__validationWarnings = (descriptor.__validationWarnings || []).concat(
            `Moved top-level external group "${group.id}" outside "${anchor.id}" to avoid visual containment overlap.`
          );
        });
    }

    separateExternalRootGroups();

    const childToGroup = new Map();
    descriptor.groups.forEach(group => {
      const groupId = GROUP_PREFIX + group.id;
      const groupBounds = groupBoundsById.get(group.id);
      if (!groupBounds) return;

      asArray(group.nodeIds).forEach(nodeId => {
        if (!nodeById.has(nodeId)) return;
        childToGroup.set(nodeId, { groupId, groupBounds });
      });
    });

    const groupNodes = [];
    function addGroupNode(group, depth = 0) {
      const groupBounds = groupBoundsById.get(group.id);
      if (!groupBounds) return;

      const groupId = GROUP_PREFIX + group.id;
      const parent = group.parentGroupId ? groupById.get(group.parentGroupId) : null;
      const parentBounds = parent ? groupBoundsById.get(parent.id) : null;
      const position = parentBounds
        ? {
            x: groupBounds.x - parentBounds.x,
            y: groupBounds.y - parentBounds.y
          }
        : {
            x: groupBounds.x,
            y: groupBounds.y
          };

      const flowGroup = {
        id: groupId,
        type: 'custom',
        position,
        data: {
          renderMode: 'group-boundary',
          id: group.id,
          label: group.label || group.id,
          type: group.type,
          color: group.visual && group.visual.color
        },
        draggable: true,
        dragHandle: '.group-boundary',
        selectable: true,
        connectable: false,
        style: {
          width: groupBounds.width,
          height: groupBounds.height,
          zIndex: Math.max(0, depth)
        }
      };

      if (parentBounds) {
        flowGroup.parentId = GROUP_PREFIX + parent.id;
        flowGroup.parentNode = GROUP_PREFIX + parent.id;
        flowGroup.extent = 'parent';
      }

      groupNodes.push(flowGroup);
      asArray(childrenByParent.get(group.id)).forEach(childGroup => addGroupNode(childGroup, depth + 1));
    }

    descriptor.groups
      .filter(group => !group.parentGroupId || !groupById.has(group.parentGroupId))
      .forEach(group => addGroupNode(group, 0));

    const groupedNodes = layoutedNodes.map(node => {
      const parent = childToGroup.get(node.id);
      if (!parent) {
        return {
          ...node,
          style: { ...(node.style || {}), zIndex: 10 }
        };
      }

      return {
        ...node,
        parentId: parent.groupId,
        parentNode: parent.groupId,
        extent: 'parent',
        position: {
          x: node.position.x - parent.groupBounds.x,
          y: node.position.y - parent.groupBounds.y
        },
        style: { ...(node.style || {}), zIndex: 10 }
      };
    });

    return groupNodes.concat(groupedNodes);
  }

  async function layoutFlatWithGroupBoundaries(flowNodes, flowEdges, measuredNodes) {
    const graph = buildFlatElkGraph(flowNodes, flowEdges, measuredNodes);
    const flowNodeById = graph.__flowNodeById;
    delete graph.__flowNodeById;

    const result = await elk.layout(graph);
    const positionedNodes = (result.children || []).map(child => {
      const original = flowNodeById.get(child.id);
      if (!original) return null;

      return {
        ...original,
        position: {
          x: Number(child.x) || 0,
          y: Number(child.y) || 0
        },
        style: { ...(original.style || {}), zIndex: 10 }
      };
    }).filter(Boolean);

    return addFlatGroupBoundaries(positionedNodes);
  }

  async function layoutGeneric(flowNodes, flowEdges, measuredNodes) {
    const graph = buildCompoundElkGraph(flowNodes, flowEdges, measuredNodes);
    const flowNodeById = graph.__flowNodeById;
    const groupById = graph.__groupById;
    delete graph.__flowNodeById;
    delete graph.__groupById;

    try {
      const result = await elk.layout(graph);
      return flattenCompoundLayout(result, flowNodeById, groupById);
    } catch (error) {
      const message =
        'Compound ELK group layout failed; rendered with flat fallback while preserving draggable nested group boundaries: ' +
        (error && error.message ? error.message : String(error));
      descriptor.__validationWarnings = (descriptor.__validationWarnings || []).concat(message);
      return layoutFlatWithGroupBoundaries(flowNodes, flowEdges, measuredNodes);
    }
  }

  function DetailsPanel() {
    const assumptions = descriptor.assumptions;
    const reviewNotes = asArray(descriptor.quality.reviewNotes);
    const warnings = descriptor.__validationWarnings || [];
    const notes = reviewNotes.concat(warnings);
    const confidenceValue = Number(descriptor.quality.overallConfidence);
    const confidenceLabel = Number.isFinite(confidenceValue)
      ? Math.round(confidenceValue * 100) + '%'
      : 'N/A';
    const attributionText = nonEmptyString(
      descriptor.attribution.text,
      'React Flow diagrams provided by Molina Application Security team.'
    );
    const attributionEmail = nonEmptyString(
      descriptor.attribution.email,
      'carlos.saenz@molinahealthcare.com'
    );

    return React.createElement(
      'aside',
      { className: 'details' },
      React.createElement('h2', null, 'Diagram Inventory'),
      React.createElement(
        'div',
        { className: 'stat-grid' },
        React.createElement(
          'div',
          { className: 'stat' },
          React.createElement('strong', null, descriptor.nodes.length),
          React.createElement('span', null, 'Nodes')
        ),
        React.createElement(
          'div',
          { className: 'stat' },
          React.createElement('strong', null, descriptor.edges.length),
          React.createElement('span', null, 'Edges')
        ),
        React.createElement(
          'div',
          { className: 'stat' },
          React.createElement('strong', null, descriptor.groups.length),
          React.createElement('span', null, 'Groups')
        ),
        React.createElement(
          'div',
          { className: 'stat' },
          React.createElement('strong', null, confidenceLabel),
          React.createElement('span', null, 'Confidence')
        )
      ),
      React.createElement('h2', null, 'Assumptions'),
      assumptions.length
        ? React.createElement(
            'ul',
            null,
            assumptions.map((item, index) =>
              React.createElement('li', { key: 'assumption-' + index }, item)
            )
          )
        : React.createElement('p', null, 'None recorded.'),
      React.createElement('h2', null, 'Review Notes'),
      notes.length
        ? React.createElement(
            'ul',
            null,
            notes.map((item, index) =>
              React.createElement('li', { key: 'note-' + index }, item)
            )
          )
        : React.createElement('p', null, 'None recorded.'),
      React.createElement(
        'div',
        { className: 'details-attribution' },
        attributionText,
        attributionEmail
          ? React.createElement(
              React.Fragment,
              null,
              ' For questions or improvements please contact ',
              React.createElement(
                'a',
                { href: 'mailto:' + attributionEmail },
                attributionEmail
              ),
              '.'
            )
          : null,
        React.createElement(
          'div',
          { style: { marginTop: '8px' } },
          `Schema ${descriptor.schemaVersion} · Viewer ${VIEWER_VERSION}`
        )
      )
    );
  }

  function focusSequenceStart(instance, model) {
    const desiredZoom = model.participantCount > 7
      ? 0.58
      : model.participantCount > 5
        ? 0.68
        : 0.78;

    instance.setViewport(
      { x: 34, y: 76, zoom: desiredZoom },
      { duration: 450 }
    );
  }

  function diagramSummary() {
    const candidates = [
      descriptor.summary.ai,
      descriptor.summary.short,
      descriptor.aiSummary,
      descriptor.source.summary,
      descriptor.annotations[0] && descriptor.annotations[0].description
    ];

    const summary = candidates.find(
      value => typeof value === 'string' && value.trim()
    ) || 'Diagram generated from the JSON master descriptor.';

    return summary
      .split(/\r?\n/)
      .map(line => line.trim())
      .filter(Boolean)
      .slice(0, 3)
      .join('\n');
  }

  function App() {
    const model = useMemo(buildFlowModel, []);
    const initialNodes = useMemo(() => model.nodes, [model]);
    const initialEdges = useMemo(() => model.edges, [model]);
    const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
    const [edges, , onEdgesChange] = useEdgesState(initialEdges);
    const [error, setError] = useState(null);
    const [inventoryOpen, setInventoryOpen] = useState(false);
    const [summaryOpen, setSummaryOpen] = useState(false);
    const [layoutReady, setLayoutReady] = useState(model.mode === 'sequence');
    const [flowInstance, setFlowInstance] = useState(null);
    const layoutStartedRef = useRef(false);

    useEffect(() => {
      function onKeyDown(event) {
        if (event.repeat) return;
        if (event.ctrlKey && event.altKey && event.code === 'KeyA') {
          event.preventDefault();
          event.stopPropagation();
          setInventoryOpen(open => !open);
        }
      }

      window.addEventListener('keydown', onKeyDown, true);
      return () => window.removeEventListener('keydown', onKeyDown, true);
    }, []);

    useEffect(() => {
      if (!flowInstance) return;
      const timer = window.setTimeout(() => {
        if (model.mode === 'sequence') {
          focusSequenceStart(flowInstance, model);
        } else {
          flowInstance.fitView({
            padding: 0.18,
            duration: 300,
            maxZoom: 0.95
          });
        }
      }, 90);

      return () => window.clearTimeout(timer);
    }, [inventoryOpen, flowInstance]);

    useEffect(() => {
      if (!flowInstance || layoutStartedRef.current) return;
      layoutStartedRef.current = true;

      if (model.mode === 'sequence') {
        setNodes(initialNodes);
        window.requestAnimationFrame(() => {
          window.setTimeout(() => {
            if (flowInstance) focusSequenceStart(flowInstance, model);
          }, 180);
        });
        return;
      }

      setLayoutReady(false);
      waitForNodeMeasurements(
        flowInstance,
        initialNodes.map(node => node.id)
      )
        .then(measuredNodes => layoutGeneric(initialNodes, initialEdges, measuredNodes))
        .then(layoutedNodes => {
          setNodes(layoutedNodes);
          setLayoutReady(true);
          window.requestAnimationFrame(() => {
            window.setTimeout(() => {
              if (flowInstance) {
                flowInstance.fitView({
                  padding: 0.18,
                  duration: 450,
                  maxZoom: 0.95
                });
              }
            }, 180);
          });
        })
        .catch(err => {
          setError(err.message || String(err));
          setLayoutReady(true);
        });
    }, [flowInstance]);

    if (error) {
      return React.createElement(
        'div',
        { className: 'error' },
        'Diagram render failed:\n' + error
      );
    }

    const aiSummary = diagramSummary();
    const sourceDateMeta = descriptor.source.reviewedAt
      ? { label: 'Reviewed', value: descriptor.source.reviewedAt }
      : descriptor.source.generatedAt
        ? { label: 'Generated', value: descriptor.source.generatedAt }
        : { label: 'Date', value: 'unknown' };
    return React.createElement(
      'div',
      { className: 'shell' },
      React.createElement(
        'header',
        { className: 'header' },
        React.createElement(
          'div',
          { className: 'title-row' },
          React.createElement(
            'div',
            null,
            React.createElement('h1', null, descriptor.title)
          )
        ),
        React.createElement(
          'div',
          { className: 'meta' },
          React.createElement(
            'span',
            { className: 'pill' },
            'Source: ' + (descriptor.source.type || 'unknown')
          ),
          React.createElement(
            'span',
            { className: 'pill' },
            sourceDateMeta.label + ': ' + sourceDateMeta.value
          )
        )
      ),
      React.createElement(
        'section',
        {
          className: 'workspace' + (inventoryOpen ? ' inventory-open' : '')
        },
        React.createElement(
          'main',
          { className: 'canvas' },
          !layoutReady
            ? React.createElement(
                'div',
                { className: 'layout-loader' },
                React.createElement(
                  'div',
                  { className: 'layout-loader-card' },
                  React.createElement('span', { className: 'layout-spinner' }),
                  'Calculating diagram layout…'
                )
              )
            : null,
          React.createElement(
            'div',
            {
              className: 'canvas-stage' + (!layoutReady ? ' layout-pending' : '')
            },
            React.createElement(
              ReactFlow,
              {
                nodes,
                edges,
                nodeTypes,
                edgeTypes,
                onNodesChange,
                onEdgesChange,
                onInit: instance => {
                  setFlowInstance(instance);
                },
                fitView: model.mode !== 'sequence',
                minZoom: 0.08,
                maxZoom: 1.6
              },
              React.createElement(
                Panel,
                { position: 'top-left' },
                React.createElement(
                  'div',
                  { className: 'status' },
                  React.createElement(
                    'div',
                    { className: 'status-header' },
                    summaryOpen
                      ? React.createElement(
                          'div',
                          { className: 'status-summary' },
                          aiSummary,
                          model.mode === 'sequence'
                            ? React.createElement(
                                'div',
                                { className: 'sequence-message-hint' },
                                'Sequence view opens at readable zoom. Pan horizontally or use the minimap to inspect later participants.'
                              )
                            : null
                        )
                      : null,
                    React.createElement(
                      'button',
                      {
                        className: 'status-toggle',
                        type: 'button',
                        'aria-label': summaryOpen
                          ? 'Collapse diagram summary'
                          : 'Expand diagram summary',
                        onClick: () => setSummaryOpen(open => !open)
                      },
                      summaryOpen ? '−' : '+'
                    )
                  )
                )
              ),
              React.createElement(MiniMap, { pannable: true, zoomable: true }),
              React.createElement(Controls, null),
              React.createElement(Background, { gap: 18, size: 1 })
            )
          )
        ),
        inventoryOpen ? React.createElement(DetailsPanel, null) : null
      )
    );
  }

  window.MolinaDiagramViewer = {
    render,
    renderError,
    normalizeDescriptor,
    version: VIEWER_VERSION
  };

  const dataElement = document.getElementById('diagram-data');
  if (dataElement && dataElement.textContent.trim()) {
    render(root, readDescriptor());
  }
} catch (err) {
  showFatalError(
    'Diagram initialization failed:\n' + (err.message || String(err))
  );
}
