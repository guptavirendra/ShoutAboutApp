<#
.SYNOPSIS
    Validates the molina-diagrams skill package.
.DESCRIPTION
    Checks Agent Skills frontmatter constraints, progressive-disclosure structure,
    reference load triggers, templates, vendored assets, eval coverage, local-only
    viewer references, and lightweight JavaScript safety/syntax when Node is available.
.PARAMETER SkillPath
    Path to the skill root directory. Defaults to the parent of this script directory.
#>
[CmdletBinding()]
param(
    [Alias("skill-path")]
    [string]$SkillPath = (Split-Path $PSScriptRoot -Parent)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$script:errors = @()
$script:warnings = @()
$script:passes = @()

function Fail([string]$Message) { $script:errors += "[FAIL] $Message" }
function Warn([string]$Message) { $script:warnings += "[WARN] $Message" }
function Pass([string]$Message) { $script:passes += "[PASS] $Message" }

function Get-FrontmatterField([string]$Frontmatter, [string]$Field) {
    if ($Frontmatter -match "(?m)^$([regex]::Escape($Field)):\s*(.+)$") {
        return $Matches[1].Trim().Trim('"')
    }
    return $null
}

function Test-NoExternalReferences([string]$Path) {
    $text = Get-Content $Path -Raw -Encoding UTF8
    if ($text -match 'https?://|//cdn\.|unpkg\.com|jsdelivr\.net|cdnjs\.cloudflare\.com') {
        Fail "$(Split-Path $Path -Leaf) contains an external URL or CDN reference"
    } else {
        Pass "$(Split-Path $Path -Leaf) uses local references only"
    }
}

function Test-NodeSyntax([string]$Path) {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if (-not $node) {
        Warn "Node is not available; skipped syntax check for $(Split-Path $Path -Leaf)"
        return
    }

    $result = & node --check $Path 2>&1
    if ($LASTEXITCODE -eq 0) {
        Pass "$(Split-Path $Path -Leaf) passes node --check"
    } else {
        Fail "$(Split-Path $Path -Leaf) failed node --check: $result"
    }
}

$resolved = Resolve-Path $SkillPath -ErrorAction SilentlyContinue
if (-not $resolved) {
    Write-Error "Skill directory not found: $SkillPath"
    exit 1
}

$skillDir = $resolved.Path
$skillFile = Join-Path $skillDir "SKILL.md"
$dirName = Split-Path $skillDir -Leaf

Write-Host "`nValidating molina-diagrams skill: $skillDir`n"

if (-not (Test-Path $skillFile)) {
    Fail "SKILL.md not found"
} else {
    Pass "SKILL.md exists"
    $raw = Get-Content $skillFile -Raw -Encoding UTF8
    $lines = (Get-Content $skillFile -Encoding UTF8).Count
    $tokens = [int]($raw.Length / 4)

    $frontmatterMatch = [regex]::Match($raw, '^---[\r\n]+(.+?)[\r\n]+---', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if (-not $frontmatterMatch.Success) {
        Fail "SKILL.md does not contain YAML frontmatter delimited by ---"
    } else {
        Pass "YAML frontmatter block found"
        $frontmatter = $frontmatterMatch.Groups[1].Value

        $name = Get-FrontmatterField $frontmatter "name"
        if (-not $name) { Fail "Required field 'name' is missing" }
        elseif ($name -ne $dirName) { Fail "name '$name' does not match directory '$dirName'" }
        elseif ($name -notmatch '^[a-z0-9]([a-z0-9-]*[a-z0-9])?$' -or $name -match '--' -or $name.Length -gt 64) { Fail "name '$name' violates Agent Skills naming rules" }
        else { Pass "name field is valid and matches directory" }

        $description = Get-FrontmatterField $frontmatter "description"
        if (-not $description) { Fail "Required field 'description' is missing" }
        elseif ($description.Length -gt 1024) { Fail "description exceeds 1024 characters ($($description.Length))" }
        else { Pass "description present ($($description.Length)/1024 chars)" }

        foreach ($field in @("license", "compatibility", "metadata", "allowed-tools")) {
            if ($frontmatter -match "(?m)^$([regex]::Escape($field)):") { Pass "frontmatter.$field present" }
            else { Warn "frontmatter.$field not set" }
        }

        foreach ($metadataField in @("author", "version")) {
            if ($frontmatter -match "(?m)^\s+$([regex]::Escape($metadataField)):") { Pass "metadata.$metadataField present" }
            else { Warn "metadata.$metadataField not set" }
        }
    }

    if ($lines -le 500) { Pass "SKILL.md line count $lines is within 500-line recommendation" }
    else { Fail "SKILL.md line count $lines exceeds 500-line recommendation" }

    if ($tokens -le 5000) { Pass "Estimated token count ~$tokens is within 5000-token recommendation" }
    else { Warn "Estimated token count ~$tokens exceeds 5000-token recommendation" }

    if ($raw -match '### END NEW SECTION ###') { Fail "SKILL.md still contains stray END NEW SECTION marker" }
    else { Pass "No stray END NEW SECTION marker found" }

    if ($raw -match '## Reference files \(load on demand\)') { Pass "Reference load-trigger section present" }
    else { Fail "Reference load-trigger section missing" }
}

$referencesDir = Join-Path $skillDir "references"
$expectedReferences = @(
    "diagram-json-contract.md",
    "diagram-type-rules.md",
    "viewer-generation-and-validation.md"
)

if (-not (Test-Path $referencesDir)) {
    Fail "references/ directory missing"
} else {
    Pass "references/ directory present"
    $skillRaw = if (Test-Path $skillFile) { Get-Content $skillFile -Raw -Encoding UTF8 } else { "" }
    foreach ($reference in $expectedReferences) {
        $referencePath = Join-Path $referencesDir $reference
        if (-not (Test-Path $referencePath)) {
            Fail "Missing reference file: references/$reference"
            continue
        }

        Pass "Reference file present: references/$reference"
        if ($skillRaw -match [regex]::Escape("references/$reference")) {
            Pass "Reference load trigger found for references/$reference"
        } else {
            Fail "No SKILL.md load trigger for references/$reference"
        }
    }

    $nestedReferences = @(Get-ChildItem $referencesDir -Recurse -Directory)
    if ($nestedReferences.Count -eq 0) { Pass "No nested reference directories" }
    else { Fail "Nested reference directories are not allowed: $($nestedReferences.FullName -join ', ')" }
}

$templatesDir = Join-Path $skillDir "templates"
$assetDir = Join-Path $templatesDir "_assets"
$requiredTemplateFiles = @(
    "templates/diagram-viewer.html",
    "templates/_assets/diagram-viewer.css",
    "templates/_assets/diagram-viewer.js",
    "templates/_assets/diagram-picker.js",
    "templates/_assets/vendor/diagram-vendor.js",
    "templates/_assets/vendor/diagram-vendor.js.LEGAL.txt",
    "templates/_assets/vendor/xyflow-react.css"
)

foreach ($relativePath in $requiredTemplateFiles) {
    $fullPath = Join-Path $skillDir $relativePath
    if (Test-Path -LiteralPath $fullPath) {
        $content = Get-Content -LiteralPath $fullPath -Raw -Encoding UTF8
        if ($content.Length -gt 0) { Pass "$relativePath present and non-empty" }
        else { Fail "$relativePath is empty" }
    } else {
        Fail "Missing template asset: $relativePath"
    }
}

$htmlTemplate = Join-Path $templatesDir "diagram-viewer.html"
if (Test-Path -LiteralPath $htmlTemplate) {
    $html = Get-Content -LiteralPath $htmlTemplate -Raw -Encoding UTF8
    Test-NoExternalReferences $htmlTemplate
    if ($html -match 'window\.DIAGRAM_JSON_FILES') { Pass "diagram-viewer.html exposes DIAGRAM_JSON_FILES replacement boundary" }
    else { Fail "diagram-viewer.html missing DIAGRAM_JSON_FILES replacement boundary" }
    if ($html -match '_assets/vendor/xyflow-react\.css' -and $html -match '_assets/vendor/diagram-vendor\.js' -and $html -match '_assets/diagram-picker\.js') {
        Pass "diagram-viewer.html references required local assets"
    } else {
        Fail "diagram-viewer.html does not reference required local assets"
    }
}

$pickerJs = Join-Path $assetDir "diagram-picker.js"
$viewerJs = Join-Path $assetDir "diagram-viewer.js"
foreach ($jsPath in @($pickerJs, $viewerJs)) {
    if (Test-Path $jsPath) {
        Test-NodeSyntax $jsPath
        $js = Get-Content $jsPath -Raw -Encoding UTF8
        if ($js -match '\.innerHTML\s*=') { Fail "$(Split-Path $jsPath -Leaf) assigns innerHTML" }
        else { Pass "$(Split-Path $jsPath -Leaf) avoids innerHTML assignment" }
    }
}

if (Test-Path $pickerJs) {
    $picker = Get-Content $pickerJs -Raw -Encoding UTF8
    if ($picker -match 'json-file-input|FileReader|\.text\(' -and $picker -match 'dragover|drop') {
        Pass "diagram-picker.js retains local file input and drag/drop support"
    } else {
        Fail "diagram-picker.js must retain local JSON file input and drag/drop support"
    }
}

if (Test-Path $viewerJs) {
    $viewer = Get-Content $viewerJs -Raw -Encoding UTF8
    foreach ($requiredText in @("normalizeDescriptor", "groups", "participants", "sequenceOrder", "renderError", "textContent", "ELK")) {
        if ($viewer -match [regex]::Escape($requiredText)) { Pass "diagram-viewer.js contains $requiredText support" }
        else { Fail "diagram-viewer.js missing $requiredText support" }
    }
}

$evalsPath = Join-Path $skillDir "evals/evals.json"
if (-not (Test-Path $evalsPath)) {
    Fail "evals/evals.json missing"
} else {
    try {
        $evals = Get-Content $evalsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($evals.skill_name -eq "molina-diagrams") { Pass "evals skill_name matches molina-diagrams" }
        else { Fail "evals skill_name does not match molina-diagrams" }

        $count = @($evals.evals).Count
        if ($count -ge 3) { Pass "evals/evals.json has $count test cases" }
        else { Fail "evals/evals.json has $count test cases; expected at least 3" }

        foreach ($eval in @($evals.evals)) {
            if (-not $eval.assertions -or @($eval.assertions).Count -lt 3) {
                Fail "Eval id=$($eval.id) has fewer than 3 assertions"
            } else {
                Pass "Eval id=$($eval.id) has $(@($eval.assertions).Count) assertions"
            }
        }
    } catch {
        Fail "evals/evals.json is not valid JSON: $_"
    }
}

Write-Host "`n--- Results ---"
$script:passes | ForEach-Object { Write-Host $_ -ForegroundColor Green }
$script:warnings | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
$script:errors | ForEach-Object { Write-Host $_ -ForegroundColor Red }

Write-Host "`nSummary: $($script:passes.Count) passed, $($script:warnings.Count) warnings, $($script:errors.Count) errors"

if ($script:errors.Count -gt 0) {
    Write-Host "VALIDATION FAILED" -ForegroundColor Red
    exit 1
}

Write-Host "VALIDATION PASSED" -ForegroundColor Green
exit 0