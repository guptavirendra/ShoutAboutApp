---
name: speckit-autopilot
description: "Orchestrates full Spec-Driven Development workflow end-to-end: applies all active skills holistically across all phases, executes ralph-loop for iterative implementation, suppresses all intermediate output, and delivers a single HOTL (Human On The Loop) summary with file diffs and change counts at the end. Never pauses for human confirmation; fails forward with fallback attempts, skips unrecoverable phases, and surfaces all blockers/decisions/changes in final HOTL. Hard policy: every task request must execute through speckit-autopilot with no legacy/direct path. If routing or contract preflight fails, execution fails closed. WHEN: 'speckit', 'autopilot', 'run end to end', 'full speckit', 'HOTL', 'human on the loop', 'apply all skills', 'autonomous implementation', 'run all phases', 'speckit autopilot', 'end to end', 'speckit full workflow', '/plan', 'plan my task', 'planning mode', 'create a plan', 'run planning workflow', 'plan through speckit', 'implement this', 'fix this', 'update this file', 'run this task'."
license: MIT
compatibility: "Requires VS Code Copilot with runSubagent capability. Assumes user-level agent skills available at c:\\Users\\WeldonJo\\.agents\\skills\\. Speckit CLI optional (fallback to current branch if unavailable)."
metadata:
  author: M.AppSecAgentSkills
  version: "1.0"
  purpose: "Autonomous end-to-end Spec-Driven Development with continuous skill application and unified HOTL reporting"
allowed-tools: all
---

# Speckit Autopilot Skill

**Skills used:** speckit-autopilot

This skill orchestrates the full Spec-Driven Development workflow end-to-end using Spec Kit phases, applies all active skills holistically, runs ralph-loop for iterative implementation, suppresses intermediate output, and delivers a single Human On The Loop (HOTL) summary at the end—complete with file diffs, change counts, decisions, blockers, and next actions.

When implementation changes are present, this skill also executes publication workflow: create a new branch, commit all intended changes, push to remote, and generate pull request URL(s) with validation and verification evidence.

## Gotchas

- **Zero human checkpoints:** This skill never pauses for approval, confirmation, or input. All blockers, questions, and failures are collected and surfaced in the final HOTL summary only.
- **Fail-forward semantics:** The agent attempts reasonable fallbacks (e.g., use current branch name if speckit feature detection fails). If a fallback fails, the phase is skipped. Skipped phases are documented in HOTL.
- **Approval-gated actions:** If a tool or command requires approval, do not pause for approval. Skip that action, continue with allowed tools/commands, and record the skipped action in HOTL.
- **Ralph-loop via runSubagent:** Implementation phase uses `runSubagent` with user-level agent skills (at `c:\Users\WeldonJo\.agents\skills\`), not goose CLI. Each loop iteration gets fresh context.
- **Speckit CLI optional:** If speckit is unavailable, the skill falls back to interpreting the current Git branch name as the feature branch and uses manual phase markers instead of speckit commands.
- **HOTL is the only output:** No intermediate summaries, no per-phase status lines, no progress indicators during execution. Output begins only after all phases complete.
- **File diff accumulation:** All file changes (creates, edits, deletes) are tracked and included in HOTL with diffs, names, and change counts.
- **Publish with evidence:** If implementation produced changes, create a new branch, commit all intended changes, push, and produce PR URL(s). HOTL must include branch name, commit SHA, PR URL(s), and validation/verification results.

## When to Use This Skill

Activate when you want:
- Full spec-to-implementation workflow without interruptions.
- A single consolidated summary of everything that was decided, changed, and blocked.
- Holistic skill application across planning and implementation phases.
- Autonomous fail-forward behavior with complete audit trail in HOTL.

## Profile Skill Offer Hook

- During planning or intake contexts, check whether required skills are missing from user profile.
- If missing, invoke `/offer-copy-skills` before implementation tasks.
- Require explicit acceptance before any copy action (`yes, all`, `yes, minimal`, `yes, selective: <skill names>`, or `no`).
- Apply fail-closed checks: source validation, destination validation, collision handling, and YAML validation.
- Record offer decision and copy outcome in HOTL decisions and blockers.

Do **not** use this skill for:
- Workflows requiring interactive approval at phase boundaries.
- Exploratory/ad-hoc work (use individual prompts/skills).

## Enforcement Gateway

- All task requests are hard-gated and must be routed through speckit-autopilot before phase execution.
- Trigger detection is universal for actionable task requests (planning, implementation, edits, refactors, reviews, and docs updates).
- There is no grandfathering and no legacy/direct execution path.
- If routing or contract preflight fails, set enforcement outcome to `ERROR`, record the failure in HOTL, and fail closed.

## Enforcement Rules

Decision order is deterministic and must be applied in this sequence:
1. Task-request detection (actionable user task intent).
2. Registration and metadata check (if present on participating skills).
3. Contract preflight (`autopilot_contract_enforced=true`) before any phase execution.
4. Routing decision with explicit enforcement outcome.

Decision outcomes:
- `GATED`: Task request detected; normal flow is blocked until speckit-autopilot routing succeeds.
- `ROUTED`: Gated task was successfully routed through speckit-autopilot.
- `ERROR`: Gated task could not be routed or contract preflight failed; log blocker and maintain fail-closed behavior.

Conflict precedence:
- Active task-request detection always requires gating.
- Contract preflight failure always results in fail-closed `ERROR`.
- Registration metadata refines policy behavior but never bypasses an active gate decision.

Audit requirements:
- Record trigger type (`all-task` for actionable task requests).
- Record enforcement outcome (`GATED | ROUTED | ERROR`).
- Mirror routing visibility in both HOTL Routing Validation fields and phase status/details.

Examples:
- `GATED -> ROUTED`: "Create a plan for this new feature" routes through speckit-autopilot.
- `GATED -> ROUTED`: "Update this single file" routes through speckit-autopilot.
- `GATED -> ERROR`: "Run this task" where routing or contract preflight fails; record fail-closed impact.
- Not triggered: non-actionable conversational messages with no task intent.

## Execution Flow

0. **Route All Task Requests (Hard Gate)**
   - Detect actionable task intent for every request.
   - Evaluate registration/metadata contract when present.
   - Assert contract preflight (`autopilot_contract_enforced=true`) before phase execution.
   - Hard-gate and auto-route every task through speckit-autopilot.
   - Set and track enforcement outcome (`GATED`, `ROUTED`, or `ERROR`) in HOTL.

1. **Initialize Context**
   - Record starting branch, timestamp, and active skills at session start.
   - Create HOTL accumulator (phases, decisions, file changes, blockers, fallbacks).
   - Detect speckit availability; set fallback mode if unavailable.

2. **Speckit Constitution Phase (Optional)**
   - If speckit available: run `/speckit.constitution` to load project constitution.
   - If unavailable: skip and note in HOTL.
   - Outcome: project rules, language selection, conventions loaded (or noted as skipped).

3. **Speckit Specify Phase**
   - Apply all active skills to parse user intent, requirements, and constraints.
   - If speckit available: run `/speckit.specify` to generate initial spec document.
   - If unavailable: generate spec from user intent directly.
   - **No output** — add spec results to HOTL accumulator.

4. **Speckit Clarify Phase**
   - Apply all active skills to identify and resolve ambiguities in the spec.
   - If speckit available: run `/speckit.clarify` to refine spec.
   - If unavailable: apply skills manually to clarify.
   - **No output** — accumulate clarifications.

5. **Speckit Checklist Phase**
   - Apply all active skills to validate spec completeness and quality.
   - If speckit available: run `/speckit.checklist`.
   - If unavailable: run manual quality checks.
   - **No output** — record any gaps or validation warnings.

6. **Speckit Plan Phase**
   - Apply all active skills to create implementation plan (phases, increments, tasks).
   - If speckit available: run `/speckit.plan`.
   - If unavailable: generate plan from spec using skills.
   - **No output** — accumulate plan.

7. **Speckit Tasks Phase**
   - Apply all active skills to decompose plan into concrete tasks.
   - If speckit available: run `/speckit.tasks`.
   - If unavailable: decompose plan manually.
   - **No output** — accumulate task list.

8. **Speckit Analyze Phase**
   - Apply all active skills to verify spec/plan/task consistency.
   - If speckit available: run `/speckit.analyze`.
   - If unavailable: perform manual consistency checks.
   - If the workflow is intake/planning and required skills are missing, run the profile-offer hook via `/offer-copy-skills`.
   - **No output** — record analysis results.

9. **Ralph-Loop Implementation Phase**
   - Use `runSubagent` with user-level agents to execute ralph-loop pattern:
     - **Worker agent iteration:** Read task, write implementation code, create files, modify files.
     - **Reviewer agent feedback:** Fresh-context review of worker output, suggestions for next iteration.
     - Loop until reviewer marks "SHIP" or max iterations reached.
   - **Fail-forward:** If iteration fails, document the error and attempt next task.
   - **Track all file changes:** Record every file created, modified, deleted.
   - **No output** — accumulate all implementation artifacts and changes.

10. **Publish Phase (Branch + Commit + PR URL)**
    - Trigger condition: implementation produced file changes intended for submission.
    - Create publication branch from current HEAD using deterministic naming:
       - `autopilot/<yyyymmdd>-<task-slug>` preferred
       - fallback `autopilot/<yyyymmdd>-update`
    - Stage all intended changes and commit with traceable message including scope and workflow context.
    - Validate before PR URL generation (fail-closed for required checks):
       - run project validation commands when available (tests, lint, build)
       - capture command, status, and notable output summary in HOTL
    - Push publication branch to remote.
    - Generate PR URL(s):
       - preferred via provider CLI/API when available
       - fallback compare URL from git remote and branch refs
    - Verify publication outcomes:
       - branch exists locally and on remote
       - commit SHA resolved
       - working tree clean after commit
       - PR URL is non-empty and well-formed
    - **No output** — accumulate publication and verification evidence.

11. **HOTL Summary Generation**
    - After all phases complete (or are skipped due to failures):
      - Render HOTL from accumulator using template in `assets/hotl-summary-template.md`.
      - Include: phases completed, skills applied, key decisions, file diffs (inline or linked), file change counts, blockers/fallbacks/skipped phases, next actions.
      - Include publication evidence when Publish phase ran: branch name, commit SHA, push status, PR URL(s), validation statuses, and verification checklist results.
      - Output HOTL to user as final report.

## Failure Handling: Attempt → Skip → Accumulate

For each phase, the agent:
1. **Attempts the phase** (with speckit or fallback).
2. **If it fails, attempts a reasonable fallback** (e.g., use current branch instead of feature detection; generate plan manually instead of via speckit).
3. **If the action is approval-gated, skip that action** and continue with allowed actions in the current phase.
4. **If the fallback also fails, skip the phase** and continue to the next phase.
5. **Document fallback attempts, approval-gated skips, and phase skips** in HOTL accumulator (with reason, attempted alternative, and impact).

Example:
- Speckit constitution fails to load → fallback: load default conventions → continues to Specify phase.
- Specify phase hits API error → fallback: use prompt-based spec generation → continues to Clarify phase.
- Clarify phase fails and no fallback available → **skip Clarify, continue to Checklist** (document skip in HOTL).

## HOTL Output Contract

See [hotl-output-contract.md](references/hotl-output-contract.md) for detailed schema.

**Minimum required fields in HOTL:**
- **Execution timestamp** (when the skill ran)
- **Active skills applied** (list of all skills used, and in which phases)
- **Phases completed** (✓ or ✗ for each of 8 phases)
- **Phases skipped** (with reasons)
- **Routing validation** (`task_request_detected`, `routed_through_speckit`, `legacy_path_blocked`, `enforcement_outcome`)
- **Contract conformance** (`autopilot_contract_enforced`, `intermediate_output_suppressed`, `contract_violations_count`)
- **Fallback attempts** (which phases used fallbacks, outcomes)
- **Approval-required actions** (requested action, phase, why approval was required, fallback attempted, residual impact)
- **Key decisions made** (major plan/task/implementation choices)
- **File changes** (table: filename, action [create/edit/delete], line count/delta, inline diff or link to diff)
- **File change summary** (N files created, M files edited, K files deleted)
- **Publication summary** (branch, commit, push result, PR URL(s)) when Publish phase ran
- **Validation and verification results** (tests/lint/build status and publication verification checklist) when Publish phase ran
- **Blockers** (unresolved issues, missing context, API failures—everything that prevented full completion)
- **Next actions** (recommended next steps for human review)

## Skill Registration Contract

Skills that require orchestration through speckit-autopilot may declare an optional registration marker and metadata contract.

Optional marker file:
- `.speckit-orchestrated`

Frontmatter contract example:

```yaml
metadata:
   orchestrated: true
   orchestration_required: true
   gateway_enforced: true
```

Field definitions:
- `orchestrated`: Skill is designed to run under orchestration.
- `orchestration_required`: Skill should not run standalone when orchestration is required.
- `gateway_enforced`: Skill participates in hard-gate evaluation for all actionable task requests.

Registration metadata is consumed during Enforcement Rules evaluation and cannot override a gate decision by itself.

## Skill Application: Holistic Directive

The agent applies all active skills in the current session **holistically** at each phase. For example:
- **Specify phase:** Apply `nist-ssdf`, `nist-218a`, `owasp-genai-security`, `molina-application-security` skills to spec content to ensure compliance.
- **Plan phase:** Apply same skills to validate plan against frameworks.
- **Implement phase:** Apply skills to review code as it's written.

Do not invoke skills sequentially; rather, reason using all relevant active skills' knowledge when processing each phase. The agent's judgment on *which* skills to apply varies per phase context.

When a skill includes the registration metadata contract, include that metadata in the routing evaluation path before phase execution.

## When to Load Reference Files

Load `references/speckit-workflow.md` if you need detailed explanation of each speckit phase and CLI commands.

Load `references/hotl-output-contract.md` if you need to understand the full HOTL schema and field definitions.

## Execution Checklist (for the agent)

- [ ] Record starting branch and timestamp
- [ ] Initialize HOTL accumulator (empty dict/object for phases, decisions, changes, blockers)
- [ ] Assert `autopilot_contract_enforced=true` before phase execution
- [ ] Assert `intermediate_output_suppressed=true` before phase execution
- [ ] Initialize `contract_violations_count=0`
- [ ] Detect speckit availability; set fallback mode if needed
- [ ] Run phases 1–8 in sequence; for each: attempt → fallback → skip if needed
- [ ] Track all file I/O (create, edit, delete)
- [ ] Apply all active skills at each phase (holistically, not sequentially)
- [ ] If a tool/command is approval-gated, skip and continue with allowed actions
- [ ] If implementation changed files, run Publish phase: create branch, commit, validate, push, generate PR URL(s)
- [ ] Verify publication outcomes and capture evidence in HOTL
- [ ] Never output intermediate results or ask for confirmation
- [ ] Accumulate all results in HOTL accumulator
- [ ] Record any contract violation and increment `contract_violations_count`
- [ ] After all phases: render and output final HOTL using template
- [ ] If any phase fails with no fallback: document in HOTL and continue (unless implementation phase, then may halt)

---

## Output Template

Use [assets/hotl-summary-template.md](assets/hotl-summary-template.md) to render final HOTL. Fill in all sections with accumulated data.

---

**Example Trigger Phrases**

- "Run speckit autopilot on this project"
- "Apply all my skills and give me a HOTL summary at the end"
- "Full speckit workflow end to end"
- "Autonomous implementation with HOTL"
- "Speckit autopilot: plan and implement everything"
