# HOTL Output Contract

This document defines the complete schema for the Human On The Loop (HOTL) summary produced by speckit-autopilot after all phases complete.

## HOTL Summary Schema

```
HOTL Summary: [Project/Task Name]
═════════════════════════════════════════════

Execution Details
─────────────────
Timestamp:        [ISO 8601 datetime when execution started]
Duration:         [Elapsed time in seconds]
Starting Branch:  [Git branch name]
Ending Branch:    [Git branch name, may differ if implementation committed]

Phases Executed
─────────────────
✓ Constitution    [PASS / SKIP (reason) / ERROR (reason)]
✓ Specify         [PASS / SKIP / ERROR]
✓ Clarify         [PASS / SKIP / ERROR]
✓ Checklist       [PASS / CONDITIONAL (gaps) / FAIL / SKIP / ERROR]
✓ Plan            [PASS / SKIP / ERROR]
✓ Tasks           [PASS / SKIP / ERROR]
✓ Analyze         [PASS / GAPS / CONFLICTS / SKIP / ERROR]
✓ Implement       [PASS / PARTIAL (N% complete) / FAIL / SKIP / ERROR]
✓ Publish         [PASS / SKIP (no changes) / ERROR]

Routing Validation
──────────────────
task_request_detected:    [true/false]   # Actionable task request detected
routed_through_speckit:   [true/false]   # Request routed via hard gate
legacy_path_blocked:      [true/false]   # Must be true under hard no-legacy policy
enforcement_outcome:      [GATED | ROUTED | ERROR]

Contract Conformance
────────────────────
autopilot_contract_enforced:    [true/false]   # Contract preflight asserted before phase execution
intermediate_output_suppressed: [true/false]   # No non-HOTL run output emitted during execution
contract_violations_count:      [integer]      # Number of contract violations observed

Phase Routing Visibility
────────────────────────
- Analyze details: [must include routing decision summary when routing validation is active]
- Implement details: [must include final enforcement outcome and any fallback/error context]

Publication Summary
───────────────────
publication_branch:      [branch name used for publishing]
publication_commit_sha:  [full or short SHA]
publication_push_status: [PASS / FAIL / SKIP]
pull_request_urls:
  - [url 1]
  - [url 2 optional]

Validation Results
──────────────────
validation_tests: [PASS / FAIL / NOT_RUN]
validation_lint:  [PASS / FAIL / NOT_RUN]
validation_build: [PASS / FAIL / NOT_RUN]

Verification Checklist
──────────────────────
verify_branch_local:      [true/false]
verify_branch_remote:     [true/false]
verify_commit_resolved:   [true/false]
verify_worktree_clean:    [true/false]
verify_pr_url_generated:  [true/false]

Skills Applied
───────────────
[Skill Name 1]
  - Phases: Specify, Clarify, Plan, Implement
  - Key contributions: [brief description]

[Skill Name 2]
  - Phases: Checklist, Analyze
  - Key contributions: [brief description]

[etc.]

Key Decisions & Outcomes
─────────────────────────
• [Decision 1]: [outcome/rationale]
• [Decision 2]: [outcome/rationale]
• [etc.]

Fallbacks & Workarounds
────────────────────────
[FALLBACK] Constitution phase: Skipped (speckit CLI unavailable) → used default conventions
[FALLBACK] Specify phase: Ran manual skill-based extraction (speckit unavailable)
[etc.]

Approval-Required Actions (Skipped/Deferred)
───────────────────────────────────
[APPROVAL] [Action] in [Phase] required approval → skipped per autopilot policy
  - Reason approval was required: [reason]
  - Fallback attempted: [fallback or none]
  - Residual impact: [impact]
[DEFERRED] Profile skill copy offer in Analyze required user approval and no response was available
  - Reason approval was required: Copy to user profile requires explicit acceptance before write/overwrite
  - Fallback attempted: Continued workflow without copy
  - Residual impact: Profile skill availability remains pending manual approval
[etc.]

Blockers & Open Questions
──────────────────────────
[BLOCKER] Azure Key Vault access failed; secrets not available for implementation → documented in secrets section, manual review needed
[QUESTION] OAuth flow decision deferred; needs security team approval
[etc.]

File Changes Summary
──────────────────────
Total Files Changed:  12
  - Created:   5 files (+342 lines)
  - Modified:  6 files (+89 lines, -23 lines)
  - Deleted:   1 file (-45 lines)

File Change Details
────────────────────
| File Path | Action | Delta | Notes |
|-----------|--------|-------|-------|
| src/auth.ts | CREATE | +45 lines | OAuth flow implementation |
| src/config.ts | EDIT | +12, -5 lines | Environment variable handling |
| tests/auth.test.ts | CREATE | +78 lines | Full test coverage |
| docs/DESIGN.md | EDIT | +32, -8 lines | Updated OAuth design section |
| [etc.] | | | |

File Diffs (Inline)
────────────────────
**src/auth.ts** (NEW)
\`\`\`typescript
+export async function authenticateUser(credentials) {
+  // OAuth 2.0 PKCE flow
+  const state = generateState();
+  const codeChallenge = createCodeChallenge();
+  // ... full implementation
+}
\`\`\`

**src/config.ts** (MODIFIED)
\`\`\`diff
  export const config = {
    apiUrl: process.env.API_URL,
-   apiKey: process.env.API_KEY,
+   oauth: {
+     clientId: process.env.OAUTH_CLIENT_ID,
+     redirectUri: process.env.OAUTH_REDIRECT_URI,
+   },
  };
\`\`\`

[etc.]

Next Actions (Recommended)
───────────────────────────
1. **Human Review Required**
   - [ ] Review OAuth implementation for security compliance (P2D-08 gate)
   - [ ] Verify test coverage meets NIST SSDF PS.2 requirements
   - [ ] Approve scope changes vs. original spec

2. **Follow-up Work**
   - [ ] Resolve Azure Key Vault blocker (manual secrets injection needed)
   - [ ] Security team review for OAuth last-mile validation
   - [ ] Performance benchmarking for new auth flow

3. **Verification Checklist**
   - [ ] All tests pass
   - [ ] No console.log() or debug statements in production code
   - [ ] SBOM generated and scanned for supply chain risks
   - [ ] Code scan clean (SonarQube, Wiz, etc.)
  - [ ] Branch/commit/push/PR URL publication evidence reviewed

Execution Log (Errors/Warnings)
───────────────────────────────
[WARN] Phase Clarify: 3 ambiguities resolved by assuming defaults; security team should review
[ERROR] Phase Implement: runSubagent iteration 2 failed with timeout; resumed with fallback
[INFO] All fallbacks successful; no unrecoverable failures
```

---

## Field Definitions

| Field | Required | Type | Notes |
|-------|----------|------|-------|
| **Timestamp** | Yes | ISO 8601 | When execution began |
| **Duration** | Yes | Seconds | Total elapsed time |
| **Starting Branch** | Yes | String | Git branch at start |
| **Ending Branch** | Yes | String | Git branch at end (may differ if commits made) |
| **Phases Executed** | Yes | Status list | Each phase: PASS/SKIP/ERROR with reason |
| **Publish Phase Status** | Yes | Status | Must report PASS/SKIP/ERROR for branch/commit/push/PR publication step |
| **task_request_detected** | Yes | Boolean | True when actionable task intent is detected |
| **routed_through_speckit** | Yes | Boolean | True when hard-gated task successfully routed through speckit-autopilot |
| **legacy_path_blocked** | Yes | Boolean | Must be true when hard policy blocks all legacy/direct execution paths |
| **enforcement_outcome** | Yes | Enum | Must be one of `GATED`, `ROUTED`, `ERROR` |
| **autopilot_contract_enforced** | Yes | Boolean | Must be true before phase execution begins |
| **intermediate_output_suppressed** | Yes | Boolean | Must be true for policy-conformant HOTL-only execution |
| **contract_violations_count** | Yes | Integer | Number of policy violations recorded during execution |
| **Skills Applied** | Yes | List | All skills used, plus phases applied + contributions |
| **Key Decisions** | Yes | Bullet list | Major decisions made across all phases |
| **Fallbacks & Workarounds** | Yes | Marked list | Every fallback attempt with [FALLBACK] tag and outcome |
| **Approval-Required Actions** | Yes | Marked list | Every approval-gated action skipped or deferred, with phase, reason, fallback, and impact |
| **Blockers & Open Questions** | Yes | Marked list | All [BLOCKER] and [QUESTION] entries |
| **File Changes Summary** | Yes | Counts | Total created/modified/deleted, line deltas |
| **File Change Details** | Yes | Table | Filename, action, delta, notes for each file |
| **File Diffs** | Yes | Inline code blocks or linked | Full diffs for created/modified files (inline if <100 lines each; linked if larger) |
| **Next Actions** | Yes | Categorized list | Human review required, follow-up work, verification checklist |
| **Execution Log** | Yes | Marked entries | [WARN] / [ERROR] / [INFO] for all significant events during execution |
| **Phase Routing Visibility** | Yes | Text in phase details | Analyze/Implement details must mirror routing decision and enforcement outcome |
| **Publication Summary** | Conditional | Structured fields | Required when implementation produces publishable changes |
| **Validation Results** | Conditional | Structured fields | Required when Publish phase runs; tests/lint/build status |
| **Verification Checklist** | Conditional | Boolean fields | Required when Publish phase runs; publication integrity checks |

Enforcement notes:
- If `autopilot_contract_enforced=false`, then `enforcement_outcome` must be `ERROR` and phase execution must not begin.
- If `contract_violations_count > 0`, each violation must appear in both Execution Log and Blockers sections.
- If Publish phase is `PASS`, then `publication_branch`, `publication_commit_sha`, and at least one `pull_request_urls` entry are required.
- If Publish phase is `SKIP (no changes)`, publication and validation fields may be omitted.

---

## Compliance with Molina AppSec Program

If running in a Molina AppSec context (PRE, P2D, P2B gates):

**Additional HOTL Fields:**

```
Molina AppSec Gate Mapping
──────────────────────────
PRE Readiness:  [READY / CONDITIONAL / NOT_READY]
  - RITM Ticket:  [RITM123456 or N/A]
  - Gate Blockers: [list]

P2D Readiness:  [READY / CONDITIONAL / NOT_READY]
  - Controls Checked: [SSDF PO, PO.2.1, PO.3.2; 218A PW.5; OWASP LLM03]
  - Findings:       [list of control gaps, if any]
  - Evidence Link:  [SharePoint or repo path]

P2B Readiness:  [READY / CONDITIONAL / NOT_READY]
  - Controls Checked: [PS.2, PS.3, PS.4; supply chain; secrets management]
  - Findings:       [list]
  - Evidence Link:  [etc.]

Exception Tracking
──────────────────
Exceptions Proposed:  [N] (if any)
  - Exception 1: [control], [justification], [RITM link]
  - Exception 2: [etc.]

Audit Trail
───────────
Reviewer:           [agent name / GitHub user]
Verification Date:  [ISO 8601]
Gate Status:        [PASS / CONDITIONAL / FAIL]
```

---

## Loading This File

Load `references/hotl-output-contract.md` when you need to:
- Verify the HOTL summary includes all required fields.
- Understand the exact format expected for file diffs and blockers.
- Adapt HOTL schema for Molina AppSec compliance.
- Debug HOTL generation if fields are missing or incorrectly formatted.
