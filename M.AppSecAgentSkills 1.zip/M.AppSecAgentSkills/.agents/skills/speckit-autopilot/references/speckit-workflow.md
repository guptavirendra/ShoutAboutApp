# Speckit Workflow Reference

This document details all 9 Spec-Driven Development phases in the full Spec Kit workflow, their purpose, inputs, outputs, and how speckit-autopilot executes each.

## Full Production Path (9 Phases)

```
/speckit.constitution 
  ↓
/speckit.specify 
  ↓
/speckit.clarify 
  ↓
/speckit.checklist 
  ↓
/speckit.plan 
  ↓
/speckit.tasks 
  ↓
/speckit.analyze 
  ↓
/speckit.converge
  ↓
/speckit.implement
```

## Lean Path (4 Phases)

```
/speckit.specify 
  ↓
/speckit.plan 
  ↓
/speckit.tasks 
  ↓
/speckit.implement
```

Lean path intentionally skips constitution, clarify, checklist, analyze, and converge for fast-turn execution. Full workflow requires all 9 phases.

---

## Phase 1: Constitution

**Purpose:** Load project conventions, language choice, coding standards, and governance rules.

**Input:** User project folder with `speckit.yml` or similar project constitution file.

**CLI Command:** `/speckit.constitution`

**Fallback (if speckit unavailable):** Skip and note in HOTL. Use sensible defaults (e.g., project root language, common conventions).

**Output:** Loaded constitution rules (or noted as skipped).

**In HOTL:** 
- Whether constitution loaded successfully or skipped
- If skipped, reason and fallback applied

---

## Phase 2: Specify

**Purpose:** Parse user intent, requirements, constraints, and generate initial specification document.

**Input:** User prompt/issue/epic describing the work to be done.

**CLI Command:** `/speckit.specify`

**Fallback (if speckit unavailable):** Apply all active skills to extract spec from user intent directly; generate spec markdown manually.

**Output:** Spec document (requirements, constraints, acceptance criteria, non-functional requirements).

**In HOTL:** 
- Key requirements identified
- Major constraints or risks identified
- Number of acceptance criteria

---

## Phase 3: Clarify

**Purpose:** Identify and resolve ambiguities, gaps, and conflicts in the spec. Refine requirements.

**Input:** Spec document from Phase 2.

**CLI Command:** `/speckit.clarify`

**Fallback (if speckit unavailable):** Apply all active skills to perform manual clarification; document assumptions made.

**Output:** Refined spec with ambiguities resolved.

**In HOTL:** 
- Number of ambiguities resolved
- Assumptions documented
- Any unresolved conflicts or open questions

---

## Phase 4: Checklist

**Purpose:** Validate spec completeness, quality, and readiness for planning. Check against frameworks (SSDF, 218A, security, compliance).

**Input:** Refined spec from Phase 3.

**CLI Command:** `/speckit.checklist`

**Fallback (if speckit unavailable):** Apply all active skills to perform manual quality checks; document gaps found.

**Output:** Quality validation report with pass/fail/conditional status.

**In HOTL:** 
- Validation status (PASS / CONDITIONAL / FAIL)
- Critical gaps (if any)
- Frameworks checked (SSDF, 218A, OWASP, etc.)

---

## Phase 5: Plan

**Purpose:** Create implementation plan with phases, increments, milestones, and task groupings.

**Input:** Validated spec from Phase 4.

**CLI Command:** `/speckit.plan`

**Fallback (if speckit unavailable):** Apply all active skills to decompose spec into plan manually; structure by phases and increments.

**Output:** Implementation plan document (phases, tasks per phase, dependencies, effort estimates if applicable).

**In HOTL:** 
- Number of phases in plan
- Total tasks
- Critical path (if identified)
- Major milestones

---

## Phase 6: Tasks

**Purpose:** Decompose plan into concrete, actionable tasks with acceptance criteria.

**Input:** Plan from Phase 5.

**CLI Command:** `/speckit.tasks`

**Fallback (if speckit unavailable):** Apply all active skills to generate task list; attach acceptance criteria and effort to each.

**Output:** Task list with IDs, descriptions, acceptance criteria, effort, dependencies.

**In HOTL:** 
- Total task count
- Range of task sizes (small/medium/large)
- Any blocked or high-risk tasks identified

---

## Phase 7: Analyze

**Purpose:** Verify consistency between spec, plan, and tasks. Identify gaps, over-scoping, or conflicts.

**Input:** Spec (Phase 4), Plan (Phase 5), Tasks (Phase 6).

**CLI Command:** `/speckit.analyze`

**Fallback (if speckit unavailable):** Apply all active skills to perform manual consistency review; document any cross-phase conflicts.

**Output:** Consistency analysis report; gaps or conflicts identified (if any).

**In HOTL:** 
- Consistency status (CONSISTENT / GAPS FOUND / CONFLICTS)
- Any gaps between spec and plan
- Any conflicts between plan and tasks
- Recommendations for remediation

---

## Phase 8: Converge

**Purpose:** Consolidate analyze findings into final, implementable task scope and resolve residual alignment issues before implementation.

**Input:** Analyze output from Phase 7 plus tasks from Phase 6.

**CLI Command:** `/speckit.converge`

**Fallback (if speckit unavailable):** Apply all active skills to perform manual convergence and produce a final execution-ready scope.

**Output:** Converged execution scope with unresolved items explicitly tagged for HOTL blockers or deferred actions.

**In HOTL:**
- Convergence status (PASS / PARTIAL / GAPS / SKIP / ERROR)
- Residual gaps carried into Implement phase
- Any deferred decisions preserved for human review

---

## Phase 9: Implement

**Purpose:** Execute ralph-loop pattern: iterate worker (write code) and reviewer (fresh-context feedback) until complete.

**Input:** Tasks from Phase 6, convergence output from Phase 8; spec and plan as reference.

**CLI Command:** `/speckit.implement` (when available)

**Execution:** 
- Use `runSubagent` with user-level agents (at `c:\Users\WeldonJo\.agents\skills\`).
- Worker agent: reads task, writes code, creates/modifies files.
- Reviewer agent: fresh context, reviews worker output, suggests improvements.
- Loop: worker → reviewer → feedback → worker (next iteration) until reviewer marks "SHIP" or max iterations reached.

**Fallback:** If runSubagent fails, attempt direct implementation without loop; document and continue.

**Output:** Implemented code, all files created/modified/deleted.

**In HOTL:** 
- All file changes (create/edit/delete)
- File diffs (inline or linked)
- File change count summary (N created, M edited, K deleted)
- Ralph-loop iterations per task
- Any fallbacks used during implementation

---

## File Change Tracking

Throughout all phases, track:
- Every file created (path, initial size)
- Every file modified (path, lines added/removed, diff)
- Every file deleted (path, reason)

Accumulate into a file change log and include full diffs in final HOTL.

---

## Enforcement Invariants (All Phases)

Every phase in the orchestration MUST satisfy these invariants. Violation of these invariants results in contract violations and is documented in HOTL with [VIOLATION] markers.

**Mandatory invariants for phases 1-9:**
1. **No pause points:** Phase execution must never pause, wait for user input, or prompt for confirmation. All decisions are autonomous.
2. **No intermediate output:** Phase execution emits ZERO output. All phase content (specs, plans, decisions) is accumulated internally and rendered ONLY in HOTL.
3. **Fallback-only branching:** If phase attempt fails, attempt fallback. If fallback fails, skip phase. No user prompts at decision points.
4. **Autonomous approval handling:** If an action is approval-gated (e.g., profile skill copy), skip that action and continue with allowed actions. Do NOT pause for approval.
5. **Error accumulation:** All errors, warnings, fallbacks, and skips are accumulated in HOTL accumulator. Never stop execution due to error unless phase is implementation phase and completely unrecoverable.

**Phase 9 (Implement) specific invariants:**
1. Ralph-loop iterations are fully internal; no per-iteration output.
2. Each worker/reviewer cycle completes internally with changes tracked.
3. Only final implementation state (all files changed across all iterations) is rendered in HOTL file changes section.
4. If an iteration fails, document error and attempt next iteration or task (fail-forward).

**Example violations:**
- "Phase Specify in progress..." emitted during execution = VIOLATION
- Pausing to ask user "Which path?" during fallback branching = VIOLATION
- Rendering ralph-loop iteration 1 diff mid-run = VIOLATION
- Prompting for approval instead of skipping and deferring to HOTL = VIOLATION

## Speckit CLI Not Available: Fallback Chain

If the speckit CLI is unavailable or fails:

1. **Constitution phase:** Skip, use default conventions.
2. **Specify phase:** Use skill-based spec extraction from user intent.
3. **Clarify phase:** Use skill-based manual clarification.
4. **Checklist phase:** Use skill-based quality checks (reference SSDF, 218A, OWASP frameworks directly).
5. **Plan phase:** Use skill-based decomposition into phases/tasks.
6. **Tasks phase:** Use skill-based task ID generation and criteria definition.
7. **Analyze phase:** Use skill-based consistency review.
8. **Converge phase:** Use skill-based scope convergence before implementation.
9. **Implement phase:** Use runSubagent if available; if not, halt and report in HOTL.

All fallback uses are documented in HOTL with clear markers (**[FALLBACK]**).

---

## Load Triggers

Load this file when you need to:
- Understand what each speckit phase does.
- Clarify CLI commands for speckit integration.
- Reference fallback options for unavailable phases.
- Review file change tracking conventions.
