# HOTL Summary Template

Use this template to render the final HOTL summary after all speckit-autopilot phases complete. Fill in all sections with accumulated data from execution.

---

```markdown
# HOTL Summary: [Project/Task Name]

**Execution Details**

| Field | Value |
|-------|-------|
| Timestamp | [ISO 8601 datetime] |
| Duration | [MM:SS] |
| Starting Branch | [branch name] |
| Ending Branch | [branch name] |
| Total Files Changed | [N] |

---

## Phases Executed

| Phase | Status | Details |
|-------|--------|---------|
| Constitution | ✓ PASS / SKIP / ERROR | [brief outcome] |
| Specify | ✓ PASS / SKIP / ERROR | [brief outcome] |
| Clarify | ✓ PASS / SKIP / ERROR | [brief outcome] |
| Checklist | ✓ PASS / CONDITIONAL / FAIL / SKIP / ERROR | [brief outcome] |
| Plan | ✓ PASS / SKIP / ERROR | [brief outcome] |
| Tasks | ✓ PASS / SKIP / ERROR | [brief outcome] |
| Analyze | ✓ PASS / GAPS / CONFLICTS / SKIP / ERROR | [brief outcome; include routing decision summary when applicable] |
| Implement | ✓ PASS / PARTIAL / FAIL / SKIP / ERROR | [brief outcome; include final enforcement outcome when applicable] |
| Publish | ✓ PASS / SKIP (no changes) / ERROR | [branch/commit/push/PR URL outcome] |

---

## Routing Validation

| Field | Value | Notes |
|-------|-------|-------|
| task_request_detected | [true/false] | True if actionable task request intent was detected |
| routed_through_speckit | [true/false] | True if hard-gated task was routed through speckit-autopilot |
| legacy_path_blocked | [true/false] | Must be true under hard no-legacy policy |
| enforcement_outcome | [GATED / ROUTED / ERROR] | Final routing outcome |

### Contract Conformance

| Field | Value | Notes |
|-------|-------|-------|
| autopilot_contract_enforced | [true/false] | Must be true before phase execution |
| intermediate_output_suppressed | [true/false] | Must be true for HOTL-only run behavior |
| contract_violations_count | [integer] | Count of policy violations recorded |

Routing notes:
- Include trigger classification (`all-task`) for actionable task requests.
- Confirm no legacy/direct execution path was used.
- If `ERROR`, include fail-closed impact and blocker reference.

Contract violation notes:
- If `contract_violations_count > 0`, include each violation in Execution Log and Blockers with impact and mitigation.

---

## Publication Summary

| Field | Value | Notes |
|-------|-------|-------|
| publication_branch | [branch name] | Branch created for publish step |
| publication_commit_sha | [sha] | Commit containing implementation changes |
| publication_push_status | [PASS / FAIL / SKIP] | Push result |
| pull_request_urls | [url list] | One or more PR URLs |

If Publish phase was SKIP (no changes): *No publication action required.*

### Validation Results

| Check | Status | Notes |
|-------|--------|-------|
| Tests | [PASS / FAIL / NOT_RUN] | [command or reason] |
| Lint | [PASS / FAIL / NOT_RUN] | [command or reason] |
| Build | [PASS / FAIL / NOT_RUN] | [command or reason] |

### Verification Checklist

| Verification Item | Result |
|-------------------|--------|
| Branch exists locally | [true/false] |
| Branch exists on remote | [true/false] |
| Commit SHA resolves | [true/false] |
| Working tree clean after commit | [true/false] |
| PR URL generated | [true/false] |

---

## Skills Applied

- **[Skill Name 1]** (Phases: Specify, Clarify, Plan)
  - Key contribution: [what the skill added to these phases]
  
- **[Skill Name 2]** (Phases: Checklist, Analyze, Implement)
  - Key contribution: [what the skill added to these phases]

- **[etc.]**

---

## Key Decisions & Outcomes

- [Decision 1]: [outcome/rationale]
- [Decision 2]: [outcome/rationale]
- [Decision 3]: [outcome/rationale]

---

## Fallbacks & Workarounds Applied

- **[FALLBACK]** [Phase name]: [original attempt] → [fallback action] → [outcome]
- **[FALLBACK]** [etc.]

If no fallbacks: *No fallbacks required; all phases succeeded on first attempt.*

---

## Approval-Required Actions (Skipped/Deferred)

| Requested Action | Phase | Approval Reason | Fallback Attempted | Residual Impact |
|------------------|-------|-----------------|--------------------|-----------------|
| [action] | [phase] | [why approval was required] | [fallback or none] | [impact] |
| Profile skill copy offer (`yes, all|minimal|selective|no`) | Analyze | Copy to profile requires explicit acceptance before write/overwrite | Continued workflow without copy | Profile skill availability remains pending manual approval |

If none: *No approval-required actions were encountered.*

---

## Blockers & Open Questions

- **[BLOCKER]** [blocker description] → [impact] → [mitigation or next steps]
- **[QUESTION]** [open question] → [recommended resolution]

If no blockers: *No blockers encountered.*

---

## File Changes Summary

- **Created**: N files (+M lines)
- **Modified**: P files (+Q lines, -R lines)
- **Deleted**: S files (-T lines)

**Total Delta**: +[net lines] lines

---

## File Change Details

| File Path | Action | Delta | Notes |
|-----------|--------|-------|-------|
| src/file1.ts | CREATE | +45 lines | Core implementation |
| src/file2.ts | EDIT | +10, -5 lines | Refactored config handling |
| tests/file1.test.ts | CREATE | +78 lines | Full test coverage |
| docs/DESIGN.md | EDIT | +25, -8 lines | Updated design doc |
| old-file.js | DELETE | -42 lines | Deprecated module |

---

## File Diffs

### src/file1.ts (NEW)

\`\`\`typescript
[full file content or key excerpt]
\`\`\`

### src/file2.ts (MODIFIED)

\`\`\`diff
[diff showing lines added/removed]
\`\`\`

### tests/file1.test.ts (NEW)

\`\`\`typescript
[full test file or key excerpts]
\`\`\`

---

## Next Actions (Recommended for Human Review)

### 1. Review Required

- [ ] Review [specific area] for [compliance/security/correctness] against [framework]
- [ ] Verify acceptance criteria from Phase 6 Tasks are met
- [ ] Approve scope changes vs. original spec (if any)

### 2. Follow-up Work

- [ ] [Task 1 description]
- [ ] [Task 2 description]

### 3. Verification Checklist

- [ ] All automated tests pass
- [ ] Code scan clean (SonarQube / Wiz / other)
- [ ] Security review complete
- [ ] SBOM generated and reviewed
- [ ] Documentation up to date
- [ ] Publication branch/commit/PR URL evidence verified

---

## Execution Log (Errors, Warnings, Info)

- **[INFO]** Phase Constitution: Loaded default conventions (speckit CLI unavailable)
- **[WARN]** Phase Clarify: 2 ambiguities assumed without confirmation; security review recommended
- **[ERROR]** Phase Implement: runSubagent iteration 1 timeout → retried with extended context window
- **[INFO]** Phase Implement: Ralph-loop converged after 3 iterations
- **[INFO]** Execution completed successfully; all critical phases passed

---

**Generated by:** speckit-autopilot skill  
**Framework Versions:** Speckit (if available), SSDF v1.1, 218A v1.0  
**Review Date:** [leave blank for human to fill]  
**Reviewer:** [leave blank for human to fill]

```

---

## Template Usage

1. Copy this template markdown into HOTL rendering.
2. Fill in all bracketed fields with actual accumulated execution data.
3. For file diffs: if total diff size < 5KB, include inline; otherwise, link to diff file in repo.
4. For phases: use exact status values (PASS, SKIP, ERROR, PARTIAL, etc.).
5. For skills: list only those that were actually applied (not all available skills).
6. Ensure all sections are completed before outputting to user.

## Molina AppSec Extension

If in Molina AppSec context, add this section after "File Diffs":

```markdown
---

## Molina AppSec Program Alignment

**PRE Gate Assessment**
- Status: [READY / CONDITIONAL / NOT_READY]
- RITM Ticket: [link or N/A]
- Blockers: [list]

**P2D Gate Assessment**
- Status: [READY / CONDITIONAL / NOT_READY]
- Controls Verified: [list of control IDs]
- Gaps Found: [if any]
- Evidence Location: [SharePoint link or repo path]

**P2B Gate Assessment**
- Status: [READY / CONDITIONAL / NOT_READY]
- Controls Verified: [list]
- Gaps Found: [if any]
- Evidence Location: [etc.]

**Exception Proposals** (if applicable)
- [Control ID]: [justification], RITM: [link]

**Audit Trail**
- Reviewer: [agent / team]
- Verification Date: [date]
- Gate Status: [PASS / CONDITIONAL / FAIL]

```
