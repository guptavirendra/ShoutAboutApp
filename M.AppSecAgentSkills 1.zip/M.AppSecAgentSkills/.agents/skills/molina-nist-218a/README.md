# NIST 218A

This folder contains resources and templates for NIST 218A compliance, including mapping to SSDF and SWEBOK.

## Key Components
- Security requirements
- Risk management
- Compliance checklists

Refer to [NIST 218A](https://csrc.nist.gov/publications/detail/sp/800-218/final) for more information.
