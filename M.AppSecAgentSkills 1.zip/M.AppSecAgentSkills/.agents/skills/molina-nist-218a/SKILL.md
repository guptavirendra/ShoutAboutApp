---
name: molina-nist-218a
license: MIT
description: "Molina-aligned NIST SP 800-218A secure development practices for generative AI, foundation models, training data protection, and AI pipeline security with SonarQube/Wiz tool integration. WHEN: \"218A\", \"LLM development\", \"foundation models\", \"training data\", \"model weights\", \"AI pipelines\", \"data poisoning\", \"model poisoning\", \"AI security\", \"Molina AI\"."
allowed-tools: Read
compatibility: "Designed for Claude Code. Requires access to AI project artifacts, training data manifests, and model provenance records."
metadata:
  author: peaceful-robot
  version: "1.1"
---

# NIST 218A (Secure Software Development Practices for Generative AI)

NIST SP 800-218A extends SSDF to cover AI-specific secure development: training data integrity, model protection, AI vulnerability management, and monitoring of model inputs/outputs. It emphasizes shared responsibility among AI model producers, system producers, and acquirers, with recommendations for AI model architectures, training techniques, and automated toolchains to mitigate risks at scale.

## Automation profile (merged from legacy ai-security-218a)

Use this profile when the request is focused on AI model validation and evidence generation.

- Validate training data integrity and provenance.
- Assess model protection controls and release integrity.
- Plan adversarial testing and model card evidence.

Suggested invocation pattern:
- `--model-path PATH --checks data,protection,adversarial`

See [ai-automation-playbook.md](references/ai-automation-playbook.md) for AI threat categories, ML platform integrations, evidence artifact requirements, and testing tool list.

## Gotchas

- **218A supplements SSDF, it does not replace it.** Always apply both frameworks for AI projects. 218A adds AI-specific tasks on top of the SSDF baseline.
- **Inference-only ≠ model development scope.** Applications that only call an external LLM API (no training, fine-tuning, or weight storage) have a much lighter 218A footprint. Confirm scope before applying all controls.
- **Training data provenance cannot be retroactively established.** If provenance records don't exist, the gap must be documented and risk-accepted — not fabricated after the fact.
- **"Foundation model" includes fine-tuned variants.** Fine-tuning a base model transfers all supply chain risks of the base model plus adds new risks from the fine-tuning dataset and process.

## How to use this skill

**Skill check:** Before making a decision or asking a question, read this skill's checklist/references and confirm which skill(s) are relevant. In your output, include a `Skills used:` line naming the skill(s) and the specific section(s) relied upon. Only ask follow-up questions if the skill guidance still leaves you needing more input.

1. Identify the relevant practice from the routing table below
2. Read the linked reference file for that practice
3. Apply the tasks defined in that file
4. Use [218A-Checklist.md](218A-Checklist.md) to track overall compliance

## AI-specific cross-framework correlation

Use this section when SSDF and Molina controls need AI-specific interpretation.

Correlation map:
- Molina `P2D-02` maps to 218A `PO.5.1` for AI data security controls.
- Molina `P2D-03` maps to 218A `PS.1.3` for AI protection controls.
- Molina P2B testing gates map to 218A `PW.8` for AI security testing.
- SSDF secure design/testing controls should be interpreted with AI-specific threat modeling and adversarial testing requirements.

Decision layering:
1. Validate baseline SDDF security expectations for the increment.
2. Add 218A controls for model, data, and pipeline risk.
3. If Molina governance applies, ensure PRE/P2D/P2B evidence remains aligned.

## AI project intake addendum

Collect these details before detailed 218A routing:
- AI scope: inference-only, fine-tuning, or model training/development.
- Model provenance: pre-trained external model, internal model, or mixed.
- Data sensitivity: public, internal, PII/PHI, financial, or regulated.
- AI testing approach: adversarial testing, robustness testing, and output monitoring.

Recommended role additions for AI projects:
- AI/ML Engineer for pipeline and model protection controls.
- Data Owner for provenance and classification controls.

## AI-integrated output template

```markdown
Skills used: molina-nist-218a (AI-specific cross-framework correlation, AI project intake addendum)

AI Scope:
- Type: <inference|fine-tune|train>
- Model/data sensitivity: <classification>

Control Alignment:
- 218A: <covered/missing>
- SSDF dependencies: <covered/missing>
- Molina dependencies (if in scope): <covered/missing>

Decision:
- Result: <PASS|CONDITIONAL|FAIL>

AI-Specific Gaps:
- <control-id>: <gap and impact>
```

## Topic routing

### Prepare the Organization (PO)

| Practice | Task | Read |
|----------|------|------|
| PO.1 — AI security requirements | Include AI-specific security in org requirements, such as AI model development, architectures, training techniques, and data classification | [PO_1_1.md](references/PO_1_1.md), [PO_1_2.md](references/PO_1_2.md), [PO_1_3.md](references/PO_1_3.md) — read when AI security policy or model development standards are in scope |
| PO.2 — Roles for AI | Define roles for AI development, data science, ops, including AI model producers, system producers, and third-party providers | [PO_2_1.md](references/PO_2_1.md), [PO_2_2.md](references/PO_2_2.md), [PO_2_3.md](references/PO_2_3.md) — read when AI team roles, data science responsibilities, or third-party AI providers are in scope |
| PO.3 — AI toolchains | Automated toolchains for AI model security, reducing human effort at scale | [PO_3_1.md](references/PO_3_1.md), [PO_3_2.md](references/PO_3_2.md), [PO_3_3.md](references/PO_3_3.md) — read when AI pipeline automation or ML security tooling is in scope |
| PO.4 — AI security criteria | Define criteria for AI model security checks, including guardrails and human-in-the-loop reviews | [PO_4_1.md](references/PO_4_1.md), [PO_4_2.md](references/PO_4_2.md) — read when AI guardrails, HITL review thresholds, or model acceptance criteria are in scope |
| PO.5 — Secure AI environments | Secure environments for AI development, including separation of execution environments, monitoring resource usage, and protecting training pipelines | [PO_5_1.md](references/PO_5_1.md), [PO_5_2.md](references/PO_5_2.md), [PO_5_3.md](references/PO_5_3.md) — read when training environment isolation or pipeline access control is in scope |

### Protect the Software (PS)

| Practice | Task | Read |
|----------|------|------|
| PS.1 — Protect models and data | Protect weights, training data, pipelines, including AI models, weights, pipelines, and reward models | [PS_1_1.md](references/PS_1_1.md), [PS_1_2.md](references/PS_1_2.md), [PS_1_3.md](references/PS_1_3.md) — read when model weights, training data, or reward model protection is in scope |
| PS.2 — AI release integrity | Verify integrity of AI model releases, including cryptographic hashes and digital signatures | [PS_2_1.md](references/PS_2_1.md) — read when model release signing or hash verification is in scope |
| PS.3 — Archive AI releases | Archive models with provenance data, including versioning, training process documentation | [PS_3_1.md](references/PS_3_1.md), [PS_3_2.md](references/PS_3_2.md) — read when model versioning, archiving, or training provenance documentation is in scope |

### Produce Well-Secured Software (PW)

| Practice | Task | Read |
|----------|------|------|
| PW.1 — AI risk modeling | Threat modeling including AI-specific attack vectors, such as data poisoning, adversarial prompts, and supply chain attacks | [PW_1_1.md](references/PW_1_1.md), [PW_1_2.md](references/PW_1_2.md), [PW_1_3.md](references/PW_1_3.md) — read when AI-specific threat modeling or adversarial attack surface review is in scope |
| PW.2 — AI design review | Review AI system design against security requirements | [PW_2_1.md](references/PW_2_1.md) — read when AI architecture design review or security sign-off is in scope |
| PW.3 — Training data integrity | Confirm integrity of training, test, and fine-tuning data | [PW_3_1.md](references/PW_3_1.md), [PW_3_2.md](references/PW_3_2.md), [PW_3_3.md](references/PW_3_3.md) — read when training data validation, poisoning risk, or dataset provenance is in scope |
| PW.4 — Reuse AI models | Acquire and verify existing AI models | [PW_4_1.md](references/PW_4_1.md), [PW_4_2.md](references/PW_4_2.md), [PW_4_4.md](references/PW_4_4.md) — read when adopting a pre-trained or third-party model, or fine-tuning is in scope |
| PW.5 — Secure AI coding | Secure coding including AI technology considerations | [PW_5_1.md](references/PW_5_1.md) — read when coding AI inference pipelines, prompt construction, or model-adjacent components is in scope |
| PW.6 — AI build security | Configure build processes for AI model security | [PW_6_1.md](references/PW_6_1.md), [PW_6_2.md](references/PW_6_2.md) — read when configuring AI model build pipelines or CI/CD for model artifacts is in scope |
| PW.7 — AI code review | Review AI-related code for vulnerabilities | [PW_7_1.md](references/PW_7_1.md), [PW_7_2.md](references/PW_7_2.md) — read when reviewing AI/ML code, prompt logic, or model integration code is in scope |
| PW.8 — AI model testing | Test AI models for vulnerabilities, including frequent scanning, automation, and periodic audits | [PW_8_1.md](references/PW_8_1.md), [PW_8_2.md](references/PW_8_2.md) — read when adversarial testing, robustness evaluation, or output monitoring is in scope |
| PW.9 — Secure AI defaults | Secure default settings for AI systems | [PW_9_1.md](references/PW_9_1.md), [PW_9_2.md](references/PW_9_2.md) — read when AI system default configurations, output filters, or safety defaults are in scope |

### Respond to Vulnerabilities (RV)

| Practice | Task | Read |
|----------|------|------|
| RV.1 — Monitor AI outputs | Log, monitor, and analyze model inputs/outputs, including continuous logging, user reporting mechanisms, and monitoring vulnerability databases | [RV_1_1.md](references/RV_1_1.md), [RV_1_2.md](references/RV_1_2.md), [RV_1_3.md](references/RV_1_3.md) — read when AI output monitoring, anomaly detection, or model vulnerability intake is in scope |
| RV.2 — Remediate AI vulns | Assess and fix AI model vulnerabilities, including deep analysis of inputs/outputs and considering rebuild expenses | [RV_2_1.md](references/RV_2_1.md), [RV_2_2.md](references/RV_2_2.md) — read when triaging or remediating AI model vulnerabilities or planning model retraining is in scope |
| RV.3 — AI root cause analysis | Analyze AI vulnerabilities to identify root causes, including AI model-specific issues | [RV_3_1.md](references/RV_3_1.md) — read when root cause analysis for AI-specific failures or systemic model issues is in scope |

## Available resources

Reference files (load only when explicitly needed):
- [218A-Checklist.md](218A-Checklist.md) — all tasks with status-tracking links
- [references/ai-automation-playbook.md](references/ai-automation-playbook.md) — AI threat categories, ML platform integrations, evidence artifacts, testing tools
- `references/PO_1_1.md` through `references/PO_5_3.md` — individual PO practice task files
- `references/PS_1_1.md` through `references/PS_3_2.md` — individual PS practice task files
- `references/PW_1_1.md` through `references/PW_9_2.md` — individual PW practice task files
- `references/RV_1_1.md` through `references/RV_3_1.md` — individual RV practice task files

## Full checklist

See [218A-Checklist.md](218A-Checklist.md) for all tasks with links to individual task files.
