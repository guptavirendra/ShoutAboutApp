# NIST 218A AI Automation Playbook

Source: `02-NIST-218A/AGENTS.md`

## AI security validation workflow

For every 218A compliance run:
1. Validate training data integrity and access controls.
2. Verify model protection mechanisms (weights, APIs, infrastructure).
3. Check AI-specific defensive measures: adversarial robustness, output monitoring.
4. Assess dual-use risk management and mitigation controls.
5. Generate AI security compliance reports and model cards.

## AI threat categories

| Threat | Description | Primary controls |
|---|---|---|
| Data poisoning | Malicious manipulation of training data to corrupt model behavior | PW.3, PO.5 |
| Model extraction | Unauthorized access to model weights or architecture replication | PS.1, RV.1 |
| Adversarial attacks | Inputs designed to manipulate or deceive model predictions | PW.8, RV.1 |
| Model inversion | Techniques to extract training data or sensitive patterns from a model | PS.1, PO.5 |
| Backdoor attacks | Hidden triggers inserted during training that cause malicious behavior | PW.3, PW.8 |

## AI monitoring capabilities

- Real-time detection of unusual model behavior or performance degradation
- Training data integrity validation and anomaly detection during pipeline runs
- Model API monitoring for extraction attempts and unusual query patterns
- Integration with AI security tools for threat intelligence and automated response
- Continuous logging of model inputs/outputs for forensic and compliance use

## ML platform integrations

Supported platforms: MLflow, Kubeflow, Azure ML, AWS SageMaker, Google Vertex AI

Integration workflow:
1. Extract model training metrics and artifacts for compliance validation.
2. Integrate security scanning into model training and deployment pipelines.
3. Collect model release integrity hashes and deployment manifests.
4. Monitor model performance and behavioral drift in production.

## AI-specific evidence artifacts

- **Model cards**: capabilities, limitations, biases, intended use, known risks
- **AI security attestations**: formal declarations of security testing and defensive measures
- **Training data provenance records**: sources, integrity hashes, access control logs
- **Dual-use risk assessments**: analysis of harmful application potential and mitigations
- **Adversarial testing reports**: test coverage, attack types evaluated, robustness results
- **Explainability records**: SHAP/LIME outputs or equivalent model decision documentation

## Adversarial and AI testing tools

| Tool category | Tools |
|---|---|
| Adversarial robustness | Foolbox, IBM Adversarial Robustness Toolbox (ART) |
| Explainability analysis | SHAP, LIME |
| Privacy leakage testing | Membership inference toolkits, model inversion probes |
| Bias detection | Fairness metrics libraries, fairness test datasets |
| Dependency and code scanning | SonarQube (code + dependency scanning), Wiz SCA (software composition analysis) — Molina standard. Bandit/Safety equivalent; use SonarQube for unified scanning. |

**Molina Implementation Note:** AI model code (Python, Go, etc.) is scanned via SonarQube per Molina P2D/P2B gates; model weights and training data integrity are assessed via separate evidence artifacts (model cards, attestations).

## Model documentation requirements

### Model card minimum fields
- Model name, version, and intended use
- Training data description (sources, preprocessing, known limitations)
- Evaluation results (accuracy, bias metrics, robustness test outcomes)
- Known limitations and out-of-scope uses
- Security measures and access restrictions

### AI security attestation minimum fields
- Model protection measures (encryption, access control, API security)
- Testing completed: adversarial, bias, privacy, performance
- Known vulnerabilities and accepted residual risks
- Owner and sign-off date

## Cross-framework mapping

| 218A practice | Aligned SSDF practice | Notes |
|---|---|---|
| PW.3 — Training data integrity | PW.4 — Reuse software | Apply supply-chain rigor to training data acquisition |
| PS.1 — Protect models and data | PS.1 — Protect code | Extend to model weights, pipelines, reward models |
| PW.8 — AI model testing | PW.8 — Executable testing | Add adversarial, bias, and privacy testing scenarios |
| RV.1 — Monitor AI outputs | RV.1 — Identify vulnerabilities | Include continuous output logging and behavioral monitoring |
| PO.5 — Secure AI environments | PO.5 — Secure environments | Add training pipeline isolation and resource monitoring |
