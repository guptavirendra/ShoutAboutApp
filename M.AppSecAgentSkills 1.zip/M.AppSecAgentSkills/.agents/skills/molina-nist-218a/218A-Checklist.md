# NIST 218A Checklist for Secure Software Development Practices for Generative AI and Dual-Use Foundation Models

This checklist is organized by Practice Groups, Practices, and Tasks, with recommendations, considerations, and notes specific to AI model development.

## Prepare the Organization (PO)

### PO.1 [Define Security Requirements for Software Development](references/PO_1_1.md)
- [ ] **PO.1.1** [Identify and document all security requirements for the organization’s software development infrastructures and processes, and maintain the requirements over time.](references/PO_1_1.md)
	- [ ] R1: Include AI model development in the security requirements for software development infrastructure and processes.
	- [ ] R2: Identify and select appropriate AI model architectures and training techniques in accordance with recommended practices for cybersecurity, privacy, and reproducibility.

- [ ] **PO.1.2** [Identify and document all security requirements for organization-developed software to meet, and maintain the requirements over time.](references/PO_1_2.md)
	- [ ] R1: Organizational policies should support all current requirements specific to AI model development security for organization-developed software, including AI model development, operations, and data science.
	- [ ] C1: Consider reusing or expanding the organization’s existing data classification policy and processes.
	- [ ] N1: Possible forms of AI model documentation include data, model, and system cards.

- [ ] **PO.1.3** [Communicate requirements to all third parties who will provide commercial software components to the organization for reuse by the organization’s own software.](references/PO_1_3.md)
	- [ ] R1: Include AI model development security in the requirements being communicated for third-party software components.

### PO.2 [Implement Roles and Responsibilities](references/PO_2_1.md)
- [ ] **PO.2.1** [Create new roles and alter responsibilities for existing roles as needed to encompass all parts of the SDLC. Periodically review and maintain the defined roles and responsibilities, updating them as needed.](references/PO_2_1.md)
	- [ ] R1: Include AI model development security in SDLC-related roles and responsibilities throughout the SDLC, including AI model development, operations, and data science.
	- [ ] N1: Roles and responsibilities involving AI system producers, AI model producers, and other third-party providers can be documented in agreements.

- [ ] **PO.2.2** [Provide role-based training for all personnel with responsibilities that contribute to secure development. Periodically review personnel proficiency and role-based training, and update the training as needed.](references/PO_2_2.md)
	- [ ] R1: Role-based training should include understanding cybersecurity vulnerabilities and threats to AI models and their possible mitigations.

- [ ] **PO.2.3** [Obtain upper management or authorizing official commitment to secure development, and convey that commitment to all with development-related roles and responsibilities.](references/PO_2_3.md)
	- [ ] R1: Leadership should commit to secure development practices involving AI models.

### PO.3 [Implement Supporting Toolchains](references/PO_3_1.md)
- [ ] **PO.3.1** [Specify which tools or tool types must or should be included in each toolchain to mitigate identified risks, as well as how the toolchain components are to be integrated with each other.](references/PO_3_1.md)
	- [ ] R1: Plan to develop and implement automated toolchains that secure AI model development and reduce human effort, especially at the scale often used by AI models.
	- [ ] N1: Ideally, automated toolchains will perform the vast majority of the work related to securing AI model development.
	- [ ] N2: See PO.4, PO.5, PS, and PW for information on tool types.

- [ ] **PO.3.2** [Follow recommended security practices to deploy, operate, and maintain tools and toolchains.](references/PO_3_2.md)
	- [ ] R1: Execute the plan to develop and implement automated toolchains that secure AI model development and reduce human effort, especially at the scale often used by AI models.
	- [ ] R2: Verify the security of toolchains at a frequency commensurate with risk.

- [ ] **PO.3.3** [Configure tools to generate artifacts of their support of secure software development practices as defined by the organization.](references/PO_3_3.md)
	- [ ] N1: Artifacts provide records of secure software development practices. Examples specific to AI model development include attestations of the integrity and provenance of training datasets.

### PO.4 [Define and Use Criteria for Software Security Checks](references/PO_4_1.md)
- [ ] **PO.4.1** [Define criteria for software security checks and track throughout the SDLC.](references/PO_4_1.md)
	- [ ] R1: Implement guardrails and other controls throughout the AI development life cycle, extending beyond the traditional SDLC.
	- [ ] C1: Consider requiring review and approval from a human-in-the-loop for software security checks beyond risk-based thresholds.

- [ ] **PO.4.2** [Implement processes, mechanisms, etc. to gather and safeguard the necessary information in support of the criteria.](references/PO_4_2.md)

### PO.5 [Implement and Maintain Secure Environments for Software Development](references/PO_5_1.md)
- [ ] **PO.5.1** [Separate and protect each environment involved in software development.](references/PO_5_1.md)
	- [ ] C1: Consider separating execution environments from each other to the extent feasible.
	- [ ] R1: Monitor, track, and limit resource usage and rates for AI model users during model development.
	- [ ] R2: Only store sensitive data used during AI model development within organization-approved environments.
	- [ ] R3: Protect all training pipelines, model registries, and other components within the environments according to the principle of least privilege.
	- [ ] R4: Continuously monitor training-related activity in pipelines and model modifications in the model registry.
	- [ ] R5: Follow recommended practices for securely configuring each environment.
	- [ ] R6: Continuously monitor each environment for plaintext secrets.

- [ ] **PO.5.2** [Secure and harden development endpoints to perform development tasks using a risk-based approach.](references/PO_5_2.md)

- [ ] **PO.5.3** [Continuously monitor software execution performance and behavior in software development environments to identify potential suspicious activity and other issues.](references/PO_5_3.md)
	- [ ] R1: Perform continuous security monitoring for all development environment components that host an AI model or related resources.
	- [ ] R2: Continuous monitoring and analysis tools should generate alerts when detected activity involving an AI model passes a risk threshold or otherwise merits additional investigation.


## Protect Software (PS)

### PS.1 [Protect All Forms of Code and Data from Unauthorized Access and Tampering](references/PS_1_1.md)
- [ ] **PS.1.1** [Store all forms of code – including source code, executable code, and configuration-as-code – based on the principle of least privilege so that only authorized personnel, tools, services, etc. have access.](references/PS_1_1.md)
	- [ ] R1: Secure code storage should include AI models, model weights, pipelines, reward models, and any other AI model elements that need their confidentiality, integrity, and/or availability protected.
	- [ ] R2: Follow the principle of least privilege to minimize direct access to AI models and model elements regardless of where they are stored or executed.
	- [ ] R3: Store reward models separately from AI models and data.
	- [ ] R4: Permit indirect access only to model weights.
	- [ ] C1: Consider preventing all human access to model weights.
	- [ ] C2: Consider requiring all AI model development to be performed within organization-approved environments only.

- [ ] **PS.1.2** [Protect all training, testing, fine-tuning, and aligning data from unauthorized access and modification.](references/PS_1_2.md)
	- [ ] R1: Continuously monitor the confidentiality (for non-public data only) and integrity of training, testing, fine-tuning, and aligning data.
	- [ ] C1: Consider securely storing training, testing, fine-tuning, and aligning data for future use and reference if feasible.

- [ ] **PS.1.3** [Protect all model weights and configuration parameter data from unauthorized access and modification.](references/PS_1_3.md)
	- [ ] R1: Keep model weights and configuration parameters separate from training, testing, fine-tuning, and aligning data.
	- [ ] R2: Continuously monitor the confidentiality (for closed models only) and integrity of model weights and configuration parameters.
	- [ ] R3: Follow the principle of least privilege to restrict access to AI model weights, configuration parameters, and services during development.
	- [ ] R4: Specify and implement additional risk-proportionate cybersecurity practices around model weights, such as encryption, cryptographic hashes, digital signatures, multi-party authorization, and air-gapped environments.

### PS.2 [Provide a Mechanism for Verifying Software Release Integrity](references/PS_2_1.md)
- [ ] **PS.2.1** [Make software integrity verification information available to software acquirers.](references/PS_2_1.md)
	- [ ] R1: Generate and provide cryptographic hashes or digital signatures for an AI model and its components, artifacts, and documentation.
	- [ ] R2: Provide digital signatures for AI model changes.

### PS.3 [Archive and Protect Each Software Release](references/PS_3_1.md)
- [ ] **PS.3.1** [Securely archive the necessary files and supporting data (e.g., integrity verification information, provenance data) to be retained for each software release.](references/PS_3_1.md)
	- [ ] R1: Perform versioning and tracking for infrastructure tools (e.g., pre-processing, transforms, collection) that support dataset creation and model training.
	- [ ] R2: Include documentation of the justification for AI model selection in the retained information.
	- [ ] R3: Include documentation of the entire training process, such as data preprocessing and model architecture.
	- [ ] N1: AI models and their components may need to be added at this time to an organization’s asset inventories.

- [ ] **PS.3.2** [Collect, safeguard, maintain, and share provenance data for all components of each software release (e.g., in a software bill of materials [SBOM], through Supply-chain Levels for Software Artifacts [SLSA]).](references/PS_3_2.md)
	- [ ] R1: Track the provenance of an AI model and its components and derivatives, including the training libraries, frameworks, and pipelines used to build the model.
	- [ ] R2: Track AI models that were trained on sensitive data (e.g., payment card data, protected health information, other types of personally identifiable information), and determine if access to the models should be restricted to individuals who already have access to the sensitive data used for training.
	- [ ] C1: Consider disclosing the provenance of the training, testing, fine-tuning, and aligning data used for an AI model.

## Produce Well-Secured Software (PW)

### PW.1 [Design Software to Meet Security Requirements and Mitigate Security Risks](references/PW_1_1.md)
- [ ] **PW.1.1** [Use forms of risk modeling – such as threat modeling, attack modeling, or attack surface mapping – to help assess the security risk for the software.](references/PW_1_1.md)
	- [ ] R1: Incorporate relevant AI model-specific vulnerability and threat types in risk modeling. Examples include poisoning of training data, malicious code or other unwanted content in inputs and outputs, denial-of-service conditions arising from adversarial prompts, supply chain attacks, unauthorized information disclosure, theft of AI model weights, and misconfiguration of data pipelines.
	- [ ] C1: Consider periodic risk modeling updates for future AI model versions and derivatives after AI model release.
	- [ ] C2: During risk modeling, consider checking that the AI model is not in a critical path to make significant security decisions without a human in the loop.

- [ ] **PW.1.2** [Track and maintain the software’s security requirements, risks, and design decisions.](references/PW_1_2.md)

- [ ] **PW.1.3** [Where appropriate, build in support for using standardized security features and services (e.g., enabling software to integrate with existing log management, identity management, access control, and vulnerability management systems) instead of creating proprietary implementations of security features and services.](references/PW_1_3.md)

### PW.2 [Review the Software Design to Verify Compliance with Security Requirements and Risk Information](references/PW_2_1.md)
- [ ] **PW.2.1** [Have 1) a qualified person (or people) who were not involved with the design and 2) automated processes instantiated in the toolchain review the software design to confirm and enforce that it meets all of the security requirements and satisfactorily addresses the identified risk information.](references/PW_2_1.md)

### PW.3 [Confirm the Integrity of Training, Testing, Fine-Tuning, and Aligning Data Before Use](references/PW_3_1.md)
- [ ] **PW.3.1** [Analyze data for signs of data poisoning, bias, homogeneity, and tampering before using it for AI model training, testing, fine-tuning, or aligning purposes, and mitigate the risks as necessary.](references/PW_3_1.md)
	- [ ] R1: Verify the provenance (when known) and integrity of training, testing, fine-tuning, and aligning data before use.
	- [ ] R2: Select and apply appropriate methods for analyzing and altering the training, testing, fine-tuning, and aligning data for an AI model. Examples include anomaly detection, bias detection, data cleaning, data curation, data filtering, data sanitization, fact-checking, and noise reduction.
	- [ ] C1: Consider using a human-in-the-loop to examine data, such as with exploratory data analysis techniques.

- [ ] **PW.3.2** [Track the provenance, when known, of all training, testing, fine-tuning, and aligning data used for an AI model, and document which data do not have known provenance.](references/PW_3_2.md)
	- [ ] N1: Provenance verification is not possible in all cases because provenance is not always known. However, it is still beneficial for security purposes to track and verify provenance whenever possible, and to track when provenance is unknown.

- [ ] **PW.3.3** [Include adversarial samples in the training and testing data to improve attack prevention.](references/PW_3_3.md)
	- [ ] R1: Use a process and corresponding controls to test the adversarial samples and put appropriate guardrails on training and testing use.

### PW.4 [Reuse Existing, Well-Secured Software When Feasible Instead of Duplicating Functionality](references/PW_4_1.md)
- [ ] **PW.4.1** [Acquire and maintain well-secured software components (e.g., software libraries, modules, middleware, frameworks) from commercial, open-source, and other third-party developers for use by the organization’s software.](references/PW_4_1.md)
	- [ ] C1: Consider using an existing AI model instead of creating a new one.

- [ ] **PW.4.2** [Create and maintain well-secured software components in-house following SDLC processes to meet common internal software development needs that cannot be better met by third-party software components.](references/PW_4_2.md)

- [ ] **PW.4.4** [Verify that acquired commercial, open-source, and all other third-party software components comply with the requirements, as defined by the organization, throughout their life cycles.](references/PW_4_4.md)
	- [ ] R1: Verify the integrity, provenance, and security of an existing AI model or any other acquired AI components — including training, testing, fine-tuning, and aligning datasets; reward models; adaptation layers; and configuration parameters — before using them.
	- [ ] R2: Scan and thoroughly test acquired AI models and their components for vulnerabilities and malicious content before use.

### PW.5 [Create Source Code by Adhering to Secure Coding Practices](references/PW_5_1.md)
- [ ] **PW.5.1** [Follow all secure coding practices that are appropriate to the development languages and environment to meet the organization’s requirements.](references/PW_5_1.md)
	- [ ] R1: Expand secure coding practices to include AI technology-specific considerations.
	- [ ] R2: Code the handling of inputs (including prompts and user data) and outputs carefully. All inputs and outputs should be logged, analyzed, and validated within the context of the AI model, and those with issues should be sanitized or dropped.
	- [ ] R3: Encode inputs and outputs to prevent the execution of unauthorized code.

### PW.6 [Configure the Compilation, Interpreter, and Build Processes to Improve Executable Security](references/PW_6_1.md)
- [ ] **PW.6.1** [Use compiler, interpreter, and build tools that offer features to improve executable security.](references/PW_6_1.md)
	- [ ] C1: Consider using secure model serialization mechanisms that reduce or eliminate vectors for the introduction of malicious content.

- [ ] **PW.6.2** [Determine which compiler, interpreter, and build tool features should be used and how each should be configured, then implement and use the approved configurations.](references/PW_6_2.md)
	- [ ] C1: Consider capturing compiler, interpreter, and build tool versions and features as part of the provenance tracking.

### PW.7 [Review and/or Analyze Human-Readable Code to Identify Vulnerabilities and Verify Compliance with Security Requirements](references/PW_7_1.md)
- [ ] **PW.7.1** [Determine whether code review and/or code analysis should be used, as defined by the organization.](references/PW_7_1.md)
	- [ ] R1: Code review and analysis policies or guidelines should include code for AI models and other related components.
	- [ ] C1: Consider performing scans of AI model code in addition to testing the AI models.

- [ ] **PW.7.2** [Perform the code review and/or code analysis based on the organization’s secure coding standards, and record and triage all discovered issues and recommended remediations in the development team’s workflow or issue tracking system.](references/PW_7_2.md)
	- [ ] R1: Scan all AI models for malware, vulnerabilities, backdoors, and other security issues in accordance with the organization’s code review and analysis policies or guidelines.

### PW.8 [Test Executable Code to Identify Vulnerabilities and Verify Compliance with Security Requirements](references/PW_8_1.md)
- [ ] **PW.8.1** [Determine whether executable code testing should be performed to find vulnerabilities not identified by previous reviews, analysis, or testing and, if so, which types of testing should be used.](references/PW_8_1.md)
	- [ ] R1: Include AI models in code testing policies and guidelines. Several forms of code testing can be used for AI models, including unit testing, integration testing, penetration testing, red teaming, use case testing, and adversarial testing.
	- [ ] C1: Consider automating tests within a development pipeline as part of regression testing where possible.

- [ ] **PW.8.2** [Scope the testing, design the tests, perform the testing, and document the results, including recording and triaging all discovered issues and recommended remediations in the development team’s workflow or issue tracking system.](references/PW_8_2.md)
	- [ ] R1: Test all AI models for vulnerabilities in accordance with the organization’s code testing policies or guidelines.
	- [ ] R2: Retest AI models when they are retrained or new data sources are added.

### PW.9 [Configure Software to Have Secure Settings by Default](references/PW_9_1.md)
- [ ] **PW.9.1** [Define a secure baseline by determining how to configure each setting that has an effect on security or a security-related setting so that the default settings are secure and do not weaken the security functions provided by the platform, network infrastructure, or services.](references/PW_9_1.md)

- [ ] **PW.9.2** [Implement the default settings (or groups of default settings, if applicable), and document each setting for software administrators.](references/PW_9_2.md)
	- [ ] N1: Documenting settings can be performed earlier in the process, such as when defining a secure baseline (see PW.9.1).

## Respond to Vulnerabilities (RV)

### RV.1 [Identify and Confirm Vulnerabilities on an Ongoing Basis](references/RV_1_1.md)
- [ ] **RV.1.1** [Gather information from software acquirers, users, and public sources on potential vulnerabilities in the software and third-party components that the software uses, and investigate all credible reports.](references/RV_1_1.md)
	- [ ] R1: Log, monitor, and analyze all inputs and outputs for AI models to detect possible security and performance issues (see PO.5.3).
	- [ ] R2: Make the users of AI models aware of mechanisms for reporting potential security and performance issues.
	- [ ] N1: In this context, “users” refers to AI system producers and acquirers who are using an AI model.
	- [ ] R3: Monitor vulnerability and incident databases for information on AI-related concerns, including the machine learning frameworks and libraries used to build AI models.

- [ ] **RV.1.2** [Review, analyze, and/or test the software’s code to identify or confirm the presence of previously undetected vulnerabilities.](references/RV_1_2.md)
	- [ ] R1: Scan and test AI models frequently to identify previously undetected vulnerabilities.
	- [ ] R2: Rely mainly on automation for ongoing scanning and testing, and involve a human-in-the-loop as needed.
	- [ ] R3: Conduct periodic audits of AI models.

- [ ] **RV.1.3** [Have a policy that addresses vulnerability disclosure and remediation, and implement the roles, responsibilities, and processes needed to support that policy.](references/RV_1_3.md)
	- [ ] R1: Include AI model vulnerabilities in organization vulnerability disclosure and remediation policies.
	- [ ] R2: Make users of AI models aware of their inherent limitations and how to report any cybersecurity problems that they encounter.

### RV.2 [Assess, Prioritize, and Remediate Vulnerabilities](references/RV_2_1.md)
- [ ] **RV.2.1** [Analyze each vulnerability to gather sufficient information about risk to plan its remediation or other risk response.](references/RV_2_1.md)
	- [ ] N1: This may include deep analysis of generative AI and dual-use foundation model input and output to detect deviations from normal behavior.

- [ ] **RV.2.2** [Plan and implement risk responses for vulnerabilities.](references/RV_2_2.md)
	- [ ] R1: Risk responses for AI models should consider the time and expenses that may be associated with rebuilding them.
	- [ ] R2: Establish and implement criteria and processes for when to stop using an AI model and when to roll back to a previous version and its components.
	- [ ] C1: Consider being prepared to stop using an AI model at any time and to continue operations through other means until the AI model’s risks are sufficiently addressed.

### RV.3 [Analyze Vulnerabilities to Identify Their Root Causes](references/RV_3_1.md)
- [ ] **RV.3.1** [Analyze identified vulnerabilities to determine their root causes.](references/RV_3_1.md)
	- [ ] N1: The ability to review training, testing, fine-tuning, and aligning data after the fact can help identify some root causes.
