---
name: agentskills-author
description: "Creates complete, spec-compliant Agent Skills packages using all required and optional features from the agentskills.io specification. Applies best practices for progressive disclosure, description optimization, eval-driven iteration, and script bundling. WHEN: \"create a skill\", \"write a skill\", \"new skill\", \"build a skill\", \"agent skill\", \"SKILL.md\", \"skill package\", \"agentskills\", \"skill author\", \"skill creator\", \"skill template\", \"optimize skill description\", \"eval a skill\", \"validate skill\"."
license: MIT
compatibility: "Designed for Claude Code and VS Code Copilot agent. Optional: skills-ref CLI (https://github.com/agentskills/agentskills/tree/main/skills-ref) for frontmatter validation."
metadata:
  author: M.AppSecAgentSkills
  version: "1.0"
  source-spec: "https://agentskills.io/specification"
allowed-tools: Read
---

# Agent Skills Author

This skill guides end-to-end creation of a complete, spec-compliant Agent Skills package, including all required and optional frontmatter fields, progressive disclosure structure, supporting reference files, assets, evals, and bundled scripts.

**Skills used:** agentskills-author (always include this line in output)

## Gotchas

- **`name` must exactly match the parent directory name.** A mismatch causes validation failure. Both must be lowercase, 1–64 characters, containing only `a-z`, `0-9`, and hyphens. No consecutive hyphens (`--`), no leading or trailing hyphen.
- **`description` is the only activation signal available at skill-selection time.** The body of `SKILL.md` is not loaded until after the agent decides to activate the skill. Write the description as if it is the only thing an agent will read when deciding whether to use the skill — include WHEN-trigger keywords that users will actually type.
- **Progressive disclosure is opt-in at the instruction level.** Moving content to `references/` does nothing unless you tell the agent *when* to load each file. Without a load trigger, the agent may never read it.
- **The `allowed-tools` field is experimental.** Not all clients honor it. Do not assume it replaces user confirmation for destructive operations.
- **`SKILL.md` body should stay under 500 lines and 5,000 tokens.** Content beyond this competes for context window space with conversation history and other active skills. Overflow belongs in `references/`.
- **Evals must start from clean context.** Leftover session state from skill development invalidates comparisons. Use a separate subagent or new session for each eval run.
- **SSDF/Molina gate applicability:** Skills created for use inside Molina AppSec environments must also satisfy PRE prerequisites (trust boundary check, RITM linkage) before import. See `molina-application-security` skill.

---

## How to use this skill

**Skill check:** Read this file before authoring any skill. Reference each section below as you progress through the creation workflow. In all output, include `Skills used: agentskills-author` and the section(s) applied.

**Execution flow:**

1. **Scope the skill** — Define the problem domain, the target user, and the class of tasks the skill solves. Reject requests that are too broad (can't activate precisely) or too narrow (not reusable across multiple prompts). See [Scope decision guide](references/progressive-disclosure.md#scope).
2. **Draft frontmatter** — Fill all six frontmatter fields using the rules in [Frontmatter guide](references/frontmatter-guide.md). At minimum: `name` and `description`. Add `license`, `compatibility`, `metadata`, and `allowed-tools` when applicable.
3. **Write the body** — Apply the patterns below. Keep `SKILL.md` under 500 lines. Anything exceeding that scope moves to `references/`.
4. **Create supporting directories** — Add `references/`, `assets/`, `scripts/`, and `evals/` as needed using the directory conventions below.
5. **Validate** — Run the validation script: `pwsh scripts/validate-skill.ps1 --skill-path <path>`. Fix all errors before proceeding.
6. **Run evals** — Design at least 2–3 test cases in `evals/evals.json`. Compare with-skill and without-skill outputs. Grade and iterate. See [Eval-driven iteration](references/eval-driven-iteration.md).
7. **Optimize description** — Test that the description triggers reliably on realistic user prompts. See [Description optimization](references/description-optimization.md).

---

## Plan-validate-execute: skill creation workflow

For each new skill, produce an intermediate plan before writing files:

1. **Propose** a skill outline: name, description draft, directory structure, file list, frontmatter field values.
2. **Validate** the proposal against the checklist in [assets/skill-checklist.md](assets/skill-checklist.md) before creating any files.
3. **Execute** file creation only after the proposal passes validation.
4. **Re-validate** by running `pwsh scripts/validate-skill.ps1 --skill-path <path>` after all files are written.

---

## Body content patterns

Apply these patterns as appropriate. Not every skill needs all of them.

### Gotchas section (highest priority)

List environment-specific facts that defy reasonable assumptions. Concrete corrections to mistakes the agent will make without being told. Keep in `SKILL.md` — not in a reference file — so the agent reads them before encountering the situation.

```markdown
## Gotchas

- The `users` table uses soft deletes. Always include `WHERE deleted_at IS NULL`.
- `user_id` in the DB maps to `uid` in the auth service and `accountId` in billing.
```

### Templates for output format

Provide a concrete template when the agent must produce output in a specific structure. Short templates inline; long templates in `assets/` with an explicit load trigger.

```markdown
## Output template

Use this structure for every gate decision:

**Gate:** PRE | P2D | P2B
**Decision:** PASS | CONDITIONAL | FAIL
**Blockers:** [list or "none"]
**Evidence:** [links or artifact IDs]
```

### Checklists for multi-step workflows

```markdown
## Creation checklist

- [ ] `name` field set and matches directory name
- [ ] `description` includes WHEN-trigger keywords
- [ ] Body under 500 lines
- [ ] All `references/` files have explicit load triggers in `SKILL.md`
- [ ] `evals/evals.json` has at least 2 test cases
- [ ] `scripts/validate-skill.ps1` runs without error
```

### Validation loop

```markdown
## Validation workflow

1. Write the skill content.
2. Run: `pwsh scripts/validate-skill.ps1 --skill-path ./my-skill`
3. If validation fails:
   - Read the error message.
   - Fix the identified issue.
   - Run validation again.
4. Only proceed to eval after validation passes cleanly.
```

### Calibrating control

- **Be prescriptive** for frontmatter fields (exact constraints, no flexibility).
- **Give freedom** for body content structure (format varies by skill domain).
- **Pick one default** when multiple tools are valid; mention alternatives briefly.

---

## Directory conventions

| Directory | Purpose | When to create |
|-----------|---------|----------------|
| `references/` | Additional documentation loaded on demand | When `SKILL.md` body exceeds 300 lines, or when detail is only needed in specific conditions |
| `assets/` | Static templates, schemas, data files | When the skill needs reusable output templates or structured forms |
| `scripts/` | Bundled executable scripts | When the agent would otherwise reinvent the same logic each run |
| `evals/` | Test cases and grading results | Always — even 2 test cases are enough to start |

**File reference rules:**
- Use relative paths from the skill root: `references/REFERENCE.md`, `scripts/validate.ps1`.
- Always include a load trigger: "Read `references/api-errors.md` if the API returns a non-200 status."
- Keep references one level deep. Avoid nested chains like `references/sub/detail.md`.

---

## Reference load triggers

Instruct the agent exactly when to read each reference file. Generic "see references/ for details" is not enough.

```markdown
## Reference files (load on demand)

- Read [references/frontmatter-guide.md](references/frontmatter-guide.md)
  when setting or validating any frontmatter field.
- Read [references/progressive-disclosure.md](references/progressive-disclosure.md)
  when the SKILL.md body exceeds 300 lines or when deciding what to move to references/.
- Read [references/description-optimization.md](references/description-optimization.md)
  when writing or testing the `description` field.
- Read [references/eval-driven-iteration.md](references/eval-driven-iteration.md)
  when designing test cases or grading eval results.
- Read [assets/skill-checklist.md](assets/skill-checklist.md)
  before marking a skill ready for import or publication.
- Read [assets/SKILL-template.md](assets/SKILL-template.md)
  when starting a new skill from scratch.
```

---

## Available scripts

- **`scripts/validate-skill.ps1`** — Validates `SKILL.md` frontmatter, directory structure, naming conventions, and progressive-disclosure size limits.

Run:
```powershell
pwsh scripts/validate-skill.ps1 --skill-path ./my-skill
```

---

## Output contract

Every agent response using this skill must include:

```
Skills used: agentskills-author [section(s) applied]

Skill name:       <name>
Directory:        .agents/skills/<name>/
Frontmatter:
  name:           <value>
  description:    <value> (character count: N/1024)
  license:        <value or "not set">
  compatibility:  <value or "not set">
  metadata:       <key: value pairs or "not set">
  allowed-tools:  <value or "not set">
Body size:        <line count>/500 lines recommended
Directories:      references/ | assets/ | scripts/ | evals/ (check each present)
Validation:       PASS | FAIL (error details)
Evals:            <N> test cases defined
Next action:      <what to do next>
```