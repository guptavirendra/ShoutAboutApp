# SKILL.md Annotated Template

A fully annotated template showing all required and optional frontmatter fields plus all recommended body content patterns.
Load this file when starting a new skill from scratch.

---

## How to use this template

1. Copy the template below into your new skill's `SKILL.md`.
2. Replace every `<placeholder>` with your actual content.
3. Delete annotation comments (lines starting with `# →`) before publishing.
4. Validate with `pwsh scripts/validate-skill.ps1 --skill-path ./your-skill`.

---

## Template

```markdown
---
# → REQUIRED. 1-64 chars. Lowercase a-z, 0-9, hyphens only.
# → Must match the parent directory name exactly.
name: your-skill-name

# → REQUIRED. 1-1024 chars.
# → Describe what the skill does AND when to use it.
# → Include WHEN-trigger keywords users will actually type.
description: "<Capability statement in 1-2 sentences. WHEN: \"keyword1\", \"keyword2\", \"keyword3\", \"keyword4\", \"keyword5\"."

# → OPTIONAL. Short license name or reference to bundled LICENSE.txt.
# → Set for all skills intended for shared use. Use MIT as default in this repo.
license: MIT

# → OPTIONAL. 1-500 chars. Include only if skill has specific environment requirements.
# → Omit if the skill works in any environment.
compatibility: "Designed for Claude Code and VS Code Copilot agent. Requires <tools or services>."

# → OPTIONAL. String key-value pairs. Use unique key names.
metadata:
  author: <team-or-org>
  version: "1.0"
  source-spec: "https://<authoritative-specification-url>"

# → OPTIONAL. Experimental. Space-separated pre-approved tools.
# → Use Read for instructional-only skills. Scope Bash to specific commands.
allowed-tools: Read
---

# <Skill Display Name>

<One-paragraph description of what this skill does, who uses it, and in what context.
This paragraph appears after the agent activates the skill.>

**Skills used:** <skill-name> (always include this line in all output)

## Gotchas

<!-- Keep in SKILL.md — the agent reads these before starting, not on demand -->

- **<Non-obvious fact 1>** — <Concrete correction. Not general advice.>
- **<Non-obvious fact 2>** — <Concrete correction. Not general advice.>
- **<Non-obvious fact 3>** — <What the agent would get wrong without this instruction.>

---

## How to use this skill

**Skill check:** Read this file before <primary action>. In all output, include `Skills used: <skill-name>` and the section(s) applied.

**Execution flow:**

1. <First step — what to do first, what to check or gather>
2. <Second step — the core action>
3. <Third step — validation>
4. <Fourth step — output or next action>

---

## <Core section 1: main task instructions>

<!-- Be prescriptive for fragile, sequential steps -->
<!-- Give freedom (describe what, not how) for flexible steps -->

### <Subsection A>

<Instructions. Include specific tool names, commands, or API calls the agent wouldn't know.>

```bash
# → Replace with actual command
<command> --flag <value>
```

### <Subsection B>

<Instructions for the next subtask.>

---

## <Core section 2: another major workflow or topic>

<!-- Apply the pattern most relevant to your skill: -->
<!-- - Gotchas (already above) -->
<!-- - Output template (below) -->
<!-- - Checklist (below) -->
<!-- - Validation loop (below) -->
<!-- - Plan-validate-execute (below) -->

### Output template

<!-- Use when the agent must produce output in a specific format -->

```markdown
# [<Output type> Title]

## Summary
[One paragraph overview]

## <Section 1>
[Content]

## <Section 2>
[Content]
```

### Multi-step checklist

<!-- Use when task has sequential dependencies or validation gates -->

- [ ] Step 1: <action>
- [ ] Step 2: <action>
- [ ] Step 3: <validate>
- [ ] Step 4: <finalize>

### Validation loop

<!-- Use when the agent must verify its own work before proceeding -->

1. <Do the work>
2. Run: `<validation command>`
3. If validation fails:
   - <Read the error>
   - <Fix the issue>
   - Run validation again
4. Only proceed when validation passes

---

## Reference files (load on demand)

<!-- CRITICAL: every file in references/ needs an explicit load trigger here -->

- Read [references/<file1>.md](references/<file1>.md) when <specific condition>.
- Read [references/<file2>.md](references/<file2>.md) when <specific condition>.
- Read [assets/<template>.md](assets/<template>.md) when <specific condition>.

---

## Available scripts

<!-- List each script and its exact invocation -->

- **`scripts/<script-name>.<ext>`** — <What it does in one sentence>

```bash
<runtime> scripts/<script-name>.<ext> --<flag> <value>
```

---

## Output contract

Every agent response using this skill must include:

\`\`\`
Skills used: <skill-name> [section(s) applied]

<Field 1>:  <value>
<Field 2>:  <value>
<Field 3>:  <value>
Next action: <what to do next>
\`\`\`
```

---

## Directory structure for a complete skill

```
your-skill-name/
├── SKILL.md                      # This file (required)
├── references/
│   ├── <topic-a>.md              # Load when: <condition>
│   └── <topic-b>.md              # Load when: <condition>
├── assets/
│   ├── <output-template>.md      # Load when: <condition>
│   └── <checklist>.md            # Load when finalizing
├── scripts/
│   └── <validate>.<ps1|py|sh>    # Run as: <command>
└── evals/
    └── evals.json                # At least 2 test cases
```
