# Pre-Publish Skill Validation Checklist

Use this checklist before marking a skill ready for import or publication.
Load this file when finalizing a skill for the first time or before any major version update.

---

## Frontmatter checks

- [ ] **`name`** — lowercase, `a-z 0-9 -` only, 1–64 chars, no leading/trailing/consecutive hyphens
- [ ] **`name` matches directory** — the skill directory name is identical to the `name` field value
- [ ] **`description`** — 1–1024 characters; describes what the skill does and when to use it
- [ ] **`description` includes WHEN-keywords** — at least 5 specific trigger phrases users will type
- [ ] **`license`** — set if skill is intended for shared use (use `MIT` as default in this repo)
- [ ] **`compatibility`** — set only if the skill has specific environment requirements; omit otherwise
- [ ] **`metadata`** — includes `author` and `version` at minimum
- [ ] **`allowed-tools`** — set to the minimum required tools; use `Read` for instructional-only skills

---

## Body content checks

- [ ] **Under 500 lines** — run `(Get-Content SKILL.md).Count`
- [ ] **Estimated under 5,000 tokens** — run `[int]((Get-Content SKILL.md -Raw).Length / 4)`
- [ ] **Gotchas section present** — covers non-obvious environment facts specific to this skill's domain
- [ ] **Execution flow present** — numbered, step-by-step procedure
- [ ] **Output contract present** — specifies exactly what the agent must produce
- [ ] **`Skills used:` line** — body instructs the agent to include this in all output
- [ ] **Reference load triggers** — every file in `references/` has an explicit "read when" instruction in `SKILL.md`

---

## Directory structure checks

- [ ] **`SKILL.md` exists** at the skill root
- [ ] **`references/` present** if any content exceeds `SKILL.md` scope
- [ ] **Every reference file has a load trigger** in `SKILL.md`
- [ ] **`assets/` present** if skill uses output templates or structured data
- [ ] **`scripts/` present** if skill bundles executable code
- [ ] **Each script** is self-contained, includes error messages, handles edge cases
- [ ] **`evals/evals.json` present** with at least 2 test cases
- [ ] **No deeply nested references** — all reference paths are one level from skill root

---

## Activation checks

- [ ] **5+ activation test prompts pass** — skill activates on all relevant prompts (see `references/description-optimization.md`)
- [ ] **2+ rejection test prompts pass** — skill does NOT activate on clearly unrelated prompts

---

## Eval checks

- [ ] **At least 2 test cases** in `evals/evals.json` covering varied phrasings
- [ ] **At least one edge case** test (ambiguous input, unusual request, near-limit description)
- [ ] **Assertions written** for each test case (at least 3 per case)
- [ ] **First eval iteration complete** — with-skill vs. without-skill comparison run

---

## Repository-specific checks (M.AppSecAgentSkills)

- [ ] **`license: MIT`** set (repo default for open skills)
- [ ] **`metadata.author`** set to `M.AppSecAgentSkills` or owning team
- [ ] **`metadata.version`** set and follows semantic versioning intent
- [ ] **No secrets or credentials** embedded in any skill file or asset
- [ ] **TODO.md updated** — epic added with phase tracking consistent with existing format
- [ ] **README.md updated** if skill introduces a new category or changes import guidance
- [ ] **Skill validated** with `pwsh scripts/validate-skill.ps1 --skill-path <path>`

---

## Molina AppSec import checks (when importing into a Molina environment)

- [ ] **Azure CLI login confirmed** — `az account show` run and active account verified
- [ ] **Trust boundary review complete** — skill source reviewed before import
- [ ] **No collision with existing skills** — if same name exists, project-level skill takes precedence; operator approved override
- [ ] **Post-import validation** — each skill folder contains valid `SKILL.md` with parseable YAML frontmatter
