param([string]$SkillPath = ".")
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$errors   = [System.Collections.Generic.List[string]]::new()
$warnings = [System.Collections.Generic.List[string]]::new()
$passes   = [System.Collections.Generic.List[string]]::new()

function Fail([string]$msg)   { $errors.Add("ERROR:   $msg") }
function Warn([string]$msg)   { $warnings.Add("WARN:    $msg") }
function Pass([string]$msg)   { $passes.Add("PASS:    $msg") }

$skillDir = Resolve-Path $SkillPath -ErrorAction SilentlyContinue
if (-not $skillDir) { Write-Error "Skill directory not found: $SkillPath"; exit 1 }
$skillDir  = $skillDir.Path
$skillFile = Join-Path $skillDir "SKILL.md"
$dirName   = Split-Path $skillDir -Leaf

Write-Host ""
Write-Host "Validating: $skillDir"
Write-Host ""

if (-not (Test-Path $skillFile)) {
    Fail "SKILL.md not found in $skillDir"
    $errors | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    exit 1
}
Pass "SKILL.md exists"

$raw = Get-Content $skillFile -Raw -Encoding UTF8
if ($raw -notmatch "(?s)^---\r?\n(.+?)\r?\n---") {
    Fail "SKILL.md does not contain valid YAML frontmatter delimited by ---"
    $errors | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    exit 1
}
$frontmatter = $Matches[1]
Pass "YAML frontmatter block found"

function Get-Field([string]$field) {
    if ($frontmatter -match "(?m)^${field}:\s*(.+)$") { return $Matches[1].Trim().Trim('"') }
    return $null
}

# name
$name = Get-Field "name"
if (-not $name) { Fail "Required field 'name' is missing" }
else {
    Pass "Field 'name' present: '$name'"
    if ($name.Length -lt 1 -or $name.Length -gt 64) { Fail "'name' length $($name.Length) outside 1-64 limit" }
    else { Pass "'name' length $($name.Length) within 1-64 limit" }
    if ($name -match '^[a-z0-9]([a-z0-9\-]*[a-z0-9])?$' -and $name -notmatch '--') { Pass "'name' characters valid" }
    else { Fail "'name' invalid characters: '$name'" }
    if ($name -eq $dirName) { Pass "'name' matches directory name ('$dirName')" }
    else { Fail "'name' ('$name') does not match directory name ('$dirName')" }
}

# description
$desc = Get-Field "description"
if (-not $desc) { Fail "Required field 'description' is missing" }
else {
    $descLen = $desc.Length
    Pass "Field 'description' present ($descLen chars)"
    if ($descLen -lt 1 -or $descLen -gt 1024) { Fail "'description' length $descLen outside 1-1024 limit" }
    else { Pass "'description' length within 1-1024 limit" }
    if ($desc -match 'WHEN:') { Pass "'description' contains WHEN-trigger section" }
    else { Warn "'description' has no WHEN: section -- add WHEN: keywords to improve activation" }
}

# optional fields
foreach ($field in @("license","compatibility","allowed-tools")) {
    $val = Get-Field $field
    if ($val) {
        Pass "Optional field '$field' present"
        if ($field -eq "compatibility" -and $val.Length -gt 500) { Fail "'compatibility' exceeds 500 chars ($($val.Length))" }
    } else { Warn "Optional field '$field' not set (acceptable if not applicable)" }
}
if ($frontmatter -match "(?m)^metadata:") { Pass "Optional field 'metadata' block present" }
else { Warn "Optional field 'metadata' not set -- consider adding author and version" }

# body size
$lines  = (Get-Content $skillFile -Encoding UTF8).Count
$tokens = [int]($raw.Length / 4)
if ($lines -le 500) { Pass "SKILL.md body: $lines lines (<=500 recommended)" }
else { Warn "SKILL.md body: $lines lines exceeds 500-line recommendation" }
if ($tokens -le 5000) { Pass "Estimated token count: ~$tokens (<=5000 recommended)" }
else { Warn "Estimated token count: ~$tokens exceeds 5000-token recommendation" }

# directories
foreach ($subdir in @("references","assets","scripts","evals")) {
    $subdirPath = Join-Path $skillDir $subdir
    if (Test-Path $subdirPath) {
        Pass "Directory '$subdir/' present"
        if ($subdir -eq "references") {
            foreach ($rf in (Get-ChildItem $subdirPath -File -Recurse)) {
                if ($raw -match [regex]::Escape($rf.Name)) { Pass "  Reference '$($rf.Name)' has load trigger in SKILL.md" }
                else { Warn "  Reference '$($rf.Name)' has no load trigger in SKILL.md" }
            }
        }
        if ($subdir -eq "evals") {
            $evalsJson = Join-Path $subdirPath "evals.json"
            if (Test-Path $evalsJson) {
                Pass "  evals/evals.json present"
                try {
                    $ev = Get-Content $evalsJson -Raw | ConvertFrom-Json
                    $c = $ev.evals.Count
                    if ($c -ge 2) { Pass "  evals/evals.json has $c test cases (>=2)" }
                    else { Warn "  evals/evals.json has only $c test case(s) -- add at least 2" }
                } catch { Fail "  evals/evals.json is not valid JSON: $_" }
            } else { Warn "  evals/evals.json missing" }
        }
        if ($subdir -eq "scripts") {
            foreach ($s in (Get-ChildItem $subdirPath -File)) {
                if ($s.Length -eq 0) { Warn "  Script '$($s.Name)' is empty" }
                else { Pass "  Script '$($s.Name)' is non-empty" }
                if ($raw -match [regex]::Escape($s.Name)) { Pass "  Script '$($s.Name)' referenced in SKILL.md" }
                else { Warn "  Script '$($s.Name)' not referenced in SKILL.md" }
            }
        }
    } else { Warn "Directory '$subdir/' not present (optional -- add if applicable)" }
}

Write-Host ""
Write-Host "--- Results ---"
$passes   | ForEach-Object { Write-Host $_ -ForegroundColor Green }
$warnings | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
$errors   | ForEach-Object { Write-Host $_ -ForegroundColor Red }
Write-Host ""
Write-Host "Summary: $($passes.Count) passed, $($warnings.Count) warnings, $($errors.Count) errors"

if ($errors.Count -gt 0) { Write-Host "VALIDATION FAILED" -ForegroundColor Red; exit 1 }
else { Write-Host "VALIDATION PASSED" -ForegroundColor Green; exit 0 }