# Description Optimization

How to improve your skill's `description` field so it triggers reliably on relevant prompts.
Load this file when writing or testing the `description` field.

---

## Why the description matters

The description is the **only content loaded at startup**. The agent scans all skill descriptions to decide which (if any) to activate. If the description fails to match the user's prompt, the skill never activates — no matter how good the body content is.

---

## Description anatomy

A high-performing description has three parts:

```
[Capability statement] [Scope boundary] WHEN: [keyword list].
```

| Part | Purpose | Example |
|------|---------|---------|
| Capability statement | What the skill does | "Creates complete Agent Skills packages using all required and optional features." |
| Scope boundary | What it does NOT do (optional but useful for precise activation) | "Does not validate existing skills — only authors new ones." |
| WHEN keyword list | Exact phrases users type; quoted, comma-separated | `WHEN: "create a skill", "new skill", "SKILL.md", "skill author".` |

---

## WHEN-keyword strategy

Include keywords from these categories:

1. **User intent verbs** — what the user is trying to do: `create`, `write`, `build`, `author`, `design`
2. **Domain nouns** — the subject matter: `skill`, `agent skill`, `SKILL.md`, `agentskills`, `skill package`
3. **Trigger phrases** — multi-word phrases users commonly type: `"create a skill"`, `"new skill"`, `"skill template"`
4. **Adjacent concepts** — related terms that imply the need: `"optimize skill description"`, `"eval a skill"`, `"validate skill"`

**Avoid:**
- Generic words that appear in many contexts (`"help"`, `"create"`, `"code"` alone)
- Jargon the user would never type
- Overlapping keywords that duplicate what the capability statement already says

---

## Testing activation reliability

Run each of these test prompts and verify the skill activates:

| Test prompt | Expected result |
|-------------|----------------|
| `"Create a new agent skill for processing invoices"` | Activates |
| `"Write a SKILL.md for a PDF tool"` | Activates |
| `"Help me build an agentskills package"` | Activates |
| `"I want to optimize my skill description"` | Activates |
| `"How do I structure a skills-author skill?"` | Activates |
| `"Fix a bug in my TypeScript code"` | Does NOT activate |
| `"Run my CI pipeline"` | Does NOT activate |

**Pass criterion:** Skill activates on all relevant prompts. Skill does NOT activate on clearly unrelated prompts.

---

## Iteration workflow

1. Write an initial description using the anatomy template above.
2. Run the 5–7 activation test prompts.
3. For each prompt where the skill did NOT activate when it should have:
   - Identify what keyword was missing.
   - Add a WHEN-keyword that matches the unactivated prompt.
4. For each prompt where the skill DID activate when it should NOT have:
   - Check whether the capability statement is too broad.
   - Narrow the scope boundary or remove over-broad keywords.
5. Repeat until all test prompts pass.

---

## Character budget management

Max: 1,024 characters. Check your count:

```powershell
$desc = "your description here"
Write-Host "$($desc.Length)/1024 characters used"
```

**When near the limit:**
- Shorten the capability statement (cut adjectives, not nouns or keywords).
- Reduce WHEN-keywords to the 6–8 highest-value phrases.
- Never shorten the WHEN section at the cost of removing trigger keywords that users actually type.

---

## Common mistakes

| Mistake | Fix |
|---------|-----|
| Description describes the skill, not the user's task | Rewrite WHEN-keywords to match what users say, not what the skill does internally |
| WHEN list has synonyms of the capability statement | Replace synonyms with adjacent-concept keywords |
| Description is too short and vague | Add at least 5 specific WHEN-keywords |
| Description activates on unrelated tasks | Add a scope boundary sentence; remove overly generic keywords |
| Description exceeds 1,024 chars | Cut adjectives from the capability statement; keep all keywords |
