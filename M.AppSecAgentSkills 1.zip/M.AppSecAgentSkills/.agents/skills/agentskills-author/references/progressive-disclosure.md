# Progressive Disclosure

How to structure skill content so agents load context on demand rather than up front.
Load this file when the `SKILL.md` body exceeds 300 lines or when deciding what to move to `references/`.

---

## The three loading stages

| Stage | What loads | When it loads | Token target |
|-------|-----------|---------------|-------------|
| **Metadata** | `name` + `description` only | At startup, for every skill | ~100 tokens |
| **Instructions** | Full `SKILL.md` body | When the skill activates | < 5,000 tokens (≤ 500 lines) |
| **Resources** | Files in `references/`, `assets/`, `scripts/` | Only when the agent is told to read them | As needed |

The agent never reads reference files unless it is explicitly told when to load them. A reference file with no load trigger is dead content.

---

## Scope decision guide

A well-scoped skill encapsulates one coherent unit of work.

**Too narrow** (forces multiple skills to load for one task):
```
- skill: fill-pdf-form-field
- skill: validate-pdf-form-fields
- skill: submit-pdf-form
```

**Too broad** (hard to activate precisely):
```
- skill: do-everything-with-pdfs-and-also-database-admin
```

**Right:**
```
- skill: pdf-form-processing   # fills, validates, and submits a PDF form
```

**Questions to calibrate scope:**
1. Can you describe the skill's purpose in one sentence without using "and also"?
2. Does it activate on a coherent set of user prompts, not an unrelated mix?
3. Does it compose with other skills without overlapping their responsibilities?

---

## What belongs in `SKILL.md` vs. `references/`

### Keep in `SKILL.md`
- Gotchas — non-obvious environment facts the agent must know before starting
- Execution flow — the step-by-step procedure every run follows
- Output contract — the required output format
- Reference load triggers — explicit "read X when Y" instructions
- Short output templates that apply to every task

### Move to `references/`
- Detailed technical specifications that only apply in specific conditions
- Large tables (more than 20 rows)
- Domain-specific reference material (error codes, field schemas, API signatures)
- Long form examples that aren't needed for every run

### Move to `assets/`
- Full output templates (more than 30 lines)
- Static data files, lookup tables
- Reusable forms or structured data formats

---

## Writing effective load triggers

**Weak trigger (too generic — agent may never load it):**
```markdown
See `references/api-errors.md` for more details.
```

**Strong trigger (tells the agent exactly when and why):**
```markdown
Read `references/api-errors.md` if the API returns a non-200 status code.
```

**Pattern for every reference file:**
```markdown
- Read [references/FILE.md](references/FILE.md) when [specific condition].
```

Group all load triggers in one section in `SKILL.md` so the agent can scan them at a glance.

---

## Progressive disclosure checklist

- [ ] `SKILL.md` body is under 500 lines
- [ ] Estimated token count is under 5,000
- [ ] Every reference file has at least one explicit load trigger in `SKILL.md`
- [ ] Gotchas are in `SKILL.md` — not in a reference file
- [ ] Output contract is in `SKILL.md`
- [ ] Long templates are in `assets/` with an explicit load trigger
- [ ] Scripts are in `scripts/` with exact invocation instructions

---

## Estimating token count

Rough estimate: 1 token ≈ 4 characters of English prose. For a 500-line SKILL.md with ~80 characters per line:

```
500 lines × 80 chars/line ÷ 4 chars/token ≈ 10,000 tokens
```

That exceeds the 5,000-token recommendation. Aim for ~250 lines of dense content or ~350 lines of sparse content with blank lines and headers.

**Quick check in PowerShell:**
```powershell
$content = Get-Content "SKILL.md" -Raw
Write-Host "Chars: $($content.Length)"
Write-Host "Estimated tokens: $([int]($content.Length / 4))"
Write-Host "Lines: $((Get-Content 'SKILL.md').Count)"
```
