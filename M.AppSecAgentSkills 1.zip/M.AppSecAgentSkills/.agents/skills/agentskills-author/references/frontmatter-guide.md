# Frontmatter Guide

Complete field rules, constraints, and examples for the Agent Skills `SKILL.md` frontmatter.
Load this file when setting or validating any frontmatter field.

---

## Field summary

| Field | Required | Max length | Notes |
|-------|----------|------------|-------|
| `name` | Yes | 64 chars | Lowercase, `a-z 0-9 -` only; must match directory name |
| `description` | Yes | 1024 chars | Activation signal — must include WHEN-trigger keywords |
| `license` | No | — | Short license name or reference to bundled `LICENSE.txt` |
| `compatibility` | No | 500 chars | Only if skill has specific environment requirements |
| `metadata` | No | — | Arbitrary string key-value pairs |
| `allowed-tools` | No | — | Experimental; space-separated tool names |

---

## `name` field

**Constraints:**
- 1–64 characters
- Only `a-z`, `0-9`, `-` (hyphen)
- Must not start or end with a hyphen
- Must not contain consecutive hyphens (`--`)
- Must exactly match the parent directory name (case-sensitive)

**Valid:**
```yaml
name: agentskills-author
name: pdf-processing
name: nist-ssdf
```

**Invalid:**
```yaml
name: PDF-Processing     # uppercase
name: -my-skill          # starts with hyphen
name: my--skill          # consecutive hyphens
name: my skill           # space not allowed
```

**Validation command:**
```powershell
# Check name matches directory and passes all constraints
$name = "agentskills-author"
$dir  = Split-Path -Leaf (Get-Item ".agents/skills/agentskills-author")
$name -eq $dir                          # must be true
$name -match '^[a-z0-9]([a-z0-9-]*[a-z0-9])?$'  # must be true
-not ($name -match '--')                # must be true
```

---

## `description` field

**Constraints:**
- 1–1024 characters
- Must describe what the skill does AND when to use it
- Must include WHEN-trigger keywords (words users will actually type)
- Loaded at startup for all skills — this is the only activation signal

**Pattern for high-activation descriptions:**
```
[What the skill does in 1-2 sentences.] WHEN: "[keyword1]", "[keyword2]", "[keyword3]".
```

**Good:**
```yaml
description: "Creates complete Agent Skills packages applying all required and optional
  features from the agentskills.io specification. WHEN: \"create a skill\", \"new skill\",
  \"SKILL.md\", \"skill author\"."
```

**Poor:**
```yaml
description: Helps with skills.
```

**Testing the description:**
Run at least 5 realistic user prompts through the agent and verify the skill activates on all of them. See [description-optimization.md](description-optimization.md) for the full testing workflow.

**Character count check:**
```powershell
$desc = "your description here"
Write-Host "Length: $($desc.Length)/1024"
```

---

## `license` field

**Constraints:**
- Optional
- Keep short: either an SPDX license name or the name of a bundled license file

**Examples:**
```yaml
license: MIT
license: Apache-2.0
license: Proprietary. LICENSE.txt has complete terms.
```

**When to set it:** Always set `license` for skills intended for shared use or publication. Use `MIT` as the default for open-contribution skills in this repository.

---

## `compatibility` field

**Constraints:**
- Optional
- 1–500 characters if provided
- Only include if the skill has specific environment requirements

**Use it when the skill:**
- Requires a specific agent product (Claude Code, VS Code Copilot)
- Requires system packages (`git`, `docker`, `uv`, `pwsh`)
- Requires network access to specific services
- Requires a specific runtime version

**Do NOT include it for skills that work in any environment.**

**Examples:**
```yaml
compatibility: "Designed for Claude Code and VS Code Copilot agent."
compatibility: "Requires Python 3.12+, uv, and internet access to PyPI."
compatibility: "Designed for Claude Code in Molina Azure DevOps environments. Requires SonarQube, Wiz, PAM."
```

---

## `metadata` field

**Constraints:**
- Optional
- Map of string keys to string values
- Make key names reasonably unique to avoid conflicts across skills

**Recommended keys for this repository:**
```yaml
metadata:
  author: M.AppSecAgentSkills       # team or org that owns the skill
  version: "1.0"                    # increment on breaking changes
  source-spec: "https://..."        # link to authoritative specification
  argument-hint: "--flag VALUE"     # shown in CLI help (if applicable)
  user-invocable: "true"            # whether users can call this directly
```

**Version bump trigger:** Increment the version when the skill's execution flow, output contract, or required inputs change in a way that would break existing callers.

---

## `allowed-tools` field

**Constraints:**
- Optional
- Experimental — support varies between clients
- Space-separated string of tool names

**Examples:**
```yaml
allowed-tools: Read
allowed-tools: Bash(git:*) Bash(jq:*) Read
allowed-tools: Bash Write Read
```

**Decision guide:**
- Use `Read` for skills that only need to read files (most instructional skills).
- Add `Bash(cmd:*)` to pre-approve specific shell commands.
- Do not use `Bash` (unrestricted) without a strong reason — prefer scoped patterns.
- This field does not replace user consent for destructive operations.

---

## Minimal valid example

```yaml
---
name: my-skill
description: "Does X and Y. Use when the user asks about X, Y, or mentions Z."
---
```

## Full example (all fields)

```yaml
---
name: agentskills-author
description: "Creates complete Agent Skills packages. WHEN: \"create a skill\", \"SKILL.md\"."
license: MIT
compatibility: "Designed for Claude Code and VS Code Copilot agent. Optional: skills-ref CLI."
metadata:
  author: example-org
  version: "1.0"
  source-spec: "https://agentskills.io/specification"
allowed-tools: Read
---
```
