# Eval-Driven Iteration

How to test whether your skill produces good outputs using structured evaluations.
Load this file when designing test cases or grading eval results.

---

## Overview

Evals answer three questions:
1. Does the skill produce correct output on realistic prompts?
2. Is the output reliably better than without the skill?
3. What should change to improve the next iteration?

---

## `evals/evals.json` format

Store all test cases in `evals/evals.json` inside the skill directory:

```json
{
  "skill_name": "agentskills-author",
  "evals": [
    {
      "id": 1,
      "prompt": "Create a new agent skill called invoice-processor that extracts line items from PDF invoices.",
      "expected_output": "A complete skill directory with valid SKILL.md frontmatter (all 6 fields), at least one reference file, an assets template, and evals/evals.json with 2+ test cases.",
      "files": []
    },
    {
      "id": 2,
      "prompt": "I want to write a skill that helps my team run SonarQube scans. The skill should work in Azure DevOps.",
      "expected_output": "SKILL.md with compatibility field set for Azure DevOps, allowed-tools includes relevant tools, and WHEN-keywords include sonarqube and scan-related terms.",
      "files": []
    },
    {
      "id": 3,
      "prompt": "My skill description isn't triggering reliably. Help me optimize it.",
      "expected_output": "Applies description-optimization.md workflow: tests activation on 5+ prompts, identifies missing keywords, proposes revised description within 1024 chars.",
      "files": []
    }
  ]
}
```

**Test case tips:**
- Start with 2–3 cases. Expand after first results.
- Vary phrasing: casual (`"hey build me a skill"`), precise, edge-case.
- At least one edge case: ambiguous request, near-limit description, skill with no scripts needed.

---

## Workspace structure

```
agentskills-author/
├── SKILL.md
└── evals/
    └── evals.json
agentskills-author-workspace/
└── iteration-1/
    ├── eval-invoice-processor/
    │   ├── with_skill/
    │   │   ├── outputs/
    │   │   ├── timing.json
    │   │   └── grading.json
    │   └── without_skill/
    │       ├── outputs/
    │       ├── timing.json
    │       └── grading.json
    └── benchmark.json
```

---

## Running a single eval

Provide these instructions to a fresh subagent (clean context, no session history):

```
Execute this task:
- Skill path: .agents/skills/agentskills-author
- Task: [test prompt from evals.json]
- Input files: [if any]
- Save outputs to: agentskills-author-workspace/iteration-1/eval-[id]/with_skill/outputs/
```

For the baseline (without skill), use the same prompt, no skill path, save to `without_skill/outputs/`.

**Isolation requirement:** Each run must start from a clean context. Use a subagent or new session. Leftover state from skill development invalidates comparisons.

---

## Capturing timing data

Record immediately after each run:

```json
{
  "total_tokens": 12400,
  "duration_ms": 8200
}
```

Save to `with_skill/timing.json` and `without_skill/timing.json`.

---

## Writing assertions

Add assertions after seeing the first round of outputs. Good assertions are objectively verifiable.

```json
"assertions": [
  "SKILL.md frontmatter contains all 6 fields (name, description, license, compatibility, metadata, allowed-tools)",
  "name field value matches the skill directory name",
  "description length is between 1 and 1024 characters",
  "SKILL.md body is under 500 lines",
  "evals/evals.json is present and contains at least 2 test cases",
  "At least one reference file has an explicit load trigger in SKILL.md"
]
```

**Weak assertions to avoid:**
- `"The output is good"` — too vague
- `"Uses exactly the phrase X"` — too brittle

---

## Grading results

For each assertion, record in `grading.json`:

```json
{
  "eval_id": 1,
  "variant": "with_skill",
  "assertions": [
    { "assertion": "SKILL.md frontmatter contains all 6 fields", "result": "PASS", "notes": "" },
    { "assertion": "description length is under 1024 chars", "result": "PASS", "notes": "847 chars" },
    { "assertion": "evals/evals.json present with 2+ cases", "result": "FAIL", "notes": "evals.json missing" }
  ],
  "overall": "FAIL"
}
```

---

## Iteration decision rules

| Result | Action |
|--------|--------|
| All assertions PASS, output better than baseline | Ship the skill increment |
| 1–2 assertions FAIL, clear root cause | Fix targeted issue, re-run affected evals only |
| Multiple failures, unclear cause | Add failing case to Gotchas in `SKILL.md`; refine execution flow; re-run full suite |
| Baseline equals or beats with-skill | Skill may be redundant; audit whether description is activating unnecessarily |

---

## Benchmark summary

After all evals in an iteration, write `benchmark.json`:

```json
{
  "iteration": 1,
  "skill_name": "agentskills-author",
  "evals_run": 3,
  "with_skill_pass_rate": 0.83,
  "without_skill_pass_rate": 0.33,
  "avg_token_delta": "+1200 tokens",
  "conclusion": "Skill improves output quality on 2/3 cases. Eval 3 (description optimization) needs stronger Gotcha."
}
```
