---
name: nist-ssdf
license: MIT
description: "Applies NIST SSDF SP 800-218 across 19 practices and 42 tasks for secure software development lifecycles, compliance audits, and vulnerability response. WHEN: \"SSDF\", \"SP 800-218\", \"NIST compliance\", \"secure SDLC\", \"software supply chain\", \"vulnerability response\", \"secure coding practices\", \"federal compliance\"."
allowed-tools: Read
compatibility: "Designed for Claude Code. Requires access to project CI/CD artifacts and SSDF evidence directories."
metadata:
  author: peaceful-robot
  version: "1.1"
---

# NIST SSDF (Secure Software Development Framework)

NIST SP 800-218 defines 19 practices across 4 groups for building secure software, emphasizing risk-based application and SDLC integration. Use this skill to apply, audit, or implement any SSDF practice.

## Automation profile (merged from legacy ssdf-compliance)

Use this profile when the request is evidence collection, release gating, or audit packaging.

- Map project artifacts to SSDF checklist tasks.
- Collect evidence from CI/CD and security tools (for example SAST/DAST exports).
- Build an audit package organized by PO, PS, PW, and RV.

Suggested invocation pattern:
- `--project-path PATH --practice PO|PS|PW|RV`

See [automation-playbook.md](references/automation-playbook.md) for CI/CD checkpoints, SDLC phase validations, supported tools, and required evidence artifacts.

## Gotchas

- **PW.3 does not exist in SSDF 1.0.** It was intentionally reserved. Do not invent a control for it; the numbering gap is deliberate.
- **SSDF is risk-based, not a rigid checklist.** Each task has flexibility — an organization may choose not to implement a task if the associated risk is accepted and documented. Never imply all 42 tasks are always mandatory.
- **Evidence collection ≠ control implementation.** Gathering artifacts proves nothing unless they demonstrate the control was actually applied to the specific project under review.
- **SSDF practices cross-reference each other.** PW.4 (reuse) depends on PO.3 (toolchains). Validate dependencies when a practice is partially implemented.

## How to use this skill

**Skill check:** Before making a decision or asking a question, read this skill's checklist/references and confirm which skill(s) are relevant. In your output, include a `Skills used:` line naming the skill(s) and the specific section(s) relied upon. Only ask follow-up questions if the skill guidance still leaves you needing more input.

1. Identify the relevant practice group and practice from the routing table below
2. Read the linked reference file for that practice
3. Apply the tasks defined in that file
4. Use [SSDF-Checklist.md](SSDF-Checklist.md) to track overall compliance

## Cross-framework integration

Use this section when a request spans SSDF, 218A, and Molina controls.

Execution loop:
1. Identify project scope (software-only, AI-enabled, or Molina-governed).
2. Confirm active frameworks and checklist sources.
3. Correlate overlapping controls and identify conflicts.
4. Produce prioritized gaps with required evidence.
5. Emit a gate decision (`PASS`, `CONDITIONAL`, `FAIL`).

Evidence orchestration:
- Governance evidence: approvals, owners, role assignments.
- Design evidence: architecture, trust boundaries, control mappings.
- Validation evidence: SAST, DAST, and AI test outputs with remediation status.
- Release evidence: gate decision, exceptions, and follow-up owners.

Gate decision criteria:
- `PASS`: required controls met with verifiable evidence.
- `CONDITIONAL`: non-critical gaps with owner and due date.
- `FAIL`: critical blockers or missing mandatory evidence.

Cross-framework correlation quick map:
- SSDF PO/PW controls commonly align with Molina PRE/P2B readiness and testing gates.
- SSDF secure design/testing controls align with 218A AI risk and AI testing controls.
- Molina approvals provide organizational evidence that complements SSDF/218A controls.

## Project onboarding and framework selection

Use this intake for new projects before detailed SSDF routing:
- Project type: traditional software, AI-enabled software, or enterprise healthcare system.
- Primary stack: language, framework, deployment model, and data sensitivity.
- AI scope: none, inference-only, fine-tuning, or model development.
- Regulatory context: internal policy, healthcare/PII/PHI, or additional regulation.

Framework selection rules:
1. Always include SSDF.
2. Add 218A when AI models, training data, model weights, or AI pipelines are in scope.
3. Add Molina AppSec when Molina phase-gate governance applies.

Evidence blueprint:
- `Project-Docs/Project-Info/`
- `Project-Docs/SSDF-Evidence/`
- `Project-Docs/AI-Security-Evidence/` (when 218A applies)
- `Project-Docs/Molina-Compliance/` (when Molina applies)
- `Project-Docs/Security-Testing/`
- `Project-Docs/Audit-Packages/`

## Cross-framework output template

```markdown
Skills used: nist-ssdf (Cross-framework integration, Project onboarding and framework selection)

Scope:
- Project type: <traditional|ai|enterprise>
- Frameworks: <SSDF|218A|Molina>

Coverage Summary:
- SSDF: <covered/missing>
- 218A: <covered/missing>
- Molina: <covered/missing>

Decision:
- Gate: <PR|Sprint|Release|Audit>
- Result: <PASS|CONDITIONAL|FAIL>

Critical Gaps:
- <control-id>: <gap and impact>

Required Evidence:
- <artifact>: <owner> | <due>
```

## Templates and related skills

- SDLC gap register template: [assets/SDLC-Gap-Register-Template.md](assets/SDLC-Gap-Register-Template.md)
- Molina gate operations: [../molina-application-security/SKILL.md](../molina-application-security/SKILL.md)
- AI-specific controls: [../nist-218a/SKILL.md](../nist-218a/SKILL.md)

## Topic routing

### Prepare the Organization (PO)

| Practice | Task | Read |
|----------|------|------|
| PO.1 — Security requirements | Define/document security requirements, e.g., policies for securing infrastructures, risk-based software architecture | [PO_1.md](references/PO_1.md) — read when security requirements definition or policy review is in scope |
| PO.2 — Roles and responsibilities | Define roles, training, management commitment | [PO_2.md](references/PO_2.md) — read when roles, training, or management commitment is in scope |
| PO.3 — Supporting toolchains | Select, configure, maintain security tools, e.g., automated toolchains for SDLC | [PO_3.md](references/PO_3.md) — read when toolchain selection, configuration, or maintenance is in scope |
| PO.4 — Security check criteria | Define and track security check criteria | [PO_4.md](references/PO_4.md) — read when security check criteria or thresholds are in scope |
| PO.5 — Secure environments | Separate and harden development environments, e.g., secure endpoints, monitor performance | [PO_5.md](references/PO_5.md) — read when development environment security or access hardening is in scope |

### Protect the Software (PS)

| Practice | Task | Read |
|----------|------|------|
| PS.1 — Protect code | Least-privilege access to all code forms | [PS_1.md](references/PS_1.md) — read when code access control or least-privilege is in scope |
| PS.2 — Release integrity | Provide integrity verification for releases | [PS_2.md](references/PS_2.md) — read when release signing or integrity verification is in scope |
| PS.3 — Archive releases | Archive releases with provenance data (SBOM), e.g., integrity verification, SBOM | [PS_3.md](references/PS_3.md) — read when archiving, SBOM, or provenance records are in scope |

### Produce Well-Secured Software (PW)

| Practice | Task | Read |
|----------|------|------|
| PW.1 — Secure design | Threat modeling, risk assessment, security requirements, e.g., attack surface mapping | [PW_1.md](references/PW_1.md) — read when threat modeling or attack surface review is in scope |
| PW.2 — Design review | Qualified review of design against security requirements | [PW_2.md](references/PW_2.md) — read when design review or security architecture sign-off is in scope |
| PW.4 — Reuse software | Acquire, verify, and maintain third-party components, e.g., verify compliance with requirements | [PW_4.md](references/PW_4.md) — read when third-party components, OSS, or supply chain are in scope. **See also:** [supply-chain-package-defense](../supply-chain-package-defense/SKILL.md) for worm-specific threat vectors (malicious build scripts, OIDC token theft, cache poisoning, cross-ecosystem propagation) and ecosystem-specific hardening controls (WD-P2B-01 through WD-P2B-10). |
| PW.5 — Secure coding | Follow secure coding practices for the language/environment | [PW_5.md](references/PW_5.md) — read when coding standards or language-specific secure coding is in scope |
| PW.6 — Build security | Configure compilers and build tools for executable security | [PW_6.md](references/PW_6.md) — read when build configuration or compiler security flags are in scope |
| PW.7 — Code review | Human review and/or automated analysis of source code, e.g., static analysis | [PW_7.md](references/PW_7.md) — read when static analysis or human code review is in scope |
| PW.8 — Executable testing | Test executable code for vulnerabilities, e.g., dynamic analysis, fuzzing | [PW_8.md](references/PW_8.md) — read when dynamic testing, fuzzing, or DAST is in scope |
| PW.9 — Secure defaults | Configure software with secure settings by default | [PW_9.md](references/PW_9.md) — read when default settings or hardened configurations are in scope |

### Respond to Vulnerabilities (RV)

| Practice | Task | Read |
|----------|------|------|
| RV.1 — Identify vulnerabilities | Gather, investigate, and disclose vulnerability reports, e.g., from public sources | [RV_1.md](references/RV_1.md) — read when vulnerability intake, disclosure, or reporting is in scope |
| RV.2 — Remediate vulnerabilities | Assess, prioritize, and fix vulnerabilities, e.g., plan remediation | [RV_2.md](references/RV_2.md) — read when vulnerability prioritization or patch planning is in scope |
| RV.3 — Root cause analysis | Analyze root causes and fix vulnerability classes, e.g., identify systemic issues | [RV_3.md](references/RV_3.md) — read when systemic root cause analysis is in scope |

## Available resources

Reference files (load only when explicitly needed):
- [SSDF-Checklist.md](SSDF-Checklist.md) — all 42 tasks with status-tracking links
- [assets/SDLC-Gap-Register-Template.md](assets/SDLC-Gap-Register-Template.md) — compliance gap tracking template
- [references/automation-playbook.md](references/automation-playbook.md) — CI/CD checkpoints, evidence artifacts, supported tools
- `references/PO_1.md` through `references/PO_5.md` — individual PO practice files
- `references/PS_1.md` through `references/PS_3.md` — individual PS practice files
- `references/PW_1.md` through `references/PW_9.md` — individual PW practice files (PW.3 intentionally absent)
- `references/RV_1.md` through `references/RV_3.md` — individual RV practice files

## Full checklist

See [SSDF-Checklist.md](SSDF-Checklist.md) for all 42 tasks with links to individual task files.
