# NIST SSDF (Secure Software Development Framework)

This folder contains documentation, templates, and checklists for implementing the NIST SSDF (SP 800-218) practices.

## SSDF Statistics
- **Practice Groups:** 4
- **Practices:** 19
- **Tasks:** 42



## Practice Groups and Practices

1. **Prepare the Organization (PO)**
	- PO.1: Define Security Requirements for Software Development
	- PO.2: Implement Roles and Responsibilities
	- PO.3: Implement Supporting Toolchains
	- PO.4: Define and Use Criteria for Software Security Checks
	- PO.5: Implement and Maintain Secure Environments for Software Development

2. **Protect the Software (PS)**
	- PS.1: Protect All Forms of Code from Unauthorized Access and Tampering
	- PS.2: Provide a Mechanism for Verifying Software Release Integrity
	- PS.3: Archive and Protect Each Software Release

3. **Produce Well-Secured Software (PW)**
	- PW.1: Design Software to Meet Security Requirements and Mitigate Security Risks
	- PW.2: Review the Software Design to Verify Compliance with Security Requirements and Risk Information
	- PW.4: Reuse Existing, Well-Secured Software When Feasible Instead of Duplicating Functionality
	- PW.5: Create Source Code by Adhering to Secure Coding Practices
	- PW.6: Configure the Compilation, Interpreter, and Build Processes to Improve Executable Security
	- PW.7: Review and/or Analyze Human-Readable Code to Identify Vulnerabilities and Verify Compliance with Security Requirements
	- PW.8: Test Executable Code to Identify Vulnerabilities and Verify Compliance with Security Requirements
	- PW.9: Configure Software to Have Secure Settings by Default

4. **Respond to Vulnerabilities (RV)**
	- RV.1: Identify and Confirm Vulnerabilities on an Ongoing Basis
	- RV.2: Assess, Prioritize, and Remediate Vulnerabilities
	- RV.3: Analyze Vulnerabilities to Identify Their Root Causes

Refer to the official [NIST SSDF documentation](https://csrc.nist.gov/publications/detail/sp/800-218/final) for details.
