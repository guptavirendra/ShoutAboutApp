# PW.9: Configure Software to Have Secure Settings by Default

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Define a secure baseline configuration for the software and implement it as the default. Users should not need to take additional steps to be secure — insecurity should require deliberate opt-in.

## Tasks

- [PW.9.1](PW_9_1.md) — Define a secure baseline configuration
- [PW.9.2](PW_9_2.md) — Implement and document secure default settings

## Acceptance criteria

- [ ] Secure baseline configuration defined for all configurable settings
- [ ] Default configuration is secure without additional steps
- [ ] Insecure options require explicit opt-in and are documented
