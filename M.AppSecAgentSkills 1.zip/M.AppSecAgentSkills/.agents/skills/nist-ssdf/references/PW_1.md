# PW.1: Design Software to Meet Security Requirements and Mitigate Security Risks

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Incorporate security into the design phase through risk modeling, documented security decisions, and use of standardized security services rather than custom implementations.

## Tasks

- [PW.1.1](PW_1_1.md) — Perform risk modeling (threat modeling, attack surface mapping)
- [PW.1.2](PW_1_2.md) — Track security requirements, risks, and design decisions
- [PW.1.3](PW_1_3.md) — Use standardized security features and services

## Acceptance criteria

- [ ] Threat model completed for each significant feature or system
- [ ] Security design decisions documented and traceable
- [ ] Standardized security services used instead of custom implementations
