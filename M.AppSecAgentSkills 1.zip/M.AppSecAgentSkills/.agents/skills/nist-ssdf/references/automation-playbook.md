# NIST SSDF Automation Playbook

Source: `01-SSDF/AGENTS.md`

## Core validation workflow

For every SSDF compliance run:
1. Parse `SSDF-Checklist.md` for current completion status.
2. Cross-reference development artifacts and tool outputs against each practice.
3. Identify gaps: critical (required now), implementation (partially done), evidence (done but undocumented), tool-integration (lacking automation).
4. Generate prioritized remediation recommendations with specific actions.
5. Update compliance dashboard with current status.

## Evidence gathering categories

**Automated collection sources:**
- CI/CD pipeline results: build logs, test results, deployment configurations
- Security tool outputs: SAST/DAST scan results, dependency check reports
- Documentation systems: architecture diagrams, security reviews, training records
- Issue tracking: vulnerability reports, remediation tracking, security tasks

**Artifact handling rules:**
- Map each artifact to one or more SSDF practice IDs.
- Maintain audit trails showing collection timestamps.
- Version compliance artifacts alongside code.
- Assemble evidence packages organized by PO, PS, PW, and RV groups.

## CI/CD pipeline checkpoints

| Pipeline stage | Primary practices | Action |
|---|---|---|
| Pre-commit | PW.5 | Validate secure coding standards and linting rules |
| Build | PS.3, PW.6 | Dependency scanning; build integrity and reproducibility checks |
| Test | PW.7, PW.8 | SAST/DAST execution; security test results reviewed; critical findings resolved |
| Deploy | PW.9 | Secure-defaults configuration validation; runtime protection verification |

## SDLC phase security validations

### Before each sprint
1. **PO.1 — Training**: Check developer training status and certification currency.
2. **PW.1 — Secure design**: Verify threat model reflects planned changes.
3. **PO.3 — Toolchain**: Confirm security tools are properly configured.
4. **PO.2/PO.4 — Roles**: Check role assignments and security criteria are current.

### During development
1. **PW.5 — Secure coding**: Validate secure coding practices and review completion.
2. **PW.7/PW.8 — Testing**: Verify security tests are executed and results reviewed.
3. **PW.9 — Configuration**: Check secure-defaults configuration practices.
4. **RV.1 — Monitoring**: Monitor for new vulnerabilities; track remediation.

### Before release
1. **PW.8 — Final testing**: Complete penetration testing and security validation.
2. **PW.9 — Config review**: Validate production configuration security.
3. **RV.1 — Monitoring**: Confirm runtime security monitoring is operational.
4. **All groups — Documentation**: Verify all required security artifacts are complete.

## Supported SAST/DAST tools

SonarQube, Fortify, Coverity, Checkmarx, Veracode, OWASP ZAP

Integration workflow:
1. Parse tool output to extract vulnerability and quality metrics.
2. Map findings to SSDF practices (primarily PW.7, PW.8, RV.1).
3. Track remediation status and validate fix verification.
4. Generate compliance evidence showing security testing coverage.

## Required evidence artifacts by practice group

**PO (Prepare):**
- Developer training completion certificates and records
- Security role assignment documentation
- Secure coding standards and review checklists
- Tool configuration records and validation outputs

**PS (Protect):**
- Architecture diagrams with security components
- Data flow documentation with security controls
- Access control policy records
- Release integrity verification records and SBOMs

**PW (Produce):**
- Threat models and risk assessment records
- SAST/DAST scan results and remediation evidence
- Code review records and approval logs
- Build configuration security records
- Test execution results and coverage reports

**RV (Respond):**
- Vulnerability monitoring alerts and response records
- Remediation plans with timelines and owners
- Re-test evidence confirming vulnerability closure
- Root cause analysis documents and systemic fix records
