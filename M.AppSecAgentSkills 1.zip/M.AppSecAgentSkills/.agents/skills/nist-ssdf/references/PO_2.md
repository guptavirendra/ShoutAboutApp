# PO.2: Implement Roles and Responsibilities

**Framework:** NIST SSDF
**Practice Group:** Prepare the Organization

## What this practice requires

Define and assign security responsibilities across all roles involved in software development. Everyone who contributes to the SDLC must understand their security obligations.

## Tasks

- [PO.2.1](PO_2_1.md) — Define roles and responsibilities covering all SDLC phases
- [PO.2.2](PO_2_2.md) — Provide role-based security training
- [PO.2.3](PO_2_3.md) — Obtain and communicate management commitment

## Acceptance criteria

- [ ] Security responsibilities documented for every SDLC role
- [ ] Role-based training program exists and is current
- [ ] Management commitment to secure development is documented and communicated
