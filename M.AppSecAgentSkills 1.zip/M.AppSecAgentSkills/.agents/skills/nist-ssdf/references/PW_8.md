# PW.8: Test Executable Code to Identify Vulnerabilities

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Test running software for vulnerabilities that static analysis cannot find: runtime behavior, configuration issues, and vulnerabilities that only manifest under specific conditions.

## Tasks

- [PW.8.1](PW_8_1.md) — Determine which executable code testing to perform
- [PW.8.2](PW_8_2.md) — Scope, design, perform, and document testing

## Acceptance criteria

- [ ] Executable code testing approach defined
- [ ] Testing performed before each release
- [ ] Findings documented and tracked to resolution
