# PO.3: Implement Supporting Toolchains

**Framework:** NIST SSDF
**Practice Group:** Prepare the Organization

## What this practice requires

Define, deploy, and maintain the security toolchain that supports secure software development. Tools must be specified, integrated, configured to produce evidence, and operated securely.

## Tasks

- [PO.3.1](PO_3_1.md) — Specify required tools and their integration
- [PO.3.2](PO_3_2.md) — Deploy and maintain tools securely
- [PO.3.3](PO_3_3.md) — Configure tools to generate compliance artifacts

## Acceptance criteria

- [ ] Required security tools specified for each SDLC phase
- [ ] Tools deployed and integrated into the development workflow
- [ ] Tools operated securely (patched, access-controlled, monitored)
- [ ] Tools configured to produce artifacts demonstrating security activities
