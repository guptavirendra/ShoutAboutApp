# PO.5: Implement and Maintain Secure Environments for Software Development

**Framework:** NIST SSDF
**Practice Group:** Prepare the Organization

## What this practice requires

Ensure that the environments used to develop, build, test, and deploy software are separated from each other and from production, and that developer endpoints are hardened against compromise.

## Tasks

- [PO.5.1](PO_5_1.md) — Separate and protect each development environment
- [PO.5.2](PO_5_2.md) — Secure and harden developer endpoints

## Acceptance criteria

- [ ] Development, test, staging, and production environments are separated
- [ ] Each environment has appropriate access controls
- [ ] Developer endpoints are hardened per a defined baseline
