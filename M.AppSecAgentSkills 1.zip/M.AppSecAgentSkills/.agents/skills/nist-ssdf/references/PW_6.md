# PW.6: Configure the Build Process to Improve Executable Security

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Configure compilers, interpreters, and build tools to produce executables with security hardening features enabled. The build process is the last opportunity to add protections before code ships.

## Tasks

- [PW.6.1](PW_6_1.md) — Use build tools that offer security features
- [PW.6.2](PW_6_2.md) — Configure and use approved security settings

## Acceptance criteria

- [ ] Build tools with security hardening features selected
- [ ] Security hardening flags configured and enforced in build system
- [ ] Configuration documented and version-controlled
