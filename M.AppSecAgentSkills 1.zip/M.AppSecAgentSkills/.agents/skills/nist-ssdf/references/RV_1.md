# RV.1: Identify and Confirm Vulnerabilities on an Ongoing Basis

**Framework:** NIST SSDF
**Practice Group:** Respond to Vulnerabilities

## What this practice requires

Continuously monitor for vulnerabilities in the software and its dependencies. Investigate all credible reports. Have a policy and process for receiving and responding to vulnerability disclosures.

## Tasks

- [RV.1.1](RV_1_1.md) — Gather and investigate vulnerability information from all sources
- [RV.1.2](RV_1_2.md) — Review and test code to identify previously undetected vulnerabilities
- [RV.1.3](RV_1_3.md) — Maintain a vulnerability disclosure and remediation policy

## Acceptance criteria

- [ ] Vulnerability monitoring covers all dependencies and components
- [ ] All credible vulnerability reports investigated within defined SLA
- [ ] Vulnerability disclosure policy published and operational
