# RV.3: Analyze Vulnerabilities to Identify Their Root Causes

**Framework:** NIST SSDF
**Practice Group:** Respond to Vulnerabilities

## What this practice requires

After remediating a vulnerability, analyze its root cause to prevent recurrence. Fix the class of vulnerability, not just the instance.

## Tasks

- [RV.3.1](RV_3_1.md) — Analyze root causes of identified vulnerabilities
- [RV.3.2](RV_3_2.md) — Identify patterns across root causes over time
- [RV.3.3](RV_3_3.md) — Review for similar vulnerabilities and fix proactively
- [RV.3.4](RV_3_4.md) — Update the SDLC process to prevent recurrence

## Acceptance criteria

- [ ] Root cause analysis performed for all significant vulnerabilities
- [ ] Patterns identified and addressed systematically
- [ ] Codebase audited for similar vulnerabilities after each finding
- [ ] SDLC process updated to prevent recurrence
