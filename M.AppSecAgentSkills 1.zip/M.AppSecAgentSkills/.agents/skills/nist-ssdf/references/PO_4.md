# PO.4: Define and Use Criteria for Software Security Checks

**Framework:** NIST SSDF
**Practice Group:** Prepare the Organization

## What this practice requires

Define explicit, measurable criteria for security checks at each stage of the SDLC. Track whether criteria are met throughout development and use the results to gate releases.

## Tasks

- [PO.4.1](PO_4_1.md) — Define security check criteria and track throughout SDLC
- [PO.4.2](PO_4_2.md) — Implement processes to gather and safeguard supporting information

## Acceptance criteria

- [ ] Security check criteria defined for each SDLC gate
- [ ] Criteria tracked and reported throughout development
- [ ] Supporting information gathered and protected
