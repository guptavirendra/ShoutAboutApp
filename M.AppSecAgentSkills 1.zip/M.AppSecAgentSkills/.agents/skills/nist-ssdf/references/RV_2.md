# RV.2: Assess, Prioritize, and Remediate Vulnerabilities

**Framework:** NIST SSDF
**Practice Group:** Respond to Vulnerabilities

## What this practice requires

Once a vulnerability is confirmed, assess its risk in context, prioritize it against other vulnerabilities, and implement an appropriate response within defined timeframes.

## Tasks

- [RV.2.1](RV_2_1.md) — Analyze each vulnerability to assess risk and plan response
- [RV.2.2](RV_2_2.md) — Plan and implement risk responses

## Acceptance criteria

- [ ] All confirmed vulnerabilities assessed for contextual risk
- [ ] Vulnerabilities prioritized and assigned remediation deadlines
- [ ] Risk responses implemented within defined SLAs
