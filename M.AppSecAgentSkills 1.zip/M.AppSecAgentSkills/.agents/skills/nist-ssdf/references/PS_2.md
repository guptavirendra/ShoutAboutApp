# PS.2: Provide a Mechanism for Verifying Software Release Integrity

**Framework:** NIST SSDF
**Practice Group:** Protect the Software

## What this practice requires

Provide acquirers and users with a way to verify that the software they received has not been tampered with since it was released.

## Tasks

- [PS.2.1](PS_2_1.md) — Make integrity verification information available to acquirers

## Acceptance criteria

- [ ] Cryptographic signatures or checksums published for every release
- [ ] Verification instructions documented and accessible
- [ ] Signing keys are protected and their use is audited
