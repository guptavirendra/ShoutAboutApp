# PS.1: Protect All Forms of Code from Unauthorized Access and Tampering

**Framework:** NIST SSDF
**Practice Group:** Protect the Software

## What this practice requires

Apply access controls and integrity protections to all forms of code: source code, compiled binaries, configuration-as-code, infrastructure-as-code, and build scripts. Unauthorized modification of any of these can introduce vulnerabilities or backdoors.

## Tasks

- [PS.1.1](PS_1_1.md) — Store code with least-privilege access controls

## Acceptance criteria

- [ ] All code repositories have access controls enforced
- [ ] Access follows least privilege — only authorized personnel can read or write
- [ ] Changes require review and approval before merging
- [ ] Access is audited and reviewed periodically
