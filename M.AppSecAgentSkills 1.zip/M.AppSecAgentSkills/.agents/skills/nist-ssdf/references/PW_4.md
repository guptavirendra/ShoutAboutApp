# PW.4: Reuse Existing, Well-Secured Software When Feasible

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Prefer well-maintained, security-reviewed third-party components over building custom implementations. Verify the security of acquired components and maintain them over time.

## Tasks

- [PW.4.1](PW_4_1.md) — Acquire and maintain well-secured third-party components
- [PW.4.2](PW_4_2.md) — Create and maintain well-secured in-house components
- [PW.4.4](PW_4_4.md) — Verify third-party components comply with requirements

## Acceptance criteria

- [ ] Third-party components evaluated for security before adoption
- [ ] Components kept up to date with security patches
- [ ] In-house shared components follow the same SDLC as products
- [ ] Compliance of third-party components verified on an ongoing basis
