# PO.1: Define Security Requirements for Software Development

**Framework:** NIST SSDF
**Practice Group:** Prepare the Organization

## What this practice requires

Establish and maintain documented security requirements that govern how software is developed and how the development infrastructure is operated. Requirements must cover both the software being built and the systems used to build it.

## Tasks

- [PO.1.1](PO_1_1.md) — Security requirements for development infrastructure and processes
- [PO.1.2](PO_1_2.md) — Security requirements for organization-developed software
- [PO.1.3](PO_1_3.md) — Communicate requirements to third-party component suppliers

## Acceptance criteria

- [ ] Written security requirements exist for the development infrastructure
- [ ] Written security requirements exist for each software product
- [ ] Requirements are versioned and reviewed at least annually
- [ ] Third-party suppliers have received and acknowledged applicable requirements
