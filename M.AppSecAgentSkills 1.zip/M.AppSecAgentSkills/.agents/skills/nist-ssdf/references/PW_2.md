# PW.2: Review the Software Design to Verify Compliance with Security Requirements

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Have qualified reviewers — independent of the designers — verify that the software design meets all security requirements and adequately addresses identified risks before implementation begins.

## Tasks

- [PW.2.1](PW_2_1.md) — Conduct qualified design review against security requirements

## Acceptance criteria

- [ ] Security design review performed by someone not involved in the design
- [ ] Review verifies all security requirements are addressed
- [ ] Review findings documented and resolved before implementation
