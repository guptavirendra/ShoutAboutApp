# PS.3: Archive and Protect Each Software Release

**Framework:** NIST SSDF
**Practice Group:** Protect the Software

## What this practice requires

Securely archive each software release along with the supporting data needed to reproduce, verify, and investigate it — including provenance data and an SBOM.

## Tasks

- [PS.3.1](PS_3_1.md) — Archive release files and supporting data
- [PS.3.2](PS_3_2.md) — Collect and maintain provenance data (SBOM)

## Acceptance criteria

- [ ] All release artifacts archived with defined retention period
- [ ] SBOM generated and archived for each release
- [ ] Archives are access-controlled and tamper-evident
