# PW.7: Review and Analyze Human-Readable Code to Identify Vulnerabilities

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Review source code for security vulnerabilities using human review, automated analysis tools, or both. Code review is the primary control for catching vulnerabilities before they reach production.

## Tasks

- [PW.7.1](PW_7_1.md) — Determine the appropriate code review and analysis approach
- [PW.7.2](PW_7_2.md) — Perform code review and analysis; track findings

## Acceptance criteria

- [ ] Code review approach defined (human, automated, or both)
- [ ] All code reviewed before merging to main/release branches
- [ ] Findings tracked in issue tracker with severity ratings
- [ ] Critical and high findings resolved before release
