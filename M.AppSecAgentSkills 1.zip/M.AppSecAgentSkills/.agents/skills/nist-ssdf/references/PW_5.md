# PW.5: Create Source Code by Adhering to Secure Coding Practices

**Framework:** NIST SSDF
**Practice Group:** Produce Well-Secured Software

## What this practice requires

Developers must follow secure coding practices appropriate to their language and environment. This is the primary control for preventing vulnerabilities from being introduced during implementation.

## Tasks

- [PW.5.1](PW_5_1.md) — Follow secure coding practices for the language and environment

## Acceptance criteria

- [ ] Secure coding standards defined for each language in use
- [ ] Standards enforced through code review and automated tooling
- [ ] Developers trained on secure coding for their primary language
