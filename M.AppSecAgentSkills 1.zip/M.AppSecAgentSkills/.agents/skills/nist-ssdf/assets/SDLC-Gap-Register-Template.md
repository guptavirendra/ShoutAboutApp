# SDLC Governance Gap Register & Ownership Matrix (Template)

## Purpose
Use this template to track control ownership, compliance gaps, remediation plans, and evidence across:
- NIST SSDF (`../SSDF-Checklist.md`)
- NIST 218A (`../../nist-218a/218A-Checklist.md`) when AI is in scope
- Molina AppSec requirements (`../../molina-application-security/Molina-AppSec-Program-Checklist.md`)

## Project Metadata
| Field | Value |
|---|---|
| Project Name |  |
| System / Application |  |
| Business Owner |  |
| Security Owner |  |
| Compliance Scope (SSDF / 218A / Molina) |  |
| Reporting Period |  |
| Last Updated |  |

## Status Definitions
| Status | Meaning |
|---|---|
| Open | Gap identified; no active remediation started |
| In Progress | Remediation plan approved and underway |
| Blocked | Remediation cannot proceed due to dependency |
| Ready for Review | Remediation completed; pending verification |
| Closed | Evidence validated and control accepted |

## Ownership Matrix (RACI-Oriented)
| Control Area | Primary Owner (R) | Security Reviewer (C) | Approver (A) | Backup Owner | Review Cadence | Notes |
|---|---|---|---|---|---|---|
| Prerequisites / Intake (Molina 1–5) |  |  |  |  | Weekly |  |
| Security Requirements (PO.1) |  |  |  |  | Biweekly |  |
| Roles, Responsibilities, Training (PO.2) |  |  |  |  | Monthly |  |
| Toolchain and Security Gates (PO.3, PO.4) |  |  |  |  | Weekly |  |
| Secure Development Environments (PO.5) |  |  |  |  | Weekly |  |
| Architecture and Threat Modeling (PW.1, PW.2, Molina 6–15) |  |  |  |  | Biweekly |  |
| Secure Coding and Code Review (PW.5, PW.7) |  |  |  |  | Weekly |  |
| Testing Controls (PW.8, Molina 16–20) |  |  |  |  | Weekly |  |
| Release Integrity and Provenance (PS.2, PS.3) |  |  |  |  | Biweekly |  |
| Vulnerability Management (RV.1, RV.2, RV.3) |  |  |  |  | Weekly |  |
| AI Model/Data Security (218A PO/PS/PW/RV) |  |  |  |  | Weekly |  |

## Gap Register
| Record ID | Framework | Control ID(s) | Control Requirement | In Scope (Y/N) | Phase | Risk | Current State | Gap Summary | Remediation Plan | Primary Owner | Target Date | Status | Evidence Required | Evidence Link | Last Updated |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| GR-001 | Molina | 1 | Application Team SharePoint URL exists and maintained | Y | Prereq | Critical |  |  |  |  |  | Open | SharePoint URL + access proof |  |  |
| GR-002 | Molina | 2 | AppSec review request ticket created in iServe | Y | Prereq | Critical |  |  |  |  |  | Open | iServe ticket ID and link |  |  |
| GR-003 | Molina | 3.1 | Design Authority Review completed | Y | Prereq | Critical |  |  |  |  |  | Open | Approval artifact / meeting record |  |  |
| GR-004 | Molina | 3.2 | Previous AppSec remediation plan reviewed/closed | Y | Prereq | Critical |  |  |  |  |  | Open | Prior plan + closure evidence |  |  |
| GR-005 | Molina | 4 | Stakeholder and incident contacts defined | Y | Prereq | Critical |  |  |  |  |  | Open | Stakeholder roster |  |  |
| GR-006 | Molina | 5 | Two secure development trainings per year completed | Y | Prereq | Critical |  |  |  |  |  | Open | Training certificates |  |  |
| GR-007 | SSDF | PO.1 | Security requirements documented and maintained | Y | Prepare | High |  |  |  |  |  | Open | Requirements baseline |  |  |
| GR-008 | SSDF | PO.2 | Roles, responsibilities, and training defined | Y | Prepare | High |  |  |  |  |  | Open | RACI + training records |  |  |
| GR-009 | SSDF | PO.3, PO.4 | Toolchain and security check criteria implemented | Y | Prepare | High |  |  |  |  |  | Open | CI/CD gate configs and reports |  |  |
| GR-010 | SSDF | PO.5 | Secure/hardened development environments | Y | Prepare | High |  |  |  |  |  | Open | Hardening standards + evidence |  |  |
| GR-011 | SSDF | PW.7, PW.8 | Code review/analysis and testing controls active | Y | Build/Test | High |  |  |  |  |  | Open | SAST/DAST/test reports |  |  |
| GR-012 | SSDF | RV.1, RV.2, RV.3 | Vulnerability intake, triage, remediation, RCA | Y | Operate | High |  |  |  |  |  | Open | Vuln workflow + issue tracker links |  |  |
| GR-013 | 218A | PO/PS/PW/RV (as applicable) | AI model/data controls implemented | N | All | High |  |  |  |  |  | Open | AI risk model + control evidence |  |  |

## Weekly Governance Review Checklist
| Check | Owner | Complete (Y/N) | Notes |
|---|---|---|---|
| All Critical gaps have owners and target dates |  |  |  |
| Overdue items have escalation notes |  |  |  |
| New evidence links added for completed actions |  |  |  |
| Blocked items have dependency owner assigned |  |  |  |
| Closed items verified by Security Reviewer |  |  |  |

## Change Log
| Date | Updated By | Summary of Changes |
|---|---|---|
|  |  |  |
