# Pattern A Design Checklist: User Authentication and SSO (OIDC-Based)

Source: Molina AppSec CoE OAuth Security Pattern §5.1.1, §6, §10.3

---

## Applicability

Use this checklist when the OAuth implementation involves end-user login via a third-party identity provider using OIDC. Pattern A applies when:
- A human user is involved in the authentication flow
- The application delegates authentication to an IdP (not validating credentials directly)
- Authorization Code Flow is in use

---

## Pre-review confirmation

Before proceeding, confirm:
- [ ] Pattern A is documented in the project design artifacts
- [ ] The use case involves a human user (if not, evaluate Pattern B or C)
- [ ] Microsoft Entra ID is the designated IdP (or a formal exception is in place)
- [ ] Architecture diagram is available showing OIDC flow with labeled endpoints

---

## Required controls checklist

### Grant type and flow

- [ ] Authorization Code Flow with PKCE is implemented
- [ ] `code_challenge` (using S256 method) is sent in the authorization request
- [ ] `code_verifier` is sent in the token request
- [ ] Implicit Flow is NOT used
- [ ] ROPC (Resource Owner Password Credentials) is NOT used
- [ ] Hybrid flows without AppSec approval are NOT used

### Identity Provider configuration

- [ ] Microsoft Entra ID is used as the IdP
- [ ] Token signing uses RS256 or ES256
- [ ] Token signing keys are managed by the IdP
- [ ] JWKS endpoint is used for signature validation with rotation support
- [ ] Tokens are only accepted from approved identity providers

### Session management

- [ ] Automatic session timeouts are enforced aligned to Molina IAM policy
- [ ] Session expiration is tied to the browser session
- [ ] On IdP logout, the local application session is terminated
- [ ] Residual session access after IdP logout is not possible

### Token handling

- [ ] ID tokens are used only for authentication and identity — not forwarded to resource servers
- [ ] Access tokens (not ID tokens) are used for downstream API authorization calls
- [ ] Token claims do not contain PHI or PII
- [ ] Only Molina-approved OIDC claims are included in ID tokens
- [ ] OIDC claims follow least-privilege principle

### Token validation (at resource server)

- [ ] `iss` (issuer) claim is validated against approved IdP
- [ ] `aud` (audience) claim is validated against the intended resource/API
- [ ] Token signature is validated via trusted JWKS endpoint
- [ ] `exp` (expiration) claim is validated; expired tokens are rejected
- [ ] Scope/claims are validated against granted permissions
- [ ] Clock skew tolerance is defined and does not exceed 300 seconds
- [ ] Local JWT validation is used (introspection only when tokens are not self-contained)

### Redirect URI security

- [ ] Redirect URIs are strictly allowlisted via app registration
- [ ] No wildcard or open redirect patterns in registered URIs
- [ ] State parameter is included in authorization requests
- [ ] State parameter is validated on callback to prevent CSRF

### Token storage

- [ ] Tokens are NOT stored in `localStorage`
- [ ] Tokens are NOT stored in `sessionStorage`
- [ ] Approved storage: HTTP-only secure cookies or Backend-for-Frontend (BFF) pattern
- [ ] Tokens are never logged or written to plaintext storage
- [ ] All token transmission occurs over TLS 1.2+

---

## Threat mitigations specific to Pattern A

| Threat | Mitigation in place? |
|---|---|
| Authorization Code Interception | PKCE implemented (code_challenge/code_verifier) |
| Token Leakage | Tokens not logged; stored in HTTP-only cookies or BFF only |
| Redirect URI Manipulation | Redirect URIs strictly allowlisted in app registration |
| CSRF Attacks | State parameter validated on callback |
| Token Injection | iss, aud, and signature validated at resource server |
| Consent Phishing | Only trusted IdPs (Entra ID) used |

---

## Design review expectations

Confirm the following during AppSec review:
- [ ] Chosen OIDC flow implementation is demonstrated in the architecture diagram
- [ ] Token lifetimes are confirmed and aligned to Molina IAM policy
- [ ] Application requests only the minimum set of scopes necessary for intended functionality
- [ ] Application session termination behavior on IdP logout events is documented
- [ ] ID token vs. access token usage is explicitly separated in the design

---

## Architecture diagram requirements (§10.3)

The architecture diagram must show:
- Authorization endpoint, token endpoint, and userinfo endpoint (labeled)
- Where PKCE parameters (code_challenge, code_verifier) are passed
- Where token validation occurs at the resource server
- What the session contains vs. what the token contains
- All system components involved in the OIDC flow

---

## Exception handling

If Pattern A controls cannot be met:
- Document specific control(s) that cannot be satisfied
- Raise a Risk Acceptance and Request Exception (RARE) with the Security team
- If remediation cannot occur within 60 days, RARE must be raised immediately
- Maintain and update RARE while it remains open
