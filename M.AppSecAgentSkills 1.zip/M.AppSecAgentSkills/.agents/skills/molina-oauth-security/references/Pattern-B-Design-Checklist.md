# Pattern B Design Checklist: Service-to-Service

Source: Molina AppSec CoE OAuth Security Pattern §5.1.2, §6, §10.4

---

## Applicability

Use this checklist when the OAuth implementation is for service-to-service authentication without any human user involvement. Pattern B applies when:
- No human end-users are involved in the access
- Access is automated or scheduled
- The integration is internal to Molina

---

## Pre-review confirmation

Before proceeding, confirm:
- [ ] Pattern B is documented in the project design artifacts
- [ ] The use case has NO human user interaction (if a user is involved, evaluate Pattern A)
- [ ] The integration is internal to Molina (if external, evaluate Pattern C)
- [ ] Microsoft Entra ID is the designated IdP (or a formal exception is in place)
- [ ] Architecture diagram is available showing the service-to-service OAuth flow with labeled endpoints

---

## Required controls checklist

### Grant type and flow

- [ ] Client Credentials Grant is used
- [ ] No user interaction or consent is involved in the flow
- [ ] Authorization Code Flow is NOT used for this pattern
- [ ] Implicit Flow is NOT used
- [ ] ROPC (Resource Owner Password Credentials) is NOT used

### Client authentication

- [ ] Client authentication uses mTLS, OR
- [ ] Client authentication uses Private Key JWT (signing key JWT)
- [ ] Static shared secrets are NOT used for client authentication
- [ ] Client credentials are not stored or transmitted in plaintext

### Token security

- [ ] Access tokens are short-lived (set to the minimum required by the business)
- [ ] Tokens are never stored in plaintext
- [ ] Tokens are stored in secure memory or approved vault (e.g., Key Vault)
- [ ] Tokens are never logged
- [ ] All token transmission occurs over TLS 1.2+

### Refresh tokens

- [ ] Refresh tokens are NOT used in Pattern B — explicitly confirmed
- [ ] If refresh tokens were requested in error, they are not configured or accepted

### Authorization

- [ ] Access follows the principle of least privilege
- [ ] Client is granted only the scopes required for its function
- [ ] Each scope maps to a single authorization policy at the resource server

### Token validation (at resource server)

- [ ] `iss` (issuer) claim is validated against approved IdP
- [ ] `aud` (audience) claim is validated against the intended resource/API
- [ ] Token signature is validated via trusted JWKS endpoint
- [ ] `exp` (expiration) claim is validated; expired tokens are rejected
- [ ] Scope/claims are validated against granted permissions
- [ ] Clock skew tolerance is defined and does not exceed 300 seconds
- [ ] Local JWT validation is used (introspection only when tokens are not self-contained)

---

## Threat mitigations specific to Pattern B

| Threat | Mitigation in place? |
|---|---|
| Compromised Refresh Token | Refresh tokens not used; N/A for Pattern B |
| Token Replay | mTLS or app registration used; revocation capability in place |
| Token Leakage | Tokens not logged; stored in secure memory or vault only |
| Token Injection | iss, aud, and signature validated at resource server |

---

## Design review expectations

Confirm the following during AppSec review:
- [ ] Chosen OAuth flow (Client Credentials) is demonstrated in the architecture diagram with labeled endpoints
- [ ] Chosen client authentication method (mTLS or Private Key JWT) is confirmed and documented
- [ ] Token validation approach at the resource server is described
- [ ] Token lifetime is confirmed and justified against business requirements
- [ ] No refresh tokens are configured or requested

---

## Architecture diagram requirements (§10.4)

The architecture diagram must show:
- Token endpoint (labeled)
- Client authentication method (mTLS or signing key JWT)
- All internal services involved in the flow
- Where token validation occurs at the resource server
- Trust boundaries between services

---

## Exception handling

If Pattern B controls cannot be met:
- Document specific control(s) that cannot be satisfied
- Raise a Risk Acceptance and Request Exception (RARE) with the Security team
- If remediation cannot occur within 60 days, RARE must be raised immediately
- Maintain and update RARE while it remains open
- Note: refresh token use in Pattern B is explicitly prohibited and requires escalation, not just a RARE
