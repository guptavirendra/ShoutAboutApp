# Pattern C Design Checklist: Third-Party / Partner Service-to-Service Access

Source: Molina AppSec CoE OAuth Security Pattern §5.1.3, §6, §10.5

---

## Applicability

Use this checklist when the OAuth implementation involves non-interactive, service-to-service access with an external party. Pattern C applies when:
- No human users are involved in the access
- The integration is with an external vendor, SaaS provider, or partner
- Data exchanges, API integrations, or SaaS platform connections are in scope

---

## Pre-review confirmation

Before proceeding, confirm:
- [ ] Pattern C is documented in the project design artifacts
- [ ] The use case has NO human user interaction (if a user is involved, evaluate Pattern A)
- [ ] The integration involves an external/third-party entity (if internal, evaluate Pattern B)
- [ ] Architecture diagram is available showing the third-party OAuth flow with labeled endpoints

---

## Required controls checklist

### Grant type and flow

- [ ] Client Credentials Grant is used
- [ ] No user interaction or consent is involved
- [ ] Implicit Flow is NOT used
- [ ] ROPC (Resource Owner Password Credentials) is NOT used

### Client authentication

- [ ] Client authentication uses OAuth with JWT, OR
- [ ] Client authentication uses mTLS with API keys, with secrets stored in Key Vault
- [ ] Static shared secrets are NOT stored or transmitted in plaintext
- [ ] Credentials are not hardcoded or embedded in application code or config files

### Token security

- [ ] Access tokens are short-lived and set to the minimum lifetime necessary to fulfill business requirements
- [ ] Tokens must be protected against replay using approved TLS versions or equivalent method
- [ ] Tokens are never stored in plaintext
- [ ] Tokens are never logged
- [ ] All token transmission occurs over TLS 1.2+

### Communication security

- [ ] Communication uses HTTPS, HTTPS/2, or secure WebSockets
- [ ] TLS 1.2 or higher is enforced on all connections
- [ ] Connections to third-party endpoints are validated for TLS version compliance

### Authorization and least privilege

- [ ] Least privilege is enforced — each client is granted only the required scopes
- [ ] Each scope maps to a single authorization policy at the resource server
- [ ] Over-privileged client registrations are not permitted

### Logging and monitoring

- [ ] Service-to-service authentication and authorization events are logged
- [ ] Logs are monitored and integrated into centralized logging/monitoring
- [ ] Suspicious authorization attempts trigger alerts

### Third-party lifecycle management

- [ ] Third-party access is reviewed periodically
- [ ] Third-party OAuth clients are revocable
- [ ] Access is disabled upon termination of the partner relationship
- [ ] Client revocation procedure is documented

### Token validation (at resource server)

- [ ] `iss` (issuer) claim is validated against approved IdP
- [ ] `aud` (audience) claim is validated against the intended resource/API
- [ ] Token signature is validated via trusted JWKS endpoint
- [ ] `exp` (expiration) claim is validated; expired tokens are rejected
- [ ] Scope/claims are validated against granted permissions
- [ ] Clock skew tolerance is defined and does not exceed 300 seconds
- [ ] Local JWT validation is used (introspection only when tokens are not self-contained)

---

## Threat mitigations specific to Pattern C

| Threat | Mitigation in place? |
|---|---|
| Compromised Refresh Token | Refresh token usage explicitly justified and securely managed (if used); usage monitored; revocation in place |
| Token Replay | mTLS or equivalent replay protection using approved TLS |
| Token Leakage | Tokens not logged; secure storage only; no plaintext |
| Token Injection | iss, aud, and signature validated at resource server |

---

## Refresh token policy for Pattern C

Refresh tokens in Pattern C are only permitted when used for user-delegated access via Authorization Code flow. For non-interactive Client Credentials flows in Pattern C:
- [ ] Refresh tokens are NOT used, OR
- [ ] If used, justify the business need explicitly and confirm:
  - [ ] Refresh tokens are rotated on every use
  - [ ] Refresh tokens are revocable
  - [ ] Refresh tokens are stored securely (never in browser storage)
  - [ ] Refresh token lifetime is limited per Molina IAM policy

---

## Design review expectations

Confirm the following during AppSec review:
- [ ] Chosen authentication and authorization methods are confirmed and documented
- [ ] Secrets are not shared or stored in plaintext — confirmed
- [ ] Access and refresh token lifetimes are validated and justified
- [ ] Connections support TLS 1.2+ and use HTTPS — confirmed
- [ ] Third-party client revocation procedure is documented
- [ ] Periodic access review cadence is defined

---

## Architecture diagram requirements (§10.5)

The architecture diagram must show:
- Token endpoint (labeled)
- Client authentication method (JWT or mTLS with Key Vault)
- All external services and API interfaces involved in the flow
- Where token validation occurs at the resource server
- TLS communication paths between Molina and third-party systems
- Revocation mechanism

---

## Exception handling

If Pattern C controls cannot be met:
- Document specific control(s) that cannot be satisfied
- Raise a Risk Acceptance and Request Exception (RARE) with the Security team
- If remediation cannot occur within 60 days, RARE must be raised immediately
- Maintain and update RARE while it remains open
