# OAuth Artifacts Checklist for AppSec Submission

Source: Molina AppSec CoE OAuth Security Pattern §5.3

---

## Purpose

This checklist defines the minimum set of artifacts that must be provided to the AppSec team when submitting an OAuth implementation for review. Incomplete submissions will result in review deferral.

This checklist maps to Molina AppSec gate **P2D-08**: End-to-end OAuth including last mile to backend services.

---

## Required artifacts

### 1. OAuth pattern declaration

- [ ] The selected OAuth pattern is explicitly documented: **Pattern A**, **Pattern B**, or **Pattern C**
- [ ] The pattern selection is justified against the decision logic:
  - Pattern A: human user is involved
  - Pattern B: no user, internal integration
  - Pattern C: no user, external/third-party integration
- [ ] The pattern declaration is included in the architecture or design document

### 2. Architecture diagram

- [ ] System components are shown (client, authorization server, resource server, IdP)
- [ ] OAuth flow is demonstrated end-to-end including the last mile to backend services
- [ ] Endpoints are labeled (authorization endpoint, token endpoint, JWKS endpoint, resource endpoint)
- [ ] PKCE parameters shown where applicable (Pattern A): `code_challenge`, `code_verifier`
- [ ] Client authentication method is labeled (mTLS or signing key JWT for Pattern B/C)
- [ ] Token validation step is shown at the resource server
- [ ] TLS communication paths are indicated
- [ ] Trust boundaries are drawn

### 3. OAuth grant type justification

- [ ] The chosen OAuth grant type is documented and justified
- [ ] Rationale explains why this grant type is appropriate for the use case
- [ ] Prohibited flows (Implicit, ROPC) are confirmed as not in use

### 4. OAuth scope definitions

- [ ] All OAuth scopes used by the application are listed
- [ ] Each scope follows the `resource:action` naming convention
- [ ] Scope justification confirms that only minimum required scopes are requested
- [ ] Read and write permissions are separated into distinct scopes
- [ ] No overly broad or wildcard scopes are present

### 5. Access and refresh token lifetimes

- [ ] Access token lifetime is documented and justified against business requirements
- [ ] If refresh tokens are used:
  - [ ] Refresh token lifetime is documented per Molina IAM policy
  - [ ] Refresh token use is explicitly justified (Pattern C user-delegated flows only)
  - [ ] Confirmation that refresh tokens are NOT used in Pattern B
- [ ] Token lifetimes align with Molina IAM policy constraints

---

## Supporting evidence (recommended)

These items are not always required at submission but may be requested during review:

| Artifact | Applicability |
|---|---|
| IdP app registration screenshot or export | All patterns |
| JWKS endpoint URL and confirmed rotation policy | All patterns |
| mTLS or signing key JWT certificate details | Pattern B, Pattern C |
| Key Vault secret configuration evidence | Pattern B, Pattern C |
| Redirect URI allowlist confirmation | Pattern A |
| Session timeout and logout configuration | Pattern A |
| Token storage approach documentation (frontend) | Pattern A |
| Rate limiting and SIEM integration evidence | Pattern C |
| Third-party access review schedule | Pattern C |
| Client revocation procedure | Pattern C |

---

## Submission completeness check

Before submitting to AppSec, confirm:

| # | Artifact | Status |
|---|---|---|
| 1 | OAuth pattern declaration | `<present / missing>` |
| 2 | Architecture diagram with labeled endpoints and OAuth flow | `<present / missing>` |
| 3 | OAuth grant type justification | `<present / missing>` |
| 4 | OAuth scope definitions with naming and least-privilege justification | `<present / missing>` |
| 5 | Access token lifetime documented | `<present / missing>` |
| 5a | Refresh token lifetime documented (if applicable) | `<present / N-A / missing>` |

All required artifacts must be marked `present` before submitting for AppSec review.

---

## RARE artifacts (if applicable)

If any OAuth controls cannot be met and a Risk Acceptance and Request Exception (RARE) is required:

- [ ] RARE is initiated with the Security team
- [ ] RARE documents the specific control(s) that cannot be satisfied
- [ ] Compensating controls are described
- [ ] Remediation timeline is included (60-day maximum before RARE is mandatory)
- [ ] RARE is tracked and updated as open items progress toward closure
