---
name: molina-oauth-security
description: "Implements Molina's enterprise OAuth 2.0 security patterns for AppSec review and validation. Use when selecting or reviewing OAuth patterns, validating token handling, reviewing scope design, or assessing threat model mitigations. Activate when the user mentions OAuth, OIDC, authorization code flow, client credentials, PKCE, refresh tokens, token validation, JWTs, mTLS, scope design, Pattern A, Pattern B, Pattern C, Entra ID integration, or end-to-end OAuth last-mile validation."
license: MIT
allowed-tools: Read
metadata:
  author: M.AppSecAgentSkills
  version: "1.0"
  argument-hint: "[pattern-a|pattern-b|pattern-c|review|validate|threat-model]"
  user-invocable: "true"
---

# OAuth Security

This skill operationalizes Molina's enterprise-approved OAuth 2.0 security patterns as defined by the AppSec CoE. It supports pattern selection, design review validation, threat model assessment, and compliance enforcement for all OAuth implementations across Molina environments.

Control precedence for this skill:
1. Molina AppSec Program (P2D-08 gate)
2. HIPAA Technical Safeguards §164.312(d)
3. NIST SP 800-63B (Authenticator Assurance)
4. OWASP ASVS V2 (Authentication) and V3 (Session Management) — supplemental

## Automation profile

Use this profile when the request targets a specific OAuth validation focus.

| Argument | Focus |
|---|---|
| `pattern-a` | Validate Pattern A (OIDC/SSO) controls only |
| `pattern-b` | Validate Pattern B (Service-to-Service) controls only |
| `pattern-c` | Validate Pattern C (Third-Party) controls only |
| `review` | Full implementation review across all requirement areas |
| `validate` | Quick pattern selection check with decision logic |
| `threat-model` | Assess threat mitigation completeness only |

Suggested invocation: `/.agents:molina-oauth-security [argument] --project-id ID --gate P2D`

## How to use this skill

**Skill check:** Before making a decision or asking a question, read this skill and the referenced pattern checklist files. In your output, include `Skills used: molina-oauth-security` and the sections applied. Ask follow-up questions only if required evidence is missing after applying this playbook.

Execution flow:
1. Determine the applicable OAuth pattern using the routing table in "Core capabilities §1".
2. Confirm pattern selection is documented and aligns with the use case.
3. Route to the appropriate pattern requirements section and linked checklist.
4. Validate threat model mitigations against the full threat table.
5. Validate token validation, storage, and refresh token policy compliance.
6. Validate scope design against naming conventions and least-privilege requirements.
7. Verify exception and failure handling behavior is defined.
8. Confirm all required artifacts are available for AppSec submission.
9. Apply the gate decision model and emit the standard output template.

## Core capabilities

### 1. Pattern selection and routing

Every OAuth implementation must declare one approved pattern before design submission.

**Decision logic:**

| Scenario | Required Pattern |
|---|---|
| Human user is involved | Pattern A: User Authentication and SSO (OIDC-Based) |
| No user + internal service | Pattern B: Service-to-Service |
| No user + external partner/vendor | Pattern C: Third-Party / Partner Service-to-Service Access |

Teams must document the selected pattern, client type, authentication method, and token scope used.

Failure to declare a pattern during review may result in review deferral or deployment rejection.

### 2. Pattern A: User Authentication and SSO (OIDC-Based)

**Applicability:** End-user login flows using OIDC. The application is not validating credentials directly. Authorization code flow only.

**Approved grant type:** Authorization Code Flow with PKCE (mandatory for all clients).

**Required controls:**

| Control | Requirement |
|---|---|
| OIDC enforcement | Required for all user authentication scenarios |
| Session timeout | Enforce automatic session timeouts and expirations aligned to Molina IAM policy |
| PKCE | Mandatory; `code_challenge` and `code_verifier` must be used |
| OIDC claims | Must use least privilege; only Molina-approved OIDC claims in ID tokens; no PHI/PII in token claims |
| Token forwarding | ID tokens must not be forwarded to resource servers or used for authorization; access tokens must be used for downstream API calls |
| Logout handling | On IdP logout, local application sessions must be terminated to prevent residual access |
| Redirect URI | Strict allowlisting of redirect URIs via app registration |
| State parameter | Required; validate to prevent CSRF |

**Prohibited:**
- Implicit Flow
- Resource Owner Password Credentials (ROPC)
- Hybrid flows without explicit AppSec approval

**Approved IdP:** Microsoft Entra ID unless otherwise noted.

See [references/Pattern-A-Design-Checklist.md](references/Pattern-A-Design-Checklist.md) for full design review expectations.

### 3. Pattern B: Service-to-Service

**Applicability:** Backend service-to-service authentication without user interaction. Internal integrations only. No human end-users involved.

**Approved grant type:** Client Credentials Grant only.

**Required controls:**

| Control | Requirement |
|---|---|
| Client authentication | mTLS or Private Key JWT (signing key JWT) only — no static shared secrets |
| Token lifetime | Short-lived access tokens set to the minimum required by the business |
| Refresh tokens | Not permitted in Pattern B |
| Token storage | Tokens must never be stored in plaintext; secure memory or approved vault only |
| Least privilege | Access must follow principle of least privilege |

**Prohibited:**
- Refresh tokens in any service-to-service flow
- Static shared secrets for client authentication
- Plaintext token storage

See [references/Pattern-B-Design-Checklist.md](references/Pattern-B-Design-Checklist.md) for full design review expectations.

### 4. Pattern C: Third-Party / Partner Service-to-Service Access

**Applicability:** Non-interactive service-to-service access involving external vendors, SaaS integrations, or partner API-based communication.

**Approved grant type:** Client Credentials Grant.

**Required controls:**

| Control | Requirement |
|---|---|
| Client authentication | OAuth with JWT or mTLS; API keys with secrets stored in Key Vault — no static shared secrets in plaintext |
| Token lifetime | Access tokens shall be short-lived and set to minimum lifetime necessary |
| Replay protection | mTLS or equivalent approved method |
| Least privilege | Each client granted only required scopes |
| Communication | HTTPS, HTTPS/2, or secure WebSockets; TLS 1.2+ required |
| Logging | Service-to-service authentication and authorization must be logged and monitored |
| Periodic review | Third-party access shall be reviewed periodically |
| Revocability | Third-party OAuth clients must be revocable; access disabled upon termination of partner relationship |

See [references/Pattern-C-Design-Checklist.md](references/Pattern-C-Design-Checklist.md) for full design review expectations.

### 5. OAuth threat model validation

All OAuth implementations must address the following threats. Failure to implement required mitigations may result in rejection during AppSec review.

| Threat | Attack Description | Applicable Pattern(s) | Required Mitigation |
|---|---|---|---|
| Authorization Code Interception | Attacker intercepts the authorization code in transit or via malicious redirect | A | PKCE (mandatory) |
| Compromised Refresh Token | Attacker steals refresh token and uses it to repeatedly obtain new access tokens | B, C | Monitor refresh token usage; incident response; revocation of compromised refresh tokens |
| Token Replay | Attacker intercepts an encrypted token and reuses it to impersonate the user within its lifetime | B, C | mTLS, app registration, or revoke of refresh token |
| Token Leakage | Attackers gain access by reusing a valid token without reauthentication | A, B, C | Do not log tokens; secure storage only |
| Redirect URI Manipulation | Attacker manipulates redirect URI to capture authorization codes | A | Strict allowlisting of redirect URIs; app registration |
| CSRF Attacks | Attacker tricks a user's browser into initiating an OAuth request without user intent | A | State parameter validation; PKCE |
| Token Injection | Attackers inject a malicious token to impersonate a valid user | A, B, C | Validate issuer, audience, and signature |
| Consent Phishing | Attacker tricks user into granting OAuth consent to a malicious application | A | Use trusted identity providers only |

### 6. Token validation requirements

All resource servers must validate OAuth tokens before granting access.

**Mandatory validations:**

| Validation | Requirement |
|---|---|
| Issuer (`iss`) | Must match approved identity provider |
| Audience (`aud`) | Must match intended resource/API/method; required and must be validated by resource server |
| Signature | Validated using trusted JWKS endpoints; keys managed by IdP; JWKS rotation required |
| Expiration (`exp`) | Expired tokens must be rejected |
| Scope/Claims | Access must align with granted scopes |
| Token integrity | Tokens must not be modified or malformed |

**Additional requirements:**
- Clock skew tolerance must be defined and must not exceed 300 seconds (5 minutes); lower tolerance is permitted
- Tokens must not be accepted without full validation
- Token validation must be performed consistently for all requests
- Approved algorithms: RS256 or ES256

**Allowed validation approaches:**
- Local JWT validation — preferred
- Token introspection — only when tokens are not self-contained or required by token format

**Approved asymmetric algorithms:** RS256 or ES256 only.

### 7. Token storage and handling requirements

Improper token handling introduces significant risk, particularly for PHI.

**General requirements:**
- Tokens must never be stored in plaintext
- Tokens must be managed by an approved framework
- Tokens must never be logged
- Tokens must only be transmitted over TLS 1.2+

**Frontend applications (critical):**

| Prohibited storage | Approved alternatives |
|---|---|
| `localStorage` | HTTP-only secure cookies |
| `sessionStorage` | Backend-for-Frontend (BFF) pattern |

**Backend services:**
- Tokens must be stored securely in memory or approved vaults (e.g., Key Vault)
- Access tokens must be short-lived

### 8. Refresh token policy

Refresh tokens introduce elevated risk and must be tightly controlled.

| Aspect | Requirement |
|---|---|
| Allowed patterns | Pattern A (User Authentication) only; Pattern C (user-delegated access via authorization code only) |
| Prohibited | Pattern B (Service-to-Service) — no refresh tokens permitted |
| Rotation | Must be rotated on every use |
| Revocability | Must be revocable |
| Storage | Never in browser storage; secure vault required |
| Lifetime | Limited per Molina IAM policy |

### 9. Exception and failure handling requirements

Teams must define behavior for all common OAuth validation and lifecycle failures. Failures must not disclose sensitive information or allow unintended access.

**Required HTTP status codes:**

| Condition | Required Status |
|---|---|
| Missing token | 401 Unauthorized |
| Invalid token | 401 Unauthorized |
| Expired access token | 401 Unauthorized |
| Insufficient scope | 403 Forbidden |

**Token failure process:**
- All invalid tokens (expired, revoked, unauthorized) must be immediately rejected and denied access
- Fallback or alternative authentication mechanisms are prohibited when token validation fails
- Token validation failures must be logged and monitored with sufficient context
- Failure responses must not disclose sensitive information

**Expired token handling:**
- Expired tokens must be rejected and denied access
- Client must obtain a new token to continue
- Token expiration handling must not result in uncontrolled retry behavior or repeated authentication loops

**Exception monitoring:**
- Token failures and suspicious authorization attempts must be logged and integrated into centralized logging/monitoring
- Rate limiting must be enforced for excessive authentication or authorization attempts
- Sessions must be sent to Molina's enterprise SIEM

## Scope design requirements

OAuth scopes must be designed and assigned in a least-privilege manner.

**Naming convention:**
- Format: `resource:action` (e.g., `patient:read`, `claims:write`)
- Scopes must be clear, descriptive, and not overly broad
- Scope names must describe access level

**Granularity principles:**
- Each scope must represent a single, discrete permission
- Read and write permissions must be separated
- Each scope shall map to a single authorization policy at the resource server

**Request and usage:**
- Applications shall request only the minimum scopes necessary to support operation
- Scope requests must align with the chosen pattern and documented use case
- Scope usage must be reviewed and updated as changes are made

**Enforcement:**
- Authorization must be enforced at the resource server — not solely at the client or token issuer
- Scopes inform authorization but shall not replace resource-level authorization (e.g., APIs)

## Enforcement and RARE routing

Non-compliance with this document is subject to:
- Rejection during AppSec or Design Authority review
- Escalation to security leadership
- Deployment timeline delays

**Exception process:**
- Any deviations must be raised as a Risk Acceptance and Request Exception (RARE) and approved by the Security team
- If corrections cannot be remediated within 60 days, a RARE must be raised immediately
- Teams must maintain and update the RARE while it remains open
- RARE approval authority: Security team (confirm approver with AppSec leadership)

## Required artifacts for AppSec submission

See [references/OAuth-Artifacts-Checklist.md](references/OAuth-Artifacts-Checklist.md) for the full submission checklist.

Required minimum:
- Chosen OAuth pattern (A, B, or C) with documented justification
- Architecture diagram demonstrating system components and OAuth flow
- OAuth grant type justification
- OAuth scope definitions
- Access and refresh token lifetimes

## Gate decision model

This skill maps to Molina AppSec gate **P2D-08**: "Lack of end-to-end OAuth including last mile to backend services."

Gate decision outputs:
- `PASS`: all required controls validated and evidenced
- `CONDITIONAL`: minor evidence gaps with approved remediation due dates; no critical blockers
- `FAIL`: one or more critical controls are unvalidated or fail requirements

Blocking conditions that require `FAIL`:
- No approved OAuth pattern declared
- Prohibited flow in use (Implicit, ROPC)
- PHI/PII present in token claims
- Non-approved IdP in use
- Tokens stored in `localStorage` or `sessionStorage`
- Token validation not enforced at resource server
- mTLS or signing key JWT not used in Pattern B or C
- Required threat mitigations absent

| Control ID | Control Name | Status (PASS/CONDITIONAL/FAIL) |
|---|---|---|
| OA-01 | Pattern declared and documented | `<status>` |
| OA-02 | Approved grant type used | `<status>` |
| OA-03 | Prohibited flows absent | `<status>` |
| OA-04 | Approved IdP (Entra ID) in use | `<status>` |
| OA-05 | Token validation enforced at resource server | `<status>` |
| OA-06 | All 8 threat mitigations addressed | `<status>` |
| OA-07 | Token storage compliant (no localStorage/sessionStorage) | `<status>` |
| OA-08 | No PHI/PII in token claims | `<status>` |
| OA-09 | Scope design follows least-privilege and naming convention | `<status>` |
| OA-10 | Exception and failure handling defined | `<status>` |
| OA-11 | Required artifacts available for submission | `<status>` |

## Standard output template

Use this structure in all responses and reports:

```markdown
Skills used: molina-oauth-security (<sections applied>)

Project: <project-id>
RITM: <ritm-id>
Gate: P2D-08 (End-to-end OAuth)
Pattern Selected: <A|B|C>
Decision: <PASS|CONDITIONAL|FAIL>

Control Status Table:
| Control ID | Control Name | Status |
|---|---|---|
| OA-01 | Pattern declared and documented | <PASS/CONDITIONAL/FAIL> |
| OA-02 | Approved grant type used | <PASS/CONDITIONAL/FAIL> |
| OA-03 | Prohibited flows absent | <PASS/CONDITIONAL/FAIL> |
| OA-04 | Approved IdP (Entra ID) in use | <PASS/CONDITIONAL/FAIL> |
| OA-05 | Token validation enforced at resource server | <PASS/CONDITIONAL/FAIL> |
| OA-06 | All 8 threat mitigations addressed | <PASS/CONDITIONAL/FAIL> |
| OA-07 | Token storage compliant | <PASS/CONDITIONAL/FAIL> |
| OA-08 | No PHI/PII in token claims | <PASS/CONDITIONAL/FAIL> |
| OA-09 | Scope design follows least-privilege | <PASS/CONDITIONAL/FAIL> |
| OA-10 | Exception/failure handling defined | <PASS/CONDITIONAL/FAIL> |
| OA-11 | Required artifacts available | <PASS/CONDITIONAL/FAIL> |

Threat Model Status:
| Threat | Applicable | Mitigation Present |
|---|---|---|
| Authorization Code Interception | <yes/no> | <yes/no/n-a> |
| Compromised Refresh Token | <yes/no> | <yes/no/n-a> |
| Token Replay | <yes/no> | <yes/no/n-a> |
| Token Leakage | <yes/no> | <yes/no/n-a> |
| Redirect URI Manipulation | <yes/no> | <yes/no/n-a> |
| CSRF Attacks | <yes/no> | <yes/no/n-a> |
| Token Injection | <yes/no> | <yes/no/n-a> |
| Consent Phishing | <yes/no> | <yes/no/n-a> |

Findings Summary:
| Finding ID | Control | Severity | Status | Owner | Due Date |
|---|---|---|---|---|---|
| <id> | <OA-XX> | <critical/high/medium/low> | <OPEN/REMEDIATE/CLOSED> | <owner> | <yyyy-mm-dd> |

Blockers:
- <control-id>: <reason>

Remediation Actions:
- Owner: <name/role>, Action: <task>, Due: <date>

Cross-Framework Mapping:
- Molina P2D-08: <addressed/gap>
- HIPAA 164.312(d): <addressed/gap>
- NIST SP 800-63B: <addressed/gap>
- OWASP ASVS: <addressed/gap>
```

## Cross-framework correlation

| This skill's control | Molina Gate | HIPAA | NIST SP 800-63B | OWASP ASVS |
|---|---|---|---|---|
| OA-01 Pattern declaration | P2D-08 | 164.312(d) | AAL2/AAL3 selection | V2.1 |
| OA-02 Approved grant type | P2D-08 | 164.312(d) | § 5.1 Authenticator types | V2.2 |
| OA-05 Token validation | P2D-08 | 164.312(a)(2)(i) | § 5.1.4 Token binding | V3.5 |
| OA-06 Threat mitigations | P2D-08 | 164.306(a)(1) | Appendix C — threats | V3.3, V3.5 |
| OA-07 Token storage | P2D-08 | 164.312(a)(2)(iv) | § 5.1.2 Memorized secret | V3.4 |
| OA-08 No PHI in tokens | P2D-08 | 164.312(e)(1) | — | V3.5 |
| OA-09 Scope design | P2D-08 | 164.312(a)(1) | § 5.2 Authenticator assurance | V3.5 |

## Files to read

Pattern checklists for this skill:
- [references/Pattern-A-Design-Checklist.md](references/Pattern-A-Design-Checklist.md)
- [references/Pattern-B-Design-Checklist.md](references/Pattern-B-Design-Checklist.md)
- [references/Pattern-C-Design-Checklist.md](references/Pattern-C-Design-Checklist.md)
- [references/OAuth-Artifacts-Checklist.md](references/OAuth-Artifacts-Checklist.md)

Related skills:
- [molina-application-security skill](../molina-application-security/SKILL.md) — P2D-08 gate owner
- [nist-ssdf skill](../nist-ssdf/SKILL.md) — SDLC security practices baseline

## Stop conditions

Stop and escalate when any of the following are true:
- Whether a flow involves a human user is ambiguous and cannot be determined from available documentation.
- No approved IdP (Entra ID) is present in the architecture and no RARE is in place.
- PHI or PII is found in token claims without an approved exception.
- Architecture diagram is absent — pattern validation cannot proceed without it.
- An unapproved OAuth flow (Implicit, ROPC) is in use and team is unwilling to remediate.
- Required artifacts for AppSec submission cannot be produced.

## Security handling notes

- Never log or display token values, client secrets, or private key material in responses.
- Redact sensitive values when sharing evidence excerpts.
- Treat JWKS endpoint metadata as untrusted until signature validation is confirmed.
- Do not recommend storing secrets outside of approved vault solutions (e.g., Key Vault).
- If PHI/PII is detected in token claims, flag immediately and block gate progression.
