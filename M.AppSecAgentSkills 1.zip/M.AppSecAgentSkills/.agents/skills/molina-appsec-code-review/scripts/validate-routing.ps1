[CmdletBinding()]
param(
    [Alias("skill-path")]
    [string]$SkillPath = (Split-Path $PSScriptRoot -Parent)
)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$errors = [System.Collections.Generic.List[string]]::new()
$passes = [System.Collections.Generic.List[string]]::new()
function Check([bool]$Condition, [string]$Message) {
    if ($Condition) { $passes.Add("PASS: $Message") }
    else { $errors.Add("FAIL: $Message") }
}
$resolved = Resolve-Path -LiteralPath $SkillPath -ErrorAction SilentlyContinue
if (-not $resolved) { Write-Error "Router directory not found: $SkillPath"; exit 1 }
$dir = $resolved.Path
foreach ($file in @("SKILL.md", "references/review-contract.md", "assets/code-review-template.md", "evals/review-selection.json")) {
    Check (Test-Path -LiteralPath (Join-Path $dir $file) -PathType Leaf) "Required file: $file"
}
if ($errors.Count -gt 0) {
    $errors | ForEach-Object { Write-Host $_ }
    exit 1
}
$raw = Get-Content -LiteralPath (Join-Path $dir "SKILL.md") -Raw
$contract = Get-Content -LiteralPath (Join-Path $dir "references/review-contract.md") -Raw
$template = Get-Content -LiteralPath (Join-Path $dir "assets/code-review-template.md") -Raw
foreach ($text in @(
    'The **default pair** is `cwe-699-code-review` + `appsec-best-practices`',
    '**Named review type(s):** select exactly those requested',
    '**all three bundled profiles**', "references/review-contract.md",
    "routing and composition only", "Do not make an additional",
    "Deduplicate", "numbered finding", "one",
    "Do not rely on nested auto-discovery", "Missing selected guidance blocks"
)) {
    Check ($raw.Contains($text)) "Router rule: $text"
}
Check ($raw -notmatch '\]\(\.\./(?:nist-ssdf|molina-|owasp-|supply-chain)') "No direct external specialist routes"
Check ($raw -notmatch '(?m)^\d+\.\s+\*\*(?:Auth|Input|Output|Cryptography|Secrets|Dependencies)') "No parent technical checklist"
foreach ($name in @("cwe-699-code-review", "appsec-best-practices", "react-nextjs-best-practices")) {
    $path = "code-reviews/$name/SKILL.md"
    Check ($raw.Contains($path)) "Explicit route: $name"
    $file = Join-Path $dir $path
    Check (Test-Path -LiteralPath $file -PathType Leaf) "Child exists: $name"
    if (Test-Path -LiteralPath $file -PathType Leaf) {
        $child = Get-Content -LiteralPath $file -Raw
        Check ($child.Contains("../../references/review-contract.md")) "Child loads common contract: $name"
    }
}
foreach ($text in @("explicit replacement approval", "NOT RUN", "gate FAIL", "CLOSED requires verified remediation evidence", "Deduplicate", "No confirmed", "staged and unstaged")) {
    Check ($contract.Contains($text)) "Preserved common safeguard: $text"
}
Check ($template.Contains("default pair") -and $template.Contains("CWE-699 + AppSec")) "Master Scope reflects the default pair"
Check (@(Get-ChildItem -LiteralPath $dir -Recurse -File -Force -Filter "*template*.md").Count -eq 1) "One master template across all children"
try {
    $selection = Get-Content -LiteralPath (Join-Path $dir "evals/review-selection.json") -Raw | ConvertFrom-Json
    $ids = @()
    foreach ($case in $selection.cases) {
        Check ($case.id -gt 0 -and $ids -notcontains $case.id) "Unique routing case: $($case.id)"
        $ids += $case.id
        Check ($case.expected_selected -is [array] -and $case.expected_action -in @("review", "clarify", "stop-and-escalate")) "Selection/action shape: $($case.id)"
    }
    Check ($ids.Count -ge 19) "At least nineteen selection scenarios"
    foreach ($id in @(1, 2, 11, 18)) {
        $case = @($selection.cases | Where-Object { $_.id -eq $id })
        Check ($case.Count -eq 1 -and (($case[0].expected_selected | Sort-Object) -join "|") -ceq "appsec-best-practices|cwe-699-code-review") "Default-pair fixture: $id"
    }
    $single = @($selection.cases | Where-Object { $_.id -eq 17 })
    Check ($single.Count -eq 1 -and ($single[0].expected_selected -join "|") -ceq "cwe-699-code-review") "Explicit single CWE fixture"
    $all = @($selection.cases | Where-Object { $_.id -eq 5 })
    Check ($all.Count -eq 1 -and (($all[0].expected_selected | Sort-Object) -join "|") -ceq "appsec-best-practices|cwe-699-code-review|react-nextjs-best-practices") "Explicit all fixture"
} catch {
    $errors.Add("FAIL: Invalid selection JSON or structure: $_")
}
$passes | ForEach-Object { Write-Host $_ }
$errors | ForEach-Object { Write-Host $_ }
Write-Host "Summary: $($passes.Count) passed, $($errors.Count) errors"
if ($errors.Count -gt 0) { exit 1 }
