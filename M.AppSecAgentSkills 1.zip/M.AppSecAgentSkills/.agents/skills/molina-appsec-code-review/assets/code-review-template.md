```text
Thank you for conducting Molina's

 █████╗ ██████╗ ██████╗ ███████╗███████╗ ██████╗
██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝██╔════╝
███████║██████╔╝██████╔╝███████╗█████╗  ██║
██╔══██║██╔═══╝ ██╔═══╝ ╚════██║██╔══╝  ██║
██║  ██║██║     ██║     ███████║███████╗╚██████╗
╚═╝  ╚═╝╚═╝     ╚═╝     ╚══════╝╚══════╝ ╚═════╝

                 ╔═╗┌─┐┌┬┐┌─┐  ╦═╗┌─┐┬  ┬┬┌─┐┬ ┬
                 ║  │ │ ││├┤   ╠╦╝├┤ └┐┌┘│├┤ │││
                 ╚═╝└─┘─┴┘└─┘  ╩╚═└─┘ └┘ ┴└─┘└┴┘

```

## Summary

<One paragraph: scope, overall risk LOW / MODERATE / HIGH / CRITICAL, confirmed
findings count, and whether the assessment is complete or incomplete. Risk is
not a gate decision or a certification.>

Skills used: molina-appsec-code-review <plus only supporting skills actually applied>

| Severity | Count |
|---|---|
| CRITICAL | <N> |
| HIGH | <N> |
| MEDIUM | <N> |
| LOW | <N> |
| INFO | <N> |

## Scope

- **Repository / revision:** <repository and commit or diff range>
- **Scope selection:** <explicit input / staged and unstaged changes plus reviewable untracked files / most recent commit>
- **Selected review types / reason:** <CWE-699 + AppSec best-practices default pair / explicitly named types / explicit all three bundled types>
- **Unselected review types:** <out of scope by selection; do not imply checks were executed>
- **Changed files / paths:** <paths>
- **Context inspected:** <related callers, middleware, configuration>
- **Languages / frameworks:** <observed stack>
- **Framework context (when applicable):** <surface; applicability evidence; version/router/runtime/rendering/cache/hosting details or unknown>
- **Responsibility split (when applicable):** <client; trusted server/framework/API; build/hosting/identity owners>
- **Trust boundaries:** <observed boundaries>
- **Skills loaded and why:** <one line per applied skill>
- **Exclusions / missing evidence:** <items and reasons, or none>
- **Review status:** <complete / incomplete / halted, with reason>

## Findings

<Repeat the following block for each finding, ordered by severity then
confidence. Remove the block if none; state "No confirmed findings in the
reviewed scope" and retain limitations. Separate unverified evidence gaps from
confirmed findings.>

### Finding <N>: <short title>

- **Severity**: CRITICAL | HIGH | MEDIUM | LOW | INFO
- **Confidence**: High | Medium | Low
- **Status**: OPEN | REMEDIATE | CLOSED
- **Location**: `path/to/file.ext:Lstart-Lend` (or commit SHA)
- **Category**: <Injection / Broken Access Control / Secret Exposure / OAuth Misuse / AI/LLM / Supply Chain / Governance / other>
- **Owner layer (when applicable)**: <client / trusted server / framework / API / build / hosting / identity>
- **Skill basis**: <skill-name> - <section / control reference>
- **Framework mapping**: <verified specific CWE, SSDF task, OWASP entry, or applicable Molina control; otherwise not determined>
- **Description**: <weakness, prerequisites, existing protections and impact; no exploit instructions>
- **Evidence**: <minimal redacted excerpt or diff, source-to-operation path where applicable>
- **Recommendation**: <concrete defensive fix>
- **Gate impact**: <PRE / P2D / P2B implications when established; otherwise not assessed / not applicable>

New findings are OPEN. REMEDIATE requires evidence that remediation is in
progress; CLOSED requires verified remediation evidence. Preserve established
statuses only when supported by supplied evidence. These lifecycle values are
separate from check results (PASS / FAIL / NA / NOT RUN) and gate decisions.

## Positive observations

- <Verified controls already in place, with locations and evidence.>

## Recommended next steps

1. <Prioritized defensive remediation, subject to separate approval.>
2. <Missing evidence or validation needed and suggested owner.>
3. <Whether formal Molina review is warranted under applicable policy, with
   reason; do not issue a gate approval from this report.>

## Audit trail

- **Review date / reviewer:** <YYYY-MM-DD / reviewer>
- **Files inspected:** <complete inspected-file list>
- **Skills and sections applied:** <actual sources only>
- **Commands / checks executed:** <read-only inspection commands and results>
- **Assumptions / out-of-scope items:** <explicit limitations>
- **Escalations / blockers:** <redacted stop conditions, required approval or none>
- **Residual risk:** <unresolved risks and missing verification; do not claim none while findings remain unresolved>
- **Artifact status:** <written to project-root CODE_REVIEW.md / chat only with reason>

| Check area | Status (PASS / FAIL / NA / NOT RUN) | Evidence / reason |
|---|---|---|
| Authentication / authorization / sessions | <status> | <evidence> |
| Input handling | <status> | <evidence> |
| Output handling | <status> | <evidence> |
| Cryptography | <status> | <evidence> |
| Secrets / configuration | <status> | <redacted evidence> |
| Dependencies / supply chain | <status> | <verified version/advisory evidence or checks not run> |
| Errors / logging / telemetry | <status> | <evidence> |
| Concurrency / resource use | <status> | <evidence> |
| AI / LLM / agentic surfaces | <status> | <evidence or applicability reason> |
| OAuth / OIDC | <status> | <evidence or applicability reason> |
| Architecture / trust boundaries | <status> | <evidence> |
| Molina gate implications | <status> | <applicable policy/evidence or not assessed> |
| Runtime tests / scanners | <status> | <NOT RUN unless separately authorized and actually executed> |

Use check rows only for topics within the selected review types. Remove rows
for out-of-scope topics and record unselected types in Scope instead; their
absence is not a FAIL or a claim of coverage. Unused features within a selected
profile are NA, and selected but unexecuted checks are NOT RUN.
