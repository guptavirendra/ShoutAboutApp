---
name: molina-appsec-code-review
description: "Routes secure code reviews to bundled profiles. Default: CWE-699 and AppSec best practices combined into one CODE_REVIEW.md. Run a single named profile only when explicitly requested; run all three only on explicit all-reviews request. React/Next.js remains opt-in. Uses the shared AppSec banner and master report contract; no independent parent review pass. Use for application review, not creating, validating or locating skills. WHEN: \"secure code review\", \"Molina code review\", \"CWE review\", \"CWE-699\", \"React security review\", \"Next.js security review\", \"AppSec best practices review\", \"appsec-best-practices\", \"all code reviews\", \"CODE_REVIEW.md\", \"m-appsec-codereview\", \"AppSec banner\"."
license: MIT
compatibility: "Keep all code-reviews children, references/review-contract.md, and assets/code-review-template.md with this package. Git supports diff/commit scopes. AppSec supporting skills resolve from the installed catalog. No fixed submodule layout is required; missing selected guidance blocks the review."
metadata:
  author: M.AppSecAgentSkills
  version: "3.0"
  source: "M.AppSecSpeckit/.github/skills/m-appsec-codereview/SKILL.md"
  source-origin: "molina-appsec command, migrated from m.appsec.codereview.agent.md"
  user-invocable: "true"
allowed-tools: Read Grep Glob Bash(git status:*) Bash(git diff:*) Bash(git log:*) Bash(git show:*) Write
---

# Molina AppSec Code Review Router

Select and run child review profiles, then merge their findings into one
output. The parent is routing and composition only: no independent parent
review pass, technical checklist, or direct specialist assessment.

**Skills used:** molina-appsec-code-review (plus only profiles/supporting skills
actually applied).

## Gotchas

- **Load the shared contract first.** Read
  [references/review-contract.md](references/review-contract.md) before any
  selected review for scope, permissions, evidence, severity, lifecycle Status,
  stop/escalation and report-write rules. These apply to every child.
- **One master template.** Read
  [assets/code-review-template.md](assets/code-review-template.md) before
  producing output; children do not define separate reports.
- **Missing selected guidance blocks execution.** Stop and disclose the
  incomplete package/capability; never silently fall back to one child.
- **Do not rely on nested auto-discovery.** Explicitly read the bundled child's
  `SKILL.md` at its linked path. Direct child invocation loads this contract
  but does not recursively invoke routing or add default siblings.

## Execution flow

### 1. Select profiles from the request

| Selection | Profiles |
|---|---|
| Default (no type specified) | `cwe-699-code-review` + `appsec-best-practices` |
| Explicit named profile(s) | Exactly the named profile(s), replacing the default |
| Explicit all reviews | All three bundled profiles |

The **default pair** is `cwe-699-code-review` + `appsec-best-practices`.
Generic requests such as "secure code review", "review this React app",
"thorough review" or "all files" use that pair, not all three.

**Named review type(s):** select exactly those requested. "CWE-699 only",
"React/Next.js code review", or "appsec-best-practices only" selects one
profile, without adding default siblings. Direct child invocation also selects
only that child. "A single review" without identifying its type needs
clarification; do not choose one arbitrarily.

"All code reviews", "all review types", or "run all reviews together" selects
**all three bundled profiles**. A named combination selects only that
combination. "Both default reviews" names the default pair; unqualified
"both code reviews" is ambiguous among three and needs clarification.

Honor exclusions. Unknown/unavailable types, contradictory "only"/combination
requests, or an empty resulting selection require clarification and stop.
Do not auto-load specialists from their WHEN triggers or from code technology.

### 2. Route to child instructions

| Selected profile | Child instructions |
|---|---|
| CWE-699 | [cwe-699-code-review](code-reviews/cwe-699-code-review/SKILL.md) |
| AppSec best practices / legacy cross-framework review | [appsec-best-practices](code-reviews/appsec-best-practices/SKILL.md) |
| React/Next.js | [react-nextjs-best-practices](code-reviews/react-nextjs-best-practices/SKILL.md) |

Route explicitly requested OAuth/OIDC, SSDF, AI/agentic/MCP/218A, or Molina
gate assessments through `appsec-best-practices` with that limited focus;
do not run supporting specialist skills directly from this router. Forward
the exact focus, exclusions, code scope and formal-gate authorization to the
child. Unknown specialist requests require clarification, not substitution.

AppSec supporting-skill routing is internal to that child, whether selected
by default or explicitly. It does not add sibling review profiles. Mandatory
project policy may block/escalate work under the shared contract; it does not
authorize unrequested formal workflows.

### 3. Compose one output

Use the same code scope for all selected profiles. Do not make an additional
parent review pass. Deduplicate the same weakness across profiles into one
numbered finding with all applicable skill bases and mappings; do not sum
duplicate findings into severity or blocker totals. Preserve each selected
child's unique evidence supplements within the master report's six sections.

Record selected profiles, reason (default pair / explicit names / explicit all),
unselected types, limitations, and actual skills applied. Produce one
`CODE_REVIEW.md` using the shared template and contract, or their explicit
chat-only fallback. No second report per child or unrequested profile.

## Output contract

Return the actual report path or no-file reason, selected profiles, unique
finding counts, priorities, limitations, and Skills used. The shared contract
and master template define the report structure and safety requirements.

## Package evaluation

Run `pwsh scripts/validate-routing.ps1 -SkillPath .` when maintaining router
selection, shared-contract wiring, or the one-output composition contract.
Read [evals/review-selection.json](evals/review-selection.json) when validating
default-pair, named-only, direct-child, explicit-all, and exclusion routing.
Read [evals/default-pair-results.json](evals/default-pair-results.json) for
v3.0 tabletop routing/composition results, structural checks and their limits.
Read [evals/evals.json](evals/evals.json) for scope, reporting and safety cases.
Historical [selection results](evals/review-selection-results.json),
[benchmark](evals/benchmark.json) and [grading](evals/grading.json) describe
older behavior, not validation of this router version.
