---
name: react-nextjs-best-practices
description: "Reviews React security using OWASP ASVS 5.0 and official React/Next.js guidance, including DOM escape hatches, postMessage, navigation, and rich-content pipelines. Adds Next.js checks only when reviewed code uses Next.js: App/Pages Router, Server Actions, authorization, caching, CSP, secrets, and image SSRF. Retains React/Vite/SSR guidance without requiring Next.js. WHEN: \"React security\", \"React app security review\", \"React XSS\", \"dangerouslySetInnerHTML\", \"refs innerHTML\", \"postMessage security\", \"React Markdown security\", \"CSP nonce\", \"tokens in localStorage\", \"React Server Components security\", \"Next.js security review\", \"Next.js secrets\", \"Next.js Server Actions\", \"Next.js cache security\", \"Vite env secrets\", \"React ASVS\"."
license: MIT
compatibility: "Bundled child of molina-appsec-code-review; keep the parent SKILL.md and shared assets/code-review-template.md. Uses OWASP ASVS 5.0 and official React/Next.js documentation; framework settings must match the reviewed version. Package validation requires PowerShell 7."
metadata:
  author: M.AppSecAgentSkills
  version: "3.2"
  source-branch: "react-nextjs-best-practices"
  source-commit: "7b570af2545f26e87c26f3e7918ca12b04dbeedd"
  source-archive-tag: "archive/react-nextjs-best-practices"
  source-framework: "OWASP ASVS 5.0"
  source-document: "React Best Practices (WIP) SharePoint artifact updated 2026-08-06"
  user-invocable: "true"
allowed-tools: Read Grep Write
---

# React and Next.js Best Practices

This bundled child reviews React application security practices mapped to OWASP ASVS 5.0 and official React behavior, with a conditional Next.js security review. Its framework guidance supplements the parent review workflow; it does not define an independent report format.

**Skills used:** molina-appsec-code-review, react-nextjs-best-practices (include both and the sections actually applied).

Run this profile only when the request selects a React/Next.js review, invokes
this child directly, or explicitly includes it in a combined/all-types review.
React/Next.js source evidence alone does not select this profile. Direct child
invocation selects this profile only; loading the parent's contract does not
also run its default CWE-699 + AppSec best-practices pair.

## Gotchas

- **React is not the whole trust boundary.** React is primarily a UI rendering and composition library. Authentication, authorization, secure sessions, CORS, secrets management, dependency management, and production security headers must be enforced in trusted server, framework, identity, build, hosting, or gateway layers.
- **Next.js guidance is conditional.** Apply the Next.js section and load its reference only when reviewed code uses Next.js. React, SSR, RSC, `use server`, or generic `app/` and `pages/` directories alone do not establish Next.js usage.
- **JSX escaping is contextual, not universal.** Ordinary JSX interpolation escapes text, but values interpreted as HTML, URLs, CSS, JavaScript, form actions, or other active browser contexts need validation, sanitization, or context-specific encoding.
- **State and refs do not establish trust.** Trace untrusted inputs through state, props, hooks, effects, refs, message listeners, and third-party wrappers to the final sink. Imperative DOM writes bypass JSX escaping; API names alone do not prove a vulnerability.
- **Client-side route guards are UX only.** Protected routes, hidden controls, disabled buttons, TypeScript types, and client inactivity timers do not authorize server operations or enforce authoritative session expiration.
- **Browser-delivered values are public.** Anything in client bundles, source maps, serialized server props, Client Component props, or public env prefixes such as `NEXT_PUBLIC_*`, `VITE_*`, and `REACT_APP_*` must be treated as exposed.
- **React Server Functions are network-reachable server operations.** Validate, authenticate, authorize, and safely deserialize all server function arguments inside each operation.
- **React Server Components create a data-release boundary.** Pass only minimal, deliberately shaped data into Client Components; never pass secrets, complete privileged records, authorization metadata, or service responses that exceed the user's need.
- **Load the parent before reviewing.** Read [../../SKILL.md](../../SKILL.md) for routing and [../../references/review-contract.md](../../references/review-contract.md) for scope, read-only source protection, existing-report approval, redaction, and stop/escalation rules. If the parent or shared contract is missing, report the incomplete package and stop; do not invent a fallback template or write an unbranded report.
- **One inherited report.** Use [../../assets/code-review-template.md](../../assets/code-review-template.md) for the AppSec banner, section order, finding structure, severity, confidence, and audit trail. Do not create an independent framework report. Guidance-only or blocked-write responses use the parent's explicit chat-only fallback.
- **ZeriFlow is secondary context, not the standard.** The normative hierarchy is OWASP ASVS 5.0, then official React documentation and advisories (plus official Next.js sources when applicable), then the corrected 12-practice baseline, then application-specific procedures.

## How to use this skill

**Skill check:** Read the parent and this file before reviewing React security guidance or code. Parent-to-child loading does not recursively restart the parent workflow; apply parent safeguards once, then the applicable framework checks. Include both skill names and the sections applied.

Execution flow:

1. **Scope the review** - Identify whether the request is about code review, architecture/design guidance, remediation, secure configuration, training content, or gate evidence.
2. **Classify the React surface** - Note whether the app uses client-only React, Next.js or another framework, SSR, React Server Components, React Server Functions, Vite, external scripts, rich HTML, or third-party renderers/parsers. Determine Next.js applicability using the conditional section below.
3. **Load the practices** - Read [references/react-security-practices.md](references/react-security-practices.md) when mapping findings or recommendations to the 12-practice ASVS baseline. Read the Next.js reference only after confirming Next.js usage in the reviewed code.
4. **Apply the review checklist** - Read [assets/react-security-review-checklist.md](assets/react-security-review-checklist.md) when performing a code/design review, gate review, or remediation readiness check. For DOM writes, messaging, navigation, or rich-content components, apply the DOM Escape Hatch Review Supplement in the React reference. Record the input source, transformations, final sink, and effective or missing protection; distinguish confirmed findings from missing evidence and safe uses.
5. **Separate responsibilities** - State whether each control belongs in React code, the framework/server layer, API/gateway, identity/session system, build pipeline, dependency governance process, hosting layer, or runtime monitoring.
6. **Map evidence to ASVS** - Verify exact requirement IDs against the official release before citing them. For DOM/messaging/navigation/rich-content findings, use the supplement's ASVS 5.0 chapter areas; do not reuse historical draft mappings from the 12-practice baseline. When exact IDs are unverified, label chapter-level mappings or state not determined instead of inventing IDs.
7. **Prioritize risk** - Treat credential exposure, server-side authorization gaps, unsafe rich HTML, SSR/RSC serialization leakage, and dependency compromise paths as high priority unless the context proves otherwise.
8. **Write the inherited report** - Read [../../assets/code-review-template.md](../../assets/code-review-template.md) and [assets/framework-report-fields.md](assets/framework-report-fields.md). Integrate framework evidence into the parent's single `CODE_REVIEW.md`, preserving its banner and six top-level sections. Do not overwrite an existing report without approval or execute tests/scanners without separate permission. For guidance-only or blocked writes, provide the same structure in chat and state that no file was written.
9. **Produce actionable output** - Summarize the selected report's actual file location, corrected guidance, remediation steps, evidence needed, and residual risk.

## Report Filename

Always use `CODE_REVIEW.md` at the reviewed project root for React-only,
confirmed Next.js, mixed-scope, and unconfirmed-framework reviews. Next.js
applicability controls checks, never the filename or banner. Do not create
framework-specific reports or delete legacy reports. Keep the parent and child
together when distributing this package.

## Review Focus Areas

Use these categories as the default routing map:

| Area | Review focus |
|---|---|
| JSX and output encoding | Unsafe HTML strings, active contexts, URL/CSS/JS/form-action sinks |
| Rich HTML | `dangerouslySetInnerHTML`, Markdown, CMS content, SVG, MathML, sanitizer allowlists |
| Imperative DOM | Ref/effect/wrapper writes to `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `srcdoc`; parsing followed by live DOM insertion |
| Window messaging | `postMessage`, `event.origin`, `event.source`, payload schemas, permitted actions, exact `targetOrigin` |
| CSP | Per-response nonces/hashes, report-only rollout, `object-src`, `base-uri`, `frame-ancestors` |
| Dynamic code execution | `eval()`, `new Function()`, and string forms of `setTimeout()` or `setInterval()` |
| URLs and props | `window.location`, `location.href`, `assign`/`replace`, state-derived destinations, parsed origin/protocol allowlists, untrusted prop spreading |
| Sessions and tokens | HttpOnly/Secure/SameSite cookies, localStorage/sessionStorage/IndexedDB token exposure, route guard limits |
| Secrets | Public env prefixes, build-time substitutions, serialized props, source maps, Client Component props |
| Dependencies | Lockfiles, SBOM, package provenance, install scripts, RSC transport packages, React advisories |
| CORS | API/gateway exact-origin policy, credentials, CSRF separation, no reflected arbitrary origins |
| Input validation | Server-side schemas, business rules, React Server Function arguments, authorization per operation |
| Third-party libraries | Raw HTML options, Markdown plugins/URL transforms/custom renderers, rich-text paste/import/export, external resources, isolation |
| SSR and RSC | Script-context serialization, streaming SSR nonces, script-closing sequences, data minimization |
| Automation | SCA, secret scanning, linting, SAST, production-build checks, SBOM, DAST, headers/CSP verification |

## Reference files (load on demand)

- Read [references/react-security-practices.md](references/react-security-practices.md) when mapping React guidance to OWASP ASVS 5.0, explaining the 12 practices, writing remediation guidance, or tracing DOM escape hatches, messages, navigation, and rich-content pipelines.
- Read [references/nextjs-security-practices.md](references/nextjs-security-practices.md) only when reviewed code uses Next.js, as established by the conditional section below; do not load it for React-only or unconfirmed code.
- Read [assets/react-security-review-checklist.md](assets/react-security-review-checklist.md) when performing a React security review, preparing Molina gate evidence, or checking remediation completeness.
- Read [../../SKILL.md](../../SKILL.md) before applying this child, whether invoked directly or routed by the parent.
- Read [../../references/review-contract.md](../../references/review-contract.md) before review to apply the shared scope, safety, evidence and report-write rules.
- Read [../../assets/code-review-template.md](../../assets/code-review-template.md) before producing any review report; this is the only full report template and banner source.
- Read [assets/framework-report-fields.md](assets/framework-report-fields.md) when fitting framework metadata, owner layers, validation evidence, and residual risk into the parent report.
- Use [React Best Practices (WIP)](https://molinahealthcare.sharepoint.com/:f:/r/sites/ApplicationSecurityProgram/Shared%20Documents/4.%20Assurance,%20Guidance%20and%20Standards/Application%20Security%20Requirements/React%20Best%20Practices%20(WIP)?d=w89702c53e6594c829279bff902be5706&csf=1&web=1&e=T3BZOE) when the source artifact must be inspected directly for audit traceability or to reconcile this skill with the finalized working draft.
- Read [evals/evals.json](evals/evals.json) when running regression tests, grading skill output, or comparing with-skill and without-skill behavior.
- Read [references/migration-history.md](references/migration-history.md) when checking source commits, completed historical milestones, intentional report changes, or restoring the retired source branch. This is provenance, not Next.js control guidance.

## Next.js Security Review (Conditional)

**Activation gate:** Apply this section only when reviewed code uses Next.js. Inspect the reviewed package's manifest and resolved dependency version, imports from `next` or `next/*`, or an active Next.js configuration/build entry point. A supplied Next.js code sample or explicit description of the reviewed Next.js app can establish applicability; record description-only evidence as such. A mention in documentation, an unrelated monorepo package, or a transitive lockfile entry is insufficient.

**Absent or uncertain:** For React-only code, mark Next.js applicability `NA`, skip this section and its reference, and do not recommend Next.js migrations or configuration. When context is insufficient, record `unconfirmed`, request the relevant manifest/import evidence, and continue the generic React review without inventing Next.js findings. In mixed repositories, scope these checks to the confirmed Next.js packages and their used dependencies.

Once confirmed, read [references/nextjs-security-practices.md](references/nextjs-security-practices.md) and:

1. Record the Next.js/React versions, App Router or Pages Router (or mixed), Node.js/Edge runtime, rendering/cache modes, bundler, and hosting/CDN boundary. Unknown versions remain unknown; check supported options before prescribing configuration.
2. Review App Router data access, `server-only` boundaries, minimal DTOs, RSC/Client Component props, Server Action return values, and authentication/authorization at every protected entry point. Action IDs, encrypted closures, layouts, and Proxy/Middleware do not replace authorization near the data source.
3. Review Pages Router `getServerSideProps`, `getStaticProps`, `getInitialProps`, serialized page data, and `pages/api` independently. For Pages-only remediation, use `pages/api` or the existing trusted backend; do not suggest App Router Route Handlers, Server Actions, or a router migration unless separately requested.
4. Verify session lifecycle, input validation, Server Action origin checks, separate API/Route Handler CSRF controls, body limits, rate limits, cache isolation/revalidation, CSP nonce rendering requirements, redirect/image SSRF controls, secrets, and patched production deployment as applicable.
5. Record concrete evidence and authorized test results in the inherited `CODE_REVIEW.md`; distinguish confirmed findings, checks still needed, and `NA` controls. Use the reference's ASVS chapter mapping, verifying exact requirement IDs before claiming compliance. Do not create a second framework report.

## Validation

When maintaining this skill package, run:

```powershell
pwsh scripts/validate-skill.ps1 -SkillPath .
```

The validator checks frontmatter fields, size limits, conditional load triggers, required assets/references, source links, inherited template/filename requirements, eval structure/coverage, and React/Next.js security keywords. Its content checks do not execute behavioral evals or fully parse YAML; use a YAML parser for frontmatter syntax validation. Run each behavioral eval in clean context, with and without the skill, before claiming benchmark success.

Read [evals/port-validation.json](evals/port-validation.json) when checking port provenance, structural verification, or remaining behavioral gaps.

## Output Contract

Use the parent's report contract without substituting the former framework
format. Include `Skills used: molina-appsec-code-review, react-nextjs-best-practices`
and the sections applied. Map these fields into its existing sections:

- **Scope:** React surface, Next.js applicability/evidence, known versions,
  router/runtime/cache/hosting context, and responsibility split.
- **Findings:** the parent's per-finding severity, confidence, location,
  lifecycle Status (OPEN / REMEDIATE / CLOSED), category, skill basis,
  verified ASVS mapping, owner layer, description,
  source-to-sink evidence, recommendation, and gate impact.
- **Audit trail:** framework validation rows (PASS / FAIL / NA / NOT RUN),
  unexecuted tests, unresolved findings/residual risk, and actual artifact status.

For review tasks, write only the approved `CODE_REVIEW.md`, or use the parent
chat-only fallback with an explicit no-file reason. Keep checks for unused
Next.js features `NA`, not findings. No automatic remediation, test execution,
gate approvals, or additional artifacts.