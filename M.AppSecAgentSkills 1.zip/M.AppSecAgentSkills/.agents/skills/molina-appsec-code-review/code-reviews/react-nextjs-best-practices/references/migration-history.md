# React/Next.js Review Migration History

Read when auditing source history, completed milestones, intentional report
changes, or restoring the retired source branch. This historical record does
not assert that old validation counts apply to the current package.

## Original Git History

The annotated archival tag `archive/react-nextjs-best-practices` retains the
original source tip `7b570af2545f26e87c26f3e7918ca12b04dbeedd` and its ancestors.
These five source-branch commits are retained as actual Git objects, not
recreated commits or merely a list of hashes:

| Commit | Original subject |
|---|---|
| `f3d97bd4b3c58b00ec780ede9ddef65a17ccd209` | Add React best practices skill |
| `2bc30676612bdae98e3e53999e64e544ecdcf935` | Udpating react code review skill with latest DRAFT doc |
| `949800c12b82f220a15bd680f79a1d6bd4b0aa59` | Rename React skill and add conditional Next.js security guidance |
| `ff893779e23370243fb407bc227f546234e38460` | update to use next.js filename if code contains it |
| `7b570af2545f26e87c26f3e7918ca12b04dbeedd` | Improve coverage for react DOM escape hatches |

The source branch contained seven package files plus catalog and maintainer
history changes. Original file contents, including the superseded standalone
template and original maintainer history, remain available through the tag:

```sh
git show archive/react-nextjs-best-practices:TODO.md
git show archive/react-nextjs-best-practices:.agents/skills/react-nextjs-best-practices/assets/react-code-review-template.md
```

Restore a local branch, if that name is not already in use:

```sh
git branch react-nextjs-best-practices archive/react-nextjs-best-practices
```

The archive is separate from a merge: the source commits are retained by the
tag, not claimed as ancestors of the port commit. Local retirement does not
delete the remote branch. A local commit/tag is not a remote backup; publish
both deliberately before relying on another clone for recovery.

## Historical Maintainer Milestones

The following preserves the source branch's completed phases, validation
evidence, and pending work. Historical filenames below are intentionally
recorded as they were before the port, not current output instructions.

| Date | Milestone and original evidence |
|---|---|
| 2026-08-05 | Phase 1 complete: core skill with all six frontmatter fields, Gotchas, execution flow, routing table, output contract, and reference load triggers. |
| 2026-08-06 | Phase 2 complete: 12-practice ASVS baseline updated from React Best Practices (WIP), framework checklist, and `react-code-review.md` output template. The source artifact link remains in the current child skill. |
| 2026-08-06 | Phase 3 complete: validator and four scenarios covering rich HTML/URL XSS, token/session storage, RSC/Server Action data release, SSR serialization, and dynamic execution. Historical validator: 54 PASS / 0 errors. |
| 2026-09-30 | Package renamed to `react-nextjs-best-practices`; conditional official-source Next.js guidance added while retaining the completed baseline and React report contract. |
| 2026-09-30 | Extension structural verification: ten scenarios; 108 PASS / 0 warnings / 0 errors; YAML/JSON and local links checked. Four broken-package probes rejected: missing reference, duplicate eval ID, missing coverage, weakened skip rule. Fresh-context React-only/Pages Router spot checks tightened applicability and Pages-only remediation. Not a complete behavioral benchmark. |
| 2026-09-30 | Conditional filename migration, skill v2.1: confirmed Next.js/mixed scopes used `nextjs-react-code-review.md`; React-only/unconfirmed scopes used `react-code-review.md`. Shared template, checklist, reference, and regression assertions aligned. |
| 2026-09-30 | DOM coverage, skill v2.2: imperative DOM/ref writes, Window messaging, state-derived navigation, HTML/Markdown/rich-text pipelines, safe counterexamples, and browser/renderer sources. Fifteen scenarios, including five new DOM/messaging/navigation/rich-content/safe-control cases. |
| 2026-09-30 | DOM verification: 177 structural checks, no warnings/errors; YAML/JSON, links, and five missing-coverage probes passed. Fresh-context with-skill checks exercised scenarios 11-15. Remaining observed gap: rich-content output conflated MDX compilation with execution; scenario 14 rejects that overclaim. No full benchmark pass claimed. |
| Pending at source tip | Phase 4: complete fresh-context with/without-skill benchmark for all current scenarios, retaining grading and benchmark evidence. Structural validation is not behavioral evidence. |
| Pending at source tip | Phase 5: optimize description with at least five activation prompts and two rejection prompts; verify activation without broad false positives. |

## Port Mapping and Intentional Changes

- The current child is [../SKILL.md](../SKILL.md), inside the parent review
  package, rather than a separately distributed top-level skill.
- The React reference is byte-identical to the source. Next.js security
  controls and checklist controls are retained; only reporting instructions
  are adapted.
- All 15 original scenario prompts, IDs, coverage, and fixture lists are
  retained in [../evals/evals.json](../evals/evals.json). Output expectations
  follow the parent; scenario 16 adds inheritance and status checks.
- The parent [shared template](../../../assets/code-review-template.md) replaces
  the standalone framework template and conditional filenames. Every review
  now uses one `CODE_REVIEW.md`, the same AppSec banner, six ordered sections,
  per-finding blocks, approval safeguards, and audit trail.
- Framework metadata, practice/ASVS mappings, owner layer, responsibility
  split, validation evidence, residual risk, and per-finding lifecycle Status
  remain represented. Open/Remediate/Closed is normalized to
  OPEN / REMEDIATE / CLOSED; closure requires verified remediation evidence.
- The source validator's security and coverage checks are retained while
  obsolete standalone-template/filename checks are replaced by parent
  inheritance checks. [../evals/port-validation.json](../evals/port-validation.json)
  records structural results separately from unexecuted behavioral work.
- Original branch catalog documentation is superseded by the root
  [README](../../../../../../README.md); original completed work is retained here
  and linked from the root [maintainer tracker](../../../../../../TODO.md).
