# Next.js Security Practices

Load this file only when the reviewed code uses Next.js, following the applicability gate in SKILL.md. Do not apply it to React-only/Vite applications or infer Next.js from generic SSR, RSC, or directory names.

## Scope and Source Policy

This reference supplements the React baseline using official Next.js documentation reviewed on 2026-09-30. It is not part of the React SharePoint working draft. OWASP ASVS 5.0 defines security requirements; official framework documentation and advisories define behavior. Recommendations below include enterprise hardening beyond framework defaults.

Record the resolved Next.js, React, and runtime versions, router(s), bundler, rendering strategy, enabled experimental flags, and deployment model. Match options and defaults to that version. Current documentation is not evidence that an older app supports a setting, and a historical fixed version is not a permanently safe version. Review only features actually present; record missing evidence rather than inventing findings.

## 1. Inventory and Patch the Framework

- Inventory `next`, `react`, `react-dom`, framework-integrated RSC packages, Node.js, authentication adapters, image processors, and build plugins from the lockfile and deployed artifact.
- Check [Next.js security advisories](https://github.com/vercel/next.js/security/advisories) and official React advisories against the exact installed versions and affected features. Apply supported patched releases, rebuild, and redeploy all instances; a manifest edit alone is not remediation evidence.
- Keep dependency provenance, lockfile enforcement, secret scanning, SBOM, and security tests in the pipeline. Do not run unreviewed dependency scripts merely to inspect an app.
- Distinguish App Router, Pages Router, mixed routing, static exports, Node.js, and Edge runtimes. Proxy is the newer name for Middleware; use the installed version's conventions and API/runtime support, not a blanket file rename as a security fix.

## 2. Centralize Trusted Data Access

- Use an established authenticated backend API or a server-only Data Access Layer (DAL) that validates sessions, enforces object/tenant/operation authorization, and returns minimal Data Transfer Objects (DTOs). Preserve an existing sound API boundary rather than requiring a rewrite.
- Mark privileged App Router data/session modules with `import 'server-only'` to catch accidental Client Component imports. This is a build boundary, not an authorization check or an output sanitizer.
- Validate route `params`, `searchParams`, headers, cookies, and submitted identifiers. Derive identity and tenant membership from a verified session, never from a claimed role or tenant in client input. Use parameterized data queries and explicit writable-field allowlists.
- Treat RSC payloads, rendered HTML, Client Component props, metadata, and Server Action results as data released to the caller. Return only authorized fields; avoid spreading full database records or raw service responses.
- `use client` defines a module boundary, not browser-only execution: Client Components can be prerendered on the server. `use server` marks callable server functions, not a generic declaration that arbitrary utilities are private.
- Experimental React taint APIs (`experimental_taintObjectReference`, `experimental_taintUniqueValue`, enabled with Next.js `experimental.taint` where supported) are optional defense in depth. They do not replace DTOs or authorization, and transformed/copied sensitive data may evade the original taint.

Sources: [Data security](https://nextjs.org/docs/app/guides/data-security), [Authentication and DAL](https://nextjs.org/docs/app/guides/authentication).

## 3. Authorize Every Protected Entry Point

- Treat Server Actions, Route Handlers, and Pages API Routes as directly reachable endpoints. Authenticate protected calls and authorize the specific object and operation in the entry point or its mandatory DAL path on every request. Deliberately public operations still need validation and abuse controls.
- Do not rely on hidden UI, a layout redirect, a page-level check, an unguessable action ID, or Proxy/Middleware as the only protection. Layouts need not rerender on navigation, and nested routes/actions can execute independently.
- Review Proxy/Middleware matchers, rewrites, direct URLs, prefetch/data requests, and origin-server reachability. Defense in depth at the edge must not substitute for authoritative data-layer checks.
- Prefer a maintained authentication/session library. Verify session validity, expiration, revocation, privilege changes, logout, and rotation; use server-set `HttpOnly`, `Secure`, suitably scoped `SameSite` cookies. Cookie expiry alone does not enforce backend revocation.
- Use least-privilege service credentials even when an endpoint has already authorized the user. A valid session alone does not authorize access to another user's record.

Source: [Authentication, layouts, Server Actions, and Route Handlers](https://nextjs.org/docs/app/guides/authentication).

## 4. Harden Server Actions and Mutations

- Validate all action arguments, including `FormData`, bound arguments, hidden fields, identifiers, types, lengths, and workflow state. Recheck current permissions at execution time, even when an action captures a previously authorized value.
- Export only intended actions from `use server` modules. Action IDs and dead-code elimination reduce exposure but are not security boundaries. Minimize captured closure data and return values; closure encryption is not permission enforcement or justification for sending secrets to clients.
- Keep mutations out of render paths and GET handlers. Next.js Server Actions use POST and compare `Origin` against `Host`/`X-Forwarded-Host`. These protections do not make POST inherently CSRF-safe and are not authentication.
- Keep `experimental.serverActions.allowedOrigins` absent unless additional trusted hosts are required; when needed, list narrowly scoped hostnames (and ports where required), not arbitrary domains. Have a trusted reverse proxy normalize forwarded headers. Test hostile, missing, and `null` Origin cases against the deployed version; do not claim missing Origin is always rejected.
- Do not assume Server Action protections cover Route Handlers or `pages/api`. Cookie-authenticated mutation endpoints need explicit CSRF defenses appropriate to their clients, such as a maintained token mechanism and origin validation. CORS alone does not stop CSRF or non-browser calls.
- Keep `serverActions.bodySizeLimit` bounded (official default: 1 MB; verify version), and separately limit API/Route Handler/upload bodies at application and ingress layers. Apply rate limits, timeouts, upload type/size checks, and replay/idempotency controls appropriate to each operation.
- Authenticate revalidation and preview/draft activation endpoints, constrain affected paths/tags, and verify webhook signatures and freshness where used. Never make an arbitrary caller-supplied URL a trusted redirect or invalidation target.

Sources: [Data security](https://nextjs.org/docs/app/guides/data-security), [Server Actions configuration](https://nextjs.org/docs/app/api-reference/config/next-config-js/serverActions).

## 5. Review Pages Router Separately

- `getServerSideProps` executes on the server, but returned props are visible in HTML/hydration data and client-navigation data responses. Apply session checks and field-level minimization before returning props; server execution does not make props private.
- Treat `getStaticProps` and ISR output as shareable build/generated artifacts. Do not embed personalized data or secrets in static HTML/JSON. Inspect `getInitialProps` as well: it may execute on the client during navigation.
- Protect `pages/api` handlers independently with allowed methods, authentication, object authorization, validation, CSRF where relevant, and resource limits. A protected page does not protect its API route.
- Inspect `__NEXT_DATA__`, `/_next/data` responses where emitted, `_document` custom scripts, and JSON-LD for data leakage and unsafe script-context serialization. `JSON.stringify` alone is not an HTML-script-context encoder.
- Do not prescribe Server Actions, App Router-only experimental SRI, or RSC controls for a Pages-only app. Apply shared headers, dependency, secret, and image controls where relevant.

Sources: [getServerSideProps](https://nextjs.org/docs/pages/building-your-application/data-fetching/get-server-side-props), [getStaticProps](https://nextjs.org/docs/pages/building-your-application/data-fetching/get-static-props), [getInitialProps](https://nextjs.org/docs/pages/api-reference/functions/get-initial-props), [API Routes](https://nextjs.org/docs/pages/building-your-application/routing/api-routes).

## 6. Prevent Cache and Tenant Data Leakage

- Inventory React request memoization separately from persistent Next.js data caches (`fetch`, `unstable_cache`, `use cache` where supported), route/ISR output, client Router Cache, and CDN/reverse-proxy caches. Defaults vary across releases; dynamic rendering does not prove every data fetch is uncached.
- Do not persist sessions or authorization decisions in shared cross-request caches. Prefer request-scoped memoization for repeated checks. For explicitly cacheable authorized data, authorize outside the cached computation on every access and include all server-verified user/tenant/permission inputs needed for isolation; never trust a caller-supplied cache key as authorization.
- Use the version-supported uncached/dynamic controls for sensitive data that must not persist. Review Cache Components constraints before recommending `no-store`, route flags, or `use cache`; do not assume these options compose identically across versions.
- Keep personalized HTML, RSC, and API responses out of public shared caches. Verify actual `Cache-Control` at the external boundary and that a CDN cannot return protected content before authentication runs. Do not override private responses with `public` or `s-maxage` just to improve performance.
- Preserve Next.js HTML/RSC/prefetch response distinctions in CDN cache keys, including relevant `Vary` behavior and `_rsc` query parameters for versions that use them. Do not strip protocol headers or cache-key parameters indiscriminately.
- Scope cache invalidation to authorized resources; coordinate invalidation across instances. Next.js revalidation does not automatically purge every external CDN cache. Test permission revocation, logout, tenant switching, and stale client navigation as well as initial requests.
- Verify with two users from different tenants, anonymous requests, and warm caches. Revalidation and cache hits must not bypass authorization or expose another principal's data.

Sources: [Self-hosting and caching](https://nextjs.org/docs/app/guides/self-hosting), [CDN caching](https://nextjs.org/docs/app/guides/cdn-caching), [Caching guide](https://nextjs.org/docs/app/guides/caching).

## 7. Deploy CSP Compatible with Rendering

- Use a restrictive Content Security Policy alongside contextual encoding/sanitization. Review `script-src`, `object-src`, `base-uri`, `frame-ancestors`, `form-action`, and connection/resource destinations. Keep development-only `unsafe-eval` out of production unless an independently justified component requires it.
- For nonce-based CSP, generate an unpredictable fresh nonce per response in a trusted server layer. Supply the matching CSP request header for Next.js renderer extraction and the CSP response header for browser enforcement; overwrite untrusted inbound nonce headers and pass the nonce to custom scripts as needed.
- Nonce-based pages require dynamic rendering. A build-time nonce, static shell, ISR response, or CDN-reused nonce is not a fresh per-response policy. Assess Partial Prerendering compatibility and rendering costs before recommending nonce configuration.
- Verify hydration, streaming, client navigation, `next/script`, third-party tags, and CSS-in-JS under production CSP. A header's presence alone is insufficient evidence.
- For static output, use a tested compatible hash/CSP strategy or document the rendering change required. Experimental Next.js SRI is version/bundler dependent and App Router-specific; an integrity attribute alone does not authorize inline bootstrap scripts or provide a complete strict CSP.
- Enforce HTTPS and appropriate HSTS, `X-Content-Type-Options`, Referrer Policy, framing, and Permissions Policy at the actual deployment boundary. Do not weaken CSP to silence unexplained violations.

Source: [Content Security Policy](https://nextjs.org/docs/app/guides/content-security-policy).

## 8. Constrain Redirects, Images, and Server Fetches

- Parse untrusted destinations with a trusted base and enforce required schemes, exact origins, ports, and paths. Validate `redirect`, `NextResponse.redirect`, rewrites, login return URLs, and `router.push`/`router.replace`; a same-origin-looking prefix is not an allowlist.
- Treat backend fetches and image optimization as SSRF surfaces. Constrain destinations, redirects, resolved addresses, timeouts, response sizes, and network egress. Do not forward session cookies or authorization headers to user-selected hosts.
- Configure `images.remotePatterns` narrowly, including protocol, hostname, port, tenant path, and query restrictions where supported. Omitted fields can imply broad matching. Prefer it to the deprecated `images.domains` setting.
- Image optimizer redirects are not rechecked against `remotePatterns` in the documented behavior. Disable unnecessary redirects with `maximumRedirects: 0` where supported, or constrain the trusted upstream and egress. Do not describe `remotePatterns` as a complete redirect/SSRF defense.
- Keep `dangerouslyAllowLocalIP` false where supported; do not enable it to bypass an unexplained image error. Older versions without this option require version-appropriate mitigations and patch review.
- Keep `dangerouslyAllowSVG` disabled unless justified. When enabled, require an appropriately restrictive image `contentSecurityPolicy` (including script prohibition/sandboxing) and `contentDispositionType: 'attachment'`, plus trusted/sanitized content. SVG remains active content when served directly; bypassing optimization does not sanitize it.
- Bound image qualities, sizes, response bodies, and cache resource use where supported. Review custom loaders and private-image caching separately; the default optimizer does not forward authentication headers, and shared optimization must not expose private images.

Sources: [Image component and configuration](https://nextjs.org/docs/app/api-reference/components/image), [Redirecting](https://nextjs.org/docs/app/guides/redirecting).

## 9. Protect Secrets and Production Deployment

- `NEXT_PUBLIC_*` values are build-inlined public configuration. Values exposed through `next.config.*` `env` are also bundled regardless of prefix; a non-public-looking name is not protection. Keep actual secrets in server-side secret stores and privileged modules.
- Inspect production JS, source maps, HTML, RSC/page data, action responses, public assets, error responses, and logs. Non-public environment variables can still leak when serialized. Redact logs and error payloads; framework error redaction does not sanitize custom API responses.
- Never expose `next dev` to production traffic. Run a supported production deployment, restrict origin-server access, and use ingress/reverse-proxy limits for malformed requests, slow connections, oversized bodies, and expensive operations.
- For multiple instances, deploy consistent artifacts and coordinate action encryption keys, cache invalidation, and version skew. If overriding `NEXT_SERVER_ACTIONS_ENCRYPTION_KEY`, use a secret-managed cryptographic key with supported format, consistent across the intended build/instances; protect server build artifacts containing it and plan rotation. Never publish it with `NEXT_PUBLIC_*` or config `env`.
- Static exports have no Next.js request-time authorization layer. Hosting or backend controls must protect sensitive resources; do not claim Proxy/Middleware or Server Actions protect a static export.
- Record deploy-level evidence after patching and configuration changes. Distinguish a source review from an executed production verification; no evidence means unverified, not PASS.

Sources: [Environment variables](https://nextjs.org/docs/app/guides/environment-variables), [Config env bundling](https://nextjs.org/docs/pages/api-reference/config/next-config-js/env), [Self-hosting](https://nextjs.org/docs/app/guides/self-hosting), [Static exports](https://nextjs.org/docs/app/guides/static-exports).

## Verification and ASVS Mapping

Use these OWASP ASVS 5.0 chapter-level areas for the Next.js extension. Chapter labels are not individual requirement IDs or claims of compliance; verify exact requirement identifiers against the [official ASVS release](https://github.com/OWASP/ASVS/tree/v5.0.0) before reporting them. Historical draft mappings in the React baseline are not a source for new Next.js requirement IDs.

| Review area | ASVS 5.0 chapters | Minimum evidence |
|---|---|---|
| Input, output, URLs, SSRF | V1 Encoding and Sanitization; V2 Validation and Business Logic; V4 API and Web Service | Invalid input and unapproved destination tests, reviewed sinks |
| Sessions and authorization | V6 Authentication; V7 Session Management; V8 Authorization | Direct endpoint, cross-user/tenant, expired/revoked-session tests |
| CSP, CSRF, cookies | V3 Web Frontend Security | Production browser/header evidence and hostile-origin mutation tests |
| Cache isolation and DTOs | V8 Authorization; V14 Data Protection | Warm-cache isolation tests and inspected HTML/RSC/JSON fields |
| Secrets, dependencies, hosting | V13 Configuration; V14 Data Protection; V16 Security Logging and Error Handling | Artifact/secret scan, advisory review, ingress settings, redacted errors |

Write applicable findings and verification evidence into `CODE_REVIEW.md` using the [parent's shared report template](../../../assets/code-review-template.md) and its AppSec banner, sections, finding structure, and audit trail. The parent filename applies to every review, including React-only, confirmed Next.js, mixed-scope, and unconfirmed-framework reviews; do not also create a framework report. Include source/version, affected router/endpoint, owner layer, remediation, authorized test results or tests not run, and residual risk. Mark unused features `NA`; do not penalize a React-only app for missing Next.js controls. Respect parent approval and source-read-only safeguards.