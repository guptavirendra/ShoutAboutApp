# React Best Practices Mapped to OWASP ASVS 5.0

Load this file when mapping React guidance to OWASP ASVS 5.0, explaining the 12 practices, writing remediation guidance, or tracing DOM escape hatches, messages, navigation, and rich-content pipelines.

## Standards hierarchy

1. OWASP ASVS 5.0
2. Official React documentation and security advisories
3. Corrected React 12-practice baseline from [React Best Practices (WIP)](https://molinahealthcare.sharepoint.com/:f:/r/sites/ApplicationSecurityProgram/Shared%20Documents/4.%20Assurance,%20Guidance%20and%20Standards/Application%20Security%20Requirements/React%20Best%20Practices%20(WIP)?d=w89702c53e6594c829279bff902be5706&csf=1&web=1&e=T3BZOE)
4. Application-specific implementation and verification procedures

ZeriFlow may be useful contemporary secondary context, but it is not the normative standard. The authoritative requirements are the mapped ASVS 5.0 controls; official React documentation and advisories define React-specific behavior and current platform risks.

## Source scope

The working draft source artifact is [React Best Practices (WIP)](https://molinahealthcare.sharepoint.com/:f:/r/sites/ApplicationSecurityProgram/Shared%20Documents/4.%20Assurance,%20Guidance%20and%20Standards/Application%20Security%20Requirements/React%20Best%20Practices%20(WIP)?d=w89702c53e6594c829279bff902be5706&csf=1&web=1&e=T3BZOE). It is focused on React, not a full Next.js security standard. This file preserves that React baseline. The skill's conditional Next.js section adds a separate official-source reference only when the reviewed code uses Next.js; it does not broaden the SharePoint artifact's scope.

## 1. Use JSX for safe rendering and contextual output encoding

ASVS mappings: `v5.0.0-10`, `v5.0.0-12`

React safely escapes ordinary string values rendered through JSX, so untrusted text must normally be placed in expressions such as `{value}` rather than assembled into HTML strings. This protection is contextual, not universal: values interpreted as HTML, URLs, CSS, JavaScript, form actions, or other active browser contexts require additional validation and sanitization. Ordinary JSX must be the default rendering mechanism, while every exception must be reviewed explicitly.

Common contexts requiring additional review:

- `dangerouslySetInnerHTML`, which bypasses JSX automatic escaping and inserts raw HTML directly into the DOM. Only owner-created or fully trusted HTML may be rendered through this API, and untrusted or insufficiently trusted HTML must be sanitized with a well-established sanitizer before rendering.
- `href`, `src`, and other URL attributes. React does not make untrusted URLs safe for navigation or resource loading; untrusted URLs and URIs must be validated separately.
- `eval()`, `new Function()`, and string forms of `setTimeout()` or `setInterval()`. These mechanisms interpret strings as executable JavaScript and must never receive untrusted input. They are best avoided entirely.
- Server-side rendering. When React is rendered on the server, the initial HTML response is generated as a string before it is sent to the browser. Untrusted input in server-rendered HTML must be escaped, sanitized, or safely serialized and must never be assembled through raw string concatenation.

Official React reference: common DOM components.

## 2. Centralize and sanitize rich HTML rendering

ASVS mapping: `v5.0.0-10`

Use `dangerouslySetInnerHTML` only through a narrowly controlled reusable component that sanitizes untrusted or insufficiently trusted markup with a mature HTML sanitizer such as DOMPurify. Sanitize as close as practical to the rendering sink, keep the sanitizer updated, and avoid modifying sanitized output afterward. Treat CMS content, Markdown output, rich-text editor content, SVG, MathML, and custom URI-bearing attributes as distinct risk profiles; SVG and other script-capable formats require stricter handling than ordinary HTML. All externally managed content and user input must be treated as untrusted.

Official React reference: `dangerouslySetInnerHTML` guidance.

## 3. Enforce a strict Content Security Policy

ASVS mapping: `v5.0.0-12`

Deploy a restrictive Content Security Policy as defense in depth, not as a replacement for safe rendering. Prefer per-response cryptographic nonces or hashes for scripts, and include directives such as `object-src 'none'`, `base-uri 'none'`, and an appropriate `frame-ancestors` policy. A literal placeholder in static configuration is not a nonce: the same unpredictable value must be generated for each response and inserted into both the CSP header and permitted script elements. Roll out complex policies in report-only mode, collect violation reports, remove unnecessary sources and `unsafe-inline` allowances, and then enforce the tested policy.

Official React reference: streaming SSR and nonce support.

## 4. Validate URLs, redirects, and user-controlled props

ASVS mappings: `v5.0.0-10`, `v5.0.0-12`, `v5.0.0-15`

Validate every user-controlled value that can become a navigation target, resource location, form action, or redirect. Parse relative URLs against a trusted base, allow only required protocols, require HTTPS for external destinations, and apply exact destination or hostname allowlists where navigation is not limited to the application's own origin. Protocol validation alone does not prevent open redirects or phishing. Avoid spreading untrusted objects into DOM elements or custom components; explicitly select, type, and validate permitted props, especially URL fields, style objects, form actions, and any prop a component may interpret as HTML or executable behavior.

Official React reference: React DOM component props.

## 5. Store sessions and tokens securely; route guards are UX only

ASVS mappings: `v5.0.0-12`, `v5.0.0-16`, `v5.0.0-17`, `v5.0.0-19`, `v5.0.0-23`

Prefer server-issued cookies with `HttpOnly`, `Secure`, and appropriate `SameSite` attributes for browser sessions, and use the `__Host-` prefix where its constraints fit. Do not place access tokens, refresh tokens, passwords, private keys, or equivalent credentials in `localStorage`, `sessionStorage`, IndexedDB, or other JavaScript-readable storage. Client-side protected routes and inactivity timers improve user experience, but they do not provide authorization or authoritative session expiration. The backend must validate the session, enforce idle and absolute timeouts, rotate or invalidate session identifiers as required, and authorize every protected operation and object.

## 6. Keep API keys and secrets out of client bundles

ASVS mappings: `v5.0.0-22`, `v5.0.0-23`, `v5.0.0-24`

Treat every value referenced by browser-delivered code as public, regardless of variable name or origin. Build-time substitutions such as `NEXT_PUBLIC_*`, `VITE_*`, legacy `REACT_APP_*`, webpack definitions, generated configuration files, serialized server props, and source maps can all expose values to users. Keep secrets in controlled server-side secret stores, restrict access to the smallest necessary service identity, rotate them according to policy, and expose only minimal non-sensitive data through authenticated backend endpoints. Never pass server secrets or complete privileged records into Client Components or serialized page state.

Official React reference: React Server Components.

## 7. Govern dependencies, lockfiles, and React server packages

ASVS mappings: `v5.0.0-12`, `v5.0.0-15`

Maintain an inventory and software bill of materials for direct and transitive dependencies, use trusted registries, commit and enforce lockfiles, and apply defined remediation deadlines for known vulnerabilities. A lockfile improves reproducibility but does not itself prevent malicious packages, compromised maintainers, unsafe install scripts, or poisoned updates. Review package provenance, maintenance health, permissions, install-time behavior, and namespace controls before adoption, and avoid blindly applying automated fixes without testing. Inventory and patch React Server Components transport packages and framework integrations as well as `react` and `react-dom`, because official React advisories have affected the server-side RSC ecosystem.

Official React references: critical and follow-up React Server Components advisories.

## 8. Configure CORS as an API control, not a React control

ASVS mapping: `v5.0.0-12`

Configure CORS on the API, reverse proxy, or gateway using exact trusted origins, narrowly required methods and headers, and credentials only when necessary. Do not reflect arbitrary `Origin` values or use a wildcard for sensitive responses. CORS controls whether browser JavaScript may read a cross-origin response; it is not a general network firewall, does not stop non-browser clients, and does not replace CSRF protection. React code may need to send credentials or headers correctly, but the security decision and allowlist belong to the trusted server-side layer.

## 9. Validate every input on the server, including server function arguments

ASVS mappings: `v5.0.0-10`, `v5.0.0-11`, `v5.0.0-17`

Use client-side validation to provide immediate feedback, but enforce all security and business rules in a trusted server-side layer. Define schemas, types, ranges, lengths, relationships, business limits, and workflow preconditions, and reject invalid input rather than silently truncating or broadly sanitizing it. React Server Functions are network-reachable server operations: their arguments are controlled by the client and must be validated, safely deserialized, authenticated, and authorized inside each operation. Never rely on hidden fields, disabled buttons, component state, route guards, or TypeScript types as proof that a request is valid or permitted.

Official React reference: `use server` security guidance.

## 10. Review high-risk third-party libraries and protect external resources

ASVS mappings: `v5.0.0-12`, `v5.0.0-24`

Apply risk-based review to libraries that render or parse untrusted content, process SVG or Markdown, execute dynamic code, handle authentication or payment data, access privileged browser APIs, or cross server/client trust boundaries. Selective imports and tree-shaking can reduce bundle size but are not security guarantees. Pin externally hosted scripts, styles, and fonts to approved versions and use Subresource Integrity where supported, together with CSP source restrictions. For especially risky functionality, isolate it in a sandboxed iframe, separate origin, worker, or service boundary and limit the data and capabilities exposed to it.

## 11. Secure SSR, React Server Components, and server-to-client serialization

ASVS mappings: `v5.0.0-10`, `v5.0.0-23`, `v5.0.0-24`

Never concatenate untrusted strings into server-rendered HTML or embed raw JSON into inline scripts without a serializer designed for HTML script contexts. Use modern streaming SSR APIs appropriately, apply CSP nonces where inline bootstrap scripts are required, and prevent script-closing sequences and parser ambiguities. Treat the React Server Component boundary as a data-release boundary: pass only minimal, deliberately shaped data into Client Components, not complete database records, secret environment values, authorization metadata, or privileged service responses. Experimental taint APIs can help detect accidental leakage, but they are defense in depth rather than a substitute for explicit data minimization and review.

Official React references: `renderToPipeableStream`, Server Components, `experimental_taintObjectReference`, and `experimental_taintUniqueValue`.

## 12. Automate security verification across code, build, deployment, and runtime

ASVS mappings: `v5.0.0-22`, `v5.0.0-24`

Embed repeatable security checks into pull requests, builds, releases, and production monitoring. At minimum, combine dependency analysis, secret scanning, React and TypeScript linting, targeted security lint rules, semantic SAST, production-build verification, and checks that development-only functionality is excluded. Mature programs must also generate an SBOM, test authorization and input-validation behavior, scan infrastructure and containers, verify headers and CSP after deployment, perform DAST and API testing, and collect evidence that vulnerable dependencies are remediated within policy. A passing `npm audit` or header scan is one signal, not proof that the application satisfies ASVS.

Official React reference: official React ESLint plugin.

## DOM Escape Hatch Review Supplement

This supplement extends the review procedure without changing the historical 12-practice source artifact. Apply it to React client code in any framework, including confirmed Next.js applications. Browser APIs are not made safe by React state or TypeScript types. Sources below were reviewed on 2026-09-30.

### Source-to-Sink Tracing

- Start with URL query/hash/route values, storage, API/CMS responses, user input, messages, and imported editor documents. Establish who can control each value; a same-origin API response may still contain attacker-authored content.
- Follow values through state setters, reducers, context, props, custom hooks, effects, callback refs, imperative handles, and component/library wrappers. Encoding a value earlier or putting it into state does not make it safe for a different final context.
- Inspect the actual sink and the transformations immediately preceding it. Record source, path, sink, protection, and evidence in each finding. Search results are leads, not proof; inspect aliases and wrappers rather than stopping at literal API matches.
- Confirm attacker influence and an ineffective or absent control before declaring a vulnerability. A read of `innerHTML`, a ref used for focus, a fixed trusted template, or plain-text insertion into an ordinary element is not by itself DOM XSS. If a library's implementation/configuration is unavailable, state the evidence gap rather than assuming exploitability or safety.
- Preserve evidence fidelity: do not invent code snippets, framework/bundler versions, exploit results, or requirement IDs. Distinguish a proposed test from an executed one and a browser-dependent execution risk from demonstrated execution.

### Imperative DOM Writes

- Review ref/effect/event-handler writes to `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, iframe `srcdoc`/React `srcDoc`, and supported `setHTMLUnsafe` APIs. These paths can bypass JSX text escaping even when application code never calls `dangerouslySetInnerHTML`.
- Follow `DOMParser.parseFromString` (returns a Document) and `Range.createContextualFragment` (returns a DocumentFragment) through subsequent insertion into a live document. Parsing alone is not sanitization, but parsing without an executable downstream sink does not establish XSS either. Do not claim all inserted script elements execute: behavior depends on the parsing/insertion API and browser; event attributes and other active content also matter.
- Prefer ordinary JSX text or `textContent` on ordinary text containers when HTML is not required. Do not generalize this safety to script/style elements or URL/event-handler attributes.
- For intentional rich HTML, use a maintained sanitizer with a reviewed tag/attribute/URL allowlist after untrusted transformations and before the final sink. Avoid post-sanitization mutation that reintroduces unsafe content. Test representative event attributes, dangerous URLs, SVG/MathML, and reparsing behavior; blocking script tags alone is insufficient.
- Consider Trusted Types enforcement (`require-trusted-types-for 'script'`) and narrowly allowed policies where the supported browsers and libraries permit it. A `TrustedHTML` value is only as safe as its policy: a pass-through `createHTML` is not sanitization. CSP and Trusted Types are defense in depth, not replacements for sink-appropriate protection; validate fallback behavior too.

### Window Messaging

- For `window.addEventListener('message', ...)` and `onmessage`, validate `event.origin` against exact trusted origins (scheme, host, port) before processing. Do not use substring/suffix checks or an origin supplied in `event.data`. Check `event.source` against the expected iframe/popup window when that relationship is part of the protocol; source identity alone does not establish origin trust.
- Validate payload type, schema, size, permitted message kinds, and values, even from an allowed sender. Do not pass arbitrary payload fields into DOM sinks, navigation, dynamic dispatch, or privileged operations. Authenticate/authorize any resulting server operation independently.
- Send to a specific trusted `targetOrigin`, not `'*'`, for known-origin peers and sensitive data. Do not echo a message or reply to `event.source` until the sender is validated. A retained window reference may navigate; a previous handshake is not a permanent origin guarantee.
- Wildcard Window delivery targets the specified window regardless of its current origin; it is not a broadcast to all windows. Exact origin checks do not distinguish mutually untrusted pages sharing that origin; use a separate origin or a reviewed capability protocol where that distinction is required.
- Treat opaque/`null` origins as unauthenticated, not as a trusted allowlist entry. Where sandboxed opaque-origin peers require wildcard delivery, require an explicit threat model, expected source/capability validation, and minimized non-sensitive messages; do not invent an exact origin for them.
- CORS does not authenticate window messages. Clean up listeners on unmount and avoid stale permission state, but listener cleanup alone is not a security boundary. Worker/MessagePort messaging uses different peer/capability semantics; do not blindly require Window origin checks for every API named `postMessage`.

### State-Derived Navigation

- Inspect `window.location` assignments, `location.href`, `location.assign`, `location.replace`, `window.open`, and router/navigation wrappers. Trace destinations from query parameters, storage, messages, props, and React state through to the call site; neither JSX escaping nor state storage protects imperative navigation.
- Parse destinations with `new URL(value, trustedBase)`, handle invalid input, and check allowed protocols and the parsed exact origin (and allowed paths where required). For internal redirects require the intended origin; for external links require approved HTTPS destinations according to the application's policy. Reject unexpected credentials in URLs and never use string prefix checks as an origin check.
- Test scheme-relative URLs, misleading host/userinfo forms, encoding/normalization, unsupported schemes, and allowed relative paths. Validate the final value after transformations; a previously checked string may be changed before use.
- Distinguish open redirects/phishing or unintended data disclosure from script-capable navigation/XSS. Do not label every external URL as XSS or prohibit intentional approved external links. HTML sanitization is not a navigation destination policy.

### Third-Party HTML, Markdown, and Rich-Text Components

- Inspect the installed version, props, wrapper implementation, plugins, sanitizer settings, custom renderers, and final output mode. A React component facade does not guarantee JSX escaping inside the package; Markdown parsing and a rich-text document schema do not automatically sanitize HTML.
- Preserve safe defaults where verified. For example, `react-markdown` normally escapes or skips raw HTML and renders React elements; do not assert it requires `dangerouslySetInnerHTML` or is inherently vulnerable. Inspect `rehype-raw`, `remarkPlugins`, `rehypePlugins`, `components`, and overridden `urlTransform` for changes to that boundary.
- When raw HTML is allowed, sanitize the resulting HTML/AST with an appropriate maintained sanitizer (such as a reviewed `rehype-sanitize` schema in a unified pipeline). Place it after transformations that can introduce untrusted HTML, and review any later plugins/custom components so they cannot undo protection. Check URL-bearing attributes and embeds, not only allowed tags.
- Trace the actual tree through plugin order: `rehype-raw` is a parser, not intrinsically a sanitizer bypass, and an earlier sanitizer may remove raw nodes entirely. A confirmed later unsanitized insertion is different from an unverified ordering concern. Do not invent the node shape or execution behavior of an unavailable plugin.
- Review rich-text clipboard paste, HTML import, link/embed insertion, custom nodes, preview, HTML export, storage, and all downstream viewers. Editor-side filtering does not protect an admin page that later inserts exported HTML unsafely; enforce the appropriate trust policy at each rendering boundary, with server-side validation for persisted documents.
- Treat untrusted MDX or other executable templating separately from ordinary Markdown: do not compile/evaluate it as trusted application code. Distinguish compilation from evaluation/rendering; establish the execution path before claiming executed server code. Sanitizing rendered HTML cannot undo server-side execution, and a simple input allowlist is not a sandbox. Use non-executable content formats or a separately reviewed isolation design.
- Test both unsafe and safe configurations: raw HTML without protection, unsafe URL transforms, post-sanitization mutations, editor export-to-viewer paths, and a renderer using documented safe defaults. Do not report a vulnerability solely because an HTML-capable dependency is installed.

### Evidence and Standards

For this supplement use OWASP ASVS 5.0 chapter areas V1 (Encoding and Sanitization), V2 (Validation and Business Logic), V3 (Web Frontend Security), and V8 (Authorization) as applicable. These are chapter-level mappings, not exact requirement IDs or compliance claims; verify specific requirements against the [official ASVS 5.0 release](https://github.com/OWASP/ASVS/tree/v5.0.0) rather than copying historical draft identifiers from the baseline.

Record safe counterexamples and checks not run alongside findings in the selected review report. Include browser/library versions where behavior matters and distinguish source inspection from executed browser tests. Keyword validation of this skill does not execute these paths or establish absence of vulnerabilities.

Sources: [MDN innerHTML](https://developer.mozilla.org/en-US/docs/Web/API/Element/innerHTML), [MDN postMessage](https://developer.mozilla.org/en-US/docs/Web/API/Window/postMessage), [react-markdown security](https://github.com/remarkjs/react-markdown#security).

## Primary source set

- OWASP ASVS 5.0.0 English source documents.
- DOMPurify XSS sanitizer.
- Official React common DOM components documentation.
- Official React `use server` directive documentation.
- Official React Server Components documentation.
- Official React critical and follow-up React Server Components security advisories.
- ZeriFlow React Security Best Practices as secondary comparative source.