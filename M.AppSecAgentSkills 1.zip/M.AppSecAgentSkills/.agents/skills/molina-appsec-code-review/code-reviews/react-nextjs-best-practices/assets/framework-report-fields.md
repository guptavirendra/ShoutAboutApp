# React/Next.js Fields for the Parent Report

Read this supplement when mapping framework evidence into the parent report.
It is not a report template. Always read
[the parent template](../../../assets/code-review-template.md) for the banner,
section order, and finding format, and
[the parent workflow](../../../SKILL.md) for scope and permissions.

## Scope fields

Within the parent's Scope section, record:

- React surface: client React / Next.js / Vite / SSR / RSC / Server Functions / mixed.
- Next.js applicability: confirmed with package/import or supplied-description
  evidence / NA with React-only reason / unconfirmed with missing evidence.
- Confirmed Next.js context: version, App/Pages/mixed router, runtime,
  rendering/cache mode, bundler, hosting/CDN boundary. Unknown stays unknown.
- Responsibility split:
  - React/client: rendering, prop handling, browser state and UX.
  - Trusted server/framework/API: authentication, authorization, validation,
    sessions, CSRF/CORS, server operations and protected data release.
  - Build/hosting/identity: secrets, dependencies, headers/CSP, deployment,
    identity controls and security monitoring.

## Finding fields

Use the parent's finding block and severity/confidence rules, not a separate
React findings table. Put practice and ASVS references in Skill basis and
Framework mapping, and the responsible boundary in Owner layer.

Preserve the original per-finding Status field as OPEN / REMEDIATE / CLOSED:
new findings are OPEN; REMEDIATE requires evidence of in-progress remediation;
CLOSED requires verified remediation evidence. This normalizes the source
template's Open/Remediate/Closed labels without dropping their meaning. Do not
confuse lifecycle status with check results or imply a gate approval.

For DOM/messaging/navigation/rich-content findings, include attacker-controlled
source, transformations through state/props/hooks/refs/wrappers, final sink,
and missing/ineffective protection. Distinguish confirmed weaknesses from
missing evidence; record safe counterexamples rather than flagging API names.

## Audit trail fields

Extend the parent's check table with applicable framework rows:

| Check area | Status (PASS / FAIL / NA / NOT RUN) | Evidence / reason |
|---|---|---|
| JSX / rich HTML / URL and prop validation | <status> | <source-to-sink evidence and safe controls> |
| DOM escape hatches / messaging / navigation / rich-content pipeline | <status> | <writes, origins, state, renderer configuration, tests not run> |
| Session/token storage and client bundle secrets | <status> | <redacted evidence> |
| SSR / RSC / Server Functions | <status> | <serialization, data release, operation authorization> |
| Next.js conditional review | <status> | <applicability, router, CSRF, cache, CSP, image and deployment checks> |

Record residual risk and follow-up owner/date when known. Unused features are
NA; unexecuted checks are NOT RUN, never inferred PASS. Keep the parent's six
top-level sections and AppSec banner unchanged. The only report is
`CODE_REVIEW.md`, subject to explicit approval before replacing an existing one.
