# React Security Review Checklist

Load this file when performing a React security review, preparing Molina gate evidence, or checking remediation completeness.

## Rendering and browser sinks

- [ ] Untrusted text is rendered through normal JSX interpolation unless a reviewed escape hatch is required.
- [ ] `dangerouslySetInnerHTML` use is centralized behind a reusable component with a mature sanitizer and explicit allowlist.
- [ ] Markdown, CMS content, rich text, SVG, MathML, and URI-bearing attributes are treated as distinct risk profiles.
- [ ] URL, CSS, JavaScript, form-action, and navigation contexts are validated or encoded for their specific browser sink.
- [ ] `eval()`, `new Function()`, and string-based `setTimeout()` or `setInterval()` do not receive untrusted input and are avoided wherever practical.
- [ ] SSR does not concatenate untrusted strings into HTML and uses safe serialization for inline data.
- [ ] Untrusted object spreading into DOM elements or custom components is avoided or constrained by explicit typed prop selection.

## DOM escape hatches and client trust boundaries

- [ ] Source-to-sink tracing follows URL/storage/API/CMS/message input through state, props, hooks, effects, refs, and library wrappers; state does not establish trust.
- [ ] Imperative writes to `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `srcdoc`/`srcDoc`, and `setHTMLUnsafe` are checked independently of JSX; parsed fragments are traced to live DOM insertion.
- [ ] Plain text uses JSX or `textContent` in an ordinary text container; intentional HTML has a maintained, configured sanitizer at the final boundary with no unsafe later transformation.
- [ ] Trusted Types policies sanitize rather than pass through input; supported-browser enforcement and fallback behavior are verified where used.
- [ ] Window `postMessage` listeners validate exact `event.origin`, expected `event.source` where applicable, payload schema/size, and permitted actions before processing; CORS and cleanup are not substitutes.
- [ ] Known-origin outbound messages use a specific `targetOrigin`; opaque-origin exceptions have an explicit trust/capability design and no sensitive wildcard disclosure.
- [ ] `window.location`, `location.href`, `location.assign`/`location.replace`, and navigation wrappers validate the final parsed destination from state or other inputs against protocol/origin/path policy.
- [ ] HTML/Markdown dependencies are checked for raw-HTML flags, `urlTransform`, plugin order, custom renderers, and sanitizer schema; installed package names alone are not findings.
- [ ] Rich-text paste/import/preview/export and downstream viewers enforce safe rendering; untrusted executable MDX is not treated as ordinary Markdown.
- [ ] Findings identify attacker influence, path, sink, protection failure, and evidence; safe refs, plain text, validated messages/URLs, and safe renderer defaults are retained as counterexamples.

## Session, authorization, and server trust

- [ ] Browser sessions prefer server-issued cookies with `HttpOnly`, `Secure`, and appropriate `SameSite` attributes.
- [ ] Access tokens, refresh tokens, passwords, private keys, and equivalent credentials are not stored in JavaScript-readable browser storage.
- [ ] Route guards, disabled buttons, hidden fields, and client timers are documented as UX controls only.
- [ ] Server-side authorization is enforced for every protected operation and object.
- [ ] React Server Function arguments are validated, authenticated, authorized, and safely deserialized inside each operation.

## Secrets and data release

- [ ] No secrets are exposed through `NEXT_PUBLIC_*`, `VITE_*`, `REACT_APP_*`, webpack definitions, generated config, source maps, serialized props, or Client Component props.
- [ ] Client bundles and serialized page state contain only minimal non-sensitive data.
- [ ] React Server Components pass deliberately shaped DTOs to Client Components rather than complete privileged records.
- [ ] SSR inline JSON/script data uses serializers safe for HTML script contexts.
- [ ] Streaming SSR nonce handling uses per-response unpredictable values inserted into both CSP header and permitted scripts.

## Headers, CORS, and external resources

- [ ] CSP is restrictive, tested in report-only mode before enforcement, and avoids unnecessary `unsafe-inline` allowances.
- [ ] CSP includes `object-src 'none'`, `base-uri 'none'`, and an appropriate `frame-ancestors` policy where applicable.
- [ ] CORS is configured at the API, reverse proxy, or gateway with exact trusted origins and narrow methods/headers.
- [ ] Sensitive CORS responses do not use wildcard origins or reflected arbitrary origins.
- [ ] External scripts, styles, and fonts are approved, version-pinned, protected with SRI where supported, and constrained by CSP.

## Dependencies and automation

- [ ] Direct and transitive dependencies are inventoried with SBOM support where required.
- [ ] Lockfiles are committed and enforced, but package provenance and install-time behavior are also reviewed.
- [ ] React, `react-dom`, framework integrations, and React Server Components transport packages are monitored for official advisories.
- [ ] Pull requests and builds run dependency analysis, secret scanning, React/TypeScript linting, targeted security lint rules, semantic SAST, and production-build checks.
- [ ] Releases or deployments verify headers, CSP, authorization/input-validation behavior, DAST/API testing where applicable, and remediation evidence within policy.

## Next.js (only when reviewed code uses Next.js)

For React-only code, mark this section `NA` and skip it. For insufficient evidence, record `unconfirmed` and continue the generic React review without loading the Next.js reference.

- [ ] Next.js usage evidence, package scope, resolved versions, router(s), runtime, cache/rendering modes, and hosting boundary are recorded.
- [ ] Protected Server Actions, Route Handlers, API Routes, and DAL operations authenticate and authorize each object/tenant; layout or Proxy/Middleware checks are not the only control.
- [ ] App Router server-only modules, minimal DTOs, Client Component props, closures, and action return values prevent unintended data release.
- [ ] Pages Router props, static output, hydration data, and API Routes are reviewed independently; App Router-only controls are `NA` when unused.
- [ ] Origin/forwarded-host trust, CSRF, schema validation, body limits, rate limits, preview endpoints, and revalidation authorization are verified.
- [ ] Shared caches and CDN HTML/RSC variants cannot leak personalized data; revocation and cross-tenant warm-cache tests are recorded.
- [ ] CSP is compatible with the rendering mode; per-response nonces are not reused in static/ISR/CDN output.
- [ ] Redirects, server fetches, image remote patterns/redirects, SVG, and private-network access are constrained.
- [ ] Public/config `env`, generated artifacts, production errors, framework patches, and multi-instance keys/cache behavior are verified.

## Evidence fields for gate reviews

Capture these fields when this checklist supports PRE, P2D, or P2B evidence:

| Field | Required evidence |
|---|---|
| Application surface | React framework, SSR/RSC usage, build tool, hosting model, API boundary |
| Findings | Risk, affected files/components, ASVS mappings, owner layer |
| Remediation | Code/config change, validation command, reviewer, date |
| Exceptions | Risk acceptance, expiration, compensating controls, approver |
| Runtime controls | CSP/header evidence, CORS policy evidence, monitoring/reporting evidence |

## Required output file

- [ ] Findings use the parent's [shared template](../../../assets/code-review-template.md), including its AppSec banner and six top-level sections, in one project-root `CODE_REVIEW.md` for every framework/applicability outcome.
- [ ] The file includes scope, React surface, ASVS mappings, findings, responsibility split, validation evidence, and residual risk.
- [ ] Existing reports are not overwritten without approval; source files remain read-only and tests/scanners require separate execution permission.
- [ ] The chat response identifies `CODE_REVIEW.md` and whether it was created, updated with approval, or not written with a reason; do not create a second framework report.