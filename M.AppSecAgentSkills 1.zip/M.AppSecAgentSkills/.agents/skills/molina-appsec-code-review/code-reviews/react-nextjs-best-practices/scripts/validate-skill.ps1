<#
.SYNOPSIS
    Validates the react-nextjs-best-practices skill package.
.DESCRIPTION
    Checks Agent Skills frontmatter, package structure, explicit load triggers,
    eval coverage, and required React/Next.js/ASVS security guidance keywords.
.PARAMETER SkillPath
    Path to the skill root directory. Defaults to the parent of this script directory.
#>
[CmdletBinding()]
param(
    [Alias("skill-path")]
    [string]$SkillPath = (Split-Path $PSScriptRoot -Parent)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$script:errors = @()
$script:warnings = @()
$script:passes = @()

function Fail([string]$Message) { $script:errors += "[FAIL] $Message" }
function Warn([string]$Message) { $script:warnings += "[WARN] $Message" }
function Pass([string]$Message) { $script:passes += "[PASS] $Message" }

function Get-FrontmatterField([string]$Frontmatter, [string]$Field) {
    if ($Frontmatter -match "(?m)^$([regex]::Escape($Field)):\s*(.+)$") {
        return $Matches[1].Trim().Trim('"')
    }
    return $null
}

$resolved = Resolve-Path $SkillPath -ErrorAction SilentlyContinue
if (-not $resolved) {
    Write-Error "Skill directory not found: $SkillPath"
    exit 1
}

$skillDir = $resolved.Path
$skillFile = Join-Path $skillDir "SKILL.md"
$dirName = Split-Path $skillDir -Leaf

Write-Host "`nValidating react-nextjs-best-practices skill: $skillDir`n"

if (-not (Test-Path -LiteralPath $skillFile)) {
    Fail "SKILL.md not found"
} else {
    Pass "SKILL.md exists"
    $raw = Get-Content -LiteralPath $skillFile -Raw -Encoding UTF8
    $lines = (Get-Content -LiteralPath $skillFile -Encoding UTF8).Count
    $tokens = [int]($raw.Length / 4)

    $frontmatterMatch = [regex]::Match($raw, '^---[\r\n]+(.+?)[\r\n]+---', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if (-not $frontmatterMatch.Success) {
        Fail "SKILL.md does not contain YAML frontmatter delimited by ---"
    } else {
        Pass "YAML frontmatter block found"
        $frontmatter = $frontmatterMatch.Groups[1].Value

        $name = Get-FrontmatterField $frontmatter "name"
        if (-not $name) { Fail "Required field 'name' is missing" }
        elseif ($name -ne $dirName) { Fail "name '$name' does not match directory '$dirName'" }
        elseif ($name -notmatch '^[a-z0-9]([a-z0-9-]*[a-z0-9])?$' -or $name -match '--' -or $name.Length -gt 64) { Fail "name '$name' violates Agent Skills naming rules" }
        else { Pass "name field is valid and matches directory" }

        $description = Get-FrontmatterField $frontmatter "description"
        if (-not $description) { Fail "Required field 'description' is missing" }
        elseif ($description.Length -gt 1024) { Fail "description exceeds 1024 characters ($($description.Length))" }
        else { Pass "description present ($($description.Length)/1024 chars)" }

        if ($description -and $description -match 'WHEN:' -and $description -match 'React security' -and $description -match 'React Server Components' -and $description -match 'Next\.js security review') {
            Pass "description includes React and Next.js security activation triggers"
        } else {
            Fail "description must include WHEN triggers for React security, React Server Components, and Next.js security review"
        }

        foreach ($field in @("license", "compatibility", "metadata", "allowed-tools")) {
            if ($frontmatter -match "(?m)^$([regex]::Escape($field)):") { Pass "frontmatter.$field present" }
            else { Warn "frontmatter.$field not set" }
        }

        foreach ($metadataField in @("author", "version")) {
            if ($frontmatter -match "(?m)^\s+$([regex]::Escape($metadataField)):") { Pass "metadata.$metadataField present" }
            else { Warn "metadata.$metadataField not set" }
        }
    }

    if ($lines -le 500) { Pass "SKILL.md line count $lines is within 500-line recommendation" }
    else { Fail "SKILL.md line count $lines exceeds 500-line recommendation" }

    if ($tokens -le 5000) { Pass "Estimated token count ~$tokens is within 5000-token recommendation" }
    else { Warn "Estimated token count ~$tokens exceeds 5000-token recommendation" }

    foreach ($requiredText in @("Skills used: molina-appsec-code-review, react-nextjs-best-practices", "## Gotchas", "Execution flow", "## Output Contract", "## Reference files")) {
        if ($raw -match [regex]::Escape($requiredText)) { Pass "SKILL.md contains $requiredText" }
        else { Fail "SKILL.md missing $requiredText" }
    }
}

$requiredFiles = @(
    "references/react-security-practices.md",
    "references/nextjs-security-practices.md",
    "references/migration-history.md",
    "assets/react-security-review-checklist.md",
    "../../SKILL.md",
    "../../references/review-contract.md",
    "../../assets/code-review-template.md",
    "assets/framework-report-fields.md",
    "evals/evals.json"
)

$skillRaw = if (Test-Path -LiteralPath $skillFile) { Get-Content -LiteralPath $skillFile -Raw -Encoding UTF8 } else { "" }
foreach ($requiredText in @("## Next.js Security Review (Conditional)", "**Activation gate:**", "**Absent or uncertain:**", "unconfirmed", "React-only", "Next.js applicability")) {
    if ($skillRaw -match [regex]::Escape($requiredText)) { Pass "SKILL.md contains applicability control: $requiredText" }
    else { Fail "SKILL.md missing applicability control: $requiredText" }
}
if ($skillRaw -match '(?m)^- Read \[references/nextjs-security-practices\.md\]\(references/nextjs-security-practices\.md\) only when reviewed code uses Next\.js' -and $skillRaw -match 'do not load it for React-only or unconfirmed code') {
    Pass "Next.js reference has an explicit conditional load and skip rule"
} else {
    Fail "Next.js reference must load only for confirmed Next.js code and skip React-only/unconfirmed code"
}
foreach ($relativePath in $requiredFiles) {
    $fullPath = Join-Path $skillDir $relativePath
    if (-not (Test-Path -LiteralPath $fullPath)) {
        Fail "Missing required file: $relativePath"
        continue
    }

    $content = Get-Content -LiteralPath $fullPath -Raw -Encoding UTF8
    if ($content.Length -gt 0) { Pass "$relativePath present and non-empty" }
    else { Fail "$relativePath is empty" }

    if ($skillRaw -match [regex]::Escape($relativePath)) { Pass "SKILL.md has load trigger/reference for $relativePath" }
    else { Fail "SKILL.md has no load trigger/reference for $relativePath" }
}

$nestedReferenceDirs = @(Get-ChildItem (Join-Path $skillDir "references") -Directory -Recurse -ErrorAction SilentlyContinue)
if ($nestedReferenceDirs.Count -eq 0) { Pass "No nested reference directories" }
else { Fail "Nested reference directories are not allowed: $($nestedReferenceDirs.FullName -join ', ')" }

$practicePath = Join-Path $skillDir "references/react-security-practices.md"
if (Test-Path -LiteralPath $practicePath) {
    $practice = Get-Content -LiteralPath $practicePath -Raw -Encoding UTF8
    foreach ($keyword in @("OWASP ASVS 5.0", "dangerouslySetInnerHTML", "Content Security Policy", "localStorage", "React Server Components", "React Server Functions", "NEXT_PUBLIC", "CORS", "SBOM", "v5.0.0-", "DOMPurify", "eval()", "Server-Side Rendering")) {
        if ($practice -match [regex]::Escape($keyword)) { Pass "Practices reference contains $keyword" }
        else { Fail "Practices reference missing $keyword" }
    }
}

$templatePath = Join-Path $skillDir "../../assets/code-review-template.md"
foreach ($relativePath in @("references/react-security-practices.md", "assets/react-security-review-checklist.md")) {
    $fullPath = Join-Path $skillDir $relativePath
    if (Test-Path -LiteralPath $fullPath) {
        $content = Get-Content -LiteralPath $fullPath -Raw -Encoding UTF8
        foreach ($keyword in @("source-to-sink", "innerHTML", "outerHTML", "insertAdjacentHTML", "srcdoc", "textContent", "Trusted Types", "postMessage", "event.origin", "event.source", "targetOrigin", "window.location", "location.assign", "location.replace", "urlTransform", "MDX", "counterexamples")) {
            if ($content -match [regex]::Escape($keyword)) { Pass "$relativePath covers $keyword" }
            else { Fail "$relativePath missing DOM review control: $keyword" }
        }
    }
}
foreach ($keyword in @("DOM Escape Hatch Review Supplement", "Imperative DOM", "Window messaging", "source", "final sink")) {
    if ($skillRaw.Contains($keyword)) { Pass "SKILL.md routes DOM review: $keyword" }
    else { Fail "SKILL.md missing DOM review routing: $keyword" }
}
$nextPracticePath = Join-Path $skillDir "references/nextjs-security-practices.md"
if (Test-Path -LiteralPath $nextPracticePath) {
    $nextPractice = Get-Content -LiteralPath $nextPracticePath -Raw -Encoding UTF8
    foreach ($keyword in @("App Router", "Pages Router", "server-only", "Data Access Layer", "DTO", "Server Actions", "Route Handlers", "getServerSideProps", "getStaticProps", "getInitialProps", "CSRF", "allowedOrigins", "bodySizeLimit", "Cache-Control", "_rsc", "Content Security Policy", "dynamic rendering", "remotePatterns", "maximumRedirects", "dangerouslyAllowLocalIP", "dangerouslyAllowSVG", "NEXT_PUBLIC", "NEXT_SERVER_ACTIONS_ENCRYPTION_KEY", "ASVS 5.0", "NA")) {
        if ($nextPractice -match [regex]::Escape($keyword)) { Pass "Next.js reference contains $keyword" }
        else { Fail "Next.js reference missing $keyword" }
    }
    foreach ($source in @("https://nextjs.org/docs/app/guides/data-security", "https://nextjs.org/docs/app/guides/content-security-policy", "https://nextjs.org/docs/app/guides/authentication", "https://nextjs.org/docs/app/guides/self-hosting", "https://github.com/vercel/next.js/security/advisories")) {
        if ($nextPractice.Contains($source)) { Pass "Next.js reference cites $source" }
        else { Fail "Next.js reference missing official source: $source" }
    }
}

if (Test-Path -LiteralPath $templatePath) {
    $template = Get-Content -LiteralPath $templatePath -Raw -Encoding UTF8
    foreach ($keyword in @("Thank you for conducting Molina's", "Skills used: molina-appsec-code-review", "NOT RUN", "Owner layer", "Framework mapping", "Confidence", "Residual risk", "**Status**: OPEN | REMEDIATE | CLOSED", "CLOSED requires verified remediation evidence")) {
        if ($template.Contains($keyword)) { Pass "Parent template contains $keyword" }
        else { Fail "Parent template missing $keyword" }
    }
    $sections = @([regex]::Matches($template, '(?m)^## (.+)\r?$') | ForEach-Object { $_.Groups[1].Value.Trim() })
    if (($sections -join "|") -ceq "Summary|Scope|Findings|Positive observations|Recommended next steps|Audit trail") {
        Pass "Parent template preserves all six ordered report sections"
    } else {
        Fail "Parent template must preserve its six ordered report sections"
    }
    if ($template.StartsWith('```text') -and $template.Contains([string][char]0x2588)) {
        Pass "Parent template starts with the fenced AppSec banner"
    } else {
        Fail "Parent template must start with the fenced AppSec banner"
    }
}

foreach ($keyword in @('Always use `CODE_REVIEW.md`', "React-only", "confirmed Next.js", "mixed-scope", "unconfirmed-framework", "Do not create", "framework-specific reports", "missing", "stop", "without approval")) {
    if ($skillRaw.Contains($keyword)) { Pass "Child defines inherited report safeguard: $keyword" }
    else { Fail "Child missing inherited report safeguard: $keyword" }
}
foreach ($relativePath in @("assets/framework-report-fields.md", "assets/react-security-review-checklist.md")) {
    $fullPath = Join-Path $skillDir $relativePath
    if (Test-Path -LiteralPath $fullPath) {
        $content = Get-Content -LiteralPath $fullPath -Raw -Encoding UTF8
        if ($content.Contains('`CODE_REVIEW.md`') -and $content.Contains('../../../assets/code-review-template.md')) {
            Pass "$relativePath inherits the parent template and report filename"
        } else {
            Fail "$relativePath must inherit the parent template and report filename"
        }
    }
}
if (Test-Path -LiteralPath (Join-Path $skillDir "assets/react-code-review-template.md")) {
    Fail "Child must not duplicate the full report template"
} else {
    Pass "No duplicate child report template"
}
$parentSkillPath = Join-Path $skillDir "../../SKILL.md"
if (Test-Path -LiteralPath $parentSkillPath) {
    $parentSkill = Get-Content -LiteralPath $parentSkillPath -Raw -Encoding UTF8
    if ($parentSkill.Contains('code-reviews/react-nextjs-best-practices/SKILL.md') -and $parentSkill.Contains('read the bundled child')) {
        Pass "Parent explicitly routes to the bundled child without requiring nested auto-discovery"
    } else {
        Fail "Parent must explicitly route to the bundled child"
    }
    foreach ($rule in @('**Named review type(s):** select exactly those requested', 'Do not auto-load specialists from their WHEN triggers')) {
        if ($parentSkill.Contains($rule)) { Pass "Parent preserves opt-in framework selection: $rule" }
        else { Fail "Parent missing opt-in framework selection: $rule" }
    }
}
if ((Test-Path -LiteralPath $nextPracticePath) -and $nextPractice.Contains('into `CODE_REVIEW.md`')) {
    Pass "Next.js reference requires CODE_REVIEW.md"
} else {
    Fail "Next.js reference must require CODE_REVIEW.md"
}

if ($skillRaw -match 'React Best Practices \(WIP\)' -and $skillRaw -match 'molinahealthcare\.sharepoint\.com') {
    Pass "SKILL.md contains React Best Practices (WIP) SharePoint artifact link"
} else {
    Fail "SKILL.md must contain the React Best Practices (WIP) SharePoint artifact link"
}

$evalsPath = Join-Path $skillDir "evals/evals.json"
if (Test-Path -LiteralPath $evalsPath) {
    try {
        $evals = Get-Content -LiteralPath $evalsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($evals.skill_name -eq "react-nextjs-best-practices") { Pass "evals skill_name matches react-nextjs-best-practices" }
        else { Fail "evals skill_name does not match react-nextjs-best-practices" }

        $count = @($evals.evals).Count
        if ($count -ge 15) { Pass "evals/evals.json has $count test cases" }
        else { Fail "evals/evals.json has $count test cases; expected at least 15" }

        $seenIds = @()
        $coverage = @()
        foreach ($eval in @($evals.evals)) {
            if ($eval.id -isnot [long] -and $eval.id -isnot [int]) { Fail "Eval id must be an integer" }
            elseif ($eval.id -le 0 -or $seenIds -contains $eval.id) { Fail "Eval id=$($eval.id) must be positive and unique" }
            else { $seenIds += $eval.id }

            foreach ($field in @("prompt", "expected_output")) {
                if ($eval.$field -isnot [string] -or [string]::IsNullOrWhiteSpace($eval.$field)) { Fail "Eval id=$($eval.id) requires a non-empty $field" }
            }
            if ($eval.files -isnot [array]) { Fail "Eval id=$($eval.id) files must be an array" }
            else {
                foreach ($fixture in $eval.files) {
                    if ($fixture -isnot [string] -or [string]::IsNullOrWhiteSpace($fixture)) { Fail "Eval id=$($eval.id) has an invalid fixture path" }
                    elseif (-not (Test-Path -LiteralPath (Join-Path $skillDir $fixture) -PathType Leaf)) { Fail "Eval id=$($eval.id) missing fixture: $fixture" }
                }
            }
            if ($eval.PSObject.Properties.Name -contains "coverage") {
                if ($eval.coverage -isnot [array]) { Fail "Eval id=$($eval.id) coverage must be an array" }
                else { $coverage += $eval.coverage }
            }
            $expectedReport = "CODE_REVIEW.md"
            if ($eval.PSObject.Properties.Name -notcontains "expected_report_file" -or $eval.expected_report_file -cne $expectedReport) {
                Fail "Eval id=$($eval.id) must expect report $expectedReport"
            } elseif (@($eval.assertions | Where-Object { $_ -match "(?<![a-z-])$([regex]::Escape($expectedReport))(?![a-z.-])" }).Count -eq 0) {
                Fail "Eval id=$($eval.id) must assert the exact report filename $expectedReport"
            } else {
                Pass "Eval id=$($eval.id) asserts report filename $expectedReport"
            }
            if (-not $eval.assertions -or @($eval.assertions).Count -lt 3) {
                Fail "Eval id=$($eval.id) has fewer than 3 assertions"
            } elseif ($eval.assertions -isnot [array] -or @($eval.assertions | Where-Object { $_ -isnot [string] -or [string]::IsNullOrWhiteSpace($_) }).Count -gt 0) {
                Fail "Eval id=$($eval.id) assertions must be non-empty strings in an array"
            } else {
                Pass "Eval id=$($eval.id) has $(@($eval.assertions).Count) assertions"
            }
        }
        foreach ($area in @("nextjs-app-router", "react-only", "nextjs-pages-router", "nextjs-cache-csp", "nextjs-image-ssrf", "mixed-monorepo", "unconfirmed-framework", "react-dom-writes", "window-messaging", "state-navigation", "rich-content-pipeline", "safe-dom-controls", "parent-template-inheritance")) {
            if ($coverage -contains $area) { Pass "Eval coverage declared for $area" }
            else { Fail "Missing eval coverage for $area" }
        }
    } catch {
        Fail "evals/evals.json has invalid JSON or structure: $_"
    }
}

Write-Host "`n--- Results ---"
$script:passes | ForEach-Object { Write-Host $_ -ForegroundColor Green }
$script:warnings | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
$script:errors | ForEach-Object { Write-Host $_ -ForegroundColor Red }

Write-Host "`nSummary: $($script:passes.Count) passed, $($script:warnings.Count) warnings, $($script:errors.Count) errors"

if ($script:errors.Count -gt 0) {
    Write-Host "VALIDATION FAILED" -ForegroundColor Red
    exit 1
}

Write-Host "VALIDATION PASSED" -ForegroundColor Green
exit 0