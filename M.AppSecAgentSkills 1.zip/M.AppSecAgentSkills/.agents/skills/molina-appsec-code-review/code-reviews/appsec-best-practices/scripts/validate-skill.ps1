[CmdletBinding()]
param(
    [Alias("skill-path")]
    [string]$SkillPath = (Split-Path $PSScriptRoot -Parent)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$errors = [System.Collections.Generic.List[string]]::new()
$passes = [System.Collections.Generic.List[string]]::new()
function Check([bool]$Condition, [string]$Message) {
    if ($Condition) { $passes.Add("PASS: $Message") }
    else { $errors.Add("FAIL: $Message") }
}

$resolved = Resolve-Path -LiteralPath $SkillPath -ErrorAction SilentlyContinue
if (-not $resolved) { Write-Error "Skill directory not found: $SkillPath"; exit 1 }
$dir = $resolved.Path
foreach ($file in @("SKILL.md", "../../SKILL.md", "../../references/review-contract.md", "../../assets/code-review-template.md", "assets/appsec-report-fields.md", "evals/evals.json", "evals/migration.json", "../../evals/review-selection.json")) {
    Check (Test-Path -LiteralPath (Join-Path $dir $file) -PathType Leaf) "Required file: $file"
}
if ($errors.Count -gt 0) {
    $errors | ForEach-Object { Write-Host $_ }
    exit 1
}
$raw = Get-Content -LiteralPath (Join-Path $dir "SKILL.md") -Raw
$parent = Get-Content -LiteralPath (Join-Path $dir "../../SKILL.md") -Raw
$template = Get-Content -LiteralPath (Join-Path $dir "../../assets/code-review-template.md") -Raw
$fields = Get-Content -LiteralPath (Join-Path $dir "assets/appsec-report-fields.md") -Raw
Check ($raw -match '(?m)^name: appsec-best-practices\r?$' -and (Split-Path $dir -Leaf) -ceq "appsec-best-practices") "Skill name matches directory"
foreach ($field in @("name", "description", "license", "compatibility", "metadata", "allowed-tools")) {
    Check ($raw -match "(?m)^${field}:") "Frontmatter field: $field"
}
Check (@($raw -split '\r?\n').Count -le 500 -and $raw.Length / 4 -le 5000) "Instruction size limits"
foreach ($path in @("../../SKILL.md", "../../references/review-contract.md", "../../assets/code-review-template.md", "assets/appsec-report-fields.md", "evals/evals.json", "evals/migration.json")) {
    Check ($raw.Contains($path)) "Explicit load/reference: $path"
}
foreach ($name in @("nist-ssdf", "molina-application-security", "molina-mythNOs-agentic-security", "molina-oauth-security", "owasp-genai-security", "molina-nist-218a")) {
    $path = "../../../$name/SKILL.md"
    Check ($raw.Contains($path)) "Supporting guidance route: $name"
    Check (Test-Path -LiteralPath (Join-Path $dir $path) -PathType Leaf) "Canonical supporting guidance exists: $name"
}
Check ($parent.Contains("code-reviews/appsec-best-practices/SKILL.md")) "Parent routes to this profile explicitly"
Check ($parent.Contains('The **default pair** is `cwe-699-code-review` + `appsec-best-practices`')) "Default selects CWE and AppSec pair"
Check ($parent.Contains("all three bundled profiles")) "Explicit all includes three profiles"
foreach ($text in @("formal PRE/P2D/P2B assessment was explicitly requested", "gate FAIL", "Molina only", "Missing required guidance", "NOT RUN", "not automatic execution", "Do not recursively follow")) {
    Check ($raw.Contains($text)) "Review safety boundary: $text"
}
$topics = @([regex]::Matches($raw, '(?m)^(?:[1-9]|1[0-2])\. \*\*'))
Check ($topics.Count -eq 12) "Original twelve numbered review areas"
foreach ($text in @("**Status**: OPEN | REMEDIATE | CLOSED", "**Confidence**:", "**Skill basis**:", "**Framework mapping**:", "**Gate impact**:")) {
    Check ($template.Contains($text)) "Master finding field: $text"
}
$sections = @([regex]::Matches($template, '(?m)^## (.+)\r?$') | ForEach-Object { $_.Groups[1].Value.Trim() })
Check (($sections -join "|") -ceq "Summary|Scope|Findings|Positive observations|Recommended next steps|Audit trail") "Parent six-section report structure"
Check ($template.StartsWith('```text') -and $template.Contains([string][char]0x2588)) "Parent owns fenced AppSec banner"
Check (@(Get-ChildItem -LiteralPath (Join-Path $dir "assets") -Filter "*template*" -File).Count -eq 0) "No duplicate child report template"
foreach ($text in @("../../../assets/code-review-template.md", "RITM", "control table", "owner", "due date", "verifier", "FAIL", "not assessed", "NOT RUN", "cross-framework")) {
    Check ($fields.Contains($text)) "Preserved assessment field: $text"
}
try {
    $evals = Get-Content -LiteralPath (Join-Path $dir "evals/evals.json") -Raw | ConvertFrom-Json
    Check ($evals.skill_name -ceq "appsec-best-practices" -and @($evals.evals).Count -ge 5) "Five profile scenarios"
    $ids = @()
    foreach ($eval in $evals.evals) {
        Check (($eval.id -is [int] -or $eval.id -is [long]) -and $eval.id -gt 0 -and $ids -notcontains $eval.id) "Unique eval ID: $($eval.id)"
        $ids += $eval.id
        Check (-not [string]::IsNullOrWhiteSpace($eval.prompt) -and -not [string]::IsNullOrWhiteSpace($eval.expected_output)) "Prompt/output: $($eval.id)"
        Check (@($eval.assertions).Count -ge 3 -and $eval.files -is [array]) "Assertions/fixtures: $($eval.id)"
        foreach ($file in $eval.files) {
            Check (Test-Path -LiteralPath (Join-Path $dir $file) -PathType Leaf) "Eval fixture: $file"
        }
    }
    $selection = Get-Content -LiteralPath (Join-Path $dir "../../evals/review-selection.json") -Raw | ConvertFrom-Json
    $allCase = @($selection.cases | Where-Object { $_.id -eq 5 })
    Check ($allCase.Count -eq 1 -and (($allCase[0].expected_selected | Sort-Object) -join "|") -ceq "appsec-best-practices|cwe-699-code-review|react-nextjs-best-practices") "All-types fixture selects three profiles"
    $migration = Get-Content -LiteralPath (Join-Path $dir "evals/migration.json") -Raw | ConvertFrom-Json
    Check ($migration.source_commit -ceq "e41bcd93258a394b6aeccc8f90afa5915eef2ac5") "Original source revision recorded"
} catch {
    $errors.Add("FAIL: Invalid scenario/provenance JSON or structure: $_")
}
$passes | ForEach-Object { Write-Host $_ }
$errors | ForEach-Object { Write-Host $_ }
Write-Host "Summary: $($passes.Count) passed, $($errors.Count) errors"
if ($errors.Count -gt 0) { exit 1 }
