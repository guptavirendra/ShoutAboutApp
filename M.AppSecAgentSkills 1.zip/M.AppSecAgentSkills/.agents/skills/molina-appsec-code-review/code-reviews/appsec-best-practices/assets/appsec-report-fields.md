# AppSec Fields for the Master Report

This is a field-mapping supplement, not a report template. Read the
[master template](../../../assets/code-review-template.md) and
[parent workflow](../../../SKILL.md). Preserve the parent banner, section
order, finding schema, lifecycle Status and single `CODE_REVIEW.md`.

## Summary and Scope

- Record `appsec-best-practices` selection, full or limited focus, repository,
  language/runtime, trust boundaries, and actually applied supporting skills.
- Distinguish OAuth pattern A/B/C, inference/LLM/agent/MCP surfaces, and
  model training/fine-tuning/data/weights where applicable.
- Describe SSDF and secure-by-design scope, exclusions and evidence gaps.
- Gate mode is either alignment only (decision not assessed) or an explicitly
  authorized PRE/P2D/P2B assessment. Do not infer formal authorization from
  code technology or the profile name.

## Findings and Recommended next steps

Use parent finding blocks, not separate specialist tables. Framework mapping
holds only verified requirement IDs; Skill basis cites each actually applied
skill/section. Preserve confidence, lifecycle Status, source-to-impact evidence,
owner layer, defensive recommendation, and gate impact.

Retain source-template categories such as Injection, Broken Access Control,
Secret Exposure, OAuth Misuse, AI/LLM, Supply Chain, and Governance. Separate
technical weaknesses from missing mandatory process evidence. Deduplicate
shared findings and count them once. Recommendations remain suggestions,
not executed remediation or risk acceptance.

## Audit trail

Include applicability, source/version evidence, limitations, and checks:

| Assessment area | Status (PASS / FAIL / NA / NOT RUN) | Evidence / gap |
|---|---|---|
| SSDF / secure SDLC | <status> | <relevant practices/tasks and evidence> |
| Secure-by-design / trust boundaries | <status> | <applied governance/defense layers> |
| OAuth/OIDC | <status> | <pattern, redirects, PKCE, scopes, token controls> |
| OWASP LLM / ASI / MCP | <status> | <applicable layers and verified entry IDs> |
| NIST SP 800-218A | <status> | <producer/acquirer role, data/model/pipeline controls> |
| Molina gate alignment | <status> | <PRE/P2D/P2B implications or NA reason> |

For an explicitly authorized formal gate assessment, add a `### Molina gate
assessment` subsection within Audit trail, not a seventh top-level section:

- Project, gate and applicable baseline profile.
- RITM linkage when required, using a safe operator-approved reference; no
  sensitive RITM-internal details. Missing required linkage is a blocker.
- Assessment decision PASS / CONDITIONAL / FAIL, labeled not a human approval.
- Required control table with control ID/name, PASS/CONDITIONAL/FAIL and evidence.
- Findings summary tied to parent finding numbers with lifecycle Status,
  owner, due date, and verifier. Unknown values stay explicitly unassigned.
- Tracker-status summary, blockers, missing mandatory evidence, remediation
  priorities, reviewer/date, verification evidence and residual risk.
- Requirement-category coverage and verified cross-framework mappings.

Missing mandatory gate evidence requires FAIL; the code-review coverage table
can independently contain NOT RUN checks. An alignment-only review uses
"not assessed", not a fabricated gate decision. Record blocked/incomplete
work and required escalation without approving release or altering services.
