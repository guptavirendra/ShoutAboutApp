[CmdletBinding()]
param(
    [Alias("skill-path")]
    [string]$SkillPath = (Split-Path $PSScriptRoot -Parent)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$errors = [System.Collections.Generic.List[string]]::new()
$passes = [System.Collections.Generic.List[string]]::new()

function Check([bool]$Condition, [string]$Message) {
    if ($Condition) { $passes.Add("PASS: $Message") }
    else { $errors.Add("FAIL: $Message") }
}

$resolved = Resolve-Path -LiteralPath $SkillPath -ErrorAction SilentlyContinue
if (-not $resolved) { Write-Error "Skill directory not found: $SkillPath"; exit 1 }
$dir = $resolved.Path
$required = @(
    "SKILL.md", "../../SKILL.md", "../../references/review-contract.md", "../../assets/code-review-template.md",
    "assets/cwe-report-fields.md", "references/category-detail.md",
    "evals/evals.json", "evals/migration.json"
)
foreach ($file in $required) {
    Check (Test-Path -LiteralPath (Join-Path $dir $file) -PathType Leaf) "Required file: $file"
}
if ($errors.Count -gt 0) {
    $errors | ForEach-Object { Write-Host $_ }
    exit 1
}

$raw = Get-Content -LiteralPath (Join-Path $dir "SKILL.md") -Raw
$parent = Get-Content -LiteralPath (Join-Path $dir "../../SKILL.md") -Raw
$template = Get-Content -LiteralPath (Join-Path $dir "../../assets/code-review-template.md") -Raw
$fields = Get-Content -LiteralPath (Join-Path $dir "assets/cwe-report-fields.md") -Raw
$detail = Get-Content -LiteralPath (Join-Path $dir "references/category-detail.md") -Raw
$front = [regex]::Match($raw, '(?s)^---\r?\n(.+?)\r?\n---')
Check $front.Success "Frontmatter delimiters"
foreach ($field in @("name", "description", "license", "compatibility", "metadata", "allowed-tools")) {
    Check ($front.Success -and $front.Groups[1].Value -match "(?m)^${field}:") "Frontmatter field: $field"
}
Check ($raw -match '(?m)^name: cwe-699-code-review\r?$' -and (Split-Path $dir -Leaf) -ceq "cwe-699-code-review") "Name matches child directory"
Check (@($raw -split '\r?\n').Count -le 500 -and $raw.Length / 4 -le 5000) "Skill size limits"

foreach ($text in @("../../SKILL.md", "../../assets/code-review-template.md", "assets/cwe-report-fields.md", "Skills used: molina-appsec-code-review, cwe-699-code-review", "CODE_REVIEW.md", "incomplete package", "stop")) {
    Check ($raw.Contains($text)) "Child inheritance: $text"
}
Check ($parent.Contains("code-reviews/cwe-699-code-review/SKILL.md") -and $parent.Contains("Do not rely on nested auto-discovery")) "Parent explicitly routes to bundled CWE child"
foreach ($rule in @(
    'The **default pair** is `cwe-699-code-review` + `appsec-best-practices`',
    '**Named review type(s):** select exactly those requested',
    'Do not auto-load specialists from their WHEN triggers',
    'routing and composition only'
)) {
    Check ($parent.Contains($rule)) "Parent review selection rule: $rule"
}
Check ($raw.Contains("../../references/review-contract.md") -and $parent.Contains("references/review-contract.md")) "Shared contract loaded by router and child"
Check (-not (Test-Path -LiteralPath (Join-Path $dir "assets/review-report-template.md"))) "No obsolete standalone report template"
Check ($template.StartsWith('```text') -and $template.Contains([string][char]0x2588)) "Parent owns fenced AppSec banner"
$sections = @([regex]::Matches($template, '(?m)^## (.+)\r?$') | ForEach-Object { $_.Groups[1].Value.Trim() })
Check (($sections -join "|") -ceq "Summary|Scope|Findings|Positive observations|Recommended next steps|Audit trail") "Parent six-section order"
foreach ($text in @("**Status**: OPEN | REMEDIATE | CLOSED", "**Confidence**:", "**Framework mapping**:", "CLOSED requires verified remediation evidence")) {
    Check ($template.Contains($text)) "Master finding convention: $text"
}

$routeIds = @([regex]::Matches($raw, '(?m)^\| [^|]+ \| (\d+) \|') | ForEach-Object { $_.Groups[1].Value })
$detailIds = @([regex]::Matches($detail, '(?m)^## CWE-(\d+):') | ForEach-Object { $_.Groups[1].Value })
Check ($routeIds.Count -eq 33 -and @($routeIds | Select-Object -Unique).Count -eq 33) "Exactly 33 unique routing categories"
Check ($detailIds.Count -eq 33 -and @($detailIds | Select-Object -Unique).Count -eq 33) "Exactly 33 unique detailed category sections"
Check (($routeIds | Sort-Object) -join "," -ceq (($detailIds | Sort-Object) -join ",")) "Routing/reference category sets match"
foreach ($text in @("../../../assets/code-review-template.md", "CWE 4.20", "CWE finding index", "CWE category results", "Specific CWE ID", "Recommended fix", "CRITICAL + HIGH", "NOT RUN", "NA", "No findings in reviewed scope", "Deduplicate", "OPEN / REMEDIATE / CLOSED")) {
    Check ($fields.Contains($text)) "CWE output field: $text"
}

try {
    $data = Get-Content -LiteralPath (Join-Path $dir "evals/evals.json") -Raw | ConvertFrom-Json
    Check ($data.skill_name -ceq "cwe-699-code-review") "Eval skill name"
    Check (@($data.evals).Count -ge 5) "At least five regression scenarios"
    $ids = @()
    $coverage = @()
    foreach ($eval in $data.evals) {
        Check ($eval.id -is [long] -or $eval.id -is [int]) "Integer eval ID"
        Check ($eval.id -gt 0 -and $ids -notcontains $eval.id) "Positive unique eval ID: $($eval.id)"
        $ids += $eval.id
        Check (-not [string]::IsNullOrWhiteSpace($eval.prompt) -and -not [string]::IsNullOrWhiteSpace($eval.expected_output)) "Prompt/expected output: $($eval.id)"
        Check ($eval.expected_report_file -ceq "CODE_REVIEW.md") "Master output filename: $($eval.id)"
        Check (@($eval.assertions).Count -ge 3 -and $eval.files -is [array]) "Assertions/fixtures: $($eval.id)"
        foreach ($file in $eval.files) {
            Check (Test-Path -LiteralPath (Join-Path $dir $file) -PathType Leaf) "Eval fixture: $file"
        }
        if ($eval.PSObject.Properties.Name -contains "coverage") { $coverage += $eval.coverage }
    }
    foreach ($area in @("parent-template-inheritance", "category-reporting", "deduplication", "safe-controls", "no-findings")) {
        Check ($coverage -contains $area) "Eval coverage: $area"
    }
    $migration = Get-Content -LiteralPath (Join-Path $dir "evals/migration.json") -Raw | ConvertFrom-Json
    Check ($migration.source_commit -ceq "ec7dfb673a4ee258974c6c570ab75f83ed7ac059") "Original source commit recorded"
} catch {
    $errors.Add("FAIL: Invalid eval/migration JSON or structure: $_")
}

$passes | ForEach-Object { Write-Host $_ }
$errors | ForEach-Object { Write-Host $_ }
Write-Host "Summary: $($passes.Count) passed, $($errors.Count) errors"
if ($errors.Count -gt 0) { exit 1 }
