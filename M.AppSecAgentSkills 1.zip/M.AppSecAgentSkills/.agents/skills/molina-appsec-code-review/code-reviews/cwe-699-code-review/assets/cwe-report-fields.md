# CWE-699 Fields for the Parent Report

This is a field-mapping supplement, not a standalone report template. Read
[the parent workflow](../../../SKILL.md) and
[master template](../../../assets/code-review-template.md) first. Preserve the
AppSec banner, six ordered sections, finding blocks, lifecycle Status, and
single `CODE_REVIEW.md`. Missing parent/template means stop and report an
incomplete package, not generate a replacement format.

## Summary

Retain the parent's severity counts and report total unique findings.
Add total CRITICAL + HIGH and unresolved CRITICAL/HIGH blocker counts.
Only OPEN or REMEDIATE CRITICAL/HIGH findings count as unresolved blockers.
CLOSED findings need verified remediation evidence. A remediation blocker
does not itself issue a Molina gate decision.

## Scope

Add target, language, CWE source version (CWE 4.20), reviewed categories,
excluded categories with reasons, and unexecuted checks. Use category IDs to
describe coverage, never as the weakness identifier for a concrete finding.

## Findings

Use the master finding blocks first. A specific CWE ID goes in Framework
mapping, a category name/ID in Category, and applied reference sections in
Skill basis. Keep severity, confidence, Status, location, description,
redacted evidence, defensive recommendation, and gate impact.
The inherited lifecycle Status is OPEN / REMEDIATE / CLOSED.

Then add this optional index under `### CWE finding index` within Findings.
Its rows must reference the same parent finding numbers and evidence:

| Finding | Specific CWE ID | Category (name / ID) | Location | Description | Severity | Recommended fix |
|---|---|---|---|---|---|---|
| <parent finding N> | CWE-<specific weakness> | <category / category ID> | <file:line> | <evidence-backed summary> | <parent severity> | <defensive fix> |

This preserves the original CWE matrix, not an alternative finding schema.
Do not copy the source template's illustrative vulnerabilities into real
findings. In particular, Credentials Management is category CWE-255, not the
source example's mistaken 1255. Deduplicate findings across CWE categories
and other child skills; multiple applicable mappings do not inflate totals.

## Recommended next steps

Retain the original remediation priority list, ordered by severity and then
confidence, with unresolved blockers first. Link each item to its parent
finding number and location. Do not apply fixes, approve releases, or run
tests/scanners without the parent-required authorization.

## Audit trail

Add `### CWE category results` within Audit trail:

| Category | Category CWE ID | Result | Unique findings / evidence |
|---|---|---|---|
| <reviewed category> | CWE-<category> | FAIL | <count and parent finding numbers with specific CWEs> |
| <reviewed category> | CWE-<category> | PASS | No findings in reviewed scope; <inspection evidence> |
| <unexecuted check> | CWE-<category> | NOT RUN | <missing evidence / reason> |
| <excluded category> | CWE-<category> | NA | <language/scope exclusion reason> |

For reviewed categories with no confirmed findings, include the explicit
`CWE-<ID> (<Category>): No findings in reviewed scope.` statement. Counts
across categories can overlap; the summary counts each finding once. A
category may have confirmed findings and separately unexecuted checks:
record both rather than treating partial coverage as fully validated.

Keep the original notes, assumptions, source version, static-only limits,
reviewer/date, inspected files, and checks not run. No findings in this
scope is not a claim of application security or complete category coverage.
