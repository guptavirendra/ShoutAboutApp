# Category Detail Reference

Specific child CWEs and detection patterns for each CWE-699 top-level category.
Load when reviewing a specific category and need the concrete weakness IDs and detection patterns.

---

## CWE-1228: API / Function Errors

**Scope:** Use of built-in functions or external APIs.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 242 | Use of Inherently Dangerous Function | `gets()`, `strcpy()`, `sprintf()` without bounds; insecure API flagged by SAST |
| 474 | Use of Function with Inconsistent Implementations | Platform-specific behavior assumed; no portability guard |
| 475 | Undefined Behavior for Input to API | Missing pre-condition check before calling API with constrained input domain |
| 477 | Use of Obsolete Function | Deprecated API calls: `md5()`, `crypt()`, `gets()`, `mktemp()` |

---

## CWE-1210: Audit / Logging Errors

**Scope:** Logging user activities; detecting undesired access.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 117 | Improper Output Neutralization for Logs | User-controlled data written to logs without sanitization (log injection) |
| 223 | Omission of Security-relevant Information | Missing log entries for authentication events, privilege changes, errors |
| 532 | Insertion of Sensitive Information into Log File | Passwords, tokens, PII written to log output |

---

## CWE-1211: Authentication Errors

**Scope:** Verifying identity; authentication algorithms and protocols.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 287 | Improper Authentication | Authentication decision based on untrusted input; bypass via alternate path |
| 289 | Authentication Bypass by Alternate Name | Different name/path for same resource bypasses auth check |
| 290 | Authentication Bypass by Spoofing | IP address, hostname, or header used as authentication token |
| 294 | Authentication Bypass by Capture-replay | No replay protection (nonce, timestamp, TOTP) in auth protocol |
| 295 | Improper Certificate Validation | `verify=False`, skipped hostname check, self-signed cert accepted |
| 303 | Incorrect Implementation of Authentication Algorithm | Custom auth logic; deviation from standard spec |
| 306 | Missing Authentication for Critical Function | Admin endpoint, API route, or function reachable without authentication |
| 307 | Improper Restriction of Excessive Authentication Attempts | No rate limiting, lockout, or CAPTCHA on login |
| 308 | Use of Single-factor Authentication | No MFA for high-privilege operations |

---

## CWE-1212: Authorization Errors

**Scope:** Enforcing permissions; access control decisions.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 283 | Unverified Ownership | Resource accessed without checking it belongs to the requesting user |
| 285 | Improper Authorization | Authorization check missing, bypassable, or based on untrusted data |
| 732 | Incorrect Permission Assignment for Critical Resource | File/directory permissions too permissive; world-readable sensitive files |

---

## CWE-1006: Bad Coding Practices

**Scope:** Unsafe coding patterns that increase vulnerability likelihood.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 1041 | Use of Redundant Code | Duplicate logic with divergent security behavior |
| 1059 | Insufficient Technical Documentation | Missing security contract on public API |
| 1060 | Excessive Attack Surface | Unused endpoints, features, or APIs left enabled |

---

## CWE-255: Credentials Management Errors

**Scope:** Management of credentials across their lifecycle.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 256 | Plaintext Storage of a Password | Password stored in DB, config, or file without hashing |
| 257 | Storing Passwords in a Recoverable Format | Reversible encryption used for passwords instead of one-way hash |
| 260 | Password in Configuration File | Hardcoded credentials in config YAML, `.env`, or source |
| 261 | Weak Encoding for Password | Base64 or ROT13 used instead of bcrypt/Argon2/scrypt |
| 321 | Use of Hard-coded Cryptographic Key | Symmetric key embedded in source |
| 798 | Use of Hard-coded Credentials | Username/password/API key in source code |

---

## CWE-310: Cryptographic Issues

**Scope:** Data confidentiality and integrity; encoding, encryption, hashing.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 326 | Inadequate Encryption Strength | Key size < 2048-bit RSA, < 128-bit AES, < 256-bit ECC |
| 327 | Use of a Broken or Risky Cryptographic Algorithm | MD5, SHA-1, DES, RC4, ECB mode |
| 328 | Use of Weak Hash | MD5 or SHA-1 for password hashing or security tokens |
| 330 | Use of Insufficiently Random Values | `rand()`, `Math.random()`, or seeded PRNG for security values |
| 347 | Improper Verification of Cryptographic Signature | Missing signature check; signature error ignored |

---

## CWE-320: Key Management Errors

**Scope:** Cryptographic key lifecycle: generation, storage, rotation, expiry.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 321 | Use of Hard-coded Cryptographic Key | Key embedded in source or config |
| 323 | Reusing a Nonce, Key Pair in Encryption | Same IV/nonce used for multiple messages |
| 324 | Use of a Key Past its Expiration Date | No key rotation logic; expired certificate accepted |
| 325 | Missing Cryptographic Step | Encrypt-then-MAC pattern missing; missing signature step |

---

## CWE-1215: Data Validation Issues

**Scope:** Input and output validation; boundary checks.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 20 | Improper Input Validation | No validation of length, type, format, or range at trust boundary |
| 89 | SQL Injection | String concatenation in SQL queries; no parameterized queries |
| 78 | OS Command Injection | User input passed to `system()`, `exec()`, `subprocess` without sanitization |
| 79 | Cross-site Scripting | User input reflected in HTML response without encoding |
| 90 | LDAP Injection | User input in LDAP filter without escaping |
| 91 | XML Injection | User input in XML without escaping |
| 113 | HTTP Response Splitting | CRLF injection via user-controlled headers |

---

## CWE-1218: Memory Buffer Errors

**Scope:** C/C++ and unsafe-language memory handling.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 119 | Improper Restriction of Operations within Bounds of a Memory Buffer | Buffer read/write without bounds check |
| 120 | Buffer Copy without Checking Size of Input ("Classic Buffer Overflow") | `strcpy()`, `strcat()` without length limit |
| 122 | Heap-based Buffer Overflow | `malloc()` + write beyond allocated size |
| 125 | Out-of-bounds Read | Array index not validated; pointer arithmetic |
| 416 | Use After Free | Freed pointer accessed; dangling pointer dereference |
| 476 | NULL Pointer Dereference | Pointer used without null check after `malloc()`/API return |

---

## CWE-1217: User Session Errors

**Scope:** Session management for multi-request user interactions.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 384 | Session Fixation | Session ID not rotated after authentication |
| 613 | Insufficient Session Expiration | No idle timeout; tokens without expiry |
| 614 | Sensitive Cookie Without Secure Attribute | Session cookie missing `Secure` and/or `HttpOnly` flag |

---

## CWE-189: Numeric Errors

**Scope:** Improper calculation or number conversion.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 190 | Integer Overflow or Wraparound | Arithmetic result exceeds type bounds without check |
| 191 | Integer Underflow | Unsigned subtraction produces large positive value |
| 193 | Off-by-one Error | Loop bound or array index off by one |
| 369 | Divide by Zero | Divisor not checked before division |

---

## CWE-399: Resource Management Errors

**Scope:** System resource lifecycle: allocation, release, limits.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 400 | Uncontrolled Resource Consumption | No limit on input size, request rate, loop iteration, or allocation |
| 404 | Improper Resource Shutdown or Release | File handle, DB connection, socket not closed on error path |
| 772 | Missing Release of Resource after Effective Lifetime | Resource allocated in loop without release |

---

## CWE-557: Concurrency Issues

**Scope:** Concurrent access to shared resources.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 362 | Concurrent Execution Using Shared Resource with Improper Synchronization (Race Condition) | Shared state accessed without mutex/lock |
| 366 | Race Condition within a Thread | Non-atomic read-modify-write on shared variable |
| 820 | Missing Synchronization | Shared resource mutated in multiple threads without synchronization |

---

## CWE-1213: Random Number Issues

**Scope:** Random number generation for security-sensitive purposes.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 330 | Use of Insufficiently Random Values | `rand()`, `Math.random()`, `random.random()` for tokens, IDs, or nonces |
| 331 | Insufficient Entropy | Small seed space; predictable initialization |
| 334 | Small Space of Random Values | Token space too small for brute-force resistance |
| 338 | Use of Cryptographically Weak PRNG | Non-CSPRNG used for security material |

---

## CWE-133: String Errors

**Scope:** Creation, copying, and manipulation of strings in memory. Primarily C/C++.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 134 | Use of Externally-Controlled Format String | `printf(user_input)` — format string not a literal; user data as first argument |
| 170 | Improper Null Termination | `strncpy()` without explicit null terminator; off-by-one in buffer size |
| 193 | Off-by-one Error | `strlen(s)` used as buffer size without `+1` for null byte |
| 467 | Use of sizeof() on a Pointer Type | `sizeof(ptr)` returns pointer width, not buffer size; used for `memcpy`/`memset` length |
| 676 | Use of Potentially Dangerous Function | `gets()`, `strcpy()`, `strcat()` — no bounds checking |

---

## CWE-465: Pointer Issues

**Scope:** Improper handling of pointers. Primarily C/C++ and unsafe memory languages.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 416 | Use After Free | Pointer used after `free()`; object accessed after destructor; dangling reference |
| 476 | NULL Pointer Dereference | Return value of `malloc()`, `fopen()`, or API call not checked before dereference |
| 588 | Attempt to Access Child of a Non-structure Pointer | Cast to struct pointer without type verification |
| 824 | Access of Uninitialized Pointer | Pointer declared but not assigned before use; conditional initialization paths |
| 825 | Expired Pointer Dereference | Pointer to stack variable returned and used after function returns |

---

## CWE-387: Signal Errors

**Scope:** Improper handling of signals (POSIX/C). Primarily C/C++ on Unix-like systems.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 364 | Signal Handler Race Condition | Signal handler modifies global state also accessed by main program without atomic operations |
| 479 | Signal Handler Use of a Non-reentrant Function | `malloc()`, `printf()`, `syslog()`, or other non-async-signal-safe functions called in signal handler |
| 828 | Signal Handler with Functionality that Calls Non-reentrant Function | Complex logic (memory allocation, I/O) inside signal handler |

---

## CWE-137: Data Neutralization Issues

**Scope:** Creating or neutralizing data using an incorrect format; encoding and escaping failures.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 116 | Improper Encoding or Escaping of Output | User data embedded in HTML/SQL/shell/XML without proper encoding for the target context |
| 117 | Improper Output Neutralization for Logs | User-controlled data written to logs enabling log injection (CRLF, escape sequences) |
| 838 | Inappropriate Encoding for Output Context | HTML encoding applied to SQL context, or vice versa — wrong escaping for the sink |

---

## CWE-199: Information Management Errors

**Scope:** Improper handling of sensitive information — exposure, omission, or misrepresentation.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 200 | Exposure of Sensitive Information to an Unauthorized Actor | Stack traces, debug info, internal paths in error responses; verbose error messages in production |
| 209 | Generation of Error Message Containing Sensitive Information | Exception messages that include passwords, tokens, SQL, or internal schema details |
| 215 | Insertion of Sensitive Information Into Debugging Code | Debug `print`/`console.log`/`log.debug` statements that output credentials or PII |
| 532 | Insertion of Sensitive Information into Log File | Passwords, tokens, credit card numbers, SSNs written to log output |

---

## CWE-275: Permission Issues

**Scope:** Improper assignment or handling of permissions on files, directories, or resources.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 276 | Incorrect Default Permissions | New files/dirs created world-readable or world-writable; `umask` not set |
| 277 | Insecure Inherited Permissions | Child process or spawned file inherits overly permissive parent permissions |
| 279 | Incorrect Execution-Assigned Permissions | Setuid/setgid bits applied to files that should not have elevated execution |
| 732 | Incorrect Permission Assignment for Critical Resource | Config files, key files, or secrets readable by all users; `chmod 777` on sensitive paths |

---

## CWE-355: User Interface Security Issues

**Scope:** Security weaknesses introduced at or through the user interface layer. Web and mobile UI.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 79 | Cross-site Scripting (XSS) | User input reflected in HTML response without output encoding; `innerHTML`, `document.write` with user data |
| 451 | User Interface Misrepresentation of Critical Information | Security warnings hidden or obscured; clickjacking via iframe overlay; misleading UI labels |
| 1021 | Improper Restriction of Rendered UI Layers or Frames | Missing `X-Frame-Options` or `Content-Security-Policy: frame-ancestors`; UI redressing/tapjacking |

---

## CWE-371: State Issues

**Scope:** Improper management of system state across transitions, concurrent threads, or lifecycle events.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 362 | Race Condition | TOCTOU — check-then-use pattern where state can change between check and use |
| 372 | Incomplete Internal State Distinction | Security decision based on a state flag that can be set before authentication completes |
| 374 | Passing Mutable Objects to an Untrusted Method | Shared mutable object passed to callback or plugin that can alter security-relevant state |
| 375 | Returning a Mutable Object to an Untrusted Caller | Internal mutable state (list, map, array) returned directly — caller can modify it |

---

## CWE-411: Resource Locking Problems

**Scope:** Improper handling of locks controlling access to shared resources.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 412 | Unrestricted Externally Accessible Lock | Lock file or mutex accessible to untrusted processes; denial-of-service via lock starvation |
| 413 | Improper Resource Locking | Lock not acquired before accessing shared resource; partial locking leaves window |
| 414 | Missing Lock Check | Code assumes lock is held without verifying; no assertion on lock state |
| 667 | Improper Locking | Lock not released on error path; double-lock (deadlock); lock held across blocking I/O |

---

## CWE-417: Communication Channel Errors

**Scope:** Improper handling of communication channels and access paths; alternate/covert channels.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 419 | Unprotected Primary Channel | Primary communication channel lacks authentication or encryption |
| 420 | Unprotected Alternate Channel | Alternate path (debug port, API backdoor, admin interface) accessible without primary auth controls |
| 421 | Race Condition During Access to Alternate Channel | TOCTOU on channel selection; attacker can redirect during setup window |
| 923 | Improper Restriction of Communication Channel to Intended Endpoints | Service bound to `0.0.0.0` when only loopback needed; no network-level access control |

---

## CWE-1214: Data Integrity Issues

**Scope:** Ensuring integrity of data — messages, files, and stored values.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 345 | Insufficient Verification of Data Authenticity | Data accepted without HMAC, signature, or checksum verification |
| 353 | Missing Support for Integrity Check | No integrity mechanism provided for data that crosses a trust boundary |
| 354 | Improper Validation of Integrity Check Value | Checksum or hash computed but result not verified or comparison is skippable |
| 494 | Download of Code Without Integrity Check | External script, binary, or package fetched over HTTP without hash verification |

---

## CWE-1216: Lockout Mechanism Errors

**Scope:** Account and resource lockout after repeated failed access attempts.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 307 | Improper Restriction of Excessive Authentication Attempts | No login attempt counter, rate limiting, or lockout on authentication endpoints |
| 645 | Overly Restrictive Account Lockout Mechanism | Lockout threshold so low it enables DoS; no unlock path available to legitimate user |

---

## CWE-1219: File Handling Issues

**Scope:** Handling of files, directories, and paths within a software system.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 22 | Path Traversal | User-controlled filename used in file operation without canonicalization; `../` sequences not stripped |
| 36 | Absolute Path Traversal | Absolute path from user input passed directly to file open/read/write |
| 73 | External Control of File Name or Path | User-controlled input determines the file path operated on |
| 434 | Unrestricted Upload of File with Dangerous Type | File upload endpoint accepts executable types (`.php`, `.jsp`, `.exe`) without allowlist validation |
| 538 | Insertion of Sensitive Information into Externally-Accessible File | Sensitive data written to a publicly accessible file or temp file |

---

## CWE-429: Handler Errors

**Scope:** Improper management of event handlers, exception handlers, or signal handlers.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 390 | Detection of Error Condition Without Action | Error caught and silently swallowed; empty `catch` block; exception logged but not re-raised |
| 391 | Unchecked Error Condition | Return value of function that can fail not checked (file open, network call, parse) |
| 392 | Missing Report of Error Condition | Failure condition reached but no error returned or logged; caller receives success |
| 755 | Improper Handling of Exceptional Conditions | Exception caught at wrong level; `catch (Exception e)` masking security-relevant failures |

---

## CWE-438: Behavioral Problems

**Scope:** Unexpected behaviors from code that an application uses; behavioral changes across versions or environments.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 439 | Behavioral Change in New Version or Environment | Dependency upgrade changes security-relevant behavior (e.g., default TLS version, cookie flags) without code update |
| 440 | Expected Behavior Violation | Function/API behaves differently from documented contract under edge-case inputs |

---

## CWE-569: Expression Issues

**Scope:** Incorrectly written expressions within code that cause unintended logic or behavior.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 480 | Use of Incorrect Operator | `=` instead of `==` in condition; `|` instead of `||`; bit operation instead of boolean |
| 481 | Assigning Instead of Comparing | Assignment in `if` condition: `if (x = getval())` where `==` was intended |
| 482 | Comparing Instead of Assigning | `==` used where `=` was intended in initialization; value silently not set |
| 570 | Expression is Always False | Condition that can never be true due to type mismatch or logic error |
| 571 | Expression is Always True | Tautological condition; dead code that always executes regardless of input |

---

## CWE-1225: Documentation Issues

**Scope:** Documentation provided to support, create, or analyze a product; security contracts.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 1059 | Insufficient Technical Documentation | Public API or security-sensitive function has no documented preconditions, trust boundary, or error behavior |
| 1110 | Incomplete Design Documentation | Security architecture decisions not captured; threat model not linked from code or README |

---

## CWE-1227: Encapsulation Issues

**Scope:** Bundling of data with the methods intended to operate on it; visibility and access control.

| CWE | Name | Detection pattern |
|-----|------|-------------------|
| 766 | Critical Data Element Declared Public | Security-sensitive field (credentials, keys, session token) declared `public` instead of `private` |
| 767 | Access to Critical Private Variable via Public Method | Private field exposed via public getter/setter without access control check |
| 1061 | Insufficient Encapsulation | Business logic or security state directly accessible from outside the class boundary |
| 1090 | Method Defined in Subclass Without Call to Super Method | Subclass overrides security method (`authenticate`, `validate`) without calling `super` — bypasses parent check |
