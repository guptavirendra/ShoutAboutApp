---
name: cwe-699-code-review
description: "Adds MITRE CWE-699 weakness classification to the parent Molina secure code review. Covers 33 routing categories including input validation, authentication, authorization, cryptography, memory, concurrency, credentials, and injection. Preserves specific CWE IDs, category coverage, a finding index, severity/blocker counts, and remediation priorities inside the parent's CODE_REVIEW.md. WHEN: \"CWE review\", \"CWE-699\", \"software weaknesses\", \"weakness review\", \"find weaknesses\", \"check for CWE\", \"MITRE CWE\", \"vulnerability review\", \"code audit\", \"review for injection\", \"review authentication\", \"review authorization\"."
license: MIT
compatibility: "Bundled child of molina-appsec-code-review. Keep the parent SKILL.md and assets/code-review-template.md with this package. Direct invocation loads the parent explicitly; independent nested skill discovery is not required. Package validation requires PowerShell 7."
metadata:
  author: M.AppSecAgentSkills
  version: "2.1"
  source-commit: "ec7dfb673a4ee258974c6c570ab75f83ed7ac059"
  source-path: ".agents/skills/cwe-699-code-review"
  source-spec: "https://cwe.mitre.org/data/definitions/699.html"
  source-version: "CWE 4.20"
allowed-tools: Read Grep Write
---

# CWE-699 Software Development Code Review

Adds CWE-699 classification across 33 routing categories to the parent review.
The detailed CWE reference remains the detection baseline; the parent owns
scope, source-read-only permissions, evidence standards, severity calibration,
report structure, lifecycle Status, and stop/escalation rules.

**Skills used:** molina-appsec-code-review, cwe-699-code-review (include both and the categories/sections actually examined).

This is one member of the parent's default pair, alongside
`appsec-best-practices`. Direct invocation selects CWE-699 only; it does not
start the default pair. The parent selects combinations; this child never
adds siblings based on code technology. Parent routing/contract loading is
not a separate review pass.

---

## Gotchas

- **Load the parent explicitly.** Read [../../SKILL.md](../../SKILL.md) before applying
  this child and always load the
  [shared contract](../../references/review-contract.md). Parent-to-child
  routing does not restart the parent recursively.
  If the parent or shared template is missing, report the incomplete package
  and stop; do not invent a standalone report.
- **Only the parent defines the report.** Read
  [../../assets/code-review-template.md](../../assets/code-review-template.md) for the
  sole AppSec banner, six ordered sections, and finding blocks. Keep one
  project-root `CODE_REVIEW.md`, or use the parent's explicit chat-only fallback.
- **Patterns are review leads, not automatic findings.** Check data flow,
  protections, framework behavior, and attacker prerequisites. Missing rate
  limiting or session rotation in an isolated snippet is not proof that those
  controls are absent application-wide. Do not force CRITICAL severity from
  an API name or category priority.
- **CWE-699 category IDs cannot be mapped to real-world vulnerabilities.** Category-level IDs (like CWE-255, CWE-310) are prohibited for CVE mapping. Always cite the specific child weakness ID (e.g., CWE-798, CWE-327) in findings, not the category.
- **Abstract weaknesses need context to be findings.** A class-level CWE (e.g., CWE-20 Improper Input Validation) is only a finding when you can point to the specific code location and data flow. Do not report category-level IDs without a concrete code reference.
- **Language-specific variant CWEs exist.** When reviewing code in a specific language, prefer the most specific applicable CWE variant (e.g., CWE-193 for C off-by-one) over a generic base (CWE-682 Incorrect Calculation).
- **Not all CWE-699 categories apply to every codebase.** Signal handling (CWE-387) and pointer issues (CWE-465) apply primarily to C/C++. Filter the category routing table by the target language before reviewing.
- **Documentation and behavioral issues are still security-relevant.** CWE-1225 (Documentation Issues) and CWE-438 (Behavioral Problems) are frequently overlooked but can introduce exploitable gaps in security assumptions.

---

## How to use this skill

**Skill check:** Read the parent, this file, and its category routing table
before applying CWE checks. Include both skill names and the categories
actually examined. Keep the parent and this child together for distribution.

**Execution flow:**

1. **Identify scope** — Apply parent scope rules, then determine the language,
   framework, and applicable categories. Record excluded categories and reasons.
2. **Route to categories** — For each applicable category, load the relevant reference section on demand (see Reference load triggers below).
3. **Review code** — Trace relevant patterns and confirm weaknesses against
   available evidence. Use a specific child CWE as the finding mapping and a
   category ID only for grouping. Retain the parent's severity, confidence,
   lifecycle Status, location, evidence, recommendation, and gate impact fields.
4. **Produce report** — Read the shared parent template and
   [assets/cwe-report-fields.md](assets/cwe-report-fields.md). Add CWE metadata,
   a finding index, category results, and blocker counts within the existing
   parent sections; do not replace the parent finding blocks or create another
   report. Redact sensitive evidence and obtain approval before replacing an
   existing report. Source edits and test execution require separate approval.
5. **Prioritize** — Sort by parent severity, then confidence. Preserve total
   CRITICAL + HIGH counts and flag unresolved CRITICAL/HIGH findings as
   remediation blockers, not as an automatically issued gate decision.

---

## Category routing table

Use this table to select which categories to review based on code area and language.

| Category | CWE ID | Applies to | Priority |
|----------|--------|-----------|----------|
| API / Function Errors | 1228 | All | High |
| Audit / Logging Errors | 1210 | All | High |
| Authentication Errors | 1211 | Auth flows | Critical |
| Authorization Errors | 1212 | Access control | Critical |
| Bad Coding Practices | 1006 | All | Medium |
| Behavioral Problems | 438 | All | Medium |
| Communication Channel Errors | 417 | Networking | High |
| Concurrency Issues | 557 | Threaded/async code | High |
| Credentials Management Errors | 255 | Auth, config | Critical |
| Cryptographic Issues | 310 | Crypto, TLS, hashing | Critical |
| Data Integrity Issues | 1214 | Data storage, messaging | High |
| Data Neutralization Issues | 137 | Input/output handling | High |
| Data Validation Issues | 1215 | All boundary inputs | Critical |
| Documentation Issues | 1225 | APIs, security contracts | Low |
| Encapsulation Issues | 1227 | OOP code | Medium |
| Expression Issues | 569 | All | Medium |
| File Handling Issues | 1219 | File I/O | High |
| Handler Errors | 429 | Event/exception handling | Medium |
| Information Management Errors | 199 | Logging, error output | High |
| Key Management Errors | 320 | Crypto | Critical |
| Lockout Mechanism Errors | 1216 | Auth, rate limiting | High |
| Memory Buffer Errors | 1218 | C/C++, unsafe languages | Critical |
| Numeric Errors | 189 | All | High |
| Permission Issues | 275 | File system, OS | High |
| Pointer Issues | 465 | C/C++ | Critical |
| Random Number Issues | 1213 | Crypto, tokens, IDs | High |
| Resource Locking Problems | 411 | Threaded code | High |
| Resource Management Errors | 399 | All | High |
| Signal Errors | 387 | C/C++, POSIX | High |
| State Issues | 371 | Stateful systems | High |
| String Errors | 133 | C/C++, string parsing | Critical |
| User Interface Security Issues | 355 | Web, mobile UI | High |
| User Session Errors | 1217 | Web, API sessions | Critical |

---

## Severity and lifecycle

Use only the parent's CRITICAL / HIGH / MEDIUM / LOW / INFO severity and
High / Medium / Low confidence rules. Routing-table Priority helps select
checks; it is not the severity of an observed finding. New findings are OPEN;
REMEDIATE requires evidence of ongoing work, and CLOSED requires verified
remediation evidence. Do not confuse lifecycle Status with check results.

---

## Reference load triggers

- Read [references/category-detail.md](references/category-detail.md) when reviewing any category from the routing table and need the list of specific child CWEs and detection patterns for that category.
- Read [../../SKILL.md](../../SKILL.md) before applying this child.
- Read [../../references/review-contract.md](../../references/review-contract.md) before review for shared scope, safety, evidence, severity and report-write rules.
- Read [../../assets/code-review-template.md](../../assets/code-review-template.md) before generating any review output; this is the only full report template and banner source.
- Read [assets/cwe-report-fields.md](assets/cwe-report-fields.md) when incorporating CWE-specific evidence, coverage, finding index, counts, and priorities into that report.
- Read [evals/evals.json](evals/evals.json) when testing detection calibration, safe controls, or inherited reporting.
- Read [evals/migration.json](evals/migration.json) when auditing preserved source content, intentional changes, or validation limits.

---

## Output contract

Use the parent's six sections and finding blocks without a second logo,
standalone title, or separate report file:

Include `Skills used: molina-appsec-code-review, cwe-699-code-review` and the
categories/sections actually applied.

- **Summary:** original severity counts and total CRITICAL + HIGH; also count
  unresolved CRITICAL/HIGH blockers. Count unique findings, not category matches.
- **Scope:** target/language, CWE source version (CWE 4.20), reviewed categories,
  and exclusions with reasons.
- **Findings:** parent blocks with specific CWE IDs in Framework mapping,
  category name/ID in Category, and a `### CWE finding index` cross-referencing
  the same numbered findings. Do not duplicate weaknesses reported by other
  children; cite all applicable skill bases on one finding.
- **Recommended next steps:** severity/confidence-ordered defensive fixes,
  unresolved blockers, and required validation.
- **Audit trail:** `### CWE category results`, category IDs, finding counts,
  explicit no-finding results, exclusions, unexecuted checks, assumptions and
  source/version evidence. Preserve the original notes here.

For an actually reviewed category with no confirmed weaknesses, record
`CWE-<ID> (<Category>): No findings in reviewed scope.` Mark unexecuted checks
NOT RUN and exclusions NA with reasons; neither implies "No findings".
If no findings exist, retain the parent no-confirmed-findings statement and
report limits, rather than claiming the application is secure.

## Validation

When maintaining this package, run
`pwsh scripts/validate-skill.ps1 -SkillPath .`.
The script checks required files, inheritance, routing/category preservation,
and regression definitions; it is not a full YAML parser or behavioral
benchmark. Use actual YAML parsing and fresh-context scenarios before making
corresponding claims.
