# Dependency Execution Controls

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Threat vectors covered:** WD-TV-02 (malicious build scripts / post-install hooks), WD-TV-04 (artifact integrity / tampered releases), WD-TV-06 (typosquatting / dependency confusion)
**Gate controls:** WD-P2D-02, WD-P2D-04, WD-P2B-02, WD-P2B-05, WD-P2B-06, WD-P2B-08
**Framework mapping:** SSDF PW.4.1, PW.4.4, PS.3.2; OWASP LLM03:2025, ASI04; openbsd-principles (sandbox, least privilege, input validation)

---

## Core Principle

Every dependency you install is code you did not write, reviewed by someone else (or no one), and executed with your process's permissions. Post-install hooks run at install or build time with full filesystem, network, and environment access — unless you explicitly restrict them. The default in every major ecosystem is to run all hooks. The secure posture is to run none and allowlist only those with verified need.

**Defense-in-depth order:**
1. **Source control** — allow only registry sources you trust; block unknown or private mirrors
2. **Hash pinning** — pin to content hash, not version string
3. **Execution restriction** — disable build scripts by default; allowlist exceptions
4. **Sandboxed execution** — when build scripts must run, execute in a container with no network and no credentials
5. **Dual SCA scanning** — scan with two independent tools; require zero critical unresolved findings
6. **Artifact signing** — verify signature and provenance before deployment; do not rely on signature as sole trust signal

---

## Control WD-P2D-02 — Build-Script Sandboxing Design

**Severity:** CRITICAL
**Gate:** P2D
**Objective:** The build architecture must prevent any package post-install or build-time script from accessing secrets, CI credentials, the network, or sensitive filesystem paths.

### Required Architecture Properties

**1. Default-deny execution policy:**
Configure the package manager to disable build scripts by default. Only explicitly allowlisted packages may run build scripts, and only for documented reasons.

**npm:**
```json
// .npmrc
ignore-scripts=true
```
Or with pnpm (recommended — enforces per-package allowlist):
```yaml
# pnpm-workspace.yaml or package.json
# pnpm.onlyBuiltDependencies controls which packages can run postinstall
```
```json
// package.json
{
  "pnpm": {
    "onlyBuiltDependencies": ["esbuild", "sharp"]  // explicit allowlist only
  }
}
```

**pip (Python):**
```toml
# pyproject.toml
[tool.pip]
no-build-isolation = false  # Use PEP 517 isolated build environments
```
Run pip in `--no-deps` and then `--only-binary :all:` where possible to avoid build-time execution entirely.

**Cargo (Rust):**
- Inspect all `build.rs` files before adding a dependency. There is no blanket disable flag.
- For CI: use `CARGO_BUILD_JOBS=1` and network-disabled containers to limit blast radius.
- Recommended: run `cargo build` in a network-isolated container where outbound connections fail by default.

**Maven:**
```xml
<!-- pom.xml: restrict plugin execution to known lifecycle phases -->
<build>
  <plugins>
    <!-- Only explicitly declared plugins run. No auto-discovered plugins. -->
  </plugins>
</build>
```

**2. Network isolation during dependency installation:**
Run `npm ci`, `pip install`, `cargo build`, and equivalent commands inside a container or VM with no outbound network access (or with outbound restricted to the specific registry only). A malicious post-install hook that cannot reach the attacker's exfiltration endpoint is contained.

```yaml
# GitHub Actions: use network isolation
steps:
  - name: Install dependencies (network restricted)
    run: npm ci --ignore-scripts
    # If some packages genuinely need scripts: run in isolated container
    # with only registry egress allowed, no credentials in environment
```

**3. Non-root execution for all build steps:**
No dependency installation or build step should run as root or with elevated privileges. Use:
- Docker: `USER nonroot` in Dockerfile
- GitHub Actions: run without `sudo`; use rootless containers
- Azure Pipelines: use standard agent pool (non-elevated)

### Evidence Required for P2D Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2D-02-a | Package manager configuration showing `ignore-scripts` or explicit allowlist | `.npmrc`, `package.json pnpm`, or equivalent | FAIL if not present |
| E-WD-P2D-02-b | CI configuration showing network isolation during install | CI/CD config or architecture diagram | FAIL if not present |
| E-WD-P2D-02-c | Non-root execution evidence (container config or pipeline user context) | CI/CD config or Docker config | FAIL if OPEN |

---

## Control WD-P2D-04 — Artifact Signing and Provenance Design

**Severity:** HIGH
**Gate:** P2D
**Objective:** All release artifacts must be cryptographically signed, and the signing approach must be documented before P2B testing begins.

### Required Architecture Properties

**1. Choose a signing approach:**

| Ecosystem | Recommended Signing | Alternative |
|-----------|---------------------|-------------|
| npm | `npm publish --provenance` (Sigstore in-toto attestation via GitHub Actions OIDC) | cosign blob signing |
| PyPI | GitHub OIDC attestations (`pypa/gh-action-pypi-publish` with `attestations: true`) | Sigstore `sigstore-python` |
| RubyGems | `gem cert` (legacy X.509) or cosign attestation for the `.gem` artifact | — |
| Cargo | `cargo-crev` (code review) + cosign for release assets | Sigstore experimental Rust client |
| Maven | GPG signing plugin (`maven-gpg-plugin`) + GitHub OIDC attestation for build provenance | cosign for `.jar` artifacts |

**2. Document signing key management:**
- Public keys must be published to a discoverable, tamper-evident location (npm provenance log, Sigstore Rekor, GitHub Attestations).
- Private keys must never exist in CI/CD environment files or secrets storage in plaintext (use ephemeral keys via OIDC where supported).
- For GPG signing (Maven): key must be registered in PAM; rotation ≤1 year.

**3. SLSA provenance level target:**
- Minimum: SLSA Level 1 (provenance exists and is published).
- Recommended: SLSA Level 2 (provenance is signed and includes build integrity).
- For high-criticality packages: SLSA Level 3 (builder is hardened, provenance non-forgeable).

### Evidence Required for P2D Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2D-04-a | Documented signing approach and key management policy | Architecture doc | FAIL if OPEN |
| E-WD-P2D-04-b | SLSA level target and rationale | Architecture doc | CONDITIONAL if Level 1 with plan to reach Level 2 |

---

## Control WD-P2B-02 — Build-Script Execution Sandboxed (Evidenced)

**Severity:** CRITICAL
**Gate:** P2B
**Objective:** Demonstrate that dependency installation and build-time scripts ran in a sandboxed environment with no credential access and restricted network access during the current release pipeline run.

### Required Evidence for P2B Gate

**1. Container/VM isolation run log:**
- Provide a CI pipeline run log showing the install step ran in a container with `USER nonroot` or equivalent.
- If using a network-blocked container, provide the network policy or firewall rule active during the run.

**2. Seccomp or AppArmor policy (if applicable):**
- For Docker-based builds, provide the seccomp profile in use.
- Confirm that outbound network syscalls (connect, sendmsg) to non-registry addresses are blocked.

**3. Build script allowlist verification:**
- Provide the current `.npmrc` `ignore-scripts=true` (or equivalent) configuration at the time of the build.
- If any packages are on the allowlist, provide documented justification for each.

**4. Non-root execution confirmation:**
- Provide the CI agent user context (e.g., `whoami` output from the install step, or Dockerfile `USER` directive).

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-02-a | Install step run log showing non-root user context | CI pipeline log | FAIL if OPEN |
| E-WD-P2B-02-b | Package manager config confirming ignore-scripts or allowlist | Config file at build time | FAIL if OPEN |
| E-WD-P2B-02-c | Network isolation evidence (firewall policy, container network config) | CI/CD config or network policy | FAIL if OPEN |

---

## Control WD-P2B-05 — Supply-Chain Worm Scan Passing (Two Detectors Minimum)

**Severity:** CRITICAL
**Gate:** P2B
**Objective:** Two independent supply-chain scanning tools must both pass with zero unresolved critical findings before release.

### Why Two Detectors?

A single scanner can only detect what is in its database. Behavioral and heuristic detectors catch patterns that CVE-based scanners miss. Using two detectors provides:
- Coverage breadth: one CVE-based, one behavioral/heuristic
- Independent corroboration: reduces false-negative risk
- Defense-in-depth: a worm in a CVE-free package (like mini-Shy-Halud variants) is more likely to be flagged by a behavioral detector

### Recommended Detector Pairs by Ecosystem

| Ecosystem | Detector 1 (CVE-based) | Detector 2 (behavioral/heuristic) |
|-----------|----------------------|----------------------------------|
| npm | `npm audit` | `socket.dev` CLI or `phylum analyze` |
| PyPI | `pip audit` | `osv-scanner` + `guarddog` |
| RubyGems | `bundler-audit` | `osv-scanner` |
| Cargo | `cargo audit` | `osv-scanner` |
| Maven | OWASP Dependency-Check | `osv-scanner` |
| All (container layer) | Wiz container scan | `syft` + `grype` |

### Failure Thresholds

| Finding Severity | Threshold | Gate Impact |
|-----------------|-----------|-------------|
| Critical (CVSS ≥9.0 or behavioral confirmed-malicious) | Zero tolerance — must be CLOSED before P2B gate | FAIL if any unresolved |
| High (CVSS 7.0–8.9) | Must have active remediation plan (REMEDIATE status) with owner and due date ≤7 days | CONDITIONAL |
| Medium and below | Must be acknowledged; tracked in remediation register | CONDITIONAL if > 5 unacknowledged |

### Evidence Required for P2B Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-05-a | Detector 1 scan report — zero critical unresolved | Tool output (e.g., npm audit, Wiz) | FAIL if critical OPEN |
| E-WD-P2B-05-b | Detector 2 scan report — zero critical unresolved | Tool output (e.g., socket.dev, osv-scanner) | FAIL if critical OPEN |
| E-WD-P2B-05-c | Scan date confirmation — both scans within 24 hours of gate submission | Report timestamps | FAIL if stale (>24h) |

---

## Control WD-P2B-06 — Artifact Signatures Verified at Deployment Stage

**Severity:** HIGH
**Gate:** P2B
**Objective:** Demonstrate that artifact signatures are verified at the deployment pipeline stage before any artifact is deployed or published to downstream consumers.

### Verification Requirements

**npm provenance:**
```bash
# Verify before publishing or consuming
npm audit signatures
# Or for individual package:
npm pack && cosign verify-blob --bundle provenance.bundle <package>.tgz
```

**PyPI attestations:**
```bash
# Using pip (>=23.1) with attestation verification
pip install --require-hashes -r requirements.txt
# Or using pypi-attestations:
python -m pypi_attestations verify <artifact>.whl
```

**Generic cosign:**
```bash
cosign verify-blob \
  --certificate artifact.cert \
  --signature artifact.sig \
  --certificate-identity-regexp "https://github.com/YOUR_ORG/YOUR_REPO" \
  --certificate-oidc-issuer "https://token.actions.githubusercontent.com" \
  artifact.tar.gz
```

**What to check:**
1. Signature is valid and certificate is not expired.
2. Certificate identity matches the expected CI pipeline (not just any GitHub Actions workflow).
3. Provenance claims include expected repository, workflow file, and commit SHA.
4. No unexplained version bump between last known-good and current artifact.

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-06-a | Signature verification log for latest release artifact | Deployment pipeline log | FAIL if OPEN |
| E-WD-P2B-06-b | Provenance claim inspection showing expected repo and workflow | cosign / npm audit signatures output | FAIL if OPEN |

---

## Control WD-P2B-08 — Dependency Hash Pinning Confirmed in Lock Files

**Severity:** HIGH
**Gate:** P2B
**Objective:** All dependencies must be pinned to content hashes in lock files, not version strings alone.

### Verification by Ecosystem

**npm:** `package-lock.json` must contain `integrity` field (`sha512-...`) for every dependency entry.
```bash
# Check all entries have integrity hashes
node -e "const l = require('./package-lock.json'); const missing = Object.entries(l.packages || {}).filter(([k,v]) => k && !v.integrity); console.log(missing.length ? 'MISSING HASHES:' : 'ALL HASHES PRESENT', missing.map(([k])=>k))"
```

**pip:** `requirements.txt` must use `--hash` option per package, or use `pip-compile --generate-hashes`.
```
# Example compliant requirements.txt entry:
requests==2.32.3 \
    --hash=sha256:70761cfe03c773ceb22aa2f671b4757976145175cdfca038c02654d061d6dcc6 \
    --hash=sha256:ca78cf4a4ea3efd481467c8a47a75e42c81b9793f05d028e3e5fa832e882fcfe
```

**Cargo:** `Cargo.lock` is auto-generated and content-hash based. Verify it is committed to the repository and not in `.gitignore`.

**RubyGems:** `Gemfile.lock` must be committed. Verify it is not ignored.

**Maven:** Use `maven-enforcer-plugin` with `requirePluginVersions` and `DependencyConvergence`, plus `.sha512` checksum files for critical artifacts.

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-08-a | Lock file with hash-pinned entries for all direct and transitive dependencies | Lock file review | FAIL if any direct dependency missing hash |
| E-WD-P2B-08-b | CI pipeline configured to fail if lock file is out of date | CI config or pipeline output | FAIL if OPEN |

---

## Typosquatting and Dependency Confusion Detection (WD-TV-06)

Typosquatting and dependency confusion are vectors where hash pinning and SCA scanning provide primary defense. Additional checks:

**Name similarity detection:**
- Run `socket.dev` or `phylum` with name-confusion analysis enabled.
- Confirm no recently published packages match any of your dependency names with minor variations (e.g., `reacts` vs `react`, `lodas` vs `lodash`).

**Private package namespace protection:**
- If using private packages: register the same package name on the public registry to prevent namespace squatting.
- Configure `.npmrc` with scoped registry (`@your-org:registry=https://your-private-registry`) so internal packages never fall through to the public registry.

**Minimum package age policy:**
- Consider rejecting packages published within the last N days (PNPM supports `minimumReleaseAge`).
- Tradeoff: new releases with security patches may be delayed. Set N ≤ 3 days as a minimum reasonable threshold.
