# Cache Integrity Controls

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Threat vectors covered:** WD-TV-03 (build cache poisoning)
**Gate controls:** WD-P2D-03, WD-P2B-03
**Framework mapping:** SSDF PW.6.2, RV.1.1; OWASP ASI06 (context/memory poisoning analog), ASI08 (cascading failures); correctness-by-design (cache miss triggers clean rebuild, no silent pass-through)

---

## Why Cache Poisoning Is a Distinct Threat

Build caches accelerate CI/CD pipelines by storing previously downloaded or computed artifacts. They are also an attractive attack surface:

- **Shared caches across jobs** allow a low-privilege workflow to write content that a high-privilege workflow later restores and executes.
- **Cross-run cache persistence** allows an attacker to plant a poisoned artifact that gets used in builds days or weeks later, long after the initial compromise is forgotten.
- **Cache bypass of registry checks** is the most dangerous property: when a build restores from cache, it typically skips re-downloading from the registry, which means registry-level integrity checks (npm audit, PyPI hash verification) do not run.

**Real-world precedent:** The mini-Shy-Halud worm poisoned the GitHub Actions cache. Downstream CI jobs restored the poisoned artifact from cache and executed the malicious payload without downloading from the registry — meaning standard supply-chain scanners found nothing wrong with the registry state.

---

## Control WD-P2D-03 — Build Cache Isolation and Trust Architecture

**Severity:** HIGH
**Gate:** P2D
**Objective:** The build architecture must ensure each CI job uses a cache that cannot be written by an untrusted or lower-privilege job, is cryptographically verified before use, and is isolated per project and per branch.

### Required Architecture Properties

**1. Per-job, per-branch cache isolation:**
Cache keys must be scoped so that a workflow run from a fork or a lower-trust branch cannot write to or restore from the same cache as a main-branch or release workflow.

```yaml
# GitHub Actions — secure cache key pattern
- uses: actions/cache@v4
  with:
    path: ~/.npm
    key: ${{ runner.os }}-node-${{ hashFiles('**/package-lock.json') }}
    # Restore only from caches written by the same branch:
    restore-keys: |
      ${{ runner.os }}-node-${{ github.ref_name }}-
    # NEVER use a bare key like `node-modules` with no branch/hash scoping
```

**GitHub-specific cache write permission note:** As of 2024, GitHub Actions caches written by fork PRs cannot be restored by the base repository's workflows (and vice versa) by default. Verify this isolation is active and not overridden by `ACTIONS_CACHE_URL` or custom cache action configurations.

**2. Content-addressed cache verification:**
Before a cache is restored and used, its content hash must be verified against the expected hash. The cache action must fail closed on hash mismatch — triggering a clean (no-cache) rebuild rather than using the suspect cache.

```yaml
# Pattern: verify cache hash before use
steps:
  - name: Restore cache
    id: cache-restore
    uses: actions/cache@v4
    with:
      path: ~/.npm
      key: ${{ runner.os }}-node-${{ hashFiles('**/package-lock.json') }}

  - name: Verify cache integrity
    if: steps.cache-restore.outputs.cache-hit == 'true'
    run: |
      EXPECTED_HASH=$(cat .cache-expected-hash 2>/dev/null || echo "none")
      ACTUAL_HASH=$(find ~/.npm -type f | sort | xargs sha256sum | sha256sum | awk '{print $1}')
      if [ "$EXPECTED_HASH" != "$ACTUAL_HASH" ] && [ "$EXPECTED_HASH" != "none" ]; then
        echo "CACHE INTEGRITY MISMATCH — falling back to clean install"
        rm -rf ~/.npm
        echo "cache-valid=false" >> $GITHUB_OUTPUT
      else
        echo "cache-valid=true" >> $GITHUB_OUTPUT
      fi

  - name: Install (clean if cache invalid)
    run: npm ci
    # npm ci will regenerate cache from registry if ~/.npm was cleared above
```

**3. Separate cache namespaces per project, per environment:**
- Never share a cache between `production`, `staging`, and `development` build environments.
- Scope cache keys to include the environment name, the lock file hash, and the runner OS.
- For monorepos: scope to the affected workspace, not the entire monorepo.

**4. Cache TTL and automatic expiry:**
- GitHub Actions: caches expire after 7 days of no access (platform default). Do not configure longer TTLs.
- Azure Pipelines: pipeline caches expire per pipeline configuration. Set maximum TTL to 7 days.
- Self-hosted cache stores: configure explicit expiry. Entries older than 7 days should be automatically evicted.

### Evidence Required for P2D Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2D-03-a | CI cache key configuration showing hash-scoped, branch-isolated keys | CI/CD config file | FAIL if not present |
| E-WD-P2D-03-b | Cache TTL policy (≤7 days) | CI platform config or policy doc | FAIL if OPEN |
| E-WD-P2D-03-c | Cache integrity verification step in pipeline (hash check before use) | CI/CD config | FAIL if OPEN |

---

## Control WD-P2B-03 — CI Cache Integrity Check Passing

**Severity:** HIGH
**Gate:** P2B
**Objective:** Demonstrate that the cache integrity architecture approved at P2D is running correctly in the current pipeline, with audit evidence of hash validation and clean-rebuild fallback behavior.

### Required Evidence for P2B Gate

**1. Cache hash validation log:**
- Provide a CI pipeline run log showing the cache integrity verification step ran.
- Confirm the hash matched (or, if it did not match, that the fallback clean install ran correctly).
- If the verification step has never triggered a mismatch, provide the verification step log from at least one recent build.

**2. Clean-rebuild-on-failure confirmation:**
- Provide evidence that the pipeline is configured to fall back to a clean install (no cache) when the integrity check fails.
- This can be the CI/CD configuration showing `rm -rf` or `cache-hit: false` fallback, or a test run log showing the fallback triggered.

**3. Audit trail for cache writes:**
- Identify which CI jobs are allowed to write to the cache.
- Confirm that fork workflows, pull request workflows from external contributors, and lower-trust workflows are not allowed to write to the main branch cache.
- For GitHub Actions: confirm cache write permissions align with `GITHUB_TOKEN` permissions scoping.

**4. Cache miss alert integration (recommended):**
- Configure monitoring to alert when cache miss rate unexpectedly increases.
- A sudden increase in cache misses can indicate cache eviction or tampering.

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-03-a | Cache hash validation log from most recent release pipeline run | CI pipeline log | FAIL if OPEN |
| E-WD-P2B-03-b | Clean-rebuild fallback confirmation (config or triggered run evidence) | CI/CD config or run log | FAIL if OPEN |
| E-WD-P2B-03-c | Cache write permission scope (confirming fork/PR isolation) | CI/CD config or GitHub Actions permission settings | FAIL if OPEN |

---

## Self-Hosted Cache Stores — Additional Controls

When using a self-hosted artifact proxy or cache (Artifactory, Nexus, Azure Artifacts, Verdaccio, Sonatype Nexus):

| Additional Control | Requirement | Evidence |
|-------------------|-------------|---------|
| Registry mirroring integrity | The proxy must re-validate upstream package hashes on every request, not just on first download | Proxy configuration showing hash validation on serve |
| Access control to cache write operations | Only authenticated CI service accounts may write to the cache; human developers must not have direct write access | RBAC policy export from cache store |
| Audit logging on cache writes | All cache write operations must be logged with identity, timestamp, and content hash | Audit log sample from cache store |
| Immutable artifact storage | Published/cached artifacts must not be overwritable after publish. Use immutable storage policies. | Storage policy configuration showing `mutable=false` or equivalent |

---

## Ecosystem-Specific Cache Considerations

| Ecosystem | Cache Layer | Key Recommendation |
|-----------|------------|-------------------|
| npm | `~/.npm` (local registry cache), `node_modules` (resolved modules) | Never cache `node_modules` directly in CI. Cache only `~/.npm` (the raw package store) and regenerate `node_modules` via `npm ci` on every run. |
| pip | `~/.cache/pip` | Pin to hash-based requirements file. Cache the pip cache directory, but validate lock file hash in cache key. |
| Cargo | `~/.cargo/registry`, `target/` | Cache `~/.cargo/registry` (source) and `~/.cargo/git` only. Never cache `target/` across security-sensitive builds. |
| Docker | Layer cache | Use `--no-cache` for production image builds. Use `--cache-from` only from images stored in a registry you control with immutable tags. |
| Maven | `~/.m2/repository` | Cache `.m2` with a key scoped to `pom.xml` hash. Use `maven-enforcer-plugin` to validate dependency checksums on restore. |

---

## Detection Signal: Unexpected Cache Misses as a Worm Indicator

A sudden increase in cache misses or cache key changes that are not correlated with lock file changes can indicate:
- A poisoned cache was evicted or expired (protective behavior)
- A worm modifying lock files to invalidate existing caches and force fresh downloads from a poisoned registry

Treat unexpected cache key change patterns as a security signal, not just a performance issue. Integrate with your SIEM or alerting system if possible.
