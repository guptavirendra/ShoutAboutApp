# Propagation Containment

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Threat vectors covered:** WD-TV-05 (cross-ecosystem worm propagation), WD-TV-04 (lineage tracking and artifact integrity)
**Gate controls:** WD-PRE-01, WD-PRE-02, WD-P2D-06, WD-P2B-04, WD-P2B-09, WD-P2B-10
**Framework mapping:** SSDF RV.3.3, RV.1.1, PS.3.2; OWASP ASI04, ASI07, ASI08; NIST 218A PW.1.3 (when AI agents perform registry operations); defensive-governance (trust boundaries, kill-switch escalation)

---

## Why Propagation Is the Force-Multiplier Threat

Every other threat vector in this skill suite causes damage proportional to the number of systems that immediately install the compromised package. Propagation multiplies that damage across time, ecosystem boundaries, and organizational boundaries:

- A malicious npm package embedded in a Docker image spreads to every deployment of that image.
- A compromised CI system that publishes malicious packages can infect dozens of downstream projects before it is detected.
- An AI agent performing autonomous dependency updates can propagate a worm at machine speed across a monorepo.

The mini-Shy-Halud worm infected **42+ npm packages** and also propagated to the PyPI registry, demonstrating cross-ecosystem spread from a single initial compromise. The mini-Shy-Halud group was also believed to have outstanding, undetected access to CI/CD systems of major software companies weeks after the initial incident.

---

## Control WD-PRE-01 — Supply-Chain Threat Model Scope Declaration

**Severity:** HIGH
**Gate:** PRE
**Objective:** Before any architecture or development work begins, the project team must produce and agree on a written inventory of all ecosystems, package managers, CI platforms, and deployment targets in scope for the project. This becomes the bounded scope for all subsequent worm defense controls.

### Required Content

The scope declaration must include:

1. **Ecosystem inventory:**
   - Programming languages and their package managers (e.g., TypeScript/npm, Python/pip, Rust/Cargo)
   - Whether any automated dependency update tools are in use (Dependabot, Renovate, Snyk PR bot)
   - Whether any AI agents have write access to dependency manifests

2. **CI/CD platform inventory:**
   - CI/CD platforms and versions (GitHub Actions, Azure Pipelines, Jenkins, etc.)
   - Whether the CI/CD system publishes packages to any external registry
   - Whether OIDC-based federated credentials are in use

3. **Deployment target inventory:**
   - Container registries in use
   - Kubernetes clusters or other orchestration targets
   - Cloud-based dependency sources (Azure Artifacts, AWS CodeArtifact)

4. **Trust boundary map:**
   - Which registries are trusted sources
   - Which registries (private or public) the project publishes to
   - Which downstream consumers (internal or external) will be affected by a malicious release

### Evidence Required for PRE Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-PRE-01-a | Written ecosystem and CI/CD inventory | Architecture doc or intake form | FAIL if not present |
| E-WD-PRE-01-b | Trust boundary map covering source and publish registries | Architecture diagram or policy doc | FAIL if not present |

---

## Control WD-PRE-02 — Trust-Boundary Declaration for Package Registries

**Severity:** HIGH
**Gate:** PRE
**Objective:** Written policy must declare which package registries the project trusts as sources, distinguishing public registries, private mirrors, and internal repositories.

### Required Policy Elements

1. **Approved source registries:** List each registry the project is allowed to install packages from. Any registry not on this list must not be used.
2. **Private registry policy:** If a private registry (Artifactory, Nexus, Azure Artifacts) is in use, document which upstream registries it mirrors and whether upstream packages are re-validated.
3. **Prohibited patterns:** Explicitly state that direct installation from arbitrary URLs, GitHub repos without pinned commits, or unknown private registries is prohibited.
4. **Exception process:** State how an exception to use an unlisted registry source can be approved (requires IT Security review and documented risk acceptance).

### Evidence Required for PRE Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-PRE-02-a | Written registry trust policy | Policy document | FAIL if not present |

---

## Control WD-P2D-06 — Cross-Ecosystem Dependency Lineage Plan

**Severity:** HIGH
**Gate:** P2D
**Objective:** The project architecture must define how SBOM and dependency lineage will be tracked across all ecosystem layers identified in WD-PRE-01, covering the full chain from source code through container through deployment.

### Lineage Scope Requirements

**Layer 1 — Source packages:**
- SBOM generated from package manager lock files
- Tool: `syft`, `cyclonedx-*`, or equivalent
- Format: CycloneDX or SPDX JSON

**Layer 2 — Container images:**
- SBOM generated from Docker image layers
- Tool: `syft` against built Docker image
- Must include the base image SBOM (OS packages, system libraries) and the application layer SBOM

**Layer 3 — Deployment artifacts:**
- If deploying Helm charts or Kubernetes manifests: SBOM covering image references
- If using serverless functions: SBOM covering the bundled artifact

**Cross-layer lineage:**
- The project must define how SBOMs from different layers are linked (e.g., the container SBOM references the application SBOM which references the npm SBOM).
- Tool recommendation: CycloneDX BOM Merger or in-toto link metadata.

### Evidence Required for P2D Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2D-06-a | SBOM scope definition document (layers covered, tools, format) | Architecture doc | FAIL if OPEN |
| E-WD-P2D-06-b | SBOM generation automation confirmed in CI pipeline design | CI/CD config or architecture doc | FAIL if OPEN |

---

## Control WD-P2B-04 — Signed SBOM Generated and Validated

**Severity:** HIGH
**Gate:** P2B
**Objective:** A signed, complete SBOM covering all dependency layers must be generated at the current pipeline run and its signature validated.

### Generation Requirements

```yaml
# Example: syft-based SBOM generation in GitHub Actions
steps:
  - name: Generate application SBOM
    uses: anchore/sbom-action@v0
    with:
      image: "" # Use path-based scan for source
      path: "."
      format: cyclonedx-json
      output-file: sbom-application.json

  - name: Generate container SBOM
    uses: anchore/sbom-action@v0
    with:
      image: "${{ env.IMAGE_REF }}"
      format: cyclonedx-json
      output-file: sbom-container.json

  - name: Sign SBOMs with cosign
    run: |
      cosign sign-blob --bundle sbom-application.bundle sbom-application.json
      cosign sign-blob --bundle sbom-container.bundle sbom-container.json

  - name: Upload SBOM artifacts
    uses: actions/upload-artifact@v4
    with:
      name: sboms
      path: |
        sbom-application.json
        sbom-application.bundle
        sbom-container.json
        sbom-container.bundle
```

### Validation Requirements

The deployment pipeline must verify SBOM signatures before deployment:

```bash
# Verify application SBOM
cosign verify-blob \
  --bundle sbom-application.bundle \
  --certificate-identity-regexp "https://github.com/YOUR_ORG/YOUR_REPO" \
  --certificate-oidc-issuer "https://token.actions.githubusercontent.com" \
  sbom-application.json

# Check for unexpected new components (delta analysis)
# Compare component list against last known-good SBOM
```

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-04-a | Signed SBOM artifact (application layer) with signature bundle | CI pipeline artifact | FAIL if OPEN |
| E-WD-P2B-04-b | Signed SBOM artifact (container layer, if applicable) | CI pipeline artifact | FAIL if OPEN |
| E-WD-P2B-04-c | SBOM signature verification log from deployment pipeline | Deployment pipeline log | FAIL if OPEN |

---

## Control WD-P2B-09 — Incident Response Runbook Reviewed and Owner Assigned

**Severity:** MEDIUM
**Gate:** P2B
**Objective:** The worm incident response runbook must be reviewed, a named incident owner must be designated, and the escalation path must be confirmed before release.

### Requirements

- The [Worm-Incident-Response-Runbook](../assets/Worm-Incident-Response-Runbook.md) must be reviewed by the project's IT Security contact.
- A named incident owner (individual, not a team) must be documented.
- The escalation path (incident owner → IT Security → CISO) must be confirmed and reachable.
- Review must occur within 30 days of the P2B gate submission.

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-09-a | IR runbook review confirmation with reviewer name and date | Email, RITM comment, or meeting notes | CONDITIONAL if runbook exists but review pending with committed date |
| E-WD-P2B-09-b | Named incident owner documentation | RITM record or project contacts doc | CONDITIONAL if pending assignment with due date |

---

## Control WD-P2B-10 — Cross-Ecosystem Lineage SBOM Validated

**Severity:** HIGH
**Gate:** P2B
**Objective:** The cross-ecosystem SBOM covering all dependency layers must be validated at P2B, with no unresolved provenance gaps in the lineage chain.

### Validation Checklist

- [ ] Application SBOM (source packages) present and signed
- [ ] Container SBOM (OS packages + application layer) present and signed
- [ ] Base image source is from a trusted, pinned digest reference (e.g., `node:22-alpine@sha256:...`)
- [ ] No anonymous or unknown components in any SBOM layer
- [ ] SBOM delta comparison: no unexpected new components since last gate
- [ ] SBOM cross-layer linking: container SBOM references or embeds application SBOM
- [ ] SBOM retained as build artifact and linked in RITM record

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-10-a | Cross-layer SBOM validation checklist completed | Gate submission artifact | FAIL if any checkbox OPEN |
| E-WD-P2B-10-b | SBOM delta report (new components vs. last gate) | SBOM comparison tool output | FAIL if unexpected new components with no explanation |

---

## Kill-Switch and Emergency Revocation

**Kill-switch requirement:** Every project that publishes packages must have a documented emergency revocation procedure before P2B gate passes.

### Kill-Switch Elements

1. **Package deprecation / unpublish authority:**
   - Who has permission to `npm deprecate`, `npm unpublish` (within the 72-hour window), or mark a PyPI release as yanked?
   - Document the named individuals and their access level.

2. **Downstream consumer notification:**
   - How will consuming projects be notified of a compromised release?
   - Options: GitHub Security Advisory, npm Security Advisory, email to known consumers, RITM notification chain.

3. **Rollback target version:**
   - What is the last known-good version that should be pinned as the rollback target?
   - Document in the IR runbook with instructions for consumer projects.

4. **Registry-level revocation timeline:**
   - npm: unpublish within 72 hours; after that, deprecation only.
   - PyPI: yank is always available (removes from default index, does not delete). Prefer yank over delete.
   - crates.io: yank available. Cannot delete.
   - RubyGems: yank available for gem owners.
   - Maven Central: contact Sonatype support for emergency removal.

### Evidence Required for P2B Gate (via WD-P2B-09)

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-KS-a | Documented kill-switch procedure with named revocation authority | IR runbook or project policy doc | CONDITIONAL if in progress with due date |
| E-WD-P2B-KS-b | Consumer notification mechanism documented | IR runbook | CONDITIONAL if in progress with due date |

---

## Propagation Containment Through Staged Rollout

For projects that publish packages consumed by many downstream projects:

**Staged release gates:**
1. Publish to an internal or `beta` tag first (`npm publish --tag beta`).
2. Run integration tests against the beta release in staging environment.
3. Monitor for anomalies for a minimum of 24 hours.
4. Promote to `latest` only after manual approval.

**Dependency update bot controls:**
- Configure Dependabot or Renovate to create PRs for review, not auto-merge.
- For critical dependencies (package count ≥1000 weekly downloads consumed by your project): require two reviewer approvals before merging dependency updates.
- Rate-limit dependency update PRs: no more than 3 dependency updates merged per day without security team review.
