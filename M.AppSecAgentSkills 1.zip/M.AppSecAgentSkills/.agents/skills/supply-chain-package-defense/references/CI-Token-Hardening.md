# CI Token Hardening

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Threat vectors covered:** WD-TV-01 (OIDC token exfiltration), WD-TV-07 (secret/credential exfiltration)
**Gate controls:** WD-P2D-01, WD-P2D-05, WD-P2B-01, WD-P2B-07
**Framework mapping:** SSDF PW.6.2, PO.5.1, PW.9.1; molina-oauth-security P2D-08; OWASP MCP §5–§6; Molina P2D-02, P2D-03

---

## Why This Is the Highest-Risk Vector

The mini-Shy-Halud worm (2025) did not break cryptography. It did not find a zero-day in the package registry. It poisoned the GitHub Actions cache so that a malicious script ran inside the CI environment, saw the OIDC token that was already present in the environment, and exfiltrated it. The attacker then used that token to publish new, malicious package versions from the legitimate pipeline identity. Every downstream project that trusted the pipeline signature accepted the malicious release.

The attack worked because:
1. OIDC tokens were available in the same execution environment as untrusted code.
2. There was no detection for token use outside the expected pipeline step.
3. Token scopes were broad enough to publish to multiple packages.
4. Token TTLs were long enough to complete the malicious publish cycle.

These are all architectural failures that controls can prevent.

---

## Control WD-P2D-01 — OIDC Token Lifecycle Architecture

**Severity:** CRITICAL
**Gate:** P2D
**Objective:** The architecture must ensure OIDC tokens used for package registry publishing are issued with minimum scope, used for a single operation, and never available in the same execution context as untrusted package code.

### Required Architecture Properties

**1. Token isolation from package execution:**
OIDC token generation and use must occur in a **separate, isolated job** from any job that installs or executes package dependencies. Never allow a `npm install`, `pip install`, `cargo build`, or equivalent command to run in a job that also holds an active publish token.

```yaml
# REQUIRED pattern: separate jobs, no shared environment
jobs:
  build:
    # This job installs dependencies and runs tests.
    # It has NO access to the publish token.
    steps:
      - uses: actions/checkout@v4
      - run: npm ci
      - run: npm test

  publish:
    needs: [build]  # Only runs after build succeeds
    if: github.event_name == 'release'
    # This job has NO npm install or dependency execution.
    # Only signs and publishes the already-built artifact.
    permissions:
      id-token: write  # Scoped only to this job
    steps:
      - uses: actions/setup-node@v4
        with:
          registry-url: https://registry.npmjs.org
      - run: npm publish --provenance
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
```

**2. Token scope and audience restriction:**
- OIDC token `aud` claim must be scoped to the specific registry action (e.g., `npm:publish`, `pypi:upload`).
- Token must not have broad registry admin scopes.
- For npm: use granular publish tokens scoped to a single package or namespace.
- For PyPI: use Trusted Publishers with environment and workflow-level granularity.
- For RubyGems: use gem-specific OIDC trusted publisher.
- For crates.io / Maven: use narrowly scoped PAT or service account (no OIDC native yet — see WD-P2B-07).

**3. Token TTL and expiry enforcement:**
- CI platform OIDC tokens must expire within 15 minutes of issuance.
- Confirm the token TTL in the CI platform identity configuration (GitHub Actions: `permissions.id-token`, Azure Pipelines: workload identity).
- If a token cannot be configured to expire within 15 minutes, document the risk and require IT Security exception approval.

**4. Federated credentials replace long-lived secrets:**
- No publish step should use a long-lived API key or secret stored in CI secrets storage.
- Use OIDC federated credentials wherever the registry supports them (npm, PyPI, RubyGems).
- For registries without OIDC support, use PAM-managed service account credentials with automated rotation (90-day max; prefer 30-day).

### Evidence Required for P2D Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2D-01-a | Architecture diagram or pipeline configuration showing publish job isolation from dependency installation | CI/CD config file or architecture doc | FAIL if not present |
| E-WD-P2D-01-b | Token scope/audience restriction documentation | CI platform OIDC config or registry Trusted Publisher config | FAIL if not present |
| E-WD-P2D-01-c | Token TTL policy (≤15 min) | CI platform config export | FAIL if OPEN |

---

## Control WD-P2D-05 — Secret Isolation from Build-Script Execution

**Severity:** CRITICAL
**Gate:** P2D
**Objective:** The architecture must ensure no build script, post-install hook, or test runner can access vault credentials, publish tokens, or service account keys.

### Required Architecture Properties

**1. Vault access only from isolated steps:**
- All vault interactions (Azure Key Vault, AWS Secrets Manager, HashiCorp Vault) must occur in dedicated steps that do not run any untrusted code before or after.
- Never inject vault secrets into a shell environment that then runs `npm install` or equivalent.

```yaml
# PROHIBITED pattern:
steps:
  - run: |
      export DB_SECRET=$(az keyvault secret show ...)
      npm install  # npm postinstall now has DB_SECRET in environment
      node app.js
```

```yaml
# REQUIRED pattern:
steps:
  - run: npm ci  # No secrets in environment
  - name: Fetch secret (after install, isolated)
    run: echo "SECRET=$(az keyvault secret show ...)" >> $GITHUB_ENV
  - name: Use secret
    run: node deploy.js
    env:
      SECRET: ${{ env.SECRET }}
```

**2. Secret redaction in all logs:**
- CI platform log redaction must be enabled.
- Validate by reviewing a build log sample and confirming secrets do not appear.
- Add regex-based redaction for known secret patterns (tokens, keys, UUIDs matching credential formats).

**3. Service account audits per PAM policy:**
- All service accounts used in CI/CD must be registered in PAM.
- Credentials must rotate per Molina PAM policy (≤90 days; prefer ≤30 days).
- No shared service accounts across projects.

### Evidence Required for P2D Gate

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2D-05-a | Architecture diagram showing vault access path and isolation from build-script execution | Architecture doc | FAIL if not present |
| E-WD-P2D-05-b | Pipeline configuration showing no secrets injected before or during dependency install | CI/CD config review | FAIL if not present |
| E-WD-P2D-05-c | PAM-registered service accounts list with rotation schedule | PAM report | FAIL if OPEN |

---

## Control WD-P2B-01 — OIDC Token Lifecycle Policy Enforced in Pipeline

**Severity:** CRITICAL
**Gate:** P2B
**Objective:** Demonstrate that the OIDC token architecture approved at P2D is actively enforced in the running pipeline, with audit evidence.

### Required Evidence for P2B Gate

**1. Token TTL audit log:**
- Provide a CI pipeline run log showing token issuance timestamp and expiry.
- Confirm the token was not used outside the publish job.

**2. Federated credential configuration export:**
- Export the OIDC provider configuration from the CI platform.
- For GitHub Actions: capture the `id-token: write` permission scoping.
- For Azure Pipelines: capture the workload identity federation configuration.

**3. Token usage scope confirmation:**
- Provide registry audit log entry confirming the token was used only for the expected publish action.
- For npm: `npm access` audit or registry publish event log.
- For PyPI: PyPI Trusted Publisher event log showing only the configured workflow triggered publication.

**4. Separation of publish from install jobs (runtime confirmation):**
- Provide evidence (pipeline run URL or job dependency graph) showing install and publish ran in separate, non-sharing jobs.

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-01-a | CI pipeline run log showing token issuance and expiry ≤15 min | CI platform | FAIL if OPEN |
| E-WD-P2B-01-b | Federated credential configuration export | CI platform settings | FAIL if OPEN |
| E-WD-P2B-01-c | Registry publish audit log confirming expected scope | Registry audit log | FAIL if OPEN |
| E-WD-P2B-01-d | Pipeline job graph showing publish and install job separation | Pipeline run screenshot or config | FAIL if OPEN |

---

## Control WD-P2B-07 — Secrets Vault in Use; No Plaintext Secrets in Build

**Severity:** CRITICAL
**Gate:** P2B
**Objective:** Demonstrate that no plaintext secrets exist in the repository, build configuration, or build logs, and that vault-based credential management is active.

### Required Evidence for P2B Gate

**1. Repository secrets scan (gitleaks or equivalent):**
- Run gitleaks, truffleHog, or equivalent tool against the full repository history.
- Scan must return zero confirmed findings.
- Provide the scan report with tool version, scan date, and result summary.

**2. Vault access policy export:**
- Provide Azure Key Vault, AWS Secrets Manager, or equivalent access policy.
- Show that the CI/CD service account has only the minimum permissions needed.
- Show that secret rotation is configured with the correct interval.

**3. Build log sample with secrets redacted:**
- Provide a recent build log extract.
- Confirm that no secret values appear in the log (token strings, API keys, certificate material).
- Show the redaction rule configuration if applicable.

**4. PAM service account audit:**
- Confirm all CI/CD service accounts are registered in PAM.
- Confirm last rotation date is within the rotation policy window.

| Evidence ID | Description | Source | Fail-Closed Rule |
|-------------|-------------|--------|-----------------|
| E-WD-P2B-07-a | Gitleaks or equivalent scan report — zero confirmed findings | Security scan output | FAIL if any confirmed finding OPEN |
| E-WD-P2B-07-b | Vault access policy export with minimal permissions and rotation config | Vault admin export | FAIL if OPEN |
| E-WD-P2B-07-c | Build log sample confirming secrets are redacted | CI platform | FAIL if OPEN |
| E-WD-P2B-07-d | PAM service account audit — last rotation within policy window | PAM report | FAIL if OPEN |

---

## Ecosystem-Specific OIDC Configuration Notes

### npm / GitHub Actions
```yaml
# .github/workflows/publish.yml
permissions:
  id-token: write   # Only in the publish job
  contents: read

steps:
  - uses: actions/setup-node@v4
    with:
      node-version: '22'
      registry-url: 'https://registry.npmjs.org'
  - run: npm publish --provenance
    env:
      NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
```
- Enable npm Trusted Publishers in the npm package settings page.
- Set `aud` to `npm:publish` in the OIDC token request.
- Enable `--provenance` flag to generate in-toto attestation.

### PyPI / GitHub Actions
```toml
# pyproject.toml — Trusted Publisher config
# (set in PyPI project settings, not in code)
# Workflow: .github/workflows/publish.yml
# Environment: release
```
```yaml
permissions:
  id-token: write

steps:
  - uses: pypa/gh-action-pypi-publish@release/v1
    # No API token needed with Trusted Publishers
```

### Azure Pipelines — Workload Identity Federation
```yaml
# azure-pipelines.yml
steps:
  - task: AzureCLI@2
    inputs:
      azureSubscription: 'my-workload-identity-service-connection'
      scriptType: bash
      scriptLocation: inlineScript
      inlineScript: |
        # Publish step using workload identity; no long-lived secret
        az artifacts universal publish ...
```
- Use Workload Identity Federation service connections (not classic service principal with client secret).
- Scope the service connection to the specific feed and operation.

---

## Common Failure Patterns (from real incidents)

| Failure Pattern | Detection Signal | Remediation |
|----------------|-----------------|-------------|
| Install and publish in same job | CI config has `npm install` and `npm publish` in same job steps | Refactor to separate jobs with `needs:` dependency |
| OIDC token in environment during install | `env:` block sets `NODE_AUTH_TOKEN` before `npm ci` runs | Move token injection to publish-only job |
| Long-lived npm token stored as CI secret | Secret name `NPM_TOKEN` with value `npm_xxxx...` (long PAT) | Migrate to npm Trusted Publishers; retire old token |
| Build log contains token substring | Log scan finds `npm_` prefix or `//registry.npmjs.org/:_authToken=` in logs | Enable CI log redaction; audit if token was already leaked |
| Shared service account across projects | PAM shows same service account used in 3+ projects | Create per-project service accounts with rotation |
| Token TTL > 15 minutes | CI platform config shows token validity period of 60+ minutes | Update OIDC provider configuration to enforce 15-min TTL |
