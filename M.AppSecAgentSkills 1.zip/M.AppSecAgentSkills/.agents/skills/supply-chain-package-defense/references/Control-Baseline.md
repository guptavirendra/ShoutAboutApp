# Supply Chain Package Defense — Control Baseline

**Scope:** This document defines the canonical control families, threat vectors, acceptance criteria, and evidence schema for the `supply-chain-package-defense` skill suite. It is the authoritative reference for control IDs, severity classifications, and framework mappings used across all component skills.

**Status:** Active — all component skills reference this document.

---

## 1. Threat Vector Taxonomy

The following five threat vector families are addressed by this skill suite. Each family maps to one or more component skills. All threat vectors apply to all supported ecosystems unless an ecosystem-specific exception is documented.

### WD-TV-01: CI/CD OIDC Token Exfiltration

**Description:** A malicious package or cache entry, once executed during a CI/CD build step, exfiltrates the OIDC token vended by the CI platform (GitHub Actions, Azure Pipelines) to authenticate against a package registry (npm, PyPI). The attacker then uses this token to publish a malicious release under the victim organization's namespace. Because the release is published from the legitimate CI pipeline, it passes signature verification and appears authoritative.

**Real-world precedent:** The mini-Shy-Halud worm (2025) exploited this exact pattern to publish malicious versions of 42+ packages including TanStack and other high-profile npm packages. The attacker gained the OIDC token by poisoning the GitHub Actions cache, which then executed during CI and exfiltrated the token before the legitimate build step.

**Ecosystems affected:** npm, PyPI, RubyGems, Cargo, Maven — any ecosystem where the CI/CD system has a federated OIDC publish credential.

**Attack path:**
```
Attacker compromises developer account
  → Malicious code in package or cache executes in CI
    → OIDC token exfiltrated to attacker infrastructure
      → Attacker publishes malicious version via authentic CI pipeline
        → Downstream projects install malicious version automatically
          → Worm propagates to downstream CI systems
```

**Component skill:** [CI-Token-Hardening](CI-Token-Hardening.md)

---

### WD-TV-02: Malicious Build-Script / Post-Install Hook Execution

**Description:** Package ecosystems allow maintainers to run arbitrary code at install or build time. In npm this is `postinstall`; in Python this is `setup.py install`; in Rust this is `build.rs`; in Maven this is plugin lifecycle hooks. When a malicious or compromised package containing a harmful hook is installed or built, it executes with the permissions of the CI/build agent — often with network access and read access to the filesystem including tokens, secrets, and SSH keys.

**Key distinction:** Unlike typical vulnerabilities, a package containing a malicious hook may have zero CVEs. Static analysis (SAST) does not typically execute the hook, so it will not be caught by source-code scanning. Behavioral inspection (sandbox execution, dynamic analysis) is required.

**Ecosystems affected:** All (npm, PyPI/pip, Cargo/Rust, Maven, RubyGems/Bundler).

**Component skill:** [Dependency-Execution-Controls](Dependency-Execution-Controls.md)

---

### WD-TV-03: Build Cache Poisoning

**Description:** Build caches (npm/yarn/pnpm local cache, pip cache, Maven `.m2`, Docker layer cache, CI shared caches such as GitHub Actions cache and Azure Pipelines pipeline cache) store previously downloaded or built artifacts for reuse. An attacker who can write to a shared or improperly isolated cache (e.g., by exploiting a CI workflow with write access to the cache store) can inject a malicious artifact that will be served from cache on future runs, bypassing the normal package registry download and signature verification.

**Notable pattern:** The mini-Shy-Halud worm poisoned the GitHub Actions cache. Downstream CI jobs that restored from cache received the malicious artifact without downloading from the registry, bypassing npm audit and registry integrity checks entirely.

**Ecosystems affected:** All ecosystems that use any form of build or dependency cache.

**Component skill:** [Cache-Integrity-Controls](Cache-Integrity-Controls.md)

---

### WD-TV-04: Artifact Integrity Compromise / Tampered Release

**Description:** An attacker who has gained publish credentials (via OIDC theft or account compromise) publishes a malicious version of a package. Because it is published through the legitimate pipeline, it may carry a valid package signature, a valid CI provenance attestation, and a changelog entry that looks normal. Consumers relying solely on "is this package signed?" as a trust signal will accept the tampered release.

**Defense principle:** Signing proves **who** published and **from what pipeline** — it does not prove the contents are safe. Behavioral analysis, dual-detector SCA scanning, and supply-chain provenance inspection (SLSA level, dependency graph delta) are required to supplement signature verification.

**Component skill:** [Dependency-Execution-Controls](Dependency-Execution-Controls.md) (artifact verification section)

---

### WD-TV-05: Cross-Ecosystem Worm Propagation

**Description:** A worm introduced in one package ecosystem propagates to dependent projects and then into adjacent ecosystems. Example: a malicious npm package is bundled into a Docker image build, which is then published to a container registry and deployed to Kubernetes, infecting the runtime environment. From that environment, the worm can access other package sources (Python, Maven) and spread to additional CI/CD systems.

**Key risk:** The blast radius is amplified at every hop. A single compromised npm package can propagate to hundreds of Docker images and thousands of Kubernetes deployments if lineage is not tracked and kill-switch controls are not in place.

**AIBOM note:** If AI agents perform autonomous dependency updates or publish packages, cross-ecosystem propagation can be extremely rapid. NIST 218A PW.1.3 supply chain threat modeling and OWASP ASI04 apply in this scenario.

**Component skill:** [Propagation-Containment](Propagation-Containment.md)

---

## 2. Control Family Definitions

### Family WD-CI-TOKEN — CI Token Lifecycle Controls
**Objective:** Ensure CI/CD OIDC tokens used for package registry publishing are short-lived, narrowly scoped, isolated from untrusted code execution, and auditable.

**Controls:** WD-P2D-01, WD-P2B-01 (see SKILL.md gate tables)
**Component skill:** [CI-Token-Hardening](CI-Token-Hardening.md)

---

### Family WD-DEP — Dependency Execution and Acquisition Controls
**Objective:** Ensure all package dependencies are acquired from trusted sources, hash-pinned, scanned by at least two independent detectors, and execute build-time scripts only in sandboxed environments with no access to secrets or CI credentials.

**Controls:** WD-P2D-02, WD-P2D-04, WD-P2B-02, WD-P2B-05, WD-P2B-06, WD-P2B-08
**Component skill:** [Dependency-Execution-Controls](Dependency-Execution-Controls.md)

---

### Family WD-CACHE — Cache Integrity Controls
**Objective:** Ensure all build cache entries are content-addressed and cryptographically verified before use, isolated per CI job, and subject to tamper-evident audit logging.

**Controls:** WD-P2D-03, WD-P2B-03
**Component skill:** [Cache-Integrity-Controls](Cache-Integrity-Controls.md)

---

### Family WD-SECRET — Secret and Credential Isolation Controls
**Objective:** Ensure CI secrets, vault tokens, and service account credentials are never accessible from build-script execution environments, never appear in logs, and are managed through PAM-compliant vault policies.

**Controls:** WD-P2D-05, WD-P2B-07
**Component skill:** [CI-Token-Hardening](CI-Token-Hardening.md) (secrets section)

---

### Family WD-LINEAGE — Supply Chain Lineage and SBOM Controls
**Objective:** Ensure a signed, complete SBOM covering all dependency layers (source → package → container → deployment) is generated at every build, validated at deployment, and retained as an auditable artifact.

**Controls:** WD-P2D-06, WD-P2B-04, WD-P2B-10
**Component skill:** [Propagation-Containment](Propagation-Containment.md) (lineage section)

---

### Family WD-IR — Incident Response and Containment Controls
**Objective:** Ensure a named incident owner exists, a tested worm response runbook is available, and emergency revocation/rollback mechanisms are documented and exercised before release.

**Controls:** WD-P2B-09
**Component skill:** [Worm-Incident-Response-Runbook](../assets/Worm-Incident-Response-Runbook.md)

---

## 3. Ecosystem-Specific Control Overlay Matrix

Each row defines the ecosystem-specific tool or mechanism that satisfies the generic control family. The generic control ID applies across all ecosystems; the ecosystem column shows the specific artifact or configuration expected as evidence.

| Control Family | npm | PyPI | RubyGems | Cargo (Rust) | Maven (Java) |
|----------------|-----|------|----------|--------------|--------------|
| **Hash pinning** | `package-lock.json` (integrity field, sha512) | `requirements.txt` with `--hash` flags or `pip-compile --generate-hashes` | `Gemfile.lock` (content hash) | `Cargo.lock` (content hash; auto-generated) | Maven enforcer plugin or `.sha512` checksum files |
| **Build-script sandboxing** | `--ignore-scripts` flag or `pnpm` with `onlyBuiltDependencies`; containerized builds | PEP 517/518 isolated build env; `pip install --no-build-isolation` disabled by default | Bundler `--without` for build gems; Gemspec validation | Cargo `--no-default-features`; disable `build.rs` for untrusted crates | Maven `--offline` + plugin allowlist; no network in build |
| **SCA scanning (2 detectors)** | `npm audit` + `socket.dev` or `Phylum` | `pip audit` + `osv-scanner` | `bundler-audit` + `osv-scanner` | `cargo audit` + `osv-scanner` | OWASP Dependency-Check + `osv-scanner` |
| **Registry source trust** | `.npmrc` with `registry=` set to private mirror or scoped to org | `pip.conf` / `pyproject.toml` `[tool.pip]` with `index-url` locked to private registry | `~/.gemrc` or `.bundle/config` `BUNDLE_MIRROR__HTTPS` | `~/.cargo/config.toml` `[source.crates-io]` replacement | `settings.xml` with `<mirror>` pointing to Nexus/Artifactory |
| **OIDC token scope** | npm publish job uses GitHub OIDC with `npm:publish` audience, scoped per package namespace | PyPI trusted publisher with granular environment and workflow constraints | RubyGems OIDC trusted publisher (per-gem scope) | crates.io token scoped per crate; no OIDC native yet (use PAT with minimal scope) | Maven Central publishing with scoped service account; no native OIDC yet |
| **SBOM generation** | `cyclonedx-npm` or `syft` | `cyclonedx-python` or `syft` | `cyclonedx-ruby` or `syft` | `cyclonedx-rust` or `syft` | `cyclonedx-maven-plugin` or `syft` |
| **Artifact signing** | `sigstore/npm-provenance` or cosign attestation via CI | Sigstore Python client or GitHub OIDC attestations | `gem cert` (legacy) or cosign attestation | `cargo-crev` + cosign; Sigstore experimental support | Maven GPG signing plugin + cosign for container artifacts |

---

## 4. Evidence Schema

Every control evaluation must produce evidence entries conforming to this schema. Evidence entries are referenced in the gate decision output contract.

```markdown
| Evidence ID | Control ID | Evidence Type | Description | Source / Tool | Artifact Link | Collected By | Collection Date | Verified By | Verification Date |
|-------------|------------|---------------|-------------|---------------|---------------|--------------|-----------------|-------------|-------------------|
| E-001 | WD-P2B-01 | Configuration export | GitHub OIDC token policy showing 15-min TTL and npm:publish audience restriction | GitHub Actions OIDC config | [link] | [name] | YYYY-MM-DD | [name] | YYYY-MM-DD |
```

**Evidence type vocabulary:**
- `Configuration export` — Policy, config file, or setting export proving a control is configured
- `Scan report` — Output from a security scanning tool
- `Audit log` — Timestamped system log showing control behavior at runtime
- `Architecture diagram` — Design artifact proving structural enforcement of a control
- `Lock file` — Dependency lock file with hash pinning evidence
- `Signed artifact` — A signed SBOM, binary, or attestation record
- `Run log` — CI/CD job log showing execution evidence
- `Policy document` — Written organizational policy covering the control

---

## 5. Acceptance Criteria by Control Severity

### CRITICAL controls
- Status must be CLOSED with verifiable evidence before P2B gate PASS.
- Status REMEDIATE (active plan) blocks gate unless approved exception documented in [AppSec-Request-for-Approval-Form-Template](../assets/Approval-Form-Template.md) with named risk owner, IT Security sign-off, and expiration date.
- Status OPEN with no plan → immediate FAIL; no exceptions.

### HIGH controls
- Status CLOSED required for gate PASS.
- Up to two HIGH controls may be REMEDIATE with approved due date for CONDITIONAL gate.
- Three or more HIGH controls OPEN/REMEDIATE without approved plans → FAIL.

### MEDIUM controls
- Status CLOSED required for gate PASS.
- May remain REMEDIATE with approved due date for CONDITIONAL gate with no upper limit, provided no critical or high blockers exist.

---

## 6. Framework Cross-Reference Completion Checklist

Use this checklist to verify a new control added to this baseline has complete framework coverage before it is published.

- [ ] SSDF practice and task assigned (PW, PS, PO, or RV family)
- [ ] Molina gate phase assigned (PRE, P2D, or P2B)
- [ ] Molina control ID assigned (WD-PRE-xx, WD-P2D-xx, or WD-P2B-xx)
- [ ] OWASP reference assigned (LLM Top 10 2025, ASI Top 10 2026, or MCP Guide)
- [ ] 218A reference assigned if control is AI-pipeline-specific
- [ ] Ecosystem overlay row added to Section 3 matrix
- [ ] Evidence schema entry defined
- [ ] Severity classified (CRITICAL, HIGH, or MEDIUM)
- [ ] Fail-closed rule stated (FAIL if OPEN, or CONDITIONAL threshold)
