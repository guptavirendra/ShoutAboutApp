# Supply Chain Package Defense — Skill Suite

## Purpose

This skill suite defends software projects against the class of attacks known as **package-manager worms**: compromise vectors that exploit the dependency installation lifecycle, CI/CD token management, build cache trust, and cross-ecosystem propagation to silently inject malicious code into release pipelines.

The suite is activated by patterns observed in real-world incidents including the mini-Shy-Halud worm (2025) and the broader Shy-Halud attack class, which demonstrated that:
- High-profile packages with active CI pipelines can be weaponized against their own consumers.
- Signing and provenance do not guarantee content safety when the CI pipeline itself is compromised.
- Cross-ecosystem propagation (npm → Docker → Kubernetes → PyPI) amplifies blast radius across organizational boundaries.
- Cache poisoning bypasses registry integrity checks entirely.

---

## What This Skill Suite Covers

| Component | File | Threat Vector |
|-----------|------|--------------|
| Orchestrator (this suite's entrypoint) | [SKILL.md](SKILL.md) | All vectors — routing, gate decision contract, conflict resolution |
| Control Baseline | [references/Control-Baseline.md](references/Control-Baseline.md) | All vectors — canonical control IDs, evidence schema, acceptance criteria |
| CI Token Hardening | [references/CI-Token-Hardening.md](references/CI-Token-Hardening.md) | WD-TV-01: OIDC token exfiltration; WD-TV-07: Secret exfiltration |
| Dependency Execution Controls | [references/Dependency-Execution-Controls.md](references/Dependency-Execution-Controls.md) | WD-TV-02: Malicious build scripts; WD-TV-04: Artifact integrity; WD-TV-06: Typosquatting |
| Cache Integrity Controls | [references/Cache-Integrity-Controls.md](references/Cache-Integrity-Controls.md) | WD-TV-03: Build cache poisoning |
| Propagation Containment | [references/Propagation-Containment.md](references/Propagation-Containment.md) | WD-TV-05: Cross-ecosystem propagation; WD-TV-04: Lineage tracking |
| Worm Incident Response Runbook | [assets/Worm-Incident-Response-Runbook.md](assets/Worm-Incident-Response-Runbook.md) | All vectors — breach detection, triage, containment, recovery |
| Approval Form Template | [assets/Approval-Form-Template.md](assets/Approval-Form-Template.md) | Gate exception process for deferred remediation |
| Remediation Tracker | [assets/Remediation-Tracker.md](assets/Remediation-Tracker.md) | All vectors — finding tracking from detection to verified closure |

---

## What This Skill Suite Does NOT Cover

- **Application-level vulnerabilities in package source code** — Use the standard Molina SonarQube/SAST workflow (P2B gate, existing controls) for those.
- **Key management infrastructure design** — This suite validates that artifact signing is in use; the cryptographic key management architecture is owned by the `molina-oauth-security` and `defensive-governance` skills.
- **AI model supply chain** — This suite covers software packages. If a project uses LLM models as dependencies, refer to `molina-nist-218a` for the model weight and training pipeline supply chain.
- **Malware reverse engineering** — This suite is defensive-only. It does not provide guidance on analyzing or reproducing malicious package behavior.
- **Upstream package registry policy** — This suite controls what projects can do. It does not govern npm, PyPI, RubyGems, or crates.io registry policies themselves.

---

## Integration with Existing Skills

This suite **extends** rather than replaces existing Molina AppSec controls. Key integration points:

| Existing Skill | Integration Point |
|----------------|--------------------|
| `molina-application-security` | Gate decision output contract format; RITM traceability; OPEN/REMEDIATE/CLOSED status vocabulary |
| `nist-ssdf` | Primary framework baseline (PW.4, PW.6, PS.3, PO.5, RV.1, RV.3); all worm controls map to SSDF tasks |
| `molina-oauth-security` | OIDC token scope and lifecycle patterns; CI federated credential architecture |
| `owasp-genai-security` | ASI04 (agentic supply chain), LLM03:2025, MCP §6 overlays; active when agentic components perform registry operations |
| `anti-mythos-agentic-security` | Tool-contract enforcement for automated package management agents; evidence-harness patterns |
| `defensive-governance` | Trust-boundary declarations for registry → build → deploy chain; escalation rules |
| `openbsd-principles` | Manifest parsing, signature verification implementation, least-privilege build isolation |
| `application-defense-workflow` | Threat inventory, runtime monitoring baseline, incident containment |
| `correctness-by-design` | No `allow_failure` on security scanning jobs; scanner exit-code enforcement |
| `swebok` | Requirements traceability for acceptance criteria; test strategy for worm detection |
| `molina-nist-218a` | Optional lane activated only when AI/LLM-based detection or agentic dependency management is in use |

---

## Activation

This skill suite activates when any of the following keywords or topics are present in a request:

- `supply chain`, `package worm`, `npm worm`, `malicious package`, `postinstall hook`, `build script execution`
- `OIDC token theft`, `CI token`, `GitHub Actions OIDC`, `federated credential`
- `cache poisoning`, `build cache`, `GitHub Actions cache`, `npm cache integrity`
- `artifact integrity`, `tampered release`, `signed package`, `SBOM`, `SLSA`
- `cross-ecosystem propagation`, `dependency confusion`, `typosquat`
- `Shy Halud`, `mini Shy Halud`, `TanStack compromise`, `npm worm incident`
- `WD-PRE-xx`, `WD-P2D-xx`, `WD-P2B-xx` control IDs

---

## Gate Summary

| Phase | Controls Added | Fail-Closed Threshold |
|-------|---------------|----------------------|
| **PRE** | WD-PRE-01, WD-PRE-02, WD-PRE-03 | FAIL if ecosystem inventory or trust-boundary declaration missing |
| **P2D** | WD-P2D-01 through WD-P2D-06 | FAIL if any CRITICAL control OPEN; CONDITIONAL with approved remediation plan |
| **P2B** | WD-P2B-01 through WD-P2B-10 | FAIL if any CRITICAL control OPEN; max 2 HIGH controls CONDITIONAL with approved plan |

---

## Framework Alignment Summary

| Framework | Version | Controls Mapped |
|-----------|---------|----------------|
| NIST SSDF | SP 800-218 | PW.4.1, PW.4.4, PW.6.2, PW.9.1, PS.3.2, PO.5.1, RV.1.1, RV.3.3 |
| NIST 218A | SP 800-218A | PW.1.3 (conditional — AI detection lane) |
| OWASP LLM Top 10 | 2025 | LLM03:2025 |
| OWASP Agentic Top 10 | 2026 | ASI04, ASI06, ASI07, ASI08 |
| OWASP MCP Guide | v1.0 (Feb 2026) | §5, §6 |
| Molina AppSec Program | Current | PRE, P2D, P2B gate extensions |
| OAuth 2.1 / OIDC | RFC 9068, OIDC Core | CI token lifecycle (WD-P2D-01, WD-P2B-01) |

---

## Ecosystem Coverage

| Ecosystem | Package Manager | Registry | Build-Script Vector |
|-----------|----------------|----------|---------------------|
| JavaScript / TypeScript | npm, pnpm, yarn | npmjs.com | `postinstall`, `preinstall`, `prepare` |
| Python | pip, uv, poetry | PyPI | `setup.py`, `pyproject.toml build-system` |
| Ruby | Bundler, gem | RubyGems.org | `extconf.rb`, Gemspec native extensions |
| Rust | Cargo | crates.io | `build.rs` |
| Java / JVM | Maven, Gradle | Maven Central, Sonatype | Plugin lifecycle hooks, Maven wrapper scripts |

---

## Versioning and Maintenance

| Field | Value |
|-------|-------|
| Suite version | 1.0 |
| Created | 2026-05-19 |
| Owner | M.AppSecAgentSkills |
| Review cycle | Quarterly or after any supply-chain worm incident affecting Molina-adjacent technology stack |
| Next review | 2026-08-19 |
