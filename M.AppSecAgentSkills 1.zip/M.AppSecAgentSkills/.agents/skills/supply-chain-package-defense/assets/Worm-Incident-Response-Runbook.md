# Worm Incident Response Runbook

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Gate control:** WD-P2B-09
**Framework mapping:** SSDF RV.1.1, RV.3.3; OWASP ASI08 (cascading failures); application-defense-workflow (incident containment); anti-mythos-agentic-security (evidence collection during response)

---

## Runbook Purpose and Scope

This runbook guides first responders through detection, triage, containment, eradication, and recovery for a suspected or confirmed package-manager worm incident. It applies to any of the threat vectors covered by the `supply-chain-package-defense` skill suite:

- WD-TV-01: CI/CD OIDC token exfiltration
- WD-TV-02: Malicious post-install hook execution
- WD-TV-03: Build cache poisoning
- WD-TV-04: Artifact integrity compromise
- WD-TV-05: Cross-ecosystem propagation

**Primary audience:** Incident owner (named in P2B gate record), IT Security, DevOps/Platform Engineering.

---

## Pre-Incident: Roles and Contacts

Complete this section before the P2B gate. Do not leave these fields blank.

| Role | Name | Contact | On-Call Availability |
|------|------|---------|----------------------|
| **Incident Owner** (primary responder) | [NAME] | [EMAIL / PHONE] | [HOURS / PAGER] |
| **IT Security Lead** | [NAME] | [EMAIL / PHONE] | [HOURS / PAGER] |
| **Platform / DevOps Lead** | [NAME] | [EMAIL / PHONE] | [HOURS / PAGER] |
| **Business Owner** | [NAME] | [EMAIL / PHONE] | [HOURS / PAGER] |
| **Legal / Compliance** | [NAME] | [EMAIL / PHONE] | [HOURS / PAGER] |

**Last review date:** [YYYY-MM-DD]
**Next review due:** [YYYY-MM-DD + 6 months]

---

## Detection Signals

Treat the following as immediate escalation triggers requiring this runbook:

| Signal | Threshold | Immediate Action |
|--------|-----------|-----------------|
| Unexpected package version published to registry | Any version not triggered by an approved release workflow | Initiate this runbook at Step 1 |
| CI OIDC token used outside expected pipeline | Token audience or `iss` claim does not match expected pipeline | Initiate this runbook at Step 1 |
| Cache integrity check failure in CI | Hash mismatch detected by WD-P2B-03 controls | Initiate this runbook at Step 1 |
| SCA scanner (Detector 1 or 2) flags a confirmed malicious package | Severity = confirmed-malicious (not just CVE) | Initiate this runbook at Step 1 |
| Unexpected new SBOM component with no corresponding dependency update PR | Delta comparison from WD-P2B-10 shows unexplained new component | Initiate this runbook at Step 2 |
| Developer reports credential theft or account compromise | Any report of stolen credentials used in CI context | Initiate this runbook at Step 1 |
| Downstream consumer reports anomalous behavior traced to your package | Consumer incident report linking to your package version | Initiate this runbook at Step 2 |

---

## Response Steps

### Step 1 — Immediate Containment (0–30 minutes)

**Goal:** Stop the spread. Do not investigate first. Contain first.

- [ ] **1.1** Pause all CI/CD pipelines for the affected project immediately.
  - GitHub Actions: disable all workflows in repository settings.
  - Azure Pipelines: pause the pipeline via the UI.
- [ ] **1.2** Revoke the CI/CD OIDC token or publish credential if token exfiltration is suspected.
  - npm: rotate the Automation token or disable Trusted Publisher; generate new token from a clean device.
  - PyPI: disable the Trusted Publisher configuration; generate new API token.
  - Azure Artifacts: rotate the service connection credentials.
- [ ] **1.3** If a malicious package version was published: deprecate or yank it immediately.
  - npm: `npm deprecate <package>@<version> "SECURITY: Malicious release — do not use"`
  - PyPI: Yank the release from the PyPI project settings page.
  - crates.io: Yank via `cargo yank --version <version>`.
- [ ] **1.4** Notify IT Security Lead within 30 minutes of detection. Do not wait for root cause.
- [ ] **1.5** Document the time of detection, the time of first action, and who was notified.

**Stop condition:** If you cannot revoke the publish credential (it is not under your control or the registry does not support revocation), escalate to IT Security Lead immediately and request emergency assistance from the registry operator.

---

### Step 2 — Initial Triage (30 minutes – 2 hours)

**Goal:** Determine scope, blast radius, and initial timeline.

- [ ] **2.1** Determine which package versions are affected (time range of compromise).
  - Review CI pipeline run logs for the affected window.
  - Compare package versions published against approved release records (RITM history).
- [ ] **2.2** Determine how the compromise occurred (initial hypothesis):
  - Token exfiltration via post-install hook? (Check build logs for unexpected network connections)
  - Cache poisoning? (Check if restored cache key hash matched expected)
  - Account compromise? (Check for unusual logins in CI platform audit log)
- [ ] **2.3** Identify downstream consumers:
  - Check registry download stats for the affected version(s).
  - Identify internal projects that depend on the affected package.
  - Identify any Docker images built using the affected package.
- [ ] **2.4** Determine if any secrets were exposed:
  - Review CI pipeline logs for the affected time window.
  - Check vault access logs for unexpected access by the CI service account.
  - Check registry audit logs for unexpected token use.
- [ ] **2.5** Assign a severity level:
  - **P1** (Critical): Confirmed malicious code execution on CI or production systems; secrets confirmed exfiltrated; downstream consumers actively installing malicious version.
  - **P2** (High): Malicious version published; no confirmed execution in production; limited consumer exposure confirmed.
  - **P3** (Medium): Suspicious indicators only; no confirmed malicious release; investigation in progress.

---

### Step 3 — Eradication (2–24 hours)

**Goal:** Remove the threat from all affected systems and pipelines.

- [ ] **3.1** For each affected system identified in Step 2:
  - Remove the malicious package version from any installed environment.
  - Run `npm ci` (or equivalent clean install) to replace with verified clean version.
  - Rebuild and redeploy any Docker images that contained the malicious version.
- [ ] **3.2** Rotate all credentials that may have been exposed:
  - All CI/CD publish tokens (npm, PyPI, etc.)
  - All service account credentials in PAM
  - Any developer credentials stored in CI secrets that may have been visible during the compromised build window
- [ ] **3.3** Clear and invalidate all CI caches for affected pipelines:
  - GitHub Actions: clear caches via the API (`gh cache delete --all`) or repository settings.
  - Azure Pipelines: clear pipeline cache via the UI.
  - Self-hosted caches: manually evict all entries from the affected time window.
- [ ] **3.4** Re-run all supply-chain scans (WD-P2B-05) against the clean environment to confirm no residual artifacts.
- [ ] **3.5** Notify downstream consumers with remediation guidance:
  - Publish a GitHub Security Advisory if the package is public.
  - Send direct notification to known enterprise consumers via the IT Security contact chain.
  - Include: affected version(s), recommended action (upgrade to clean version or pin to last known good), timeline.

---

### Step 4 — Recovery (24–72 hours)

**Goal:** Restore normal operations with additional hardening in place.

- [ ] **4.1** Re-enable CI/CD pipelines only after all compromised credentials are rotated and all scans pass.
- [ ] **4.2** Publish a verified clean release using a fresh, clean build environment (not restored from any cache).
- [ ] **4.3** Re-run P2B gate controls for the clean release, documenting that all WD-P2B-xx controls pass.
- [ ] **4.4** File a new RITM to track the post-incident hardening work.
- [ ] **4.5** Conduct a post-incident review within 7 days (see Step 5).

---

### Step 5 — Post-Incident Review (within 7 days of recovery)

**Goal:** Understand root cause, document lessons, improve controls.

- [ ] **5.1** Document the complete timeline (detection → containment → eradication → recovery).
- [ ] **5.2** Identify root cause and contributing factors.
- [ ] **5.3** Identify which controls from this skill suite would have prevented or detected the incident earlier.
- [ ] **5.4** Produce a remediation action plan with owners and due dates for all identified gaps.
- [ ] **5.5** Update this runbook with lessons learned.
- [ ] **5.6** Present findings to IT Security and Business Owner within 14 days of recovery.
- [ ] **5.7** Update relevant P2D and P2B gate controls in the RITM record to reflect the new hardening applied.

---

## Escalation Path

```
Incident Owner (first 30 min)
  ↓ if not resolved or if P1/P2
IT Security Lead (30 min – 2 hours)
  ↓ if confirmed malicious code execution, credential theft, or external consumer impact
CISO / VP Security (2 hours)
  ↓ if regulatory notification may be required or external disclosure needed
Legal / Compliance + External PR (as required)
```

---

## Evidence Collection During Response

Per anti-mythos evidence requirements, collect and retain the following artifacts throughout the response. These will be required for the post-incident RITM record and any regulatory review.

| Evidence Item | When to Collect | Storage Location |
|---------------|----------------|-----------------|
| CI pipeline run logs (affected time window) | Step 1 | Attach to RITM |
| Registry audit logs (publish events, token usage) | Step 2 | Attach to RITM |
| Vault access logs | Step 2 | Attach to RITM |
| SCA scan reports (pre- and post-remediation) | Steps 2 and 4 | Attach to RITM |
| Credential rotation records (timestamps, actor, new credential ID) | Steps 1 and 3 | Attach to RITM |
| Downstream consumer notification records | Step 3 | Attach to RITM |
| Post-incident review document | Step 5 | Attach to RITM and IT Security intake |

---

## Decision Reference: Incident Severity Classification

| Criteria | P1 — Critical | P2 — High | P3 — Medium |
|----------|--------------|-----------|-------------|
| Malicious code confirmed executed | Yes | No (published but not confirmed executed) | Suspicious only |
| Secrets confirmed exfiltrated | Yes | Possible (evidence under investigation) | No evidence |
| Downstream consumers impacted | Multiple confirmed | Limited or unconfirmed | Not yet identified |
| Time to containment SLA | 30 minutes | 2 hours | 24 hours |
| Mandatory IT Security notification | Immediate (within 15 min) | Within 30 min | Within 2 hours |
| Post-incident review SLA | Within 5 days | Within 7 days | Within 14 days |
