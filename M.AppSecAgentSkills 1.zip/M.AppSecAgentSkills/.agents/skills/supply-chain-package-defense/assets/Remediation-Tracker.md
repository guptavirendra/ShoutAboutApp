# Supply Chain Worm Defense — Remediation Tracker

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Purpose:** Track all worm defense findings from initial detection through verified closure. One row per finding. Archive closed findings after 90 days.
**Related:** [Approval-Form-Template](Approval-Form-Template.md) | [Worm-Incident-Response-Runbook](Worm-Incident-Response-Runbook.md)
**RITM:** [RITM ID — replace before use]
**Project:** [Project name — replace before use]
**Gate Phase:** [PRE / P2D / P2B — replace before use]

---

## Finding Register

| Finding ID | Control ID | Threat Vector | Source Tool / Evidence | Finding Summary | Severity | Status | Owner | Target Date | Evidence Link | Verified By | Verification Date | Notes |
|------------|------------|--------------|----------------------|----------------|----------|--------|-------|-------------|---------------|-------------|-------------------|-------|
| F-WD-001 | WD-P2B-01 | WD-TV-01 | CI config review | Publish job and install job share the same GitHub Actions job; OIDC token available during npm install | CRITICAL | OPEN | [Owner] | [Date] | — | — | — | Job isolation refactor required |
| F-WD-002 | WD-P2B-07 | WD-TV-07 | gitleaks scan | Long-lived npm publish token stored as CI secret; no rotation in 180 days | CRITICAL | OPEN | [Owner] | [Date] | — | — | — | Migrate to Trusted Publisher |
| F-WD-003 | WD-P2B-03 | WD-TV-03 | CI config review | Cache key not scoped to branch; fork PRs can write to main-branch cache | HIGH | OPEN | [Owner] | [Date] | — | — | — | Update cache key pattern |
| F-WD-004 | WD-P2B-02 | WD-TV-02 | CI config review | npm install runs as root in CI container | CRITICAL | OPEN | [Owner] | [Date] | — | — | — | Add USER nonroot to Dockerfile |
| F-WD-005 | WD-P2B-05 | WD-TV-02 | npm audit | Three high-severity CVEs unresolved in direct dependencies | HIGH | OPEN | [Owner] | [Date] | — | — | — | Patch or replace affected packages |

*Replace sample rows with actual findings. Add rows as new findings are identified.*

---

## Status Vocabulary

| Status | Meaning | Gate Implication |
|--------|---------|-----------------|
| **OPEN** | Gap identified; no active remediation plan exists | **FAIL** for CRITICAL; contributes to FAIL threshold for HIGH |
| **REMEDIATE** | Remediation work is actively in progress; owner and due date are assigned | **CONDITIONAL** if critical approved by IT Security with exception; HIGH allows CONDITIONAL up to 2 items |
| **CLOSED** | Remediation verified by a named verifier with an artifact link | Contributes to **PASS** |
| **ACCEPTED** | Risk formally accepted via [Approval-Form-Template](Approval-Form-Template.md); not remediated | Must have signed approval form attached; treated as CLOSED for gate, but flagged for audit |

---

## Remediation Progress Summary

| Control ID | Control Name | Severity | # Open | # Remediate | # Closed | # Accepted | Gate Impact |
|------------|-------------|----------|--------|-------------|----------|------------|-------------|
| WD-P2B-01 | OIDC token lifecycle enforced | CRITICAL | | | | | |
| WD-P2B-02 | Build-script execution sandboxed | CRITICAL | | | | | |
| WD-P2B-03 | CI cache integrity check passing | HIGH | | | | | |
| WD-P2B-04 | Signed SBOM generated | HIGH | | | | | |
| WD-P2B-05 | Supply-chain worm scan passing (2 detectors) | CRITICAL | | | | | |
| WD-P2B-06 | Artifact signatures verified at deployment | HIGH | | | | | |
| WD-P2B-07 | Secrets vault in use; no plaintext secrets | CRITICAL | | | | | |
| WD-P2B-08 | Dependency hash pinning confirmed | HIGH | | | | | |
| WD-P2B-09 | IR runbook reviewed and owner assigned | MEDIUM | | | | | |
| WD-P2B-10 | Cross-ecosystem lineage SBOM validated | HIGH | | | | | |
| WD-P2D-01 | OIDC token lifecycle architecture | CRITICAL | | | | | |
| WD-P2D-02 | Build-script sandboxing design | CRITICAL | | | | | |
| WD-P2D-03 | Build cache isolation architecture | HIGH | | | | | |
| WD-P2D-04 | Artifact signing design | HIGH | | | | | |
| WD-P2D-05 | Secret isolation architecture | CRITICAL | | | | | |
| WD-P2D-06 | Cross-ecosystem lineage plan | HIGH | | | | | |
| WD-PRE-01 | Supply-chain threat model scope | HIGH | | | | | |
| WD-PRE-02 | Registry trust-boundary declaration | HIGH | | | | | |

---

## Closure Criteria

A finding may be marked CLOSED only when ALL of the following are true:

1. Remediation action completed (not just planned).
2. A specific evidence artifact exists (link, log, config export, scan report) proving the remediation.
3. A named verifier (different from the owner) has reviewed the evidence.
4. The verifier has recorded their name and the date of verification in this tracker.

**Prohibited closure patterns:**
- "Fixed in code review" with no evidence link → NOT CLOSED
- "Will be addressed in next sprint" → REMEDIATE (not CLOSED)
- Status changed to CLOSED by the same person who is listed as Owner → NOT VALID; requires separate verifier

---

## Tracker Maintenance

| Action | Frequency | Responsible |
|--------|-----------|-------------|
| Add new findings from gate reviews | Per gate submission | IT Security reviewer |
| Update status of REMEDIATE items | Weekly | Finding owner |
| Verify CLOSED items | Within 3 business days of owner marking CLOSED | Designated verifier |
| Archive rows older than 90 days (CLOSED) | Quarterly | IT Security |
| Report summary to RITM record | At each gate decision | IT Security reviewer |
