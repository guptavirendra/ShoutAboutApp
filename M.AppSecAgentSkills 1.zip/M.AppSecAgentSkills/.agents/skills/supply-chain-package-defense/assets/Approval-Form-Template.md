# Supply Chain Worm Defense — AppSec Request for Approval Form

**Skill component of:** [supply-chain-package-defense](../SKILL.md)
**Purpose:** Document formal risk acceptance when a worm defense control cannot be closed before a gate decision, and the project team is requesting a CONDITIONAL gate decision with deferred remediation.
**Related:** [Remediation-Tracker](Remediation-Tracker.md) | [SKILL.md gate decision contract](../SKILL.md)

---

## Instructions for Use

This form is required when any of the following conditions are true:

- A CRITICAL control is in REMEDIATE status and the project team is requesting IT Security approval for a CONDITIONAL gate decision.
- The project team is requesting formal risk acceptance for a finding that cannot be technically remediated and a compensating control is proposed instead.
- A finding is being accepted as residual risk with no further remediation planned.

**This form is NOT a substitute for remediation.** It is a formal record that an exception was considered, reviewed, and explicitly approved by named stakeholders. The approval expires on the stated expiration date, after which the control must be CLOSED or a new approval must be filed.

---

## Request Header

| Field | Value |
|-------|-------|
| **Request ID** | [AR-WD-YYYY-NNN — generate a unique ID] |
| **RITM** | [RITM ID] |
| **Project / Application** | [Name] |
| **Gate Phase** | [P2D / P2B] |
| **Date of Request** | [YYYY-MM-DD] |
| **Requested by** | [Name, Role] |
| **IT Security Reviewer** | [Name] |
| **Business Owner** | [Name] |

---

## Finding(s) Covered by This Request

List each finding that requires approval. Reference the Finding ID from the [Remediation-Tracker](Remediation-Tracker.md).

| Finding ID | Control ID | Control Name | Severity | Current Status | Root Cause of Non-Closure |
|------------|------------|-------------|----------|----------------|--------------------------|
| F-WD-xxx | WD-P2B-xx | [Name] | [CRITICAL/HIGH/MEDIUM] | REMEDIATE | [Why it cannot be closed before the gate] |

---

## Risk Assessment

**1. Threat vector addressed by this control:**
[Describe which threat vector (WD-TV-01 through WD-TV-07) this control defends against and what an attacker could do if the control is absent.]

**2. Current exposure:**
[What is the current risk level with the control in REMEDIATE status? Is the attack vector currently accessible? What is the likelihood and impact if exploited?]

**3. Mitigating factors:**
[What existing controls partially reduce the risk? List each compensating control with its control ID, description, and evidence that it is active.]

| Compensating Control | Description | Evidence |
|---------------------|-------------|---------|
| [Control ID or description] | [How it reduces exposure] | [Link to evidence] |

---

## Proposed Remediation Plan

| Step | Action | Owner | Due Date | Verification Method |
|------|--------|-------|----------|---------------------|
| 1 | [First remediation step] | [Name] | [Date] | [How it will be verified] |
| 2 | [Second remediation step] | [Name] | [Date] | [How it will be verified] |

**Final closure target date:** [YYYY-MM-DD]

**This approval expires on:** [YYYY-MM-DD — same as final closure target date or sooner]

---

## Approval Disposition

| Approver Role | Name | Decision | Conditions | Signature / Approval Date |
|--------------|------|----------|-----------|--------------------------|
| **IT Security** | [Name] | [ ] Approve / [ ] Approve with conditions / [ ] Reject | [If conditions: list them] | [Date] |
| **Business Owner** | [Name] | [ ] Approve / [ ] Approve with conditions / [ ] Reject | [If conditions: list them] | [Date] |
| **Compliance** (if regulatory scope) | [Name] | [ ] Approve / [ ] Approve with conditions / [ ] N/A | [If conditions: list them] | [Date] |

**Overall disposition:** [ ] APPROVED — CONDITIONAL gate decision permitted
[ ] APPROVED WITH CONDITIONS — list conditions above must be satisfied before gate proceeds
[ ] REJECTED — gate decision must be FAIL until control is CLOSED

---

## Audit Trail

| Action | Date | Actor | Note |
|--------|------|-------|------|
| Request submitted | [Date] | [Name] | |
| IT Security review | [Date] | [Name] | |
| Business Owner review | [Date] | [Name] | |
| Final disposition recorded | [Date] | [Name] | |
| RITM updated with this form link | [Date] | [Name] | |
| Expiration review scheduled | [Date] | [Name] | Review date: [expiration date] |

---

## Expiration and Renewal

This approval expires on the date specified above. On or before the expiration date:

1. If the control is CLOSED: update the [Remediation-Tracker](Remediation-Tracker.md) and mark this form as superseded.
2. If the control remains REMEDIATE: a new approval form must be filed. Repeated renewals without progress require escalation to CISO.
3. If the control is accepted as permanent residual risk: file a formal risk acceptance record through the Molina risk management process (not this form).

**Expiration date:** [YYYY-MM-DD]
**Renewal responsibility:** [Named owner]
