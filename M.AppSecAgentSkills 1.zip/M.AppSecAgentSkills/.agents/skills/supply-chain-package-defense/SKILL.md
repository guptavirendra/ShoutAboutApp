---
name: supply-chain-package-defense
license: MIT
description: "Defends against package manager worms, malicious build-script execution, CI/CD OIDC token theft, cache poisoning, artifact integrity compromise, and cross-ecosystem propagation. Maps to SSDF PW.4/PW.6/PS.3/RV.1/RV.3, Molina PRE/P2D/P2B gates, OWASP ASI04/LLM03:2025/MCP §6, and OAuth 2.1 OIDC lifecycle controls. WHEN: \"supply chain\", \"package worm\", \"npm worm\", \"malicious package\", \"build script\", \"OIDC token theft\", \"cache poisoning\", \"artifact integrity\", \"SBOM\", \"cross-ecosystem propagation\", \"dependency execution\", \"package registry\", \"Shy Halud\", \"mini Shy Halud\", \"tanstack compromise\", \"postinstall hook\"."
allowed-tools: Read
compatibility: "Designed for Claude Code in Molina Azure DevOps environments. Requires SonarQube, Wiz, PAM, and package registry audit log access."
metadata:
  argument-hint: "--project-id ID --gate PRE|P2D|P2B --ecosystem npm|pypi|rubygems|cargo|maven|all"
  user-invocable: "true"
---

# Supply Chain Package Defense

**Skills used:** supply-chain-package-defense (orchestrator), plus component skill referenced per threat vector (see routing map below).

This skill operationalizes defense against package-manager-worm threat vectors across all major ecosystems (npm, PyPI, RubyGems, Cargo, Maven) and is integrated into Molina PRE, P2D, and P2B gate decisions with **fail-closed** evidence requirements.

**Fail-closed rule:** Any critical control in OPEN status without an active remediation plan with owner and due date results in a gate FAIL. A gate cannot progress without deterministic resolution for every critical control.

---

## Gotchas

- **Post-install hooks run after SCA scanning, not before.** `npm postinstall`, `setup.py install`, `build.rs`, and Maven lifecycle plugins execute at install or build time and bypass static dependency analysis. SCA tools report known CVEs on package metadata; they do not inspect runtime hook behavior in real time. Behavioral inspection and sandboxing are required in addition to SCA.
- **OIDC tokens are not artifacts; they are credentials.** A GitHub Actions OIDC token vended to a package registry is not captured in build logs, SBOMs, or dependency graphs. If a malicious package or cache entry can exfiltrate it during a build step, no downstream artifact scan will detect the theft. Scope the token before the build step runs, and never allow untrusted code to execute in the same environment as an active token.
- **A signed package from an authoritative CI pipeline is not inherently safe.** The `mini-Shy-Halud` class of worm signs malicious releases via compromised legitimate CI pipelines. Pipeline trust is not the same as code trust. Artifact signing proves provenance; it does not prove absence of malicious content.
- **Cache poisoning crosses ecosystems and layers.** A poisoned npm package embedded in a Docker base image carries its payload through all downstream container layers and application deployments. Single-ecosystem scanning (npm-only or Docker-only) misses cross-layer propagation. Full-chain SBOM lineage is required.
- **Worm propagation is not a vulnerability; it is a behavioral pattern.** CVE-free packages can contain worm code. SSDF PW.4 vulnerability controls are necessary but not sufficient; behavioral baseline monitoring and version hash drift detection are the primary worm-detection signals.
- **Pinning versions does not stop worms; pinning hashes does.** Version pins allow resolution to any published artifact matching a version string. Hash pinning (integrity fields, lock files with content hashes) anchors to a specific binary. Always pin to content hash, not version string alone.
- **OPEN and REMEDIATE have different gate implications.** OPEN means no active plan exists — this is a blocker. REMEDIATE means active work is in progress with a committed owner and due date — this allows a CONDITIONAL gate decision if the remaining risk is acceptable. Do not conflate the two.

---

## How to use this skill

**Skill check:** Read this skill and the [Control Baseline](references/Control-Baseline.md) before making a gate decision. Include `Skills used: supply-chain-package-defense` and the component skill(s) applied in all output.

**Execution flow:**

1. **Identify scope.** Determine which ecosystems the project uses (npm, PyPI, RubyGems, Cargo, Maven, or all). Identify CI/CD platforms (GitHub Actions, Azure Pipelines, other). Identify deployment targets (Docker, Kubernetes, VM, serverless).
2. **Identify applicable gate.** Confirm current Molina phase: PRE, P2D, or P2B.
3. **Route to relevant component skills.** Use the routing map below to load only the threat-vector skills that apply to the project's scope.
4. **Apply controls.** For each applicable control ID, collect evidence artifacts and assign OPEN / REMEDIATE / CLOSED status.
5. **Apply fail-closed logic.** Any critical control with status OPEN (no plan) → gate decision is FAIL. Any critical control with status REMEDIATE (plan exists, owner assigned, due date committed) → gate decision is CONDITIONAL. All critical controls CLOSED with evidence → gate decision is PASS.
6. **Emit output.** Produce the standard gate decision report (see output contract below) including RITM linkage, control table, framework cross-reference, blocker list, and evidence manifest.

**Component skill activation order (highest-risk first):**
1. [CI Token Hardening](references/CI-Token-Hardening.md) — OIDC/token theft (activated for all projects using automated package publishing)
2. [Cache Integrity Controls](references/Cache-Integrity-Controls.md) — cache poisoning (activated for all projects using any build cache layer)
3. [Dependency Execution Controls](references/Dependency-Execution-Controls.md) — malicious build scripts (activated for all package-manager-using projects)
4. [Propagation Containment](references/Propagation-Containment.md) — cross-ecosystem spread (activated when project spans multiple ecosystems or uses container layers)
5. [Incident Response Runbook](assets/Worm-Incident-Response-Runbook.md) — breach-ready posture (required at P2B gate for all projects)

---

## Threat Vector Routing Map

| Vector ID | Threat Vector | Risk | Applicable Gate(s) | Primary Component Skill | Framework Mapping |
|-----------|--------------|------|--------------------|------------------------|-------------------|
| WD-TV-01 | CI/CD OIDC token exfiltration | CRITICAL — credential theft enables silent malicious publish | PRE (scope), P2D (architecture), P2B (evidence) | [CI-Token-Hardening](references/CI-Token-Hardening.md) | SSDF PW.6.2, SSDF PO.5; molina-oauth-security P2D-08; OWASP ASI04 |
| WD-TV-02 | Malicious build-script / post-install hook execution | CRITICAL — arbitrary code execution at install or build time | P2D (sandbox design), P2B (execution evidence) | [Dependency-Execution-Controls](references/Dependency-Execution-Controls.md) | SSDF PW.4.1, PW.4.4; OWASP LLM03:2025, ASI04 |
| WD-TV-03 | Build cache poisoning | HIGH — stale or tampered cache injects malicious artifacts | P2D (cache architecture), P2B (cache validation) | [Cache-Integrity-Controls](references/Cache-Integrity-Controls.md) | SSDF PW.6.2, RV.1.1; OWASP ASI06, ASI08 |
| WD-TV-04 | Artifact integrity compromise and tampered release | HIGH — signed release from poisoned pipeline is trusted by consumers | P2B (signing evidence) | [Dependency-Execution-Controls](references/Dependency-Execution-Controls.md) | SSDF PS.3.2, PW.4.4; OWASP LLM03:2025; anti-mythos evidence contract |
| WD-TV-05 | Cross-ecosystem worm propagation (npm→Docker→K8s) | HIGH — blast radius amplification across layers | PRE (scope), P2D (lineage design), P2B (lineage evidence) | [Propagation-Containment](references/Propagation-Containment.md) | SSDF RV.3, RV.1.1; OWASP ASI04, ASI07, ASI08; NIST 218A PW.1.3 |
| WD-TV-06 | Typosquat and dependency confusion attacks | MEDIUM — deceives developers into installing malicious lookalike packages | P2D (registry design), P2B (scanning evidence) | [Dependency-Execution-Controls](references/Dependency-Execution-Controls.md) | SSDF PW.4.1; OWASP LLM03:2025 |
| WD-TV-07 | Secret / credential exfiltration via build scripts | CRITICAL — secrets harvested during build propagate to attacker infrastructure | P2D (secrets isolation), P2B (vault evidence) | [CI-Token-Hardening](references/CI-Token-Hardening.md) | SSDF PW.9.1, RV.2; OWASP MCP §5; Molina P2D-02, P2D-03 |

---

## Gate Control Summary by Phase

### PRE Gate Controls (Worm Defense Extension)
| Control ID | Control Name | Severity | Evidence Required | Fail-Closed Rule |
|------------|-------------|----------|-------------------|------------------|
| WD-PRE-01 | Supply-chain threat model scope declaration | HIGH | Documented ecosystem inventory (languages, package managers, CI platforms) | FAIL if not present |
| WD-PRE-02 | Trust-boundary declaration for package registries | HIGH | Written policy identifying public vs. private registry sources | FAIL if not present |
| WD-PRE-03 | Package worm training acknowledgment | MEDIUM | Developer security training record covering supply-chain worm threats | CONDITIONAL if pending enrollment with date |

### P2D Gate Controls (Design and Architecture)
| Control ID | Control Name | Severity | Evidence Required | Fail-Closed Rule |
|------------|-------------|----------|-------------------|------------------|
| WD-P2D-01 | OIDC token lifecycle architecture validated | CRITICAL | Token scope/TTL policy document; audience restriction proof | FAIL if OPEN |
| WD-P2D-02 | Build-script sandboxing design approved | CRITICAL | Sandbox/isolation architecture diagram or policy | FAIL if OPEN |
| WD-P2D-03 | Build cache isolation and trust architecture | HIGH | Cache isolation design; per-job namespace policy | FAIL if OPEN |
| WD-P2D-04 | Artifact signing and provenance design | HIGH | Signing approach documented (Sigstore/cosign, in-toto, or equivalent) | FAIL if OPEN |
| WD-P2D-05 | Secret isolation from build-script execution environment | CRITICAL | Architecture diagram showing vault access path; scripts cannot directly access vault | FAIL if OPEN |
| WD-P2D-06 | Cross-ecosystem dependency lineage plan | HIGH | SBOM/AIBOM scope definition covering all layers | FAIL if OPEN |

### P2B Gate Controls (Testing and Release)
| Control ID | Control Name | Severity | Evidence Required | Fail-Closed Rule |
|------------|-------------|----------|-------------------|------------------|
| WD-P2B-01 | OIDC token lifecycle policy enforced in pipeline | CRITICAL | Token TTL audit log; federated credential config export | FAIL if OPEN |
| WD-P2B-02 | Build-script execution sandboxed (evidenced) | CRITICAL | Container/VM isolation run log; seccomp/AppArmor policy; non-root execution confirmed | FAIL if OPEN |
| WD-P2B-03 | CI cache integrity check passing | HIGH | Cache hash validation log; checksum pass/fail audit; clean-rebuild-on-failure confirmation | FAIL if OPEN |
| WD-P2B-04 | Signed SBOM generated and validated | HIGH | Signed SBOM artifact link; component hash manifest | FAIL if OPEN |
| WD-P2B-05 | Supply-chain worm scan passing (two detectors minimum) | CRITICAL | SCA tool report (e.g., Wiz, Socketdev, Phylum, OSV-Scanner) — two independent tools required; zero critical unresolved findings | FAIL if any critical finding OPEN |
| WD-P2B-06 | Artifact signatures verified at deployment stage | HIGH | cosign/Sigstore verify log; deployment pipeline signature check confirmation | FAIL if OPEN |
| WD-P2B-07 | Secrets vault in use; no plaintext secrets in build | CRITICAL | Vault access policy export; repo plaintext-secrets scan (gitleaks or equivalent) passing | FAIL if OPEN |
| WD-P2B-08 | Dependency hash pinning confirmed in lock files | HIGH | Lock file review (package-lock.json, requirements.txt with hashes, go.sum, Cargo.lock, Gemfile.lock) showing hash-pinned entries | FAIL if OPEN |
| WD-P2B-09 | Incident response runbook reviewed and owner assigned | MEDIUM | IR runbook link; named incident owner; escalation path confirmed | CONDITIONAL if runbook exists but owner not yet assigned |
| WD-P2B-10 | Cross-ecosystem lineage SBOM validated | HIGH | Cross-layer SBOM (npm→Docker→deployment) with no unresolved provenance gaps | FAIL if OPEN |

---

## Conflict Resolution Rules

| Conflict | Resolution |
|----------|-----------|
| SSDF PW.4 (supply chain) vs. OWASP ASI04 (agentic supply chain) | SSDF PW.4 is the **baseline** for all projects. ASI04 adds controls **only when agents make autonomous registry decisions** (e.g., agentic dependency update bots). Do not apply ASI04 overhead to non-agentic builds. |
| Molina P2D-08 (OAuth gate) vs. molina-oauth-security skill (pattern ownership) | `molina-oauth-security` skill owns **pattern selection and technical validation**. Molina P2D-08 gate owns **approval decision, RITM linkage, and SLA tracking**. Both must be satisfied at P2D. |
| Defensive-governance trust-boundary vs. anti-mythos tool contracts | `defensive-governance` defines **where** the trust boundary is (registry → build → deploy). `anti-mythos-agentic-security` defines **how** to enforce it operationally via tool contracts. Apply governance first, then enforce with contracts. |
| OWASP LLM03 vs. SSDF PW.4 for AI-assisted detection | If an LLM or AI model performs dependency scanning or worm detection, its pipeline falls under **NIST 218A + OWASP LLM03** (model supply chain lane). Packages the AI analyzes fall under **SSDF PW.4** (software supply chain lane). Keep the two lanes distinct in control mapping. |
| Correctness-by-design CI/CD checks vs. SSDF PS.3.2 evidence collection | `correctness-by-design` ensures the **CI/CD pipeline produces reliable results** (no silent failures, correct exit codes). SSDF PS.3.2 ensures the **evidence produced is collected, signed, and traceable**. Both must be satisfied; they are complementary, not redundant. |
| Cost-optimization model routing vs. security analysis quality | **Never** route security analysis, cryptographic validation, or threat assessment to lower-tier models for cost savings. Cost-optimization applies only to non-security operations (metadata parsing, report formatting). |
| Runtime non-leakage proof obligations vs. supply-chain artifact lineage controls | Runtime/state leakage proof authority belongs to `molina-mythNOs-agentic-security`. This skill consumes proof status as a dependency at P2D/P2B when runtime controls interact with build or deployment trust boundaries. Artifact lineage and provenance remain owned by this skill. |

---

## Stop Conditions and Escalation

Stop and escalate to IT Security when:
- The ecosystem inventory is incomplete and scope cannot be bounded for gate assessment.
- CI/CD toolchain audit logs are unavailable and OIDC token usage cannot be verified.
- Deployment target is unknown and cross-ecosystem blast radius cannot be assessed.
- A malicious package is suspected to already be installed in a production system.
- A supply-chain worm indicator is detected (unexpected version bump, hash mismatch, CI token reuse outside expected scope).

**Escalation format:**
```
ESCALATION — Supply Chain Package Defense
Gate: [PRE / P2D / P2B]
RITM: [RITM ID]
Reason: [one sentence description of stop condition]
Last confident control state: [control ID and status]
Recommended next action: [notify IT Security / isolate build environment / initiate worm IR runbook]
Escalation owner: IT Security
```

---

## Standard Gate Decision Output Contract

```markdown
## Gate Decision Report — Supply Chain Package Defense

**Skills used:** supply-chain-package-defense + [component skills applied]
**RITM:** [ID] → [iServe Link]
**Gate Phase:** [PRE / P2D / P2B]
**Decision:** PASS / CONDITIONAL / FAIL
**Date:** [YYYY-MM-DD]
**Reviewer:** [name or role]

### Scope
- Ecosystems: [npm | PyPI | RubyGems | Cargo | Maven | all]
- CI/CD platforms: [GitHub Actions | Azure Pipelines | other]
- Deployment targets: [Docker | K8s | VM | serverless | other]

### Control Status Summary
| Control ID | Control Name | Severity | Status | Owner | Due Date | Evidence Link |
|------------|-------------|----------|--------|-------|----------|---------------|
| WD-P2B-01 | OIDC token lifecycle policy enforced | CRITICAL | [OPEN / REMEDIATE / CLOSED] | [name] | [date or N/A] | [link] |
| ... | | | | | | |

### Cross-Framework Alignment
- **SSDF:** PW.4.1, PW.4.4, PW.6.2, PS.3.2, RV.1.1, RV.3
- **Molina:** PRE-xx, P2D-xx, P2B-04 (extended), P2B-xx
- **OWASP:** ASI04, LLM03:2025, MCP §6
- **NIST 218A:** PW.1.3 (if AI detection in scope)
- **OAuth / OIDC:** WD-P2D-01, WD-P2B-01
- **Runtime non-leakage dependency:** Include boundary proof status from `molina-mythNOs-agentic-security` for P2D and P2B outputs when runtime isolation affects release risk.

### Decision Criteria Applied
- **PASS:** All critical and high controls = CLOSED with evidence
- **CONDITIONAL:** ≤2 high controls = REMEDIATE with approved owner and due date; no critical controls OPEN
- **FAIL:** Any critical control = OPEN; or ≥3 high controls OPEN/REMEDIATE without approved plan

### Blockers (if FAIL or CONDITIONAL)
| Blocker ID | Control | Gap Description | Owner | Due Date |
|------------|---------|----------------|-------|----------|
| | | | | |

### Evidence Manifest
| Evidence Item | Control | Source | Link / Location |
|---------------|---------|--------|-----------------|
| | | | |

### Next Steps
**If PASS:** Proceed to next gate or release phase.
**If CONDITIONAL:** Complete remediation items; retest on [date]; obtain IT Security sign-off.
**If FAIL:** Stop promotion. Remediate all critical blockers. Re-initiate gate review after closure.
```

---

## Framework Cross-Reference Index

| SSDF Practice | Task | Worm Defense Control(s) |
|---------------|------|------------------------|
| PW.4 | PW.4.1 — Acquire and maintain well-secured software components | WD-P2B-05, WD-P2B-08 |
| PW.4 | PW.4.4 — Verify compliance and risk posture of acquired components | WD-P2B-04, WD-P2B-05, WD-P2B-10 |
| PW.6 | PW.6.2 — Configure build tools and environments securely | WD-P2D-02, WD-P2D-03, WD-P2B-02, WD-P2B-03 |
| PW.9 | PW.9.1 — Configure secure defaults in code and pipeline | WD-P2D-05, WD-P2B-07 |
| PS.3 | PS.3.2 — Collect and maintain provenance data (SBOM) | WD-P2D-06, WD-P2B-04, WD-P2B-10 |
| PO.5 | PO.5.1 — Implement and maintain secure environments | WD-P2D-01, WD-P2B-01, WD-TV-07 |
| RV.1 | RV.1.1 — Gather vulnerability, threat, and exploitation data | WD-P2B-05, WD-TV-05 |
| RV.3 | RV.3.3 — Update threat models based on new information | WD-PRE-01, WD-TV-05 |

| OWASP Entry | Worm Defense Control(s) | Notes |
|-------------|------------------------|-------|
| LLM03:2025 — Supply Chain Vulnerabilities | WD-P2B-05, WD-TV-02, WD-TV-06 | Applies to all package ecosystems |
| ASI04 — Agentic Supply Chain Vulnerabilities | WD-TV-01, WD-TV-05 | Add when agent performs autonomous registry operations |
| ASI06 — Memory and Context Poisoning | WD-TV-03 | Cache poisoning analog for agentic context |
| ASI07 — Inter-Agent Trust Exploitation | WD-TV-05 | Cross-ecosystem propagation via agent-to-agent calls |
| ASI08 — Cascading Failures | WD-TV-05 | Amplified blast radius from propagating worm |
| MCP §5 — Auth and Secrets | WD-TV-07, WD-P2D-05 | MCP registry access secret isolation |
| MCP §6 — Secure Deployment and Updates | WD-TV-01, WD-P2B-01, WD-P2B-06 | CI/CD token lifecycle and artifact verification |
