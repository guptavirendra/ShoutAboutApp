---
name: review-pre-gate
description: "PRE gate validation: verify prerequisites completion, validate RITM traceability, assess stakeholder readiness, output gate decision"
category: "Molina AppSec Gates"
tags: ["PRE-gate", "gate-review", "validation", "decision"]
scopes:
  - name: "project"
    description: "Project context from intake"
  - name: "controls"
    description: "PRE controls PRE-01 through PRE-06 with status"
  - name: "decision"
    description: "Gate decision: PASS / CONDITIONAL / FAIL"
---

# PRE Gate Validation & Decision

## 🎯 Purpose
Validate PRE gate prerequisites, assess control status, generate gate decision report with SSDF/218A correlation and RITM traceability.

---

## 📋 Pre-Review Checklist

Before proceeding, confirm you have:

- ☐ Intake report from `/start-intake` workflow
- ☐ Remediation tracker initialized with PRE controls (PRE-01 through PRE-06)
- ☐ RITM ticket ID and iServe link
- ☐ Status updates for all prerequisites (training, access, alignment)
- ☐ Evidence links for CLOSED items (certificates, access confirmations, etc.)

---

## 🔍 PRE Gate Control Review

Please provide status for each control:

### PRE-01: Development Team Training
**Requirement:** AppSec fundamentals training completed  
**Evidence:** Training completion certificate or LMS confirmation  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Owner:** (name)  
**Due Date:** (if not CLOSED)  
**Evidence Link:** (URL or document reference)

### PRE-02: Security Champion Expertise
**Requirement:** Security champion completed secure architecture training  
**Evidence:** Training certificate or certification ID  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Owner:** (name)  
**Due Date:** (if not CLOSED)  
**Evidence Link:** (URL or document reference)

### PRE-03: Security Tooling Access
**Requirement:** Team access to SonarQube and Wiz provisioned  
**Evidence:** Access confirmations, tool dashboard links  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Owner:** (name)  
**Due Date:** (if not CLOSED)  
**Evidence Link:** (URL or document reference)

### PRE-04: PAM Enrollment
**Requirement:** Privileged Azure access controlled via PAM  
**Evidence:** PAM enrollment confirmation, Azure RBAC audit  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Owner:** (name)  
**Due Date:** (if not CLOSED)  
**Evidence Link:** (URL or document reference)

### PRE-05: 96-Requirement Alignment
**Requirement:** Tech lead confirmed alignment with 96-requirement framework  
**Evidence:** Alignment checklist, architecture review notes  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Owner:** (name)  
**Due Date:** (if not CLOSED)  
**Evidence Link:** (URL or document reference)

### PRE-06: Security Acceptance Criteria
**Requirement:** Project charter includes security acceptance criteria  
**Evidence:** Project charter excerpt, gate decision criteria doc  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Owner:** (name)  
**Due Date:** (if not CLOSED)  
**Evidence Link:** (URL or document reference)

---

## � Supply Chain Worm Defense — PRE Gate Controls

> **Skill:** `supply-chain-package-defense` — activate for all projects using external package dependencies.
> **Fail-closed rule:** WD-PRE-01 and WD-PRE-02 are HIGH severity. Missing either results in a gate FAIL regardless of all other PRE controls passing.

### WD-PRE-01: Supply-Chain Threat Model Scope Declaration (SSDF RV.3.3)
**Requirement:** Written inventory of all ecosystems, package managers, CI/CD platforms, and deployment targets. Trust boundary map covering source and publish registries.  
**Assessment Questions:**
- Are all package ecosystems used by this project identified (npm, PyPI, Cargo, Maven, RubyGems)?
- Are all CI/CD platforms identified, including whether any publish packages to external registries?
- Are trust boundaries documented (which registries are trusted sources vs. publish targets)?
- Are any AI agents or automated dependency update bots (Dependabot, Renovate) in scope?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (ecosystem inventory doc or architecture artifact)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-PRE-02: Trust-Boundary Declaration for Package Registries (SSDF PO.5.1)
**Requirement:** Written policy declaring which package registries are approved sources; prohibited patterns documented; exception process defined.  
**Assessment Questions:**
- Is there a written list of approved registries (npmjs.com, pypi.org, private mirrors)?
- Are direct-URL installs and unlisted private registries explicitly prohibited?
- Is the exception process for unlisted registries documented (requires IT Security approval)?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (registry trust policy document)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-PRE-03: Package Worm Security Training (SSDF PO.2)
**Requirement:** Developer security training record includes supply-chain worm threats (post-install hooks, OIDC token theft, cache poisoning).  
**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (training record or LMS confirmation)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

## �📊 Expected Gate Decision Output

After validation, you'll receive:

```markdown
## PRE Gate Decision Report
- **Project:** [Project Name]
- **RITM:** [RITM ID] → [iServe Link]
- **Gate Phase:** PRE (Prerequisites)
- **Decision:** PASS / CONDITIONAL / FAIL
- **Review Date:** [Timestamp]
- **Reviewer:** [Gate Reviewer Agent]

### Control Status Summary
| Control | Requirement | Status | Owner | Due Date | Evidence |
|---------|-------------|--------|-------|----------|----------|
| PRE-01  | Training    | CLOSED | [name] | — | [link] |
| PRE-02  | Champion    | CLOSED | [name] | — | [link] |
| PRE-03  | Tooling     | CLOSED | [name] | — | [link] |
| PRE-04  | PAM         | REMEDIATE | [name] | 2026-05-22 | [link] |
| PRE-05  | 96-Req      | CLOSED | [name] | — | [link] |
| PRE-06  | CharterSec  | CLOSED | [name] | — | [link] |

### Cross-Framework Alignment
- **SSDF PO.1 (org policies):** Controls PRE-01, PRE-06 address personnel and project governance
- **SSDF PS.1 (personnel security):** Controls PRE-02, PRE-04 ensure skilled, authorized personnel
- **NIST 218A:** Training requirements (PRE-01, PRE-02) align with AI development team qualifications if applicable

### Decision Criteria
- **PASS:** All 6 controls = CLOSED, no critical blockers
- **CONDITIONAL:** 1-2 controls = REMEDIATE with approved due dates, no critical blockers
- **FAIL:** 3+ controls = OPEN/REMEDIATE, or critical blocker identified

### Next Steps
**PASS:** Advance to P2D gate (`/review-p2d-gate`)  
**CONDITIONAL:** Approved due dates in remediation tracker, schedule remediation cycle (`/run-remediation-cycle`)  
**FAIL:** Resolve blockers, escalate to security review board, defer to next cycle

### Blockers & Risks
- [List any critical issues preventing advancement]
- [Escalation requirements, if any]

### Audit Trail
- RITM linked for traceability
- Control evidence archived
- Decision documented and immutable
```

---

## 🚀 Gate Workflow Paths

**If PASS:** Proceed immediately to P2D gate  
**If CONDITIONAL:** Remediation due dates approved; schedule remediation cycle and re-validate  
**If FAIL:** Resolve critical blockers; escalate to security review board  

---

**Provide control status updates above, and I'll generate the PRE gate decision report.**
