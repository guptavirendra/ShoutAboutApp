---
name: review-p2d-gate
description: "P2D gate validation: architecture design review, OAuth design validation, data protection assessment, 96-requirement alignment, output gate decision"
category: "Molina AppSec Gates"
tags: ["P2D-gate", "design-review", "architecture", "gate-decision"]
scopes:
  - name: "architecture"
    description: "Architecture diagrams, component descriptions"
  - name: "oauth"
    description: "OAuth implementation pattern, token flow"
  - name: "dataprotection"
    description: "Data classification, encryption, PII handling"
---

# P2D Gate: Design & Architecture Review

## 🎯 Purpose
Validate P2D (Design) gate controls through architecture review, secure design verification, and compliance assessment. Output gate decision with SSDF/218A correlation.

---

## 📋 Pre-Review Checklist

Before proceeding, confirm you have:

- ☐ PRE gate PASSED (or CONDITIONAL with approved remediation)
- ☐ Architecture diagrams (C4 model or equivalent)
- ☐ Component threat model
- ☐ OAuth/OIDC implementation details
- ☐ Data classification matrix
- ☐ 96-requirement alignment assessment
- ☐ RITM ticket ID from PRE gate intake
- ☐ Remediation tracker initialized with P2D controls (P2D-01 through P2D-09)

---

## 🏗️ P2D Gate Control Review

### P2D-01: Architecture & Component Design (SSDF PS.2)
**Requirement:** Architecture diagrams document system boundaries, data flows, trust boundaries  
**Assessment Questions:**
- Are system components and their interactions clearly documented?
- Are trust boundaries identified and justified?
- Are data flows labeled with sensitivity classification?
- Does architecture address defense-in-depth principles?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (architecture documentation URL or file reference)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-02: OAuth/OIDC Design (SSDF PS.2, molina-oauth-security)
**Requirement:** OAuth/OIDC implementation validates token flow, scope design, and PKCE usage  
**Assessment Questions:**
- Is the OAuth pattern documented (Molina Pattern A/B/C)?
- Are scopes minimal and justified?
- Is PKCE implemented for public clients?
- Is token validation enforced (JWTs, signatures)?
- Is mTLS used for service-to-service auth?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (OAuth design document URL)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-03: Secrets Management (SSDF PS.3)
**Requirement:** Secrets (API keys, credentials, certificates) stored securely, rotated regularly  
**Assessment Questions:**
- Are all secrets stored in Azure Key Vault (or equivalent)?
- Is secrets rotation scheduled (90-day or less)?
- Are secrets never logged or exposed in code?
- Is access to secrets logged and audited?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (Key Vault configuration, rotation policy)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-04: Data Classification & Protection (SSDF PS.3, NIST 218A)
**Requirement:** Data classified by sensitivity; encryption applied (in transit, at rest)  
**Assessment Questions:**
- Is all data classified (PUBLIC / INTERNAL / CONFIDENTIAL / RESTRICTED)?
- Is PII identified and encrypted?
- Is in-transit encryption enforced (TLS 1.3+)?
- Is at-rest encryption enabled (AES-256)?
- Is key management documented?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (data classification matrix, encryption audit)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-05: Input Validation & Injection Prevention (SSDF PS.1.3)
**Requirement:** Input validation prevents injection attacks (SQL, XSS, command injection)  
**Assessment Questions:**
- Are all inputs validated against a whitelist?
- Is SQL parameterization enforced (no string concatenation)?
- Are outputs encoded/escaped for context?
- Is CSP (Content Security Policy) configured?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (validation implementation docs, SAST baseline)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-06: Logging & Monitoring (SSDF PS.2)
**Requirement:** Security-relevant events logged and monitored for anomalies  
**Assessment Questions:**
- Are authentication/authorization events logged?
- Are failed access attempts logged?
- Are PII/secrets excluded from logs?
- Is log retention policy defined (>90 days)?
- Are logs centralized (e.g., Azure Log Analytics)?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (logging configuration, sample logs)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-07: Error Handling & Information Disclosure (SSDF PS.2)
**Requirement:** Errors handled securely without leaking sensitive information  
**Assessment Questions:**
- Are stack traces never exposed to users?
- Are generic error messages returned to clients?
- Are detailed errors logged (not shown)?
- Is debug mode disabled in production?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (error handling code review, config audit)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-08: Dependency & Supply Chain Security (SSDF PS.1, PW.8)
**Requirement:** Third-party dependencies scanned for vulnerabilities; SBoM maintained  
**Assessment Questions:**
- Are npm/NuGet dependencies scanned (Wiz)?
- Are known vulnerabilities tracked and patched?
- Is SBoM (Software Bill of Materials) generated?
- Are transitive dependencies assessed?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (Wiz scan results, SBoM document)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### P2D-09: 96-Requirement Alignment (Molina Policy)
**Requirement:** Design validated against 96-requirement framework (governance, SSDF, OWASP)  
**Assessment Questions:**
- Are all applicable SSDF practices addressed?
- Are OWASP LLM Top 10 mitigations included (if AI-relevant)?
- Are privacy/data protection laws addressed (HIPAA/GDPR)?
- Is alignment documented in requirement matrix?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (96-requirement alignment checklist)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

## � Supply Chain Worm Defense — P2D Gate Controls

> **Skill:** `supply-chain-package-defense` — activate when project uses automated package publishing or any external dependencies.
> **Fail-closed rule:** WD-P2D-01, WD-P2D-02, and WD-P2D-05 are CRITICAL. Any OPEN status on a CRITICAL control results in a gate FAIL. WD-P2D-03, WD-P2D-04, and WD-P2D-06 are HIGH; failure on all three without approved remediation also results in FAIL.

### WD-P2D-01: OIDC Token Lifecycle Architecture (SSDF PW.6.2, molina-oauth-security P2D-08 extension)
**Requirement:** Architecture ensures OIDC tokens for package registry publishing are short-lived (≤15 min), narrowly scoped, and isolated from any job that installs or runs package dependencies.  
**Assessment Questions:**
- Is the publish job separated from the install/build job? (Never in the same GitHub Actions or Azure Pipelines job)
- Are token scopes restricted to the minimum required (e.g., `npm:publish` for a single package)?
- Is the token TTL configured to ≤15 minutes?
- Are federated credentials (OIDC Trusted Publishers) used instead of long-lived API tokens?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (CI/CD pipeline config or architecture diagram)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-P2D-02: Build-Script Sandboxing Design (SSDF PW.4.1)
**Requirement:** Architecture enforces default-deny for package post-install/build-time scripts, with explicit allowlist; network-isolated containers for all dependency installation steps; non-root execution.  
**Assessment Questions:**
- Is `ignore-scripts=true` (npm) or equivalent configured as the default?
- Is a per-package allowlist defined for packages that genuinely require build scripts?
- Are dependency install steps run in network-restricted containers?
- Are all install/build steps configured to run as non-root?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (.npmrc, pnpm config, Dockerfile, or CI architecture diagram)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-P2D-03: Build Cache Isolation and Trust Architecture (SSDF PW.6.2)
**Requirement:** Cache keys are hash-scoped and branch-isolated; fork/PR workflows cannot write to main-branch caches; cache TTL ≤7 days; integrity verification step before cache restore.  
**Assessment Questions:**
- Are cache keys scoped to include lock file hash and branch name?
- Are fork PR workflows prevented from writing to main-branch caches?
- Is cache TTL configured to ≤7 days?
- Is a hash verification step present that triggers clean rebuild on mismatch?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (CI/CD cache configuration)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-P2D-04: Artifact Signing and Provenance Design (SSDF PS.3.2)
**Requirement:** Artifact signing approach documented (Sigstore/cosign, npm provenance, PyPI attestations); SLSA Level 1 minimum; signing key management policy defined.  
**Assessment Questions:**
- Is an artifact signing approach selected and documented?
- Is the SLSA provenance level target defined (Level 1 minimum)?
- Is signing key management documented (ephemeral OIDC keys preferred; GPG keys in PAM)?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (signing design document or architecture artifact)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-P2D-05: Secret Isolation from Build-Script Execution (SSDF PW.9.1)
**Requirement:** Architecture guarantees no vault credentials, publish tokens, or service account keys are accessible from any environment that also runs package installation or build scripts.  
**Assessment Questions:**
- Is there a clear architectural boundary between vault access steps and dependency installation steps?
- Are secrets injected only after all untrusted code has finished executing?
- Is CI log redaction enabled?
- Are all CI service accounts registered in PAM with rotation schedule?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (architecture diagram showing vault isolation boundary)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

### WD-P2D-06: Cross-Ecosystem Dependency Lineage Plan (SSDF PS.3.2)
**Requirement:** SBOM scope defined covering all dependency layers (source packages → container → deployment); SBOM generation automation confirmed in CI pipeline design; format CycloneDX or SPDX.  
**Assessment Questions:**
- Is the SBOM scope defined to cover source, container, and deployment layers?
- Is SBOM generation automated (syft, cyclonedx-npm, or equivalent)?
- Is CycloneDX or SPDX JSON the output format?

**Current Status:** OPEN / REMEDIATE / CLOSED  
**Evidence Link:** (SBOM scope document or CI pipeline config)  
**Owner:** (name)  
**Due Date:** (if not CLOSED)

---

## �📊 Expected Gate Decision Output

```markdown
## P2D Gate Decision Report
- **Project:** [Project Name]
- **RITM:** [RITM ID] → [iServe Link]
- **Gate Phase:** P2D (Design & Architecture)
- **Decision:** PASS / CONDITIONAL / FAIL
- **Review Date:** [Timestamp]
- **Reviewer:** [Gate Reviewer Agent]

### Control Status Summary
| Control | Requirement | Status | Owner | Due Date | Evidence |
|---------|-------------|--------|-------|----------|----------|
| P2D-01  | Architecture | CLOSED | [name] | — | [link] |
| P2D-02  | OAuth Design | CLOSED | [name] | — | [link] |
| P2D-03  | Secrets Mgmt | REMEDIATE | [name] | 2026-05-22 | [link] |
| P2D-04  | Data Protect | CLOSED | [name] | — | [link] |
| P2D-05  | Input Valid  | CLOSED | [name] | — | [link] |
| P2D-06  | Logging      | CLOSED | [name] | — | [link] |
| P2D-07  | Error Hdlng  | CLOSED | [name] | — | [link] |
| P2D-08  | Dependencies | CLOSED | [name] | — | [link] |
| P2D-09  | 96-Req Align | CLOSED | [name] | — | [link] |

### Cross-Framework Alignment
- **SSDF PS.2:** Architecture & component security (P2D-01, P2D-06, P2D-07)
- **SSDF PS.3:** Secrets & data protection (P2D-03, P2D-04)
- **SSDF PS.1.3:** Input validation (P2D-05)
- **SSDF PW.8:** Dependency management (P2D-08)
- **NIST 218A:** Data protection & AI model security (P2D-04 if AI-relevant)
- **OWASP LLM Top 10:** Injection/prompt-related (P2D-05 if AI model)

### Decision Criteria
- **PASS:** All 9 controls = CLOSED, no critical blockers
- **CONDITIONAL:** 1-2 controls = REMEDIATE with approved due dates
- **FAIL:** 3+ controls = OPEN, or critical security gap identified

### Next Steps
**PASS:** Proceed to P2B gate (`/review-p2b-gate`)  
**CONDITIONAL:** Remediation due dates approved; schedule remediation cycle  
**FAIL:** Resolve critical gaps; design review required; defer to next cycle

### Blockers & Risks
- [List critical design flaws or gaps]
- [Risk escalation if required]

### Audit Trail
- RITM linked for traceability
- Design review evidence archived
- Decision immutable and documented
```

---

## 🚀 Gate Workflow Paths

**If PASS:** Schedule P2B gate review  
**If CONDITIONAL:** Remediation due dates approved; execute `/run-remediation-cycle`  
**If FAIL:** Halt development; escalate design review; defer to next cycle  

---

**Provide P2D control status updates, and I'll generate the gate decision report.**
