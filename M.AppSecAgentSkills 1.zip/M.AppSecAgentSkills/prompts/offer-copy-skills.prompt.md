---
name: offer-copy-skills
description: "Offer to copy selected M.AppSecAgentSkills packages into user profile with non-blocking autopilot capture, explicit copy approval, collision handling, and fail-closed validation"
category: "Workspace Setup"
tags: ["skills", "profile", "onboarding", "copy"]
scopes:
  - name: "selection"
    description: "Skill set to offer (all, minimal, selective)"
  - name: "response"
    description: "User acceptance decision"
  - name: "validation"
    description: "Source, destination, collision, and YAML validation"
---

# Offer to Copy Skills to User Profile

## Purpose
Offer relevant skills from this repository to the user profile path so skills are reusable across workspaces.

In autonomous `speckit-autopilot` runs, this offer is non-blocking: if no response is available, continue execution and log the approval-needed copy action as deferred in HOTL.

## Offer Script

I can copy selected skills from this repository into your profile path:
- Source: `<repo>/.agents/skills/`
- Destination: `c:\Users\<user>\.agents\skills\`

Please choose one response:
- `yes, all`
- `yes, minimal`
- `yes, selective: <skill names>`
- `no`

If no response is available during autonomous execution, do not block progress. Continue without copy and record the deferred approval-needed action in HOTL.

## Minimal Set (recommended for gate workflows)

- `molina-application-security`
- `nist-ssdf`
- `molina-nist-218a`

## Validation and copy behavior

When explicit acceptance is provided, the agent will:

1. Validate source path and selected skill folders.
2. Validate destination path exists or can be created safely.
3. Check collisions in destination for each selected skill.
4. Create timestamped backups for collided destination skills before overwrite at `c:\Users\<user>\.agents\skill-backups\skills-copy-<yyyyMMdd-HHmmss>\`.
5. Ask overwrite approval per collided skill.
6. Copy approved skills.
7. Validate copied `SKILL.md` files and YAML frontmatter.
8. Report copied, skipped, overwritten, failed, and backup path details.

If validation fails, the process stops and reports all failures (fail-closed).
If copy or post-copy validation fails after overwrite, report rollback instructions using the recorded backup path.

If no explicit acceptance is provided in an autonomous run, do not execute copy actions. Record the pending approval-needed action in HOTL and continue with the workflow.
