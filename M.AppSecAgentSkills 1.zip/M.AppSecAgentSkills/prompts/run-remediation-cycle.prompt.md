---
name: run-remediation-cycle
description: "Execute remediation workflow: track findings, assign ownership, manage due dates, verify evidence, update gate status"
category: "Molina AppSec Gates"
tags: ["remediation", "tracking", "evidence", "workflow"]
scopes:
  - name: "findings"
    description: "Security findings from SAST, DAST, pentest, or gate reviews"
  - name: "tracker"
    description: "Remediation tracker with ownership, due dates, status"
  - name: "evidence"
    description: "Evidence collection and verification"
---

# Remediation Cycle Workflow

## 🎯 Purpose
Manage remediation of security findings across gate phases, track ownership and due dates, collect evidence, verify closure, and update gate status with evidence audit trail.

---

## 📋 Remediation Intake

### Current Gate Status
Please provide:
- **Gate Phase:** PRE / P2D / P2B
- **RITM Ticket:** (e.g., "RITM0123456789")
- **Gate Decision:** PASS / CONDITIONAL / FAIL
- **Controls at REMEDIATE Status:** (list control IDs)
- **Controls at OPEN Status:** (list control IDs)

### Remediation Findings
For each finding at REMEDIATE or OPEN status, provide:

**Finding [1]:**
- **Control ID:** (e.g., "PRE-04", "P2D-03")
- **Description:** (e.g., "PAM enrollment not completed for 3 team members")
- **Severity:** CRITICAL / HIGH / MEDIUM / LOW
- **Root Cause:** (brief explanation)
- **Remediation Plan:** (what will be done)
- **Assigned Owner:** (name, email)
- **Original Due Date:** (YYYY-MM-DD)
- **Updated Due Date:** (if extended; YYYY-MM-DD)
- **Dependencies:** (other findings or work items blocking this)

[Repeat for each finding]

---

## 📊 Remediation Tracker Management

### Create / Update Tracker Entry

For each finding, the tracker will include:

```markdown
## Remediation Tracker — [Gate Phase] Gate
**RITM:** [RITM ID]  
**Last Updated:** [Timestamp]

| ID | Control | Finding | Severity | Owner | Status | Original Due | Updated Due | Evidence Link | Verified By | Verify Date |
|----|---------|---------|----------|-------|--------|--------------|-------------|---------------|-------------|-------------|
| 1  | PRE-04  | PAM enrollment incomplete | HIGH | Alice Chen | REMEDIATE | 2026-05-20 | 2026-05-27 | — | — | — |
| 2  | P2D-03  | Secrets stored in config | CRITICAL | Bob Smith | OPEN | 2026-05-25 | 2026-06-01 | — | — | — |
| 3  | P2B-02  | DAST finding: XXS in user input | MEDIUM | Carol Wong | REMEDIATE | 2026-05-30 | 2026-06-05 | — | — | — |

**Summary:**
- Total Findings: 3
- OPEN (blocking gate): 1 (CRITICAL)
- REMEDIATE (approved due dates): 2 (HIGH, MEDIUM)
- CLOSED (evidence verified): 0
```

---

## 🔄 Remediation Workflow Steps

### Phase 1: Assignment & Planning
1. ✅ Owner assigned (name, email confirmed)
2. ✅ Due date approved (acceptable for gate progression)
3. ✅ Remediation plan detailed and feasible
4. ✅ Dependencies identified and tracked
5. ✅ Tracker entry created with all fields populated

### Phase 2: Execution & Tracking
1. ✅ Owner begins remediation work
2. ✅ Progress updates provided weekly (at minimum)
3. ✅ Blockers escalated immediately
4. ✅ Due date at risk → escalate and negotiate extension
5. ✅ Tracker updated with progress status

### Phase 3: Evidence Collection
1. ✅ Remediation completed by due date
2. ✅ Evidence collected (certificate, log, configuration, screenshot, etc.)
3. ✅ Evidence uploaded to secure location (Azure blob, iServe attachment, etc.)
4. ✅ Evidence link added to tracker
5. ✅ Status changed to "PENDING VERIFICATION"

### Phase 4: Verification & Closure
1. ✅ Verifier (security team member) assigned
2. ✅ Evidence reviewed and validated
3. ✅ Remediation confirmed as complete
4. ✅ Status changed to "CLOSED"
5. ✅ Closure date and verifier recorded
6. ✅ Gate status re-evaluated

---

## 📝 Evidence Requirements by Finding Type

### Training Completion (PRE-01, PRE-02)
**Acceptable Evidence:**
- LMS course completion certificate
- Training attendance roster (signed)
- Certification ID (if externally certified)
- Screenshot of LMS completion badge

---

### Access Provisioning (PRE-03, PRE-04)
**Acceptable Evidence:**
- Tool dashboard confirmation (SonarQube, Wiz, Azure RBAC)
- System access log showing user provisioned
- Access confirmation email from admin
- Screenshot of access granted

---

### Architecture/Design Review (P2D-01, P2D-02, etc.)
**Acceptable Evidence:**
- Signed architecture review form
- Architecture diagrams with review annotations
- Review meeting minutes and attendance
- Remediation checklist (signed)
- C4 model, OAuth flow diagram, data flow diagram

---

### SAST/DAST Findings (P2B-01, P2B-02)
**Acceptable Evidence:**
- Scan report showing finding resolved (re-run SonarQube/ZAP)
- Code commit with fix (pull request link, commit hash)
- Risk acceptance form (if finding waived)
- Before/after scan results

---

### Penetration Testing (P2B-04)
**Acceptable Evidence:**
- Penetration test engagement completion certificate
- Pentest report showing findings and remediation status
- Risk acceptance forms for any waived findings
- Remediation evidence (code fixes, configuration changes)

---

## 🎯 Remediation Status Definitions

| Status | Definition | Gate Impact |
|--------|-----------|-------------|
| **OPEN** | Finding not yet assigned or remediation not started | BLOCKS gate |
| **REMEDIATE** | Remediation in progress with approved due date | CONDITIONAL gate (approved dates) |
| **PENDING VERIFICATION** | Remediation complete; evidence provided; awaiting verification | Provisional (pending verification) |
| **CLOSED** | Remediation verified; evidence accepted; closure documented | Counts toward PASS |
| **WAIVED** | Finding accepted as risk; documented and approved | Counts as accepted risk |

---

## 📊 Expected Remediation Cycle Output

### Weekly Progress Report
```markdown
## Remediation Progress — [Gate Phase]
**Report Date:** [Timestamp]  
**RITM:** [RITM ID]

### Finding Status Overview
| Finding | Control | Owner | Due Date | Status | % Complete | Blockers |
|---------|---------|-------|----------|--------|------------|----------|
| 1       | PRE-04  | Alice | 2026-05-27 | REMEDIATE | 60% | Awaiting PAM team response |
| 2       | P2D-03  | Bob   | 2026-06-01 | OPEN | 0% | Blocked by review cycle |
| 3       | P2B-02  | Carol | 2026-06-05 | REMEDIATE | 100% | Evidence submitted for verification |

### Blockers & Escalations
- [ ] Finding 1: PAM team SLA exceeded — escalate to VP Ops
- [ ] Finding 2: Review cycle slot not available — request expedited slot

### Next Actions
- [ ] Follow up with Alice on Finding 1 (status call scheduled 2026-05-23)
- [ ] Carol to submit evidence for Finding 3 verification (Carol: on track)
- [ ] Bob: meeting with review board to expedite Finding 2 (scheduled 2026-05-24)

### Forecast
- **On Track for Closure:** Finding 3 (due 2026-06-05)
- **At Risk:** Finding 1 (due 2026-05-27, currently 60% complete)
- **Blocked:** Finding 2 (due 2026-06-01, awaiting review)
```

### Closure Report (Evidence Verified)
```markdown
## Remediation Closure Report — [Gate Phase]
**Report Date:** [Timestamp]  
**RITM:** [RITM ID]

### All Findings Closed
| Finding | Control | Remediation | Owner | Closed Date | Verified By | Status |
|---------|---------|-------------|-------|------------|-------------|--------|
| 1       | PRE-04  | PAM enrollment | Alice | 2026-05-27 | Security Review | ✅ CLOSED |
| 2       | P2D-03  | Key Vault integration | Bob | 2026-06-02 | Security Review | ✅ CLOSED |
| 3       | P2B-02  | XSS input validation | Carol | 2026-06-05 | Security Review | ✅ CLOSED |

### Gate Re-Evaluation
- **Previous Status:** CONDITIONAL (2 findings at REMEDIATE)
- **Current Status:** All controls now CLOSED
- **Gate Decision:** **PASS** — Proceed to next phase

### Evidence Archive
- All evidence linked in RITM ticket
- Proof of closure: [link to verification sign-off]
- Audit trail: Complete (owner → verifier → closure)
```

---

## 🚀 Next Steps After Remediation Completion

1. **All Findings CLOSED:**
   - Gate re-evaluated
   - Status updated to PASS (if all controls CLOSED)
   - Proceed to next gate phase
   - Update RITM ticket with closure confirmation

2. **Findings Still OPEN or at Risk:**
   - Escalate to security review board
   - Request deadline extension (if justified)
   - Consider risk acceptance (if approved)
   - Defer to next cycle (if critical)

---

## 📋 Remediation Cycle Checklist

- ☐ All findings assigned to owner with confirmed due date
- ☐ Remediation plan documented and tracked
- ☐ Weekly progress updates collected and escalations managed
- ☐ Evidence collected and linked to tracker
- ☐ Verification assigned and completion sign-off recorded
- ☐ Gate status re-evaluated after closure
- ☐ RITM ticket updated with closure evidence
- ☐ Audit trail complete and immutable

---

**Provide remediation findings and I'll initialize the tracker, manage assignments, and guide closure.**
