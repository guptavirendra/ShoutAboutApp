---
name: start-intake
description: "Start Molina AppSec gate intake workflow: gather project context, establish RITM traceability, verify prerequisites, and initialize remediation tracker"
category: "Molina AppSec Gates"
tags: ["PRE-gate", "intake", "gate-workflow", "stakeholder-validation"]
scopes:
  - name: "project"
    description: "Project metadata (name, team, tech stack, deployment target)"
  - name: "ritm"
    description: "RITM ticket reference for audit traceability"
  - name: "prerequisites"
    description: "Training completion and access provisioning status"
---

# Molina AppSec Gate Intake Workflow

## 🎯 Purpose
Start the PRE gate intake phase: gather project context, establish RITM traceability, confirm prerequisites, and initialize the remediation tracker for gate progression.

---

## 📋 Intake Form

Please provide the following information to proceed:

### Project Context
- **Project Name:** (e.g., "MRX Customer Portal Modernization")
- **Business Unit:** (e.g., "Healthcare Solutions")
- **Tech Stack:** (e.g., "Node.js/React, Azure App Service, Azure SQL")
- **Deployment Target:** (e.g., "Azure Production - East US 2")
- **Project Manager:** (name, email)
- **Development Team Lead:** (name, email)
- **Security Champion:** (name, email)

### RITM Traceability (Mandatory)
- **RITM Ticket ID:** (e.g., "RITM0123456789")
- **RITM URL:** (link to ticket in iServe)
- **Gate Phase:** PRE (Prerequisites)

### Stakeholder Training & Access (PRE-01 through PRE-06)
- ☐ Development team completed AppSec fundamentals training (PRE-01)
- ☐ Security champion completed secure architecture training (PRE-02)
- ☐ Team has access to SonarQube (SAST) (PRE-03)
- ☐ Team has access to Wiz (supply chain scan) (PRE-03)
- ☐ Team has PAM enrollment for privileged Azure access (PRE-04)
- ☐ Tech lead confirmed 96-requirement alignment (PRE-05)
- ☐ Project charter includes security acceptance criteria (PRE-06)

### Skill Setup (Optional)
- ☐ Offer copy of profile skills before intake using `/offer-copy-skills`
- ☐ If accepted, copy selected skills to `c:\Users\<user>\.agents\skills\`
- ☐ Validate copied `SKILL.md` YAML and report copy summary

---

## 📊 Intake Processing

Once you provide the above information, the Planner agent will:

1. ✅ **Validate RITM traceability** - Confirm RITM ticket exists and is linked to this gate
2. ✅ **Verify prerequisites** - Check training completion and access provisioning
3. ✅ **Create remediation tracker** - Initialize tracker with:
   - RITM ID (source of truth)
   - PRE gate controls (PRE-01 through PRE-06)
   - Status (OPEN → awaiting evidence)
   - Owner, due date, verifier fields
   - Evidence storage location
4. ✅ **Generate PRE gate checklist** - Output required for progression:
   - Pre-gate control status table
   - SSDF practice correlation (PO.1, PS.1, PO.5.1)
   - 218A task alignment
   - Blockers/risks
   - Next steps

---

## 📤 Expected Output

After validation, you'll receive:

### PRE Gate Intake Checklist
```markdown
## PRE Gate Intake Report
- **Project:** [Project Name]
- **RITM:** [RITM ID] → [iServe Link]
- **Status:** PASS / CONDITIONAL / FAIL
- **Date:** [Timestamp]
- **Reviewer:** [Agent: Planner]

### Control Status
| Control | Requirement | Status | Owner | Due Date | Evidence |
|---------|-------------|--------|-------|----------|----------|
| PRE-01  | Training    | [OPEN/REMEDIATE/CLOSED] | [name] | [date] | [link] |
| PRE-02  | ChampionExp | [OPEN/REMEDIATE/CLOSED] | [name] | [date] | [link] |
| ... (6 controls) |

### Cross-Framework Alignment
- SSDF PO.1: Org policies aligned (PRE-01, PRE-06)
- SSDF PS.1: Personnel security (PRE-02, PRE-04)
- NIST 218A: ... (AI training requirements if applicable)

### Blockers & Next Steps
- [ ] All prerequisites CLOSED before advancing to P2D
- [ ] RITM ticket remains open through all gate phases
- [ ] Remediation tracker shared with security reviewers
```

---

## 🚀 Next Steps After Intake

- **CONDITIONAL:** Approved due dates for open remediation items
- **PASS:** Proceed to P2D gate validation (`/review-p2d-gate`)
- **FAIL:** Resolve blockers, re-run intake, escalate to security review board

---

**Ready to start? Please provide the intake form details above, or reply with your project information.**
