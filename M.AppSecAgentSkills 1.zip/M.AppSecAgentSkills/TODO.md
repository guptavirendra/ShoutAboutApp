# TODO - M.AppSecAgentSkills

## Scope
- This file is an internal maintainer backlog for this template repository.
- Do not use this file as a downstream implementation checklist for consuming projects.
- For each epic, include a short Consumer impact note and keep downstream runbook steps out of this file.

## Priority Maintainer Workstream

### Molina AppSec Code Review Skill
Consumer impact: Consumers gain a focused defensive secure code review with the AppSec banner and a single `CODE_REVIEW.md`, without a fixed submodule layout or mandatory whole-program gate execution.
- [x] Phase 1: Adapt source workflow from `M.AppSecSpeckit/.github/skills/m-appsec-codereview/SKILL.md` into [SKILL.md](.agents/skills/molina-appsec-code-review/SKILL.md), preserving checklist, report intent, and escalation rules - COMPLETE 2026-10-15.
- [x] Phase 2: Extract [report template](.agents/skills/molina-appsec-code-review/assets/code-review-template.md) with the original AppSec banner and finding structure; clarify conditional specialist routing, source read-only/report-write exception, safe handling of existing reports, and evidence limitations - COMPLETE 2026-10-15.
- [x] Phase 3: Define five [regression scenarios](.agents/skills/molina-appsec-code-review/evals/evals.json) for findings/report shape, scope defaults, conditional routing/report collisions, sensitive data/prompt injection, and Molina-only fail-closed escalation - COMPLETE 2026-10-15.
- Structural verification (2026-10-15): existing package validator 19 PASS / 0 errors; two informational warnings for intentionally absent optional `references/` and `scripts/` directories. Actual YAML parsing, JSON scenarios, local links, report section/field contract, original banner comparison (ignoring trailing whitespace), and whitespace checks pass. React specialist routing is catalog-only because that package is not present on this branch.
- [ ] Phase 4: Run fresh-context with-skill/without-skill behavioral benchmark and activation/rejection tests; record results. Structural validation is not behavioral benchmark evidence.
- [x] Authoring workflow iteration 1 - COMPLETE 2026-10-15: ten isolated tabletop responses across all five scenarios, [per-assertion grading](.agents/skills/molina-appsec-code-review/evals/grading.json), and [benchmark limitations](.agents/skills/molina-appsec-code-review/evals/benchmark.json) recorded. With-skill: 23 observed assertions pass, six integration assertions NOT RUN. Two baseline responses claimed skill use and were excluded; the full Phase 4 benchmark remains incomplete.
- [x] Description refinement and semantic routing check - COMPLETE 2026-10-15: explicitly excludes authoring/validating/locating skills; [five positive and four negative prompts](.agents/skills/molina-appsec-code-review/evals/activation.json) classified correctly. This is not runtime editor activation evidence. Actual file-write/collision/specialist tests and uncontaminated baseline runs remain open in Phase 4.
- [x] React/Next.js child port - COMPLETE 2026-10-15: ported from branch `react-nextjs-best-practices`, commit `7b570af2545f26e87c26f3e7918ca12b04dbeedd`, into [the bundled child](.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/SKILL.md). Parent v1.1 explicitly routes to child v3.0 without relying on nested discovery. Preserved framework references, checklist, validator, and all 15 source regression scenarios; added a parent-template inheritance scenario.
- Report-contract migration: intentionally supersedes source-branch conditional framework filenames with one `CODE_REVIEW.md` and the parent-owned AppSec banner/template. Framework context, responsibility split, owner layer, validation evidence, and residual risk remain required. Source commit metadata preserves traceability; the older parent tabletop results are explicitly versioned as pre-port evidence, not port validation.
- Port verification (2026-10-15): parent validator 19 PASS / 0 errors (two optional-directory warnings); child validator 194 PASS / 0 warnings / 0 errors. Actual YAML parsing, all package JSON/local links, preserved source controls/scenarios, and five fail-closed broken-package probes pass. [Port verification record](.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/evals/port-validation.json) distinguishes structural evidence from remaining behavioral gaps.
- [ ] Framework-port behavioral benchmark - run the 16 child scenarios in clean contexts and verify runtime discovery/report writes in a consuming project. Source-branch and parent-v1.0 historical results do not establish this benchmark.
- [x] Source-history/status preservation - COMPLETE 2026-10-15: restored per-finding OPEN / REMEDIATE / CLOSED lifecycle status with evidence-backed transitions; [migration history](.agents/skills/molina-appsec-code-review/code-reviews/react-nextjs-best-practices/references/migration-history.md) retains all completed original phases, validation counts, source-branch follow-up gaps, and the five original commit IDs. The annotated tag `archive/react-nextjs-best-practices` retains the actual source history independently of the relocated port; root catalog documentation points to the bundled child. Parent v1.2 / child v3.1 retain the shared-template contract.
- Preservation verification (2026-10-15): parent validator 19 PASS / 0 errors; child validator 198 PASS / 0 warnings / 0 errors. Actual YAML/JSON, local links, original security controls, all 15 original scenario inputs, completed milestone evidence, and seven fail-closed mutation probes pass. Full port behavioral benchmark remains open above.
- [x] Explicit review selection - COMPLETE 2026-10-15: parent v2.0 defaults to CWE-699 only. Named reviews replace the default; combinations/all bundled types require an explicit request. Code technology and incidental OAuth/AI mentions no longer auto-load specialists. Both children preserve selected-only semantics when invoked directly; master Scope records types/reason and exclusions. Mandatory policies remain blocking/escalating constraints, not permission for extra passes.
- Selection evidence (2026-10-15): [12 routing cases](.agents/skills/molina-appsec-code-review/evals/review-selection.json) classified correctly in a fresh-context, description-independent tabletop check; [results and limitations](.agents/skills/molina-appsec-code-review/evals/review-selection-results.json) recorded. Covers default React/AI/OAuth context, named-only, explicit all/combination, exclusions, conflicts, unavailable types, direct child calls, and mandatory policy escalation. This is not runtime activation or an end-to-end review benchmark.
- Selection validation (2026-10-15): parent author validator 19 PASS / 0 errors; CWE validator 83 PASS / 0 errors; React validator 200 PASS / 0 warnings / 0 errors. Actual YAML/JSON, package links, size limits, and three mutation probes rejecting lost-default/lost-named-only/automatic-specialist expansion pass. Historical benchmark records remain explicitly pre-selection evidence.
- [x] AppSec best practices profile - COMPLETE 2026-10-15: [new opt-in child](.agents/skills/molina-appsec-code-review/code-reviews/appsec-best-practices/SKILL.md) restores the original 12-area cross-framework checklist, SSDF/Molina/secure-by-design baseline, conditional OAuth/AI/agentic/MCP/218A routing and Molina-only mode. Recovered source from M.AppSecSpeckit commit `e41bcd93258a394b6aeccc8f90afa5915eef2ac5` because the original skill was absent from its working tree. One parent-owned report; gate alignment is distinct from explicitly requested formal assessment.
- Selection extension: parent v2.1 retains CWE-only default and named-only behavior; explicit all now selects three bundled profiles. Unqualified "both" needs clarification. Supporting-skill routing is authorized only inside the selected AppSec profile; original two-profile tabletop results remain historical. Sixteen parent routing cases and five AppSec profile scenarios are defined.
- AppSec port validation (2026-10-15): parent author validator 19 PASS / 0 errors; new child author validator 22 PASS / 0 errors (one optional-directory warning); profile validator 79 PASS / 0 errors; CWE/React validators remain 83/200 PASS with zero errors. Actual YAML/JSON, all package local links, six rejected broken-package probes and nine fresh-context tabletop routing cases pass. [Routing results and limits](.agents/skills/molina-appsec-code-review/code-reviews/appsec-best-practices/evals/routing-results.json) distinguish intended actions from unexecuted live integrations.
- [ ] AppSec profile behavioral benchmark - run all new scenarios with/without skill in fresh contexts, and verify live integrations, report-write safety and runtime editor activation separately. Structural checks are not that benchmark.
- [x] Router-only parent and default pair - COMPLETE 2026-10-15: parent v3.0 routes only to bundled children and composes one output; shared scope/safety/evidence/severity/report rules moved to [references/review-contract.md](.agents/skills/molina-appsec-code-review/references/review-contract.md), loaded by all children. Default now combines CWE-699 + AppSec best practices, deduplicating findings while retaining both supplements. Named single profiles run alone; explicit all selects three. Earlier CWE-only/opt-in AppSec milestones above are historical, superseded by this behavior.
- Routing fixtures now define 19 cases, including explicit single CWE, default-pair wording, and unnamed-single clarification. OAuth/SSDF/AI/gate focus routes through AppSec, not direct parent specialist execution. Historical tabletop results are not evidence for v3.0.
- Router v3 verification (2026-10-15): 19/19 fresh-context tabletop selections matched, and duplicated synthetic CWE/AppSec evidence composed as one intended finding/report. Parent author validator 24 PASS / 0 warnings/errors; router 80 PASS; CWE 85 PASS; React 202 PASS; AppSec 81 PASS, all with zero errors. YAML/JSON, local links and eight rejection probes pass, including missing shared contract/default child, silent default reduction, direct specialist routes, parent technical passes, and duplicate templates. [Results/limitations](.agents/skills/molina-appsec-code-review/evals/default-pair-results.json) do not claim live execution, rendered artifacts or a full benchmark.

### CWE-699 Code Review Skill
Consumer impact: Consumers gain a complete, CWE-699-backed code review skill covering all 33 routing-table categories with specific child CWEs, detection patterns, severity classifications, and a structured weakness report template — usable for any language or framework.
- [x] Phase 1: Core SKILL.md — all 6 frontmatter fields, category routing table (33 categories), severity classification, output contract, reference load triggers — COMPLETE 2026-06-05 `.agents/skills/cwe-699-code-review/SKILL.md`
- [x] Phase 2: Initial category-detail.md — 15 high-priority categories (auth, authz, crypto, memory, sessions, validation, numeric, resource, concurrency, random numbers) — COMPLETE 2026-06-05 `.agents/skills/cwe-699-code-review/references/category-detail.md`
- [x] Phase 3: Complete category-detail.md — remaining 18 categories (string errors, pointer issues, signal errors, data neutralization, information management, permissions, UI security, state issues, resource locking, communication channels, data integrity, lockout, file handling, handler errors, behavioral problems, expression issues, documentation, encapsulation) — COMPLETE 2026-06-05; all 33 categories covered
- [x] Phase 4: Assets and evals — review-report-template.md, evals/evals.json (3 test cases: Flask SQL injection, C buffer overflow, weak token generation) — COMPLETE 2026-06-05; validation 20 PASS / 0 errors
- [ ] Phase 5: Run eval iteration 1 — compare with-skill vs. without-skill on all 3 evals.json test cases; record grading.json and benchmark.json
- [x] Bundled-child migration - COMPLETE 2026-10-15: moved to [molina-appsec-code-review/cwe-699-code-review](.agents/skills/molina-appsec-code-review/code-reviews/cwe-699-code-review/SKILL.md), preserving the category reference and all 33 routing rows. The paths above record completed pre-migration history at source commit `ec7dfb673a4ee258974c6c570ab75f83ed7ac059`; current assets use the parent master template and a CWE field-mapping supplement instead of a standalone report.
- [x] Output preservation - specific CWEs, source version, reviewed/excluded categories, finding matrix/index, category results, scoped no-findings, severity/blocker totals, remediation priorities, and notes remain within the parent's six sections. Parent lifecycle Status, confidence, redaction, approval, and deduplication rules apply. [Migration record](.agents/skills/molina-appsec-code-review/code-reviews/cwe-699-code-review/evals/migration.json) documents intentional changes and source recovery.
- [x] Regression migration - original three prompts preserved; evidence/severity assertions aligned with the parent rather than forcing CRITICAL or inventing absent surrounding controls. Added inheritance/deduplication/coverage and safe-control scenarios, for five definitions.
- Migration validation (2026-10-15): parent author validator 19 PASS / 0 errors; CWE author validator 23 PASS / 0 warnings / 0 errors; CWE-specific validator 79 PASS / 0 errors; existing React child validator 198 PASS / 0 warnings / 0 errors. Actual YAML/JSON, local links, byte-identical category reference, all 33 routing rows, all three original prompts, sole-template ownership, and seven rejected mutation probes verified. Results are recorded in the migration record; this is not a behavioral benchmark.
- [ ] Post-migration behavioral benchmark - run all five scenarios in fresh with/without-skill contexts, confirm host activation and actual report-write/collision behavior. Historical Phase 5 remains open; structural validation is not behavioral proof.

### Agent Skills Author Skill
Consumer impact: Consumers gain a complete, spec-compliant authoring guide that applies all required and optional agentskills.io features — including progressive disclosure, description optimization, eval-driven iteration, and bundled validation scripts — enabling faster, higher-quality skill creation across all Molina AppSec and SSDF skill packages.
- [x] Phase 1: Core SKILL.md — all 6 frontmatter fields, Gotchas, execution flow, output contract, reference load triggers, plan-validate-execute pattern — COMPLETE 2026-06-05 `.agents/skills/agentskills-author/SKILL.md`
- [x] Phase 2: Reference files — frontmatter-guide.md, progressive-disclosure.md, description-optimization.md, eval-driven-iteration.md — COMPLETE 2026-06-05 `.agents/skills/agentskills-author/references/`
- [x] Phase 3: Assets — annotated SKILL-template.md (all fields, all directory types), skill-checklist.md (pre-publish validation with Molina import checks) — COMPLETE 2026-06-05 `.agents/skills/agentskills-author/assets/`
- [x] Phase 4: Scripts and evals — validate-skill.ps1 (27/27 self-validation passes), evals/evals.json (4 test cases covering creation, optimization, edge cases) — COMPLETE 2026-06-05 `.agents/skills/agentskills-author/scripts/` and `evals/`
- [ ] Phase 5: Run eval iteration 1 — compare with-skill vs. without-skill on all 4 evals.json test cases; record grading.json and benchmark.json
- [ ] Phase 6: Optimize description — run 5+ activation test prompts; verify no false positives on unrelated prompts

### Supply Chain Package Defense Skill Suite
Consumer impact: Consumers gain a complete, fail-closed defense against package-manager worms (malicious build scripts, OIDC token theft, cache poisoning, cross-ecosystem propagation) integrated into PRE/P2D/P2B gate workflows across npm, PyPI, RubyGems, Cargo, and Maven.
- [x] Phase 1: Orchestrator SKILL.md with full threat-vector routing map, gate control tables (WD-PRE/P2D/P2B), conflict-resolution rules, and standard output contract — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/SKILL.md`
- [x] Phase 2: Control Baseline reference with canonical control IDs, threat vector taxonomy, ecosystem overlay matrix, evidence schema, and acceptance criteria — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/references/Control-Baseline.md`
- [x] Phase 2: README with suite scope, non-goals, integration mapping to all 13 skills, activation triggers, and ecosystem coverage table — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/README.md`
- [x] Phase 3: CI Token Hardening component skill (WD-P2D-01, WD-P2D-05, WD-P2B-01, WD-P2B-07) — OIDC architecture, token isolation, secret vault, ecosystem-specific configs — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/references/CI-Token-Hardening.md`
- [x] Phase 3: Dependency Execution Controls component skill (WD-P2D-02, WD-P2D-04, WD-P2B-02, WD-P2B-05, WD-P2B-06, WD-P2B-08) — sandbox design, dual-detector SCA, hash pinning, artifact signing — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/references/Dependency-Execution-Controls.md`
- [x] Phase 3: Cache Integrity Controls component skill (WD-P2D-03, WD-P2B-03) — cache isolation, content-address verification, clean-rebuild fallback, self-hosted cache controls — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/references/Cache-Integrity-Controls.md`
- [x] Phase 3: Propagation Containment component skill (WD-PRE-01, WD-PRE-02, WD-P2D-06, WD-P2B-04, WD-P2B-09, WD-P2B-10) — cross-ecosystem lineage, SBOM generation, staged rollout, kill-switch — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/references/Propagation-Containment.md`
- [x] Phase 4: Worm Incident Response Runbook — 5-step response (containment → triage → eradication → recovery → review), severity classification, evidence collection, escalation path — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/assets/Worm-Incident-Response-Runbook.md`
- [x] Phase 4: Remediation Tracker template — per-finding register, progress summary table, closure criteria, maintenance schedule — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/assets/Remediation-Tracker.md`
- [x] Phase 4: Approval Form Template — risk acceptance for deferred remediation with CRITICAL/HIGH controls, expiration enforcement, audit trail — COMPLETE 2026-05-19 `.agents/skills/supply-chain-package-defense/assets/Approval-Form-Template.md`
- [ ] Phase 5: Integrate WD-P2B-04/WD-P2B-05 control rows into `molina-application-security/Molina-AppSec-Program-Checklist.md` (extends P2B-04 existing row)
- [ ] Phase 5: Add cross-reference from `nist-ssdf/SKILL.md` PW.4.4 routing to new skill
- [ ] Phase 5: Add PRE gate prompt extension for supply-chain scope declaration (update `prompts/review-pre-gate.prompt.md`)
- [ ] Phase 5: Add P2D gate prompt extension for OIDC/cache architecture controls (update `prompts/review-p2d-gate.prompt.md`)
- [ ] Phase 5: Add P2B gate prompt extension for worm scan and artifact signing gates (update `prompts/review-p2b-gate.prompt.md`)
- [ ] Phase 6: Evals directory — create worm-detection regression spec and sample gate decision dry-run against representative RITM case

### Keep Skills Canonical in `.agents/skills/`
Consumer impact: Consumers receive a stable, single-source skill layout that is easier to import and validate.
- [ ] Rename canonical skill package `oauth-security` to `molina-oauth-security` and verify all in-repo references/import guidance follow the new package name.
- [ ] Maintain canonical mapping for migrated content and update package metadata as format guidance evolves.
- [ ] Validate path/link integrity across skill packages after structural or naming changes.
- [ ] Keep `.gitignore-template` aligned with local-skill and evidence artifact handling needs.

### Maintain Migration Traceability
Consumer impact: Consumers can trust that migrated guidance still maps to original framework intent.
- [ ] Preserve and update migration rationale in repository documentation when skill boundaries change.
- [ ] Track any collision decisions between SSDF and 218A guidance and record the resolved owner package.
- [ ] Record material migration changes in release notes or change summaries for transparency.

---

## Framework Enhancements (Maintainer-Owned)

### SSDF Automation Coverage
Consumer impact: Consumers can apply SSDF checks more consistently with less manual interpretation.
- [ ] Add maintainer-authored automation guidance for PW SAST/DAST checkpoints.
- [ ] Add maintainable evidence templates for PS artifact collection.
- [ ] Expand RV workflow examples for vulnerability response lifecycle coverage.
- [ ] Add PO-aligned training-tracking guidance suitable for diverse org models.

### NIST 218A AI Security Coverage
Consumer impact: Consumers get clearer AI security control mapping for model lifecycle decisions.
- [ ] Expand model security assessment guidance in `nist-218a` skill references.
- [ ] Add training-data validation patterns and expected evidence examples.
- [ ] Refine application design threat modeling and remediation language in AI sections.
- [ ] Add model deployment security gate guidance with role/accountability clarity.

### Molina AppSec Program Alignment
Consumer impact: Consumers can map local controls to Molina phase-gate expectations faster.
- [ ] Add iServe workflow integration guidance where source-approved content exists.
- [ ] Add SonarQube compliance validation patterns and evidence expectations.
- [ ] Replace remaining container-scanning-centric wording with software supply chain security language.
- [ ] Expand PAM service-account validation guidance where required by source policy.
- [ ] Add vulnerability guidance mapping once approved source material is available in-repo.

### Template Platform Improvements
Consumer impact: Consumers get easier onboarding and lower setup friction across toolchains.
- [ ] Add reusable CI validation workflow templates for compliance checks.
- [ ] Add cross-framework reporting patterns for gap analysis output consistency.
- [ ] Improve evidence artifact organization guidance for long-running projects.
- [ ] Keep import and composition guidance current for submodule and skills-only adoption paths.

### Anti-Mythos Agentic Security Blueprint
Consumer impact: Consumers get a production-grade, harness-first AppSec workflow blueprint for agentic systems across GitHub and Azure DevOps.
- [x] Phase 1: Harness-first specifications (DAG, eval harness, tool contracts, observability, platform adapters) — COMPLETE commit 439310d
- [x] Phase 2: OWASP agentic mapping references and control crosswalk assets for Molina/SSDF/218A alignment — COMPLETE commit f9dd0f8
- [x] Phase 2: Evidence-pack templates for agentic approvals, exceptions, and traceability packaging — COMPLETE commit f9dd0f8
- [x] Phase 3: Formal non-leakage assurance baseline for runtime boundaries (governance checks, proof contract, formal proof profile, evidence-template updates, and supply-chain dependency crosswalk) — COMPLETE 2026-06-17 `.agents/skills/molina-mythNOs-agentic-security/SKILL.md`, `.agents/skills/molina-mythNOs-agentic-security/references/Proof-of-Non-Leakage-Evidence-Contract.md`, `.agents/skills/molina-mythNOs-agentic-security/references/Formal-Isolation-Proof-Profile.md`, `.agents/skills/supply-chain-package-defense/SKILL.md`
- [ ] Phase 3: Platform adoption matrix guidance for GitHub-only, Azure DevOps-only, and dual-platform operating modes — IN PROGRESS feature/anti-mythos-phase3
- [ ] Phase 3: Change-management guidance for harness updates and regression baselines — IN PROGRESS feature/anti-mythos-phase3

---

## Repository Maintenance

### Documentation Quality
Consumer impact: Consumers can interpret guidance quickly without conflicting instructions.
- [ ] Refresh checklist language when framework updates require wording or structure changes.
- [ ] Keep usage documentation aligned with current skill package names and paths.
- [ ] Add integration notes for newly adopted security tooling patterns.

### Quality Assurance
Consumer impact: Consumers encounter fewer integration defects during template adoption.
- [ ] Run periodic template-import dry runs across representative project profiles.
- [ ] Validate cross-framework correlation outputs for consistency and reproducibility.
- [ ] Review ignore-template coverage for newly introduced artifact classes.
- [ ] Verify skill package behavior across supported coding assistants.

### Community and Governance
Consumer impact: Consumers benefit from clearer support paths and faster issue resolution.
- [ ] Capture structured feedback themes from template adopters.
- [ ] Publish contribution rules for framework and skill-package updates.
- [ ] Maintain exemplar implementation patterns for common adoption scenarios.

---

## Completed Items
- [x] Added `anti-mythos-agentic-security` skill package scaffold with Phase 1 harness-first references: AppSec review DAG, evaluation harness spec, strict tool contract patterns, observability/evidence contract, and GitHub/Azure DevOps platform adapter specifications.
- [x] Expanded `molina-application-security` skill with generic RITM-based review/remediation tracker guidance, normalized `OPEN/REMEDIATE/CLOSED` status handling, findings/severity evidence expectations, and an AppSec Request for Approval form template.
- [x] Repository renamed from `SSDF 218A Molina AppSec AI Instructions` to `M.AppSecAgentSkills`; retained framework terminology and migration traceability in top-level maintainer docs.
- [x] Baseline migration to `.agents/skills/` completed and legacy skill folders retired.
- [x] SSDF/218A overlap decisions documented and reflected in canonical skill packages.
- [x] Core skill package expansions completed for cross-framework orchestration and Molina enterprise guidance.
- [x] Consolidated active skills to `molina-application-security`, `nist-ssdf`, and `nist-218a`; retired orchestration/customization/migration duplicate skill folders after guidance migration.
- [x] Retained migration traceability in git history instead of local migration-history artifacts.
- [x] Documented repository role boundaries: canonical local repo, upstream reference repo, and legacy archive repo to prevent duplicate maintenance.
- [x] Removed language-specific scripts (bash, Python, Azure Pipeline YAML) to maintain governance content neutrality across consuming projects — commit 2637b82.
- [x] Added explicit Direct Skill Import guidance to README.md: prerequisites, import modes, human workflow, coding-agent preconditions with mandatory pause/confirm/validation steps, and external Agent Skills lifecycle reference (https://agentskills.io/client-implementation/adding-skills-support).
- [x] Extended AGENTS.md Preconditions for importing skills with enforceable coding-agent automation rules: pause-before-action, Azure CLI session verification, trust/collision/fail-closed handling, and explicit stop conditions.
- [x] Added OWASP GenAI Security LangGraph reference implementation: `.agents/skills/owasp-genai-security/examples/IMPLEMENTATION_GUIDE.md` with complete 12-node secure orchestration pipeline, all node implementations with inline OWASP control mappings (ASI02, ASI03, ASI08, ASI10; MCP §2, §3, §5, §7), Pydantic schemas, tool registry, service stubs, pytest test matrix, and production deployment checklist. Aligned to LangChain/LangGraph idioms (MessagesState, StateGraph, @tool, .invoke()) and SSDF/218A practices (PW.4, PW.5, PW.7, RV.3, PO.5, PS.1). Ready for copy-paste integration and Molina gate validation (PRE/P2D/P2B) — commit fa9e2c4.
- [x] Implemented speckit-autopilot plan gating and routing audit schema updates: hard-gate Step 0 in `.agents/skills/speckit-autopilot/SKILL.md`, deterministic enforcement and grandfathering precedence, registration metadata contract, and HOTL routing validation fields/template alignment in `.agents/skills/speckit-autopilot/references/hotl-output-contract.md` and `.agents/skills/speckit-autopilot/assets/hotl-summary-template.md` — COMPLETE 2026-06-17.
- [x] Polished speckit-autopilot gating precision to reduce false positives by requiring planning-intent as primary intent, and added explicit grandfathered/non-grandfathered/non-trigger examples in `.agents/skills/speckit-autopilot/SKILL.md` — COMPLETE 2026-06-17.
- [x] Added timestamped backup-and-rollback guardrails for profile skill copy workflows across `AGENTS.md`, `README.md`, and `prompts/offer-copy-skills.prompt.md` to require pre-overwrite backup under `c:\Users\<user>\.agents\skill-backups\skills-copy-<yyyyMMdd-HHmmss>\` and fail-closed rollback instructions — COMPLETE 2026-06-17.
- [x] Updated speckit-autopilot to keep approval-needed profile copy offers non-blocking while continuing spec/plan/tasks/analyze/implement phases, and to capture skipped/deferred approvals in final HOTL across `.agents/skills/speckit-autopilot/SKILL.md`, `.agents/skills/speckit-autopilot/references/hotl-output-contract.md`, `.agents/skills/speckit-autopilot/assets/hotl-summary-template.md`, `prompts/offer-copy-skills.prompt.md`, and `AGENTS.md` — COMPLETE 2026-06-17.
- [x] Enforced speckit-autopilot hard universal routing policy: every actionable task request must execute through speckit-autopilot with no grandfathering or legacy/direct path; updated routing rules and HOTL schema/template fields (`task_request_detected`, `legacy_path_blocked`, `enforcement_outcome=GATED|ROUTED|ERROR`) across `.agents/skills/speckit-autopilot/SKILL.md`, `.agents/skills/speckit-autopilot/references/hotl-output-contract.md`, `.agents/skills/speckit-autopilot/assets/hotl-summary-template.md`, and `.agents/skills/speckit-autopilot/evals/evals.json` — COMPLETE 2026-06-19.

---

**Last Updated**: June 19, 2026  
**Template Version**: 1.0.0  
**Contact**: [applicationsecurity@molinahealthcare.com](mailto:applicationsecurity@molinahealthcare.com)