# AGENTS.md

## Project overview
- This repository is a secure development instruction template aligned to NIST SP 800-218 (SSDF), NIST SP 800-218A, and Molina AppSec program expectations (AKA M.AppSecAgentSkills).
- The primary purpose is to maintain reusable guidance, checklists, and skill packages under `.agents/skills/`.
- Treat this repo as governance and instruction content, not a buildable application.

## Repository layout
- `.agents/skills/`: Canonical location for skill packages and framework guidance.
- `README.md`: Human-oriented project summary and usage notes.
- `TODO.md`: Workstream tracker, enhancement backlog, and migration progress evidence.
- `.gitignore-template`: Ignore pattern template intended for downstream projects.

## Working rules for coding agents
- Before making changes, scan `README.md` and `TODO.md` for current migration state and terminology requirements.
- Preserve framework intent and avoid weakening compliance language.
- Prefer additive edits that keep historical traceability.
- Do not remove evidence of completed migration phases unless explicitly requested.
- Use clear, auditable commit-ready diffs with minimal unrelated formatting churn.

## Preconditions for importing skills

Before copying `.agents/skills/` contents into any downstream project, all of the following conditions must be met:

### For human operators and manual import workflows:

1. **Azure CLI login (mandatory):** Run `az login` with your developer account and confirm the correct account is active by executing `az account show`. Do not proceed without this confirmation.
2. **Trust boundary:** Review the source of any skills before import, especially project-level skills that travel with the repository.
3. **Workspace readiness:** Confirm that the downstream project's `.agents/skills/` directory exists or can be created.

### For coding agents and automated import workflows:

1. **Pause before action:** If an agent is automating the copy or scaffold step, it must pause and announce the import scope to the operator before proceeding. Do not assume approval.
2. **Confirm Azure CLI session:** Verify that `az login` and `az account show` have been successfully executed in the operator's current terminal session. If not confirmed, stop and require the operator to complete these commands directly. Do not use cached or assumed credentials.
3. **Validate source repository:** Confirm the source repository path exists and contains `.agents/skills/` with expected skill directories (each with `SKILL.md`).
4. **Validate target directory:** Confirm the downstream project's `.agents/skills/` directory exists or can be safely created.
5. **Handle name collisions deterministically:** If a skill with the same `name` already exists in the target `.agents/skills/`:
   - Apply the collision rule: **project-level skills override imported skills** (principle: downstream project controls its local skill precedence).
   - Log a warning that a skill is being shadowed.
   - Do not overwrite without explicit operator approval.
6. **Post-import validation (fail-closed):** After import, verify that each skill folder contains `SKILL.md` and that YAML frontmatter parses correctly. If validation fails, report all errors and do not proceed. Fail-closed behavior is required — do not silently skip invalid skills.

These preconditions apply to all skills in this repository, regardless of which frameworks they target. An agent must not assume a prerequisite is satisfied; it must verify or stop.

## Preconditions for Offering Copy to User Profile

When offering to copy skills from this repository to the user's profile path (`c:\Users\<user>\.agents\skills\`), all of the following conditions must be met:

1. **Announce scope first:** State which skills are being offered, source path, and destination path before copying.
2. **Require explicit acceptance:** Do not copy on implied consent. Wait for an explicit yes/no/selective response.
3. **Validate source path:** Confirm `.agents/skills/` exists and each offered skill contains `SKILL.md`.
4. **Validate destination path:** Confirm `c:\Users\<user>\.agents\skills\` exists or can be created safely.
5. **Create timestamped backup before overwrite:** For every collided destination skill selected for overwrite, create a timestamped backup under `c:\Users\<user>\.agents\skill-backups\skills-copy-<yyyyMMdd-HHmmss>\` before writing.
6. **Handle collisions deterministically:** If a skill already exists in the profile destination:
  - Warn that the existing profile skill will be shadowed or overwritten.
  - Do not overwrite without explicit approval.
7. **Post-copy validation (fail-closed):** Verify copied skills still contain `SKILL.md` with valid YAML frontmatter. If validation fails, report and stop.
8. **No Azure CLI prerequisite for profile copy:** `az login` and `az account show` are mandatory for downstream project imports, but not for local profile copies.
9. **Report copy outcome:** Summarize copied, skipped, overwritten, failed, and backup path items for audit traceability.
10. **Rollback guidance on failure:** If overwrite or post-copy validation fails, report rollback instructions that restore from the recorded timestamped backup path.

### Speckit-Autopilot Non-Blocking Exception (scoped)

When profile-copy offering is initiated inside the `speckit-autopilot` autonomous workflow:

1. Do not pause phase execution waiting for offer responses.
2. Do not execute any copy or overwrite action without explicit approval.
3. Record the approval-needed copy action as deferred in HOTL (`Approval-Required Actions`) with reason, fallback, and residual impact.
4. Continue the workflow through spec, plan, tasks, analyze, and implementation phases.

This exception is scoped to `speckit-autopilot` orchestration only. Standard explicit-approval and fail-closed rules remain mandatory for direct or manual copy workflows.

### Offer and response contract (required)

When presenting the offer, agents must include:

1. **Skill list and scope:** list offered skills and whether the set is full, minimal, or task-specific.
2. **Source and destination paths:** show the repository source path and profile destination path.
3. **Allowed user responses:** `yes, all`, `yes, minimal`, `yes, selective: <skill names>`, or `no`.
4. **Collision branch behavior:** if a collision is found, request explicit overwrite approval per skill before writing.
5. **Backup path disclosure:** show where timestamped backups will be written before any overwrite.
6. **Fail-closed note:** if validation fails for any copied skill, stop and report all failures and provide rollback instructions.

## Content conventions
- Use consistent framework naming:
  - `NIST SP 800-218` or `SSDF`
  - `NIST SP 800-218A` or `218A`
  - `Molina AppSec Program`
  - `OWASP Top 10 for LLM Applications 2025` (entries: `LLM01:2025`–`LLM10:2025`)
  - `OWASP Top 10 for Agentic Applications 2026` or `ASI Top 10` (entries: `ASI01`–`ASI10`)
  - `OWASP Practical Guide for Secure MCP Server Development v1.0` or `OWASP MCP Guide`
- Keep checklist and gate language explicit (for example PRE, P2D, P2B where applicable).
- When adding references to paths, prefer repository-relative paths and keep them accurate.
- Default to Markdown with concise headings and actionable bullet points.

## Validation checklist for changes
- Verify links and file paths referenced in edited docs actually exist.
- Ensure updates remain internally consistent across `README.md`, `TODO.md`, and affected skill docs.
- If a task updates migration state, reflect it in `TODO.md` with clear status/evidence.
- For substantial instruction changes, include a short rationale in the change description.

## Security and compliance guardrails
- Never include secrets, credentials, tokens, or internal-only sensitive data in docs.
- Keep AppSec focus on secure SDLC and software supply chain controls.
- Preserve mappings and traceability language needed for audits and stakeholder review.

## Nested AGENTS.md guidance
- Add nested `AGENTS.md` files only when a subdirectory needs stricter or different rules.
- The nearest `AGENTS.md` to edited files takes precedence.
- Keep nested files narrowly scoped and avoid duplicating root guidance unless necessary.

## Pull request and change expectations
- Keep each change focused on a single intent (for example migration, terminology update, or new template content).
- Update related documentation in the same change when behavior or process guidance is altered.
- Call out any assumptions when source artifacts are missing or when guidance is intentionally deferred.

## Downstream Onboarding: VS Code Customization Workflow

When importing Molina AppSec skills into a consuming project, establish the VS Code customization stack in this sequence:

### Customization Activation Steps
1. **Always-on instructions**: Create `.github/copilot-instructions.md` with mandatory Molina rules (RITM traceability, status normalization, fail-closed behavior, gate decision semantics).
2. **File-based instructions**: Add `.instructions.md` files for architecture, scan outputs, remediation trackers, and approval forms.
3. **Import skills**: Copy `molina-application-security` and dependencies to `.agents/skills/` with post-import validation.
4. **Prompt files**: Create `/prompts/start-intake.prompt.md`, `/prompts/review-pre-gate.prompt.md`, `/prompts/review-p2d-gate.prompt.md`, `/prompts/review-p2b-gate.prompt.md`, and `/prompts/run-remediation-cycle.prompt.md`.
5. **Custom agents**: Create `.agents/planner.agent.md`, `.agents/gate-reviewer.agent.md`, `.agents/remediation-coordinator.agent.md`, `.agents/evidence-auditor.agent.md`.
6. **MCP servers**: Wire read-only integrations to iServe, SonarQube, Wiz, and repository storage.
7. **Lifecycle hooks**: Add schema validation and fail-closed guardrails via hooks configuration.
8. **Verify activation**: Run sample gate workflow and confirm RITM tracking, control status output, and evidence collection.

### Acceptance Criteria
- Every Molina gate (PRE, P2D, P2B) has a corresponding prompt file or agent workflow.
- Gate outputs include RITM link, control status table, blockers, and cross-framework mapping.
- Every remediation finding carries owner, due date, and verifier fields.
- Fail-closed guardrails are active (missing evidence triggers gate FAIL).
- Audit trail is complete (reviewer, verification date, evidence link).